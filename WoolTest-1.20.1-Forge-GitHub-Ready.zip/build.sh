#!/usr/bin/env bash
set -euo pipefail
cd -- "$(dirname -- "${BASH_SOURCE[0]}")"
if [[ -n "${JAVA_HOME:-}" ]]; then export PATH="$JAVA_HOME/bin:$PATH"; fi
command -v javac >/dev/null || { echo 'Install a 64-bit JDK 17 first.' >&2; exit 1; }
VERSION="$(java -version 2>&1)"
if ! grep -Eq 'version "17[.\"]' <<< "$VERSION"; then
  echo "Use JDK 17 (set JAVA_HOME). Detected: $VERSION" >&2
  exit 1
fi
bash tools/bootstrap.sh
if [[ $# -eq 0 ]]; then set -- clean build; fi
./gradlew --no-daemon --console=plain "$@" 2>&1 | tee build-log.txt
