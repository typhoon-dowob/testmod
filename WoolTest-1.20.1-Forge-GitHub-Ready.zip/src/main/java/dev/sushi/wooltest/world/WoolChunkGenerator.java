package dev.sushi.wooltest.world;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import dev.sushi.wooltest.logic.TestRules;
import dev.sushi.wooltest.city.CityBlueprint;
import dev.sushi.wooltest.city.CityLayoutData;
import net.minecraft.core.BlockPos;
import net.minecraft.core.RegistryAccess;
import net.minecraft.server.level.WorldGenRegion;
import net.minecraft.world.level.LevelHeightAccessor;
import net.minecraft.world.level.NoiseColumn;
import net.minecraft.world.level.StructureManager;
import net.minecraft.world.level.WorldGenLevel;
import net.minecraft.world.level.biome.BiomeManager;
import net.minecraft.world.level.biome.BiomeSource;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.chunk.ChunkAccess;
import net.minecraft.world.level.chunk.ChunkGenerator;
import net.minecraft.world.level.chunk.ChunkGeneratorStructureState;
import net.minecraft.world.level.levelgen.GenerationStep;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.level.levelgen.RandomState;
import net.minecraft.world.level.levelgen.blending.Blender;
import net.minecraft.world.level.levelgen.structure.templatesystem.StructureTemplateManager;
import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.Executor;

/** Flat wool terrain, a single coordinate-locked city, and trial grounds outside it.
 * New chunks only: no automatic writes occur when an existing chunk loads. */
public final class WoolChunkGenerator extends ChunkGenerator {
    public static final Codec<WoolChunkGenerator> CODEC = RecordCodecBuilder.create(instance ->
            instance.group(BiomeSource.CODEC.fieldOf("biome_source")
                    .forGetter(WoolChunkGenerator::getBiomeSource))
                    .apply(instance, WoolChunkGenerator::new));

    private static final BlockState[] WOOL = {
            Blocks.WHITE_WOOL.defaultBlockState(), Blocks.ORANGE_WOOL.defaultBlockState(),
            Blocks.MAGENTA_WOOL.defaultBlockState(), Blocks.LIGHT_BLUE_WOOL.defaultBlockState(),
            Blocks.YELLOW_WOOL.defaultBlockState(), Blocks.LIME_WOOL.defaultBlockState(),
            Blocks.PINK_WOOL.defaultBlockState(), Blocks.GRAY_WOOL.defaultBlockState(),
            Blocks.LIGHT_GRAY_WOOL.defaultBlockState(), Blocks.CYAN_WOOL.defaultBlockState(),
            Blocks.PURPLE_WOOL.defaultBlockState(), Blocks.BLUE_WOOL.defaultBlockState(),
            Blocks.BROWN_WOOL.defaultBlockState(), Blocks.GREEN_WOOL.defaultBlockState(),
            Blocks.RED_WOOL.defaultBlockState(), Blocks.BLACK_WOOL.defaultBlockState()
    };

    public WoolChunkGenerator(BiomeSource source) { super(source); }
    @Override protected Codec<? extends ChunkGenerator> codec() { return CODEC; }
    @Override public int getMinY() { return TestRules.MIN_Y; }
    @Override public int getGenDepth() { return TestRules.HEIGHT; }
    @Override public int getSeaLevel() { return 0; }
    @Override public int getSpawnHeight(LevelHeightAccessor level) {
        return TestRules.GROUND_TOP_EXCLUSIVE;
    }

    public static BlockState terrainState(int x, int y, int z) {
        if (CityLayoutData.contains(x, z) && y >= CityLayoutData.MIN_Y && y < 128)
            return CityBlueprint.stateAt(x, y, z);
        return TestRules.isTerrainY(y)
                ? WOOL[TestRules.colourIndex(x, y, z)] : Blocks.AIR.defaultBlockState();
    }

    @Override
    public CompletableFuture<ChunkAccess> fillFromNoise(Executor executor, Blender blender,
            RandomState random, StructureManager structures, ChunkAccess chunk) {
        Heightmap ocean = chunk.getOrCreateHeightmapUnprimed(Heightmap.Types.OCEAN_FLOOR_WG);
        Heightmap surface = chunk.getOrCreateHeightmapUnprimed(Heightmap.Types.WORLD_SURFACE_WG);
        BlockPos.MutableBlockPos cursor = new BlockPos.MutableBlockPos();
        int firstY = Math.max(getMinY(), chunk.getMinBuildHeight());
        boolean cityChunk = CityLayoutData.intersectsChunk(chunk.getPos().x, chunk.getPos().z);
        int endY = Math.min(cityChunk ? 128 : TestRules.GROUND_TOP_EXCLUSIVE, chunk.getMaxBuildHeight());
        for (int x = 0; x < 16; x++) {
            for (int z = 0; z < 16; z++) {
                int worldX = chunk.getPos().getMinBlockX() + x;
                int worldZ = chunk.getPos().getMinBlockZ() + z;
                for (int y = firstY; y < endY; y++) {
                    BlockState state = terrainState(worldX, y, worldZ);
                    if (state.isAir()) continue;
                    chunk.setBlockState(cursor.set(worldX, y, worldZ), state, false);
                    ocean.update(x, y, z, state);
                    surface.update(x, y, z, state);
                }
            }
        }
        return CompletableFuture.completedFuture(chunk);
    }

    @Override public int getBaseHeight(int x, int z, Heightmap.Types type,
            LevelHeightAccessor height, RandomState random) {
        for (int y = Math.min(127, height.getMaxBuildHeight() - 1); y >= height.getMinBuildHeight(); y--) {
            if (type.isOpaque().test(terrainState(x, y, z))) return y + 1;
        }
        return height.getMinBuildHeight();
    }

    @Override public NoiseColumn getBaseColumn(int x, int z,
            LevelHeightAccessor height, RandomState random) {
        int minY = height.getMinBuildHeight();
        BlockState[] states = new BlockState[height.getHeight()];
        for (int i = 0; i < states.length; i++) states[i] = terrainState(x, minY + i, z);
        return new NoiseColumn(minY, states);
    }

    @Override public void applyCarvers(WorldGenRegion region, long seed, RandomState random,
            BiomeManager biomes, StructureManager structures, ChunkAccess chunk,
            GenerationStep.Carving step) { }
    @Override public void buildSurface(WorldGenRegion region, StructureManager structures,
            RandomState random, ChunkAccess chunk) { }
    @Override public void spawnOriginalMobs(WorldGenRegion region) { }
    @Override public void applyBiomeDecoration(WorldGenLevel level, ChunkAccess chunk,
            StructureManager structures) {
        // Native placement clips each template to the generating chunk. Do NOT
        // build structures on ChunkEvent.Load: that would modify old terrain.
        // wool_fields has no features, so this adds only configured structures.
        if (!CityLayoutData.intersectsChunk(chunk.getPos().x, chunk.getPos().z))
            super.applyBiomeDecoration(level, chunk, structures);
    }
    @Override public void createStructures(RegistryAccess registries,
            ChunkGeneratorStructureState state, StructureManager structures,
            ChunkAccess chunk, StructureTemplateManager templates) {
        // Native structure starts/references enable /locate and saved chunk data.
        // The trial-ground biome tag contains only wooltest:wool_fields.
        if (!CityLayoutData.reservesStructureChunk(chunk.getPos().x, chunk.getPos().z))
            super.createStructures(registries, state, structures, chunk, templates);
    }
    @Override public void addDebugScreenInfo(List<String> lines,
            RandomState random, BlockPos pos) {
        lines.add("Wool Test | terrain 0..63 | build 0..127 | 16 colours | capital at (0,0), 251x251 | trial grounds outside");
    }
}
