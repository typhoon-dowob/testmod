package dev.sushi.wooltest.world;

import dev.sushi.wooltest.WoolTestMod;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.registries.Registries;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.Tag;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.util.Mth;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.event.entity.player.PlayerEvent;
import javax.annotation.Nullable;

public final class DimensionTravel {
    private DimensionTravel() { }
    public static final ResourceKey<Level> WOOL_WORLD = ResourceKey.create(Registries.DIMENSION,
            new ResourceLocation(WoolTestMod.MOD_ID, "wool_world"));
    private static final String RETURN_KEY = "wooltest_return_position";

    public static int enter(ServerPlayer player) {
        if (player.level().dimension().equals(WOOL_WORLD)) {
            tell(player, "message.wooltest.already_inside");
            return 0;
        }
        ServerLevel destination = player.server.getLevel(WOOL_WORLD);
        if (destination == null) {
            tell(player, "message.wooltest.dimension_missing");
            return 0;
        }
        Vec3 landing = findSafe(destination, player, 0.5D, 64.0D, 0.5D);
        if (landing == null) { tell(player, "message.wooltest.no_safe_spot"); return 0; }
        CompoundTag saved = new CompoundTag();
        saved.putString("Dimension", player.level().dimension().location().toString());
        saved.putDouble("X", player.getX());
        saved.putDouble("Y", player.getY());
        saved.putDouble("Z", player.getZ());
        saved.putFloat("Yaw", player.getYRot());
        saved.putFloat("Pitch", player.getXRot());
        player.getPersistentData().put(RETURN_KEY, saved);
        teleport(player, destination, landing, player.getYRot(), player.getXRot());
        tell(player, "message.wooltest.entered");
        return 1;
    }

    public static int leave(ServerPlayer player) {
        if (!player.level().dimension().equals(WOOL_WORLD)) {
            tell(player, "message.wooltest.not_inside"); return 0;
        }
        CompoundTag saved = player.getPersistentData().getCompound(RETURN_KEY);
        ServerLevel destination = null;
        ResourceLocation id = ResourceLocation.tryParse(saved.getString("Dimension"));
        if (id != null) destination = player.server.getLevel(ResourceKey.create(Registries.DIMENSION, id));
        if (destination == null || destination.dimension().equals(WOOL_WORLD)) {
            destination = player.server.overworld();
            BlockPos spawn = destination.getSharedSpawnPos();
            saved = new CompoundTag();
            saved.putDouble("X", spawn.getX() + 0.5D);
            saved.putDouble("Y", spawn.getY());
            saved.putDouble("Z", spawn.getZ() + 0.5D);
        }
        Vec3 landing = findSafe(destination, player, saved.getDouble("X"),
                saved.getDouble("Y"), saved.getDouble("Z"));
        if (landing == null) { tell(player, "message.wooltest.no_safe_spot"); return 0; }
        teleport(player, destination, landing, saved.getFloat("Yaw"), saved.getFloat("Pitch"));
        player.getPersistentData().remove(RETURN_KEY);
        tell(player, "message.wooltest.returned");
        return 1;
    }

    @Nullable public static Vec3 findSafe(ServerLevel level, ServerPlayer player,
            double x, double y, double z) {
        if (Double.isFinite(x) && Double.isFinite(y) && Double.isFinite(z)
                && safe(level, player, x, y, z)) return new Vec3(x, y, z);
        int bx = Mth.floor(x), bz = Mth.floor(z);
        for (int radius = 0; radius <= 16; radius++) {
            for (int dx = -radius; dx <= radius; dx++) {
                for (int dz = -radius; dz <= radius; dz++) {
                    if (Math.max(Math.abs(dx), Math.abs(dz)) != radius) continue;
                    int tx = bx + dx, tz = bz + dz;
                    int ty = level.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, tx, tz);
                    if (safe(level, player, tx + 0.5D, ty, tz + 0.5D)) {
                        return new Vec3(tx + 0.5D, ty, tz + 0.5D);
                    }
                }
            }
        }
        return null;
    }

    private static boolean safe(ServerLevel level, ServerPlayer player, double x, double y, double z) {
        BlockPos feet = BlockPos.containing(x, y, z);
        if (y < level.getMinBuildHeight() + 1 || y + player.getBbHeight() >= level.getMaxBuildHeight()
                || !level.getWorldBorder().isWithinBounds(feet)) return false;
        // Force the arrival chunk to exist before checking blocks/collision.
        level.getChunk(feet.getX() >> 4, feet.getZ() >> 4);
        if (!level.getBlockState(feet).isAir() || !level.getBlockState(feet.above()).isAir()
                || !level.getBlockState(feet.below()).isFaceSturdy(level, feet.below(), Direction.UP)) {
            return false;
        }
        AABB box = player.getBoundingBox().move(x - player.getX(), y - player.getY(), z - player.getZ());
        return level.noCollision(player, box);
    }

    private static void teleport(ServerPlayer player, ServerLevel level, Vec3 pos, float yaw, float pitch) {
        player.stopRiding();
        player.teleportTo(level, pos.x, pos.y, pos.z, yaw, pitch);
        player.setDeltaMovement(Vec3.ZERO);
        player.fallDistance = 0.0F;
        player.hurtMarked = true;
    }
    private static void tell(ServerPlayer player, String key) {
        player.sendSystemMessage(Component.translatable(key));
    }
    public static void onPlayerClone(PlayerEvent.Clone event) {
        CompoundTag oldData = event.getOriginal().getPersistentData();
        if (oldData.contains(RETURN_KEY, Tag.TAG_COMPOUND)) {
            event.getEntity().getPersistentData().put(RETURN_KEY, oldData.getCompound(RETURN_KEY).copy());
        }
    }
}
