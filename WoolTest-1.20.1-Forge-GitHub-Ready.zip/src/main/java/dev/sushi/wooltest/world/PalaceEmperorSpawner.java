package dev.sushi.wooltest.world;

import dev.sushi.wooltest.ModContent;
import dev.sushi.wooltest.city.CityBlueprint;
import dev.sushi.wooltest.city.CityBuildData;
import dev.sushi.wooltest.entity.EmperorEntity;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.Difficulty;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.phys.AABB;
import net.minecraftforge.event.TickEvent;

public final class PalaceEmperorSpawner {
    private PalaceEmperorSpawner() { }
    // Main hall carpet, grounded on the City 4 floor Y=67. No city blocks are changed.
    public static final double X = 0.5D, Y = 68.0625D, Z = -80.5D;
    public static void onServerTick(TickEvent.ServerTickEvent event) {
        if (event.phase != TickEvent.Phase.END || event.getServer().getTickCount() % 20 != 0) return;
        ServerLevel level = event.getServer().getLevel(DimensionTravel.WOOL_WORLD);
        if (level == null || level.getDifficulty() == Difficulty.PEACEFUL) return;
        PalaceEmperorData data = PalaceEmperorData.get(level);
        if (data.spawned || data.defeated || CityBuildData.get(level).running) return;
        if (level.players().stream().noneMatch(p -> p.distanceToSqr(X, Y, Z) <= 48.0D * 48.0D)) return;
        // Read only loaded chunks. No recursive world generation from a load callback.
        for (int x = -2; x <= 2; x++) for (int z = -83; z <= -78; z++) {
            BlockPos floor = new BlockPos(x, 67, z);
            if (!level.hasChunkAt(floor)) return;
            if (level.getBlockState(floor) != CityBlueprint.stateAt(x, 67, z)) return;
        }
        AABB space = new AABB(X-1, Y, Z-1, X+1, Y+3, Z+1);
        // Recovery if entity was saved but its matching SavedData write was interrupted.
        for (EmperorEntity existing : level.getEntitiesOfClass(EmperorEntity.class, space.inflate(32))) {
            if (existing.isPalaceBorn()) { data.register(existing.getUUID()); return; }
        }
        if (!level.getEntities((Entity)null, space).isEmpty()) return;
        EmperorEntity emperor = ModContent.EMPEROR.get().create(level);
        if (emperor == null) return;
        emperor.moveTo(X, Y, Z, 0.0F, 0.0F);
        if (!level.noCollision(emperor)) return;
        emperor.markPalaceBorn();
        if (level.addFreshEntity(emperor)) data.register(emperor.getUUID());
    }
}
