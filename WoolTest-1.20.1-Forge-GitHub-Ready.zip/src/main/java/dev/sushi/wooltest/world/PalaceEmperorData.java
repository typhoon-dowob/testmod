package dev.sushi.wooltest.world;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.saveddata.SavedData;
import javax.annotation.Nullable;
import java.util.UUID;
/** One natural palace boss per save, independently of city rebuilding. */
public final class PalaceEmperorData extends SavedData {
    public boolean spawned, defeated;
    @Nullable public UUID emperor;
    public static PalaceEmperorData get(ServerLevel level) {
        return level.getDataStorage().computeIfAbsent(PalaceEmperorData::load,
                PalaceEmperorData::new, "wooltest_palace_emperor_v1");
    }
    public static PalaceEmperorData load(CompoundTag tag) {
        PalaceEmperorData data = new PalaceEmperorData();
        data.spawned = tag.getBoolean("Spawned"); data.defeated = tag.getBoolean("Defeated");
        if (tag.hasUUID("Emperor")) data.emperor = tag.getUUID("Emperor");
        return data;
    }
    @Override public CompoundTag save(CompoundTag tag) {
        tag.putBoolean("Spawned", spawned); tag.putBoolean("Defeated", defeated);
        if (emperor != null) tag.putUUID("Emperor", emperor);
        return tag;
    }
    public void register(UUID uuid) { spawned = true; emperor = uuid; setDirty(); }
    public void defeat(UUID uuid) {
        if (uuid.equals(emperor)) { defeated = true; setDirty(); }
    }
}
