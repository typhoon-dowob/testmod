package dev.sushi.wooltest.item;

import dev.sushi.wooltest.logic.PeachWoodSwordRules;
import net.minecraft.world.item.Tier;
import net.minecraft.world.item.crafting.Ingredient;

/** Dedicated material definition, not a renamed or retextured vanilla wooden sword. */
public enum PeachWoodTier implements Tier {
    INSTANCE;

    @Override public int getUses() { return PeachWoodSwordRules.DURABILITY; }
    @Override public float getSpeed() { return 2.0F; }
    @Override public float getAttackDamageBonus() { return 0.0F; }
    @Override public int getLevel() { return 0; }
    @Override public int getEnchantmentValue() { return 15; }
    @Override public Ingredient getRepairIngredient() { return Ingredient.EMPTY; }
}
