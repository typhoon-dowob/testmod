package dev.sushi.wooltest.item;

import com.google.common.collect.ImmutableMultimap;
import com.google.common.collect.Multimap;
import dev.sushi.wooltest.logic.ImperialArmorRules;
import net.minecraft.ChatFormatting;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.Tag;
import net.minecraft.network.chat.Component;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.ai.attributes.Attribute;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ArmorItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;
import javax.annotation.Nullable;
import java.nio.charset.StandardCharsets;
import java.util.List;
import java.util.UUID;

/** Four independent armor items; rolls are made once and survive normal stack/NBT copies. */
public final class ImperialArmorItem extends ArmorItem {
    public static final String ARMOR_TAG = "WoolTestImperialArmor100";
    public static final String TOUGHNESS_TAG = "WoolTestImperialToughness100";
    private final UUID armorId;
    private final UUID toughnessId;

    public ImperialArmorItem(Type type) {
        super(ImperialArmorMaterial.INSTANCE, type, new Properties().fireResistant().setNoRepair());
        armorId = UUID.nameUUIDFromBytes(("wooltest:imperial:armor:" + type.name()).getBytes(StandardCharsets.UTF_8));
        toughnessId = UUID.nameUUIDFromBytes(("wooltest:imperial:toughness:" + type.name()).getBytes(StandardCharsets.UTF_8));
    }
    public int armorHundredths(ItemStack stack) {
        CompoundTag tag = stack.getTag();
        return tag != null && tag.contains(ARMOR_TAG, Tag.TAG_INT)
                ? ImperialArmorRules.clampArmor(tag.getInt(ARMOR_TAG)) : 200;
    }
    public int toughnessHundredths(ItemStack stack) {
        CompoundTag tag = stack.getTag();
        return tag != null && tag.contains(TOUGHNESS_TAG, Tag.TAG_INT)
                ? ImperialArmorRules.clampToughness(tag.getInt(TOUGHNESS_TAG)) : 150;
    }
    public boolean isRolled(ItemStack stack) {
        CompoundTag tag = stack.getTag();
        return tag != null && tag.contains(ARMOR_TAG, Tag.TAG_INT) && tag.contains(TOUGHNESS_TAG, Tag.TAG_INT);
    }
    public void initializeIfNeeded(ItemStack stack, RandomSource random) {
        CompoundTag tag = stack.getOrCreateTag();
        // Independently preserve either field if an older/command-created stack contains only one.
        if (!tag.contains(ARMOR_TAG, Tag.TAG_INT)) tag.putInt(ARMOR_TAG, ImperialArmorRules.rollArmor(random::nextInt));
        if (!tag.contains(TOUGHNESS_TAG, Tag.TAG_INT)) tag.putInt(TOUGHNESS_TAG, ImperialArmorRules.rollToughness(random::nextInt));
    }
    public ItemStack createRolledStack(RandomSource random) {
        ItemStack stack = new ItemStack(this);
        initializeIfNeeded(stack, random);
        return stack;
    }
    @Override public void inventoryTick(ItemStack stack, Level level, Entity entity, int slot, boolean selected) {
        super.inventoryTick(stack, level, entity, slot, selected);
        if (!level.isClientSide && !isRolled(stack)) initializeIfNeeded(stack, level.getRandom());
    }
    @Override public void onCraftedBy(ItemStack stack, Level level, Player player) {
        super.onCraftedBy(stack, level, player);
        if (!level.isClientSide && !isRolled(stack)) initializeIfNeeded(stack, level.getRandom());
    }
    @Override public boolean onEntityItemUpdate(ItemStack stack, ItemEntity entity) {
        if (!entity.level().isClientSide && !isRolled(stack)) {
            ItemStack copy = stack.copy();
            initializeIfNeeded(copy, entity.level().getRandom());
            entity.setItem(copy);
        }
        return false;
    }
    @Override public Multimap<Attribute, AttributeModifier> getAttributeModifiers(EquipmentSlot slot, ItemStack stack) {
        if (slot != getType().getSlot()) return ImmutableMultimap.of();
        return ImmutableMultimap.<Attribute, AttributeModifier>builder()
                .put(Attributes.ARMOR, new AttributeModifier(armorId, "Imperial armor", armorHundredths(stack) / 100.0D, AttributeModifier.Operation.ADDITION))
                .put(Attributes.ARMOR_TOUGHNESS, new AttributeModifier(toughnessId, "Imperial toughness", toughnessHundredths(stack) / 100.0D, AttributeModifier.Operation.ADDITION))
                .build();
    }
    @Override public String getArmorTexture(ItemStack stack, Entity entity, EquipmentSlot slot, @Nullable String type) {
        return "wooltest:textures/models/armor/imperial_layer_" + (slot == EquipmentSlot.LEGS ? "2" : "1") + ".png";
    }
    @Override public void appendHoverText(ItemStack stack, @Nullable Level level, List<Component> lines, TooltipFlag flag) {
        super.appendHoverText(stack, level, lines, flag);
        lines.add(Component.translatable("tooltip.wooltest.imperial_armor.armor", ImperialArmorRules.format(armorHundredths(stack))).withStyle(ChatFormatting.GOLD));
        lines.add(Component.translatable("tooltip.wooltest.imperial_armor.toughness", ImperialArmorRules.format(toughnessHundredths(stack))).withStyle(ChatFormatting.AQUA));
    }
}
