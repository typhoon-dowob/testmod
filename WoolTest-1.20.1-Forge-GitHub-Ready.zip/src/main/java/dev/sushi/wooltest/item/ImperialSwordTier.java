package dev.sushi.wooltest.item;
import net.minecraft.world.item.Tier;
import net.minecraft.world.item.crafting.Ingredient;
public enum ImperialSwordTier implements Tier {
    INSTANCE;
    public int getUses() { return 1024; }
    public float getSpeed() { return 6.0F; }
    public float getAttackDamageBonus() { return 0.0F; }
    public int getLevel() { return 2; }
    public int getEnchantmentValue() { return 15; }
    public Ingredient getRepairIngredient() { return Ingredient.EMPTY; }
}
