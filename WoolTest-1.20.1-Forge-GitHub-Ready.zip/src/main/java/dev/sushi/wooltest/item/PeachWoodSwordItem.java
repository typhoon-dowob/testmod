package dev.sushi.wooltest.item;

import com.google.common.collect.ImmutableMultimap;
import com.google.common.collect.Multimap;
import dev.sushi.wooltest.logic.PeachWoodSwordRules;
import net.minecraft.ChatFormatting;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.Tag;
import net.minecraft.network.chat.Component;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.ai.attributes.Attribute;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.SwordItem;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;
import javax.annotation.Nullable;
import java.util.List;

/** One NBT roll per stack; tooltip and combat both read the same saved integer. */
public final class PeachWoodSwordItem extends SwordItem {
    public static final String DAMAGE_TAG = "WoolTestPeachDamageHundredths";

    public PeachWoodSwordItem() {
        // Superclass fallback is a 6.00-total sword. The stack-aware Forge method
        // below supplies the actual roll. No two-sword crafting repair/reroll recipe.
        super(PeachWoodTier.INSTANCE, 5, -2.4F, new Properties().setNoRepair());
    }

    public boolean hasRolledDamage(ItemStack stack) {
        CompoundTag tag = stack.getTag();
        return tag != null && tag.contains(DAMAGE_TAG, Tag.TAG_INT);
    }

    public int getDamageHundredths(ItemStack stack) {
        CompoundTag tag = stack.getTag();
        return hasRolledDamage(stack)
                ? PeachWoodSwordRules.clampDamageHundredths(tag.getInt(DAMAGE_TAG))
                : PeachWoodSwordRules.DEFAULT_DAMAGE_HUNDREDTHS;
    }

    /** Call only on the logical server. Reading stats never writes or consumes RNG. */
    public void initializeIfNeeded(ItemStack stack, RandomSource random) {
        if (!hasRolledDamage(stack)) {
            stack.getOrCreateTag().putInt(DAMAGE_TAG,
                    PeachWoodSwordRules.rollDamageHundredths(random::nextInt));
        }
    }

    /** Death drops and the test command are initialized before becoming item entities. */
    public ItemStack createRolledStack(RandomSource random) {
        ItemStack stack = new ItemStack(this);
        initializeIfNeeded(stack, random);
        return stack;
    }

    @Override public void inventoryTick(ItemStack stack, Level level, Entity entity,
            int slot, boolean selected) {
        super.inventoryTick(stack, level, entity, slot, selected);
        // Covers /give and creative inventory. Existing dropped swords are untouched.
        if (!level.isClientSide) initializeIfNeeded(stack, level.getRandom());
    }

    @Override public void onCraftedBy(ItemStack stack, Level level, Player player) {
        super.onCraftedBy(stack, level, player);
        if (!level.isClientSide) initializeIfNeeded(stack, level.getRandom());
    }

    @Override public boolean onEntityItemUpdate(ItemStack stack, ItemEntity entity) {
        // Also covers command-created item entities. Copy + setItem marks synced data
        // dirty instead of silently mutating the item entity's existing stack.
        if (!entity.level().isClientSide && !hasRolledDamage(stack)) {
            ItemStack rolled = stack.copy();
            initializeIfNeeded(rolled, entity.level().getRandom());
            entity.setItem(rolled);
        }
        return false;
    }

    @Override public Multimap<Attribute, AttributeModifier> getAttributeModifiers(
            EquipmentSlot slot, ItemStack stack) {
        if (slot != EquipmentSlot.MAINHAND) return ImmutableMultimap.of();
        return attributesFor(getDamageHundredths(stack));
    }

    private static Multimap<Attribute, AttributeModifier> attributesFor(int hundredths) {
        return ImmutableMultimap.<Attribute, AttributeModifier>builder()
                .put(Attributes.ATTACK_DAMAGE, new AttributeModifier(BASE_ATTACK_DAMAGE_UUID,
                        "Weapon modifier", PeachWoodSwordRules.attackDamageModifier(hundredths),
                        AttributeModifier.Operation.ADDITION))
                .put(Attributes.ATTACK_SPEED, new AttributeModifier(BASE_ATTACK_SPEED_UUID,
                        "Weapon modifier", PeachWoodSwordRules.attackSpeedModifier(),
                        AttributeModifier.Operation.ADDITION))
                .build();
    }

    @Override public void appendHoverText(ItemStack stack, @Nullable Level level,
            List<Component> tooltip, TooltipFlag flag) {
        super.appendHoverText(stack, level, tooltip, flag);
        tooltip.add(Component.translatable("tooltip.wooltest.peach_wood_sword.flavor")
                .withStyle(ChatFormatting.GRAY));
        if (hasRolledDamage(stack)) {
            tooltip.add(Component.translatable("tooltip.wooltest.peach_wood_sword.damage",
                    PeachWoodSwordRules.formatDamage(getDamageHundredths(stack)))
                    .withStyle(ChatFormatting.GOLD));
        } else {
            tooltip.add(Component.translatable("tooltip.wooltest.peach_wood_sword.unrolled_damage")
                    .withStyle(ChatFormatting.GOLD));
        }
        tooltip.add(Component.translatable("tooltip.wooltest.peach_wood_sword.speed", "1.60")
                .withStyle(ChatFormatting.AQUA));
        // Intentionally no flag.isAdvanced() or Shift check: normal hover is enough.
    }
}
