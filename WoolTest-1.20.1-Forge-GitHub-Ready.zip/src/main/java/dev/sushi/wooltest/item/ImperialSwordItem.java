package dev.sushi.wooltest.item;

import dev.sushi.wooltest.entity.ImperialCastEntity;
import dev.sushi.wooltest.logic.EmperorRules;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.SwordItem;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.item.UseAnim;
import net.minecraft.world.level.Level;
import javax.annotation.Nullable;
import java.util.List;

/** 1 player base + 9 weapon = 10 total; right-click shares the emperor's spell. */
public final class ImperialSwordItem extends SwordItem {
    public ImperialSwordItem() {
        super(ImperialSwordTier.INSTANCE, 9, -2.4F,
                new Properties().fireResistant().setNoRepair());
    }
    @Override public InteractionResultHolder<ItemStack> use(Level level, Player player,
            InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (hand != InteractionHand.MAIN_HAND || player.getCooldowns().isOnCooldown(this))
            return InteractionResultHolder.fail(stack);
        player.startUsingItem(hand);
        if (!level.isClientSide && !ImperialCastEntity.startPlayer(player)) {
            player.stopUsingItem();
            return InteractionResultHolder.fail(stack);
        }
        return InteractionResultHolder.consume(stack);
    }
    @Override public int getUseDuration(ItemStack stack) { return 72000; }
    @Override public UseAnim getUseAnimation(ItemStack stack) { return UseAnim.BOW; }
    @Override public void releaseUsing(ItemStack stack, Level level, LivingEntity living,
            int timeLeft) {
        if (!level.isClientSide && living instanceof Player player)
            ImperialCastEntity.releasePlayer(player);
    }
    @Override public void onUseTick(Level level, LivingEntity living, ItemStack stack,
            int timeLeft) {
        if (!level.isClientSide && living instanceof Player player && timeLeft % 20 == 0) {
            ImperialCastEntity cast = ImperialCastEntity.playerCast(player);
            if (cast != null && cast.isCharging()) player.displayClientMessage(
                    Component.translatable("message.wooltest.imperial_charging",
                            String.format(java.util.Locale.ROOT, "%.1f", cast.chargeTicks() / 20.0F),
                            EmperorRules.completedCircles(cast.chargeTicks())), true);
        }
    }
    @Override public void appendHoverText(ItemStack stack, @Nullable Level level,
            List<Component> tooltip, TooltipFlag flag) {
        tooltip.add(Component.translatable("tooltip.wooltest.imperial_sword.damage").withStyle(ChatFormatting.GOLD));
        tooltip.add(Component.translatable("tooltip.wooltest.imperial_sword.speed").withStyle(ChatFormatting.AQUA));
        tooltip.add(Component.translatable("tooltip.wooltest.imperial_sword.skill").withStyle(ChatFormatting.GRAY));
    }
}
