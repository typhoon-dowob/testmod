package dev.sushi.wooltest.command;

import com.mojang.brigadier.exceptions.CommandSyntaxException;
import dev.sushi.wooltest.ModContent;
import dev.sushi.wooltest.entity.TestOneEntity;
import dev.sushi.wooltest.logic.PeachWoodSwordRules;
import dev.sushi.wooltest.world.DimensionTravel;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.phys.Vec3;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.event.RegisterCommandsEvent;

public final class TestCommands {
    private TestCommands() { }
    public static void register(RegisterCommandsEvent event) {
        event.getDispatcher().register(Commands.literal("wooltest")
                .requires(source -> source.hasPermission(2))
                .executes(context -> {
                    context.getSource().sendSuccess(() -> Component.literal(
                            "/wooltest enter | /wooltest leave | /wooltest spawn | /wooltest sword"), false);
                    return 1;
                })
                .then(Commands.literal("enter").executes(context ->
                        DimensionTravel.enter(context.getSource().getPlayerOrException())))
                .then(Commands.literal("leave").executes(context ->
                        DimensionTravel.leave(context.getSource().getPlayerOrException())))
                .then(Commands.literal("spawn").executes(context -> spawn(context.getSource())))
                .then(Commands.literal("sword").executes(context -> giveSword(context.getSource()))));
    }
    private static int giveSword(CommandSourceStack source) throws CommandSyntaxException {
        ServerPlayer player = source.getPlayerOrException();
        ItemStack stack = ModContent.PEACH_WOOD_SWORD.get().createRolledStack(player.getRandom());
        String damage = PeachWoodSwordRules.formatDamage(
                ModContent.PEACH_WOOD_SWORD.get().getDamageHundredths(stack));
        if (!player.getInventory().add(stack)) player.drop(stack, false);
        source.sendSuccess(() -> Component.translatable("message.wooltest.sword_given", damage), false);
        return 1;
    }

    private static int spawn(CommandSourceStack source) throws CommandSyntaxException {
        ServerPlayer player = source.getPlayerOrException();
        ServerLevel level = player.serverLevel();
        if (!level.dimension().equals(DimensionTravel.WOOL_WORLD)) {
            source.sendFailure(Component.translatable("message.wooltest.not_inside"));
            return 0;
        }
        double x = player.getX() + player.getDirection().getStepX() * 3.0D;
        double z = player.getZ() + player.getDirection().getStepZ() * 3.0D;
        Vec3 spot = DimensionTravel.findSafe(level, player, x, player.getY(), z);
        if (spot == null) { source.sendFailure(Component.translatable("message.wooltest.no_safe_spot")); return 0; }
        TestOneEntity entity = ModContent.TEST_ONE.get().create(level);
        if (entity == null) { source.sendFailure(Component.literal("Could not create wooltest:test_one")); return 0; }
        entity.moveTo(spot.x, spot.y, spot.z, player.getYRot() + 180.0F, 0.0F);
        if (!level.noCollision(entity) || !level.addFreshEntity(entity)) {
            source.sendFailure(Component.translatable("message.wooltest.no_safe_spot"));
            return 0;
        }
        source.sendSuccess(() -> Component.translatable("message.wooltest.spawned"), false);
        return 1;
    }
}
