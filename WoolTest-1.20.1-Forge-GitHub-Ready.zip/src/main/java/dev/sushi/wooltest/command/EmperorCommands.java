package dev.sushi.wooltest.command;

import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import dev.sushi.wooltest.ModContent;
import dev.sushi.wooltest.entity.EmperorEntity;
import dev.sushi.wooltest.world.DimensionTravel;
import dev.sushi.wooltest.world.PalaceEmperorData;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.phys.Vec3;

public final class EmperorCommands {
    private EmperorCommands() { }
    public static LiteralArgumentBuilder<CommandSourceStack> command() {
        return Commands.literal("emperor")
                .executes(c -> status(c.getSource()))
                .then(Commands.literal("test").executes(c -> test(c.getSource())));
    }
    private static int status(CommandSourceStack source) {
        ServerLevel level = source.getServer().getLevel(DimensionTravel.WOOL_WORLD);
        if (level == null) return 0;
        PalaceEmperorData data = PalaceEmperorData.get(level);
        String state = data.defeated ? "已擊敗，不會自動復活" : data.spawned
                ? "已生成，UUID=" + data.emperor : "尚未生成；靠近主殿後，在非和平難度檢查空間生成";
        source.sendSuccess(() -> Component.literal("宮殿皇帝：" + state
                + "。初始位置 (0.5, 68.0625, -80.5)。/wooltest emperor test 可在面前新增測試用皇帝。"), false);
        return 1;
    }
    public static int giveSword(CommandSourceStack source) throws CommandSyntaxException {
        ServerPlayer player = source.getPlayerOrException();
        ItemStack stack = new ItemStack(ModContent.IMPERIAL_SWORD.get());
        if (!player.getInventory().add(stack)) player.drop(stack, false);
        source.sendSuccess(() -> Component.literal("已給予天子劍。主手右鍵蓄力；放開右鍵施放，15 秒自動施放。"), false);
        return 1;
    }
    private static int test(CommandSourceStack source) throws CommandSyntaxException {
        ServerPlayer player = source.getPlayerOrException();
        ServerLevel level = player.serverLevel();
        Vec3 direction = Vec3.directionFromRotation(0.0F, player.getYRot());
        Vec3 start = player.position().add(direction.scale(5));
        EmperorEntity mob = ModContent.EMPEROR.get().create(level);
        if (mob == null) return 0;
        // Feet may already be on a carpet or slab; try nearby elevations without editing blocks.
        for (double dy : new double[] {0, 0.0625, 0.5, 1, -0.5, -1}) {
            mob.moveTo(start.x, start.y + dy, start.z, player.getYRot() + 180, 0);
            if (level.noCollision(mob)
                    && level.getBlockStates(mob.getBoundingBox().move(0, -0.1, 0))
                            .anyMatch(s -> !s.isAir())
                    && level.addFreshEntity(mob)) {
                source.sendSuccess(() -> Component.literal("已生成額外的測試皇帝；不影響宮殿唯一生成紀錄。"), false);
                return 1;
            }
        }
        source.sendFailure(Component.literal("面前沒有足夠的 2×2×3 安全空間，請換空地。"));
        return 0;
    }
}
