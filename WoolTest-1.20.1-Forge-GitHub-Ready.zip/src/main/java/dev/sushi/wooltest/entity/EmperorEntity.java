package dev.sushi.wooltest.entity;

import dev.sushi.wooltest.ModContent;
import dev.sushi.wooltest.logic.EmperorRules;
import dev.sushi.wooltest.world.PalaceEmperorData;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ClientGamePacketListener;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerBossEvent;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.BossEvent;
import net.minecraft.world.Difficulty;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.MeleeAttackGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.target.HurtByTargetGoal;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraftforge.network.NetworkHooks;
import javax.annotation.Nullable;
import java.util.EnumSet;
import java.util.UUID;

public final class EmperorEntity extends Monster {
    private static final EntityDataAccessor<Boolean> CHARGING = SynchedEntityData.defineId(
            EmperorEntity.class, EntityDataSerializers.BOOLEAN);
    private final ServerBossEvent bossBar = new ServerBossEvent(
            Component.translatable("entity.wooltest.emperor"), BossEvent.BossBarColor.YELLOW,
            BossEvent.BossBarOverlay.NOTCHED_10);
    private UUID castId;
    private int spellCooldown = 60;
    private boolean palaceBorn;

    public EmperorEntity(EntityType<? extends EmperorEntity> type, Level level) {
        super(type, level);
        setPersistenceRequired();
        setCustomName(Component.translatable("entity.wooltest.emperor"));
        setCustomNameVisible(true);
        equipSword();
        xpReward = 0;
    }
    private void equipSword() {
        setItemSlot(EquipmentSlot.MAINHAND, new ItemStack(ModContent.IMPERIAL_SWORD.get()));
        // No drop rate was specified: the held sword is not a new implicit loot reward.
        setDropChance(EquipmentSlot.MAINHAND, 0.0F);
    }
    public static AttributeSupplier.Builder createAttributes() {
        return Monster.createMonsterAttributes()
                .add(Attributes.MAX_HEALTH, EmperorRules.HEALTH)
                // The equipped sword adds 9. The equipped attribute total is 10, not 19.
                .add(Attributes.ATTACK_DAMAGE, 1.0D)
                .add(Attributes.ATTACK_SPEED, 4.0D)
                .add(Attributes.MOVEMENT_SPEED, 0.20D)
                .add(Attributes.FOLLOW_RANGE, 32.0D)
                .add(Attributes.KNOCKBACK_RESISTANCE, 0.5D)
                .add(Attributes.ARMOR, 0.0D);
    }
    @Override protected void defineSynchedData() {
        super.defineSynchedData(); entityData.define(CHARGING, false);
    }
    public boolean isChargingSpell() { return entityData.get(CHARGING); }
    public void markPalaceBorn() { palaceBorn = true; }
    public boolean isPalaceBorn() { return palaceBorn; }
    @Nullable private ImperialCastEntity activeCast() {
        if (!(level() instanceof ServerLevel level) || castId == null) return null;
        Entity e = level.getEntity(castId);
        return e instanceof ImperialCastEntity cast && !cast.isRemoved() ? cast : null;
    }
    @Override protected void registerGoals() {
        goalSelector.addGoal(0, new FloatGoal(this));
        goalSelector.addGoal(1, new Goal() {
            { setFlags(EnumSet.of(Goal.Flag.MOVE, Goal.Flag.LOOK, Goal.Flag.JUMP)); }
            @Override public boolean canUse() { return isChargingSpell(); }
            @Override public boolean canContinueToUse() { return isChargingSpell(); }
            @Override public void tick() {
                getNavigation().stop();
                setDeltaMovement(0.0D, getDeltaMovement().y, 0.0D);
                ImperialCastEntity cast = activeCast();
                if (cast != null) {
                    var p = cast.targetPoint(); getLookControl().setLookAt(p.x, p.y, p.z);
                }
            }
        });
        goalSelector.addGoal(2, new MeleeAttackGoal(this, 1.0D, true) {
            @Override public boolean canUse() { return !isChargingSpell() && super.canUse(); }
            @Override public boolean canContinueToUse() { return !isChargingSpell() && super.canContinueToUse(); }
        });
        goalSelector.addGoal(4, new LookAtPlayerGoal(this, Player.class, 16.0F));
        goalSelector.addGoal(5, new RandomLookAroundGoal(this));
        targetSelector.addGoal(1, new HurtByTargetGoal(this));
        targetSelector.addGoal(2, new NearestAttackableTargetGoal<>(this, Player.class, true));
    }
    @Override protected void customServerAiStep() {
        super.customServerAiStep();
        bossBar.setProgress(getHealth() / getMaxHealth());
        if (level().getDifficulty() == Difficulty.PEACEFUL) {
            setTarget(null); getNavigation().stop();
            ImperialCastEntity cast = activeCast();
            if (cast != null) cast.discard();
            castId = null; entityData.set(CHARGING, false); return;
        }
        ImperialCastEntity cast = activeCast();
        boolean active = cast != null && cast.isCharging();
        entityData.set(CHARGING, active);
        if (active) {
            getNavigation().stop();
            setDeltaMovement(0.0D, getDeltaMovement().y, 0.0D);
            return;
        }
        if (castId != null) { castId = null; spellCooldown = EmperorRules.COOLDOWN; }
        if (spellCooldown > 0) spellCooldown--;
        LivingEntity target = getTarget();
        if (spellCooldown == 0 && target instanceof Player player && player.isAlive()
                && !player.isCreative() && !player.isSpectator()
                && distanceToSqr(player) <= 30.0D * 30.0D && getSensing().hasLineOfSight(player)) {
            int duration = EmperorRules.MIN_CHARGE + getRandom().nextInt(
                    EmperorRules.MAX_CHARGE - EmperorRules.MIN_CHARGE + 1);
            ImperialCastEntity started = ImperialCastEntity.begin(this,
                    player.position().add(0.0D, 0.12D, 0.0D), duration);
            if (started != null) {
                castId = started.getUUID(); entityData.set(CHARGING, true); getNavigation().stop();
            } else spellCooldown = 20;
        }
    }
    @Override public boolean doHurtTarget(Entity target) {
        if (isChargingSpell() || level().getDifficulty() == Difficulty.PEACEFUL) return false;
        boolean hit = target.hurt(ModDamage.source(level(), ModDamage.IMPERIAL_MELEE, this), EmperorRules.ATTACK);
        if (hit) setLastHurtMob(target);
        return hit;
    }
    @Override public boolean hurt(DamageSource source, float amount) {
        boolean accepted = super.hurt(source, amount);
        if (accepted && !level().isClientSide && isAlive() && source.getEntity() instanceof Player) {
            ImperialCastEntity cast = activeCast();
            if (cast != null && cast.isCharging()) {
                cast.release(); entityData.set(CHARGING, false); spellCooldown = EmperorRules.COOLDOWN;
            }
        }
        return accepted;
    }
    @Override protected void dropEquipment(DamageSource source, int lootingLevel, boolean recentlyHit) {
        // Explicitly suppress equipment drops, including Looting-adjusted chances.
        // A future drop specification can be implemented here without changing combat.
    }
    @Override public void die(DamageSource source) {
        if (!level().isClientSide) {
            ImperialCastEntity cast = activeCast();
            if (cast != null) cast.discard();
            if (palaceBorn && level() instanceof ServerLevel server)
                PalaceEmperorData.get(server).defeat(getUUID());
            bossBar.removeAllPlayers();
        }
        super.die(source);
    }
    @Override public void startSeenByPlayer(ServerPlayer player) {
        super.startSeenByPlayer(player); if (isAlive()) bossBar.addPlayer(player);
    }
    @Override public void stopSeenByPlayer(ServerPlayer player) {
        super.stopSeenByPlayer(player); bossBar.removePlayer(player);
    }
    @Override public void remove(RemovalReason reason) {
        if (!level().isClientSide) {
            ImperialCastEntity cast = activeCast(); if (cast != null) cast.discard();
            bossBar.removeAllPlayers();
        }
        super.remove(reason);
    }
    // The unique emperor remains dormant in peaceful rather than being lost permanently.
    @Override protected boolean shouldDespawnInPeaceful() { return false; }
    @Override public boolean removeWhenFarAway(double distance) { return false; }
    @Override public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        tag.putBoolean("WoolTestPalaceBorn", palaceBorn);
        tag.putInt("WoolTestSpellCooldown", Math.max(60, spellCooldown));
    }
    @Override public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        palaceBorn = tag.getBoolean("WoolTestPalaceBorn");
        spellCooldown = Math.max(60, Math.min(EmperorRules.COOLDOWN, tag.getInt("WoolTestSpellCooldown")));
        castId = null; entityData.set(CHARGING, false); equipSword();
    }
    @Override protected SoundEvent getHurtSound(DamageSource source) { return SoundEvents.PLAYER_HURT; }
    @Override protected SoundEvent getDeathSound() { return SoundEvents.PLAYER_DEATH; }
    @Override public Packet<ClientGamePacketListener> getAddEntityPacket() {
        return NetworkHooks.getEntitySpawningPacket(this);
    }
}
