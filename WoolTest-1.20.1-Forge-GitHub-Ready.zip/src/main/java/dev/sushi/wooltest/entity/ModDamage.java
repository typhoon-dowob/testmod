package dev.sushi.wooltest.entity;

import dev.sushi.wooltest.WoolTestMod;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.damagesource.DamageType;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.Level;
import javax.annotation.Nullable;

public final class ModDamage {
    private ModDamage() { }
    public static final ResourceKey<DamageType> MELEE = key("test_melee");
    public static final ResourceKey<DamageType> PILLAR = key("wooden_pillar");
    public static final ResourceKey<DamageType> IMPERIAL_MELEE = key("imperial_melee");
    public static final ResourceKey<DamageType> IMPERIAL_MAGIC = key("imperial_magic");
    private static ResourceKey<DamageType> key(String name) {
        return ResourceKey.create(Registries.DAMAGE_TYPE, new ResourceLocation(WoolTestMod.MOD_ID, name));
    }
    public static DamageSource source(Level level, ResourceKey<DamageType> type,
            @Nullable Entity owner) {
        return new DamageSource(level.registryAccess().registryOrThrow(Registries.DAMAGE_TYPE)
                .getHolderOrThrow(type), owner);
    }
}
