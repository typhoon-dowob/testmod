package dev.sushi.wooltest.entity;

import dev.sushi.wooltest.ModContent;
import dev.sushi.wooltest.block.TemporaryPillarBlockEntity;
import dev.sushi.wooltest.logic.TestRules;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.particles.BlockParticleOption;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.AABB;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.UUID;

public final class PillarAbility {
    private PillarAbility() { }

    public static boolean cast(TestOneEntity caster, Player target) {
        if (!(caster.level() instanceof ServerLevel level)) return false;
        List<BlockPos> candidates = new ArrayList<>();
        int cx = Mth.floor(caster.getX());
        int cz = Mth.floor(caster.getZ());
        int referenceY = Mth.floor(caster.getY());
        for (int x = cx - 5; x <= cx + 5; x++) {
            for (int z = cz - 5; z <= cz + 5; z++) {
                if (!TestRules.insidePillarRadius(caster.getX(), caster.getZ(), x, z)) continue;
                // Search the local floor, not the top of a distant roof.
                for (int dy = 2; dy >= -2; dy--) {
                    BlockPos base = new BlockPos(x, referenceY + dy, z);
                    if (validColumn(level, base)) {
                        candidates.add(base);
                        break;
                    }
                }
            }
        }
        if (candidates.size() < TestRules.PILLAR_COUNT) return false;

        // One pillar near (not inside) the target, two random other valid columns.
        candidates.sort(Comparator.comparingDouble(pos ->
                pos.distToCenterSqr(target.getX(), target.getY(), target.getZ())));
        List<BlockPos> chosen = new ArrayList<>();
        chosen.add(candidates.remove(0));
        for (int i = candidates.size() - 1; i > 0; i--) {
            Collections.swap(candidates, i, caster.getRandom().nextInt(i + 1));
        }
        chosen.addAll(candidates.subList(0, TestRules.PILLAR_COUNT - 1));

        UUID castId = UUID.randomUUID();
        long expiry = level.getGameTime() + TestRules.PILLAR_LIFETIME_TICKS;
        List<BlockPos> placed = new ArrayList<>();
        for (BlockPos base : chosen) {
            for (int h = 0; h < TestRules.PILLAR_HEIGHT; h++) {
                BlockPos p = base.above(h);
                if (!level.getBlockState(p).isAir()
                        || !level.setBlock(p, ModContent.TEMPORARY_PILLAR.get().defaultBlockState(), 3)) {
                    rollback(level, placed, castId);
                    return false;
                }
                if (!(level.getBlockEntity(p) instanceof TemporaryPillarBlockEntity block)) {
                    level.removeBlock(p, false);
                    rollback(level, placed, castId);
                    return false;
                }
                block.initialize(expiry, caster.getUUID(), castId);
                placed.add(p);
            }
            playSummonEffects(level, base);
        }
        level.playSound(null, caster.blockPosition(), SoundEvents.EVOKER_CAST_SPELL,
                SoundSource.HOSTILE, 0.8F, 1.2F);
        return true;
    }


    private static void playSummonEffects(ServerLevel level, BlockPos base) {
        var pillarState = ModContent.TEMPORARY_PILLAR.get().defaultBlockState();
        for (int h = 0; h < TestRules.PILLAR_HEIGHT; h++) {
            double y = base.getY() + h + 0.5D;
            level.sendParticles(new BlockParticleOption(ParticleTypes.BLOCK, pillarState),
                    base.getX() + 0.5D, y, base.getZ() + 0.5D,
                    10, 0.28D, 0.22D, 0.28D, 0.02D);
        }
        level.sendParticles(ParticleTypes.CLOUD, base.getX() + 0.5D,
                base.getY() + 0.15D, base.getZ() + 0.5D,
                12, 0.35D, 0.08D, 0.35D, 0.02D);
        level.playSound(null, base, SoundEvents.WOOD_PLACE,
                SoundSource.HOSTILE, 0.9F, 0.85F + level.random.nextFloat() * 0.15F);
    }

    private static boolean validColumn(ServerLevel level, BlockPos base) {
        if (!TestRules.pillarFits(base.getY(), level.getMinBuildHeight(), level.getMaxBuildHeight())
                || !level.hasChunkAt(base) || !level.getWorldBorder().isWithinBounds(base)
                || !level.getBlockState(base.below()).isFaceSturdy(level, base.below(), Direction.UP)) {
            return false;
        }
        for (int h = 0; h < TestRules.PILLAR_HEIGHT; h++) {
            if (!level.getBlockState(base.above(h)).isAir()) return false;
        }
        AABB volume = new AABB(base.getX(), base.getY(), base.getZ(),
                base.getX() + 1.0D, base.getY() + TestRules.PILLAR_HEIGHT, base.getZ() + 1.0D);
        // Never materialise a solid block inside a player, mob, item or vehicle.
        return level.getEntities((Entity) null, volume.inflate(0.05D),
                entity -> !entity.isSpectator()).isEmpty();
    }

    private static void rollback(ServerLevel level, List<BlockPos> positions, UUID castId) {
        for (BlockPos p : positions) {
            if (level.getBlockEntity(p) instanceof TemporaryPillarBlockEntity pillar
                    && pillar.belongsTo(castId)) level.removeBlock(p, false);
        }
    }
}
