package dev.sushi.wooltest.entity;

import dev.sushi.wooltest.ModContent;
import dev.sushi.wooltest.logic.EmperorRules;
import dev.sushi.wooltest.logic.ImperialSwordCastRules;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ClientGamePacketListener;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.network.NetworkHooks;
import javax.annotation.Nullable;
import java.util.UUID;

/** The server owns targeting, charge and damage. Clients only render synced geometry. */
public final class ImperialCastEntity extends Entity {
    private static final String PLAYER_TAG = "WoolTestImperialCast";
    private static final EntityDataAccessor<Integer> ELAPSED = SynchedEntityData.defineId(ImperialCastEntity.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Integer> PHASE = SynchedEntityData.defineId(ImperialCastEntity.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Integer> FLASH = SynchedEntityData.defineId(ImperialCastEntity.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Float> DX = SynchedEntityData.defineId(ImperialCastEntity.class, EntityDataSerializers.FLOAT);
    private static final EntityDataAccessor<Float> DY = SynchedEntityData.defineId(ImperialCastEntity.class, EntityDataSerializers.FLOAT);
    private static final EntityDataAccessor<Float> DZ = SynchedEntityData.defineId(ImperialCastEntity.class, EntityDataSerializers.FLOAT);
    private static final EntityDataAccessor<Float> FOOT_OFFSET = SynchedEntityData.defineId(ImperialCastEntity.class, EntityDataSerializers.FLOAT);
    private static final EntityDataAccessor<Boolean> PLAYER_OWNED = SynchedEntityData.defineId(ImperialCastEntity.class, EntityDataSerializers.BOOLEAN);
    private UUID ownerId;
    private Vec3 lockedTarget = Vec3.ZERO;
    private int plannedTicks = EmperorRules.MAX_CHARGE;
    private boolean playerOwned;

    public ImperialCastEntity(EntityType<? extends ImperialCastEntity> type, Level level) {
        super(type, level);
        noPhysics = true;
        setNoGravity(true);
    }
    @Override protected void defineSynchedData() {
        entityData.define(PLAYER_OWNED, false); entityData.define(ELAPSED, 0); entityData.define(PHASE, 0); entityData.define(FLASH, 0);
        entityData.define(DX, 0.0F); entityData.define(DY, 0.0F); entityData.define(DZ, 1.0F); entityData.define(FOOT_OFFSET, 2.01F);
    }
    public int chargeTicks() { return entityData.get(ELAPSED); }
    public int flashTicks() { return entityData.get(FLASH); }
    public boolean isCharging() { return entityData.get(PHASE) == 0; }
    public boolean isFullRelease() { return entityData.get(PHASE) == 1; }
    public boolean isPlayerOwnedCast() { return entityData.get(PLAYER_OWNED); }
    public double sealDistance(int index, double length) {
        return isPlayerOwnedCast() ? ImperialSwordCastRules.circleDistance(index, length) : EmperorRules.circleDistance(index, length);
    }
    public float footOffset() { return entityData.get(FOOT_OFFSET); }
    public Vec3 targetPoint() { return position().add(entityData.get(DX), entityData.get(DY), entityData.get(DZ)); }
    private void syncTarget(Vec3 target) {
        entityData.set(DX, (float)(target.x - getX()));
        entityData.set(DY, (float)(target.y - getY()));
        entityData.set(DZ, (float)(target.z - getZ()));
    }
    private static Vec3 origin(LivingEntity owner) {
        return owner.position().add(0.0D, owner.getBbHeight() * 0.67D, 0.0D);
    }
    @Nullable public static ImperialCastEntity begin(LivingEntity owner, Vec3 target, int planned) {
        if (!(owner.level() instanceof ServerLevel level)) return null;
        ImperialCastEntity cast = ModContent.IMPERIAL_CAST.get().create(level);
        if (cast == null) return null;
        cast.ownerId = owner.getUUID(); cast.playerOwned = owner instanceof Player;
        cast.plannedTicks = cast.playerOwned ? ImperialSwordCastRules.MAX_CHARGE : EmperorRules.CHARGE_TICKS;
        cast.entityData.set(PLAYER_OWNED, cast.playerOwned);
        cast.entityData.set(FOOT_OFFSET, owner.getBbHeight() * 0.67F);
        cast.setPos(origin(owner));
        Vec3 delta = target.subtract(cast.position());
        cast.lockedTarget = delta.length() > EmperorRules.RANGE
                ? cast.position().add(delta.normalize().scale(EmperorRules.RANGE)) : target;
        cast.syncTarget(cast.lockedTarget);
        if (!level.addFreshEntity(cast)) return null;
        level.playSound(null, owner.blockPosition(), SoundEvents.BEACON_ACTIVATE,
                SoundSource.HOSTILE, 0.65F, 1.25F);
        return cast;
    }
    @Nullable public static ImperialCastEntity playerCast(Player player) {
        if (!(player.level() instanceof ServerLevel level)
                || !player.getPersistentData().hasUUID(PLAYER_TAG)) return null;
        Entity entity = level.getEntity(player.getPersistentData().getUUID(PLAYER_TAG));
        return entity instanceof ImperialCastEntity cast && player.getUUID().equals(cast.ownerId)
                ? cast : null;
    }
    public static boolean startPlayer(Player player) {
        ImperialCastEntity previous = playerCast(player);
        if (previous != null && previous.isCharging()) return false;
        Vec3 eye = player.getEyePosition();
        Vec3 end = eye.add(player.getLookAngle().scale(EmperorRules.RANGE));
        HitResult hit = player.level().clip(new ClipContext(eye, end,
                ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, player));
        ImperialCastEntity cast = begin(player, hit.getLocation(), ImperialSwordCastRules.MAX_CHARGE);
        if (cast == null) return false;
        player.getPersistentData().putUUID(PLAYER_TAG, cast.getUUID());
        return true;
    }
    public static void releasePlayer(Player player) {
        ImperialCastEntity cast = playerCast(player);
        if (cast != null) cast.release();
    }
    @Nullable private LivingEntity owner() {
        if (!(level() instanceof ServerLevel server) || ownerId == null) return null;
        Entity entity = server.getEntity(ownerId);
        return entity instanceof LivingEntity living && living.isAlive() ? living : null;
    }
    @Override public void tick() {
        super.tick();
        if (!(level() instanceof ServerLevel server)) return;
        if (!isCharging()) {
            entityData.set(FLASH, flashTicks() + 1);
            if (flashTicks() >= EmperorRules.FLASH_TICKS) discard();
            return;
        }
        LivingEntity owner = owner();
        if (owner == null || owner.isRemoved() || server.getDifficulty() == net.minecraft.world.Difficulty.PEACEFUL && !playerOwned) {
            discard(); return;
        }
        // A charge is not allowed to stretch beyond the skill's fixed 32-block range.
        if (origin(owner).distanceToSqr(lockedTarget) > EmperorRules.RANGE * EmperorRules.RANGE) {
            discard(); return;
        }
        setPos(origin(owner)); syncTarget(lockedTarget);
        if (owner instanceof Player player && (!player.isUsingItem()
                || !player.getUseItem().is(ModContent.IMPERIAL_SWORD.get()))) {
            release(); return;
        }
        entityData.set(ELAPSED, Math.min(plannedTicks, chargeTicks() + 1));
        if (chargeTicks() % EmperorRules.CIRCLE_TICKS == 0) {
            server.playSound(null, blockPosition(), SoundEvents.AMETHYST_BLOCK_CHIME,
                    SoundSource.HOSTILE, 0.8F, 0.8F + chargeTicks() / 500.0F);
        }
        chargeParticles(server, owner);
        if (chargeTicks() >= plannedTicks) {
            release(true);
            if (owner instanceof Player player) player.stopUsingItem();
        }
    }
    /** May be called by item release or a successful non-lethal player hit. Idempotent. */
    public void release() { release(false); }
    private void release(boolean completed) {
        if (!(level() instanceof ServerLevel server) || !isCharging()) return;
        LivingEntity caster = owner();
        if (caster == null) { discard(); return; }
        boolean fullRelease = playerOwned ? chargeTicks() >= ImperialSwordCastRules.MIN_CHARGE
                : completed && chargeTicks() >= EmperorRules.CHARGE_TICKS;
        entityData.set(PHASE, fullRelease ? 1 : 2); entityData.set(FLASH, 0);
        Vec3 start = position();
        Vec3 end = server.clip(new ClipContext(start, lockedTarget,
                ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, caster)).getLocation();
        syncTarget(end);
        // Move the LOS origin a few centimetres off an impact surface, not into its block.
        Vec3 blast = end.add(start.subtract(end).normalize().scale(0.04D));
        Vec3 beamStart = start.add(end.subtract(start).normalize().scale(
                sealDistance(0, start.distanceTo(end))));
        AABB bounds = new AABB(start, end).inflate(EmperorRules.RADIUS + 1.0D);
        for (LivingEntity victim : server.getEntitiesOfClass(LivingEntity.class, bounds,
                entity -> validVictim(caster, entity))) {
            AABB box = victim.getBoundingBox();
            AABB beamBox = box.inflate(EmperorRules.BEAM_RADIUS);
            boolean beam = (beamBox.contains(beamStart) || beamBox.contains(end)
                    || beamBox.clip(beamStart, end).isPresent())
                    && clearLine(server, caster, beamStart, box.getCenter());
            boolean area = fullRelease
                    && distanceToBoxSqr(blast, box) <= EmperorRules.RADIUS * EmperorRules.RADIUS
                    && clearLine(server, caster, blast, box.getCenter());
            float damage = playerOwned ? ImperialSwordCastRules.damage(chargeTicks(), area, beam)
                    : EmperorRules.damage(chargeTicks(), area, beam);
            if (damage > 0.0F) victim.hurt(ModDamage.source(server, ModDamage.IMPERIAL_MAGIC, caster), damage);
        }
        server.sendParticles(ParticleTypes.END_ROD, end.x, end.y + 0.1D, end.z,
                28, 0.5D, 0.5D, 0.5D, 0.05D);
        server.playSound(null, blockPosition(), SoundEvents.EVOKER_CAST_SPELL,
                SoundSource.HOSTILE, 1.0F, 0.65F);
        if (caster instanceof Player player) {
            player.getCooldowns().addCooldown(ModContent.IMPERIAL_SWORD.get(), EmperorRules.COOLDOWN);
            if (player.getPersistentData().hasUUID(PLAYER_TAG)
                    && getUUID().equals(player.getPersistentData().getUUID(PLAYER_TAG)))
                player.getPersistentData().remove(PLAYER_TAG);
            if (player.getMainHandItem().is(ModContent.IMPERIAL_SWORD.get()))
                player.getMainHandItem().hurtAndBreak(1, player,
                        p -> p.broadcastBreakEvent(net.minecraft.world.InteractionHand.MAIN_HAND));
        }
    }
    private void chargeParticles(ServerLevel server, LivingEntity caster) {
        // Modest, bounded packet budget: six orbit sparks + three source sparks every four ticks.
        if (chargeTicks() % 4 != 0) return;
        double progress = Math.min(1.0D, chargeTicks() / (double) EmperorRules.CHARGE_TICKS);
        for (int i = 0; i < 6; i++) {
            double a = chargeTicks() * 0.16D + i * Math.PI / 3.0D;
            double r = 0.85D + progress * 0.25D;
            double y = caster.getY() + 0.25D + (i / 5.0D) * caster.getBbHeight();
            server.sendParticles(ParticleTypes.END_ROD, caster.getX() + Math.cos(a) * r, y,
                    caster.getZ() + Math.sin(a) * r, 1, 0.02D, 0.06D, 0.02D, 0.006D);
        }
        server.sendParticles(ParticleTypes.ENCHANT, caster.getX(), caster.getY() + caster.getBbHeight(),
                caster.getZ(), 3, 0.3D, 0.10D, 0.3D, 0.15D);
    }
    private boolean validVictim(LivingEntity caster, LivingEntity victim) {
        if (victim == caster || !victim.isAlive() || victim.isSpectator() || caster.isAlliedTo(victim)) return false;
        if (victim instanceof Player p && (p.isCreative() || p.isSpectator())) return false;
        if (!playerOwned) return victim instanceof Player;
        return !(caster instanceof Player p && victim instanceof Player other && !p.canHarmPlayer(other));
    }
    private static boolean clearLine(ServerLevel server, Entity caster, Vec3 a, Vec3 b) {
        if (a.distanceToSqr(b) < 0.0001D) return true;
        HitResult hit = server.clip(new ClipContext(a, b, ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, caster));
        return hit.getType() == HitResult.Type.MISS || hit.getLocation().distanceToSqr(b) < 0.04D;
    }
    private static double distanceToBoxSqr(Vec3 p, AABB b) {
        double x = Math.max(b.minX, Math.min(b.maxX, p.x)) - p.x;
        double y = Math.max(b.minY, Math.min(b.maxY, p.y)) - p.y;
        double z = Math.max(b.minZ, Math.min(b.maxZ, p.z)) - p.z;
        return x*x + y*y + z*z;
    }
    // Casts deliberately do not survive unload/restart: no ghost or offline damage.
    @Override protected void readAdditionalSaveData(CompoundTag tag) { }
    @Override protected void addAdditionalSaveData(CompoundTag tag) { }
    @Override public boolean isPickable() { return false; }
    @Override public boolean shouldRenderAtSqrDistance(double distance) { return distance < 128.0D * 128.0D; }
    @Override public Packet<ClientGamePacketListener> getAddEntityPacket() {
        return NetworkHooks.getEntitySpawningPacket(this);
    }
}
