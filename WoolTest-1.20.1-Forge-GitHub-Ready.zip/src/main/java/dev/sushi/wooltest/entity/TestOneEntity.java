package dev.sushi.wooltest.entity;

import dev.sushi.wooltest.logic.TestRules;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ClientGamePacketListener;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.MeleeAttackGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.WaterAvoidingRandomStrollGoal;
import net.minecraft.world.entity.ai.goal.target.HurtByTargetGoal;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraftforge.network.NetworkHooks;

/** Independent registered mob; reuses the vanilla humanoid model only. */
public final class TestOneEntity extends Monster {
    private int skillCooldown = 40;

    public TestOneEntity(EntityType<? extends TestOneEntity> type, Level level) {
        super(type, level);
        setCustomName(Component.translatable("entity.wooltest.test_one"));
        setCustomNameVisible(true);
        setPersistenceRequired();
        xpReward = 0;
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Monster.createMonsterAttributes()
                .add(Attributes.MAX_HEALTH, TestRules.MAX_HEALTH)
                .add(Attributes.ATTACK_DAMAGE, TestRules.MELEE_DAMAGE)
                .add(Attributes.MOVEMENT_SPEED, 0.23D)
                .add(Attributes.FOLLOW_RANGE, 16.0D)
                .add(Attributes.ARMOR, 0.0D);
    }

    @Override protected void registerGoals() {
        goalSelector.addGoal(0, new FloatGoal(this));
        goalSelector.addGoal(1, new MeleeAttackGoal(this, 1.0D, false));
        goalSelector.addGoal(3, new WaterAvoidingRandomStrollGoal(this, 0.8D));
        goalSelector.addGoal(4, new LookAtPlayerGoal(this, Player.class, 8.0F));
        goalSelector.addGoal(5, new RandomLookAroundGoal(this));
        targetSelector.addGoal(1, new HurtByTargetGoal(this));
        targetSelector.addGoal(2, new NearestAttackableTargetGoal<>(this, Player.class, true));
    }

    @Override protected void customServerAiStep() {
        super.customServerAiStep();
        if (skillCooldown > 0) skillCooldown--;
        LivingEntity target = getTarget();
        if (skillCooldown == 0 && target instanceof Player player
                && player.isAlive() && !player.isCreative() && !player.isSpectator()
                && distanceToSqr(player) <= TestRules.PILLAR_RADIUS * TestRules.PILLAR_RADIUS
                && getSensing().hasLineOfSight(player)) {
            skillCooldown = PillarAbility.cast(this, player)
                    ? TestRules.CAST_COOLDOWN_TICKS : 20;
        }
    }

    @Override public boolean doHurtTarget(Entity target) {
        // Custom damage type uses scaling=never: no hidden difficulty multiplier.
        boolean hit = target.hurt(ModDamage.source(level(), ModDamage.MELEE, this),
                (float) getAttributeValue(Attributes.ATTACK_DAMAGE));
        if (hit) setLastHurtMob(target);
        return hit;
    }

    @Override public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        tag.putInt("WoolTestSkillCooldown", skillCooldown);
    }
    @Override public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        if (tag.contains("WoolTestSkillCooldown")) {
            skillCooldown = Math.max(0, Math.min(TestRules.CAST_COOLDOWN_TICKS,
                    tag.getInt("WoolTestSkillCooldown")));
        }
    }
    @Override protected SoundEvent getAmbientSound() { return SoundEvents.ZOMBIE_AMBIENT; }
    @Override protected SoundEvent getHurtSound(DamageSource source) { return SoundEvents.ZOMBIE_HURT; }
    @Override protected SoundEvent getDeathSound() { return SoundEvents.ZOMBIE_DEATH; }
    @Override public Packet<ClientGamePacketListener> getAddEntityPacket() {
        return NetworkHooks.getEntitySpawningPacket(this);
    }
}
