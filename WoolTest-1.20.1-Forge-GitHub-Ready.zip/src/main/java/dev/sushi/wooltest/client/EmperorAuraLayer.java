package dev.sushi.wooltest.client;

import com.mojang.blaze3d.vertex.PoseStack;
import dev.sushi.wooltest.WoolTestMod;
import dev.sushi.wooltest.entity.EmperorEntity;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.RenderLayerParent;
import net.minecraft.client.renderer.entity.layers.RenderLayer;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;

/** A selectively painted full-bright overlay. It renders only while charging. */
public final class EmperorAuraLayer extends RenderLayer<EmperorEntity, EmperorModel> {
    private static final ResourceLocation MASK = new ResourceLocation(WoolTestMod.MOD_ID, "textures/entity/emperor_charge.png");
    public EmperorAuraLayer(RenderLayerParent<EmperorEntity, EmperorModel> parent) { super(parent); }
    @Override public void render(PoseStack pose, MultiBufferSource buffers, int light, EmperorEntity e,
            float limbSwing, float limbAmount, float partial, float age, float yaw, float pitch) {
        if (!e.isChargingSpell() || e.isInvisible()) return;
        float alpha = 0.65F + 0.25F * (float)Math.sin(age * 0.22F);
        getParentModel().renderToBuffer(pose, buffers.getBuffer(RenderType.entityTranslucent(MASK)),
                0xF000F0, OverlayTexture.NO_OVERLAY, 1.0F, 0.9F, 0.65F, alpha);
    }
}
