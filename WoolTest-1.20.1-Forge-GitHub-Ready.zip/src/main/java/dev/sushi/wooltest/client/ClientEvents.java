package dev.sushi.wooltest.client;

import dev.sushi.wooltest.ModContent;
import dev.sushi.wooltest.city.CityBlocks;
import dev.sushi.wooltest.WoolTestMod;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.event.BuildCreativeModeTabContentsEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/** Loaded on the physical client only, keeping renderer classes off dedicated servers. */
@Mod.EventBusSubscriber(modid = WoolTestMod.MOD_ID, bus = Mod.EventBusSubscriber.Bus.MOD,
        value = Dist.CLIENT)
public final class ClientEvents {
    private ClientEvents() { }
    @SubscribeEvent public static void registerLayers(EntityRenderersEvent.RegisterLayerDefinitions event) {
        event.registerLayerDefinition(TestOneModel.LAYER_LOCATION, TestOneModel::createBodyLayer);
        event.registerLayerDefinition(EmperorModel.LAYER, EmperorModel::createBodyLayer);
    }
    @SubscribeEvent public static void registerRenderers(EntityRenderersEvent.RegisterRenderers event) {
        event.registerEntityRenderer(ModContent.TEST_ONE.get(), TestOneRenderer::new);
        event.registerEntityRenderer(ModContent.EMPEROR.get(), EmperorRenderer::new);
        event.registerEntityRenderer(ModContent.IMPERIAL_CAST.get(), ImperialCastRenderer::new);
    }
    @SubscribeEvent public static void addEgg(BuildCreativeModeTabContentsEvent event) {
        if (event.getTabKey() == CreativeModeTabs.SPAWN_EGGS) {
            event.accept(ModContent.TEST_ONE_SPAWN_EGG.get());
            event.accept(ModContent.EMPEROR_SPAWN_EGG.get());
        }
        if (event.getTabKey() == CreativeModeTabs.BUILDING_BLOCKS) {
            CityBlocks.ALL_ITEMS.forEach(item -> event.accept(item.get()));
        }
        if (event.getTabKey() == CreativeModeTabs.COMBAT) {
            event.accept(ModContent.PEACH_WOOD_SWORD.get());
            event.accept(ModContent.IMPERIAL_SWORD.get());
        }
    }
}
