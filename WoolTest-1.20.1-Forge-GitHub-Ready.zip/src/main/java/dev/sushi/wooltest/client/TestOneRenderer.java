package dev.sushi.wooltest.client;

import dev.sushi.wooltest.entity.TestOneEntity;
import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.resources.ResourceLocation;

/** Placeholder visuals: references the installed game's zombie model/texture, not bundled assets. */
public final class TestOneRenderer extends MobRenderer<TestOneEntity, HumanoidModel<TestOneEntity>> {
    private static final ResourceLocation TEXTURE =
            new ResourceLocation("minecraft", "textures/entity/zombie/zombie.png");
    public TestOneRenderer(EntityRendererProvider.Context context) {
        super(context, new HumanoidModel<>(context.bakeLayer(ModelLayers.ZOMBIE)), 0.5F);
    }
    @Override public ResourceLocation getTextureLocation(TestOneEntity entity) { return TEXTURE; }
}
