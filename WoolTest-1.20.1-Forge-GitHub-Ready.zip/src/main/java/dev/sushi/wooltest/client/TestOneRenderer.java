package dev.sushi.wooltest.client;

import dev.sushi.wooltest.entity.TestOneEntity;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.resources.ResourceLocation;

/** Custom doll geometry and atlas. This renderer does not alter collision or AI. */
public final class TestOneRenderer extends MobRenderer<TestOneEntity, TestOneModel> {
    private static final ResourceLocation TEXTURE =
            new ResourceLocation("wooltest", "textures/entity/test_one_model1.png");

    public TestOneRenderer(EntityRendererProvider.Context context) {
        super(context, new TestOneModel(context.bakeLayer(TestOneModel.LAYER_LOCATION)), 0.5F);
    }

    @Override
    public ResourceLocation getTextureLocation(TestOneEntity entity) {
        return TEXTURE;
    }
}
