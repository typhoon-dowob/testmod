package dev.sushi.wooltest.client;

import java.io.DataInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.zip.GZIPInputStream;

/** Immutable-on-load WEM4 data. No Minecraft/Forge dependency: the real parser can be unit tested. */
public final class EmperorMeshData {
    public static final int FLOATS_PER_VERTEX = 8;
    public static final int FLOATS_PER_QUAD = 32;
    private static final int MAX_BONES = 128;
    private static final int MAX_QUADS = 20000;
    private final Map<String, float[]> meshes;
    private EmperorMeshData(Map<String, float[]> meshes) {
        this.meshes = Collections.unmodifiableMap(meshes);
    }
    /** Renderer-owned read-only data; do not mutate the returned array. */
    public float[] mesh(String name) {
        float[] data = meshes.get(name);
        if (data == null) throw new IllegalArgumentException("Emperor mesh has no bone: " + name);
        return data;
    }
    public java.util.Set<String> boneNames() { return meshes.keySet(); }
    public int quadCount() {
        int count = 0;
        for (float[] data : meshes.values()) count += data.length / FLOATS_PER_QUAD;
        return count;
    }
    public static EmperorMeshData loadBundled() {
        String path = "/assets/wooltest/geometry/emperor5.wem.gz";
        InputStream stream = EmperorMeshData.class.getResourceAsStream(path);
        if (stream == null) throw new IllegalStateException("Missing bundled emperor model: " + path);
        try (InputStream input = stream) {
            return read(input);
        } catch (IOException ex) {
            throw new IllegalStateException("Cannot read bundled emperor model " + path, ex);
        }
    }
    /** Reads and validates the shipped vertex payload, with bounded allocation. */
    public static EmperorMeshData read(InputStream compressed) throws IOException {
        if (compressed == null) throw new IOException("No emperor mesh input");
        try (DataInputStream in = new DataInputStream(new GZIPInputStream(compressed))) {
            if (in.readInt() != 0x57454D34 || in.readInt() != 1)
                throw new IOException("Unsupported emperor mesh header/version");
            int bones = in.readInt();
            if (bones < 1 || bones > MAX_BONES) throw new IOException("Invalid bone count: " + bones);
            Map<String, float[]> result = new LinkedHashMap<>();
            int totalQuads = 0;
            for (int bone = 0; bone < bones; bone++) {
                String name = in.readUTF();
                if (!name.matches("[a-z0-9_]{1,48}") || result.containsKey(name))
                    throw new IOException("Invalid or duplicate bone: " + name);
                int quads = in.readInt();
                if (quads < 0 || quads > MAX_QUADS || totalQuads + quads > MAX_QUADS)
                    throw new IOException("Invalid face count at " + name);
                totalQuads += quads;
                float[] data = new float[quads * FLOATS_PER_QUAD];
                for (int i = 0; i < data.length; i++) {
                    float value = in.readFloat();
                    int field = i % FLOATS_PER_VERTEX;
                    if (!Float.isFinite(value) || (field < 3 && Math.abs(value) > 128.0F)
                            || (field >= 3 && field <= 5 && Math.abs(value) > 1.001F)
                            || (field >= 6 && (value < 0.0F || value > 1.0F)))
                        throw new IOException("Invalid vertex value at " + name + ":" + i);
                    data[i] = value;
                }
                for (int i = 0; i < data.length; i += FLOATS_PER_VERTEX) {
                    float nx=data[i+3], ny=data[i+4], nz=data[i+5];
                    float lengthSquared=nx*nx+ny*ny+nz*nz;
                    if (lengthSquared < 0.98F || lengthSquared > 1.02F)
                        throw new IOException("Non-unit vertex normal at " + name);
                }
                result.put(name, data);
            }
            if (in.read() != -1) throw new IOException("Trailing bytes in emperor mesh");
            return new EmperorMeshData(result);
        }
    }
}
