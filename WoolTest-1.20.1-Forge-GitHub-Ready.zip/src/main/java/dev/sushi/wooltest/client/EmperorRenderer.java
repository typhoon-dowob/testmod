package dev.sushi.wooltest.client;
import dev.sushi.wooltest.WoolTestMod;
import dev.sushi.wooltest.entity.EmperorEntity;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.client.renderer.entity.layers.ItemInHandLayer;
import net.minecraft.resources.ResourceLocation;
public final class EmperorRenderer extends MobRenderer<EmperorEntity, EmperorModel> {
    private static final ResourceLocation TEXTURE=new ResourceLocation(WoolTestMod.MOD_ID,"textures/entity/emperor.png");
    public EmperorRenderer(EntityRendererProvider.Context context) {
        super(context,new EmperorModel(context.bakeLayer(EmperorModel.LAYER)),0.68F);
        addLayer(new ItemInHandLayer<>(this,context.getItemInHandRenderer()));
        addLayer(new EmperorAuraLayer(this));
    }
    @Override public ResourceLocation getTextureLocation(EmperorEntity entity) { return TEXTURE; }
}
