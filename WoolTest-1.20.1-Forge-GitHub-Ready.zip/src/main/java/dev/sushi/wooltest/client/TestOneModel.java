package dev.sushi.wooltest.client;

import dev.sushi.wooltest.WoolTestMod;
import dev.sushi.wooltest.entity.TestOneEntity;
import net.minecraft.client.model.HierarchicalModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;

/** Dedicated patchwork-doll model. No gameplay state is read or changed here.
 * Geometry is generated from art_source/model1/test_one_model1.json.
 * This class is referenced only by the physical-client event subscriber.
 */
public final class TestOneModel extends HierarchicalModel<TestOneEntity> {
    public static final ModelLayerLocation LAYER_LOCATION = new ModelLayerLocation(
            new ResourceLocation(WoolTestMod.MOD_ID, "test_one_model1"), "main");
    private final ModelPart root;
    private final ModelPart torso;
    private final ModelPart head;
    private final ModelPart rightArm;
    private final ModelPart leftArm;
    private final ModelPart rightForearm;
    private final ModelPart leftForearm;
    private final ModelPart rightLeg;
    private final ModelPart leftLeg;

    public TestOneModel(ModelPart root) {
        this.root = root;
        ModelPart doll = root.getChild("doll");
        this.torso = doll.getChild("torso");
        this.head = torso.getChild("head");
        this.rightArm = torso.getChild("right_arm");
        this.leftArm = torso.getChild("left_arm");
        this.rightForearm = rightArm.getChild("right_forearm");
        this.leftForearm = leftArm.getChild("left_forearm");
        this.rightLeg = doll.getChild("right_leg");
        this.leftLeg = doll.getChild("left_leg");
    }

    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();
        PartDefinition doll = root.addOrReplaceChild("doll", CubeListBuilder.create(),
                PartPose.offset(0.0F, 0.0F, 0.0F));
        PartDefinition torso = doll.addOrReplaceChild("torso", CubeListBuilder.create()
                .texOffs(0, 0).addBox(-5.0F, 0.0F, -3.0F, 10.0F, 11.0F, 6.0F),
                PartPose.offset(0.0F, 3.0F, 0.0F));
        PartDefinition hips = torso.addOrReplaceChild("hips", CubeListBuilder.create()
                .texOffs(33, 0).addBox(-4.0F, 0.0F, -2.5F, 8.0F, 3.0F, 5.0F),
                PartPose.offset(0.0F, 10.0F, 0.0F));
        PartDefinition head = torso.addOrReplaceChild("head", CubeListBuilder.create()
                .texOffs(60, 0).addBox(-5.0F, -10.0F, -4.0F, 10.0F, 10.0F, 8.0F),
                PartPose.offset(0.0F, 0.0F, 0.0F));
        PartDefinition right_button = head.addOrReplaceChild("right_button", CubeListBuilder.create()
                .texOffs(97, 0).addBox(-1.5F, -1.5F, -0.6F, 3.0F, 3.0F, 1.0F),
                PartPose.offset(-2.5F, -6.0F, -4.05F));
        PartDefinition left_button = head.addOrReplaceChild("left_button", CubeListBuilder.create()
                .texOffs(106, 0).addBox(-1.5F, -1.5F, -0.6F, 3.0F, 3.0F, 1.0F),
                PartPose.offset(2.5F, -6.0F, -4.05F));
        PartDefinition folded_seam = head.addOrReplaceChild("folded_seam", CubeListBuilder.create()
                .texOffs(115, 0).addBox(-0.15F, -1.0F, -1.0F, 1.0F, 2.0F, 2.0F),
                PartPose.offset(4.65F, -8.0F, 0.0F));
        PartDefinition badge = torso.addOrReplaceChild("badge", CubeListBuilder.create()
                .texOffs(0, 19).addBox(-3.5F, -2.0F, -0.6F, 7.0F, 5.0F, 1.0F),
                PartPose.offset(0.0F, 3.8F, -3.05F));
        PartDefinition back_patch = torso.addOrReplaceChild("back_patch", CubeListBuilder.create()
                .texOffs(17, 19).addBox(-2.5F, -1.5F, 0.0F, 5.0F, 4.0F, 1.0F),
                PartPose.offset(-0.3F, 5.0F, 2.65F));
        PartDefinition right_arm = torso.addOrReplaceChild("right_arm", CubeListBuilder.create()
                .texOffs(30, 19).addBox(-2.0F, -1.0F, -2.5F, 4.0F, 4.0F, 5.0F)
                .texOffs(49, 19).addBox(-1.5F, 1.0F, -1.5F, 3.0F, 4.0F, 3.0F),
                PartPose.offset(-6.1F, 2.0F, 0.0F));
        PartDefinition right_forearm = right_arm.addOrReplaceChild("right_forearm", CubeListBuilder.create()
                .texOffs(62, 19).addBox(-1.5F, -0.8F, -1.5F, 3.0F, 2.0F, 3.0F)
                .texOffs(75, 19).addBox(-2.0F, 1.0F, -2.0F, 4.0F, 4.0F, 4.0F)
                .texOffs(92, 19).addBox(-2.5F, 4.0F, -2.5F, 5.0F, 1.0F, 5.0F)
                .texOffs(0, 29).addBox(-2.5F, 5.0F, -2.5F, 5.0F, 2.0F, 5.0F),
                PartPose.offset(0.0F, 5.0F, 0.0F));
        PartDefinition left_arm = torso.addOrReplaceChild("left_arm", CubeListBuilder.create()
                .texOffs(21, 29).addBox(-2.0F, -1.0F, -2.5F, 4.0F, 4.0F, 5.0F)
                .texOffs(40, 29).addBox(-1.5F, 1.0F, -1.5F, 3.0F, 4.0F, 3.0F),
                PartPose.offset(6.1F, 2.0F, 0.0F));
        PartDefinition left_forearm = left_arm.addOrReplaceChild("left_forearm", CubeListBuilder.create()
                .texOffs(53, 29).addBox(-1.5F, -0.8F, -1.5F, 3.0F, 2.0F, 3.0F)
                .texOffs(66, 29).addBox(-2.0F, 1.0F, -2.0F, 4.0F, 4.0F, 4.0F)
                .texOffs(83, 29).addBox(-2.5F, 4.0F, -2.5F, 5.0F, 1.0F, 5.0F)
                .texOffs(104, 29).addBox(-2.5F, 5.0F, -2.5F, 5.0F, 2.0F, 5.0F),
                PartPose.offset(0.0F, 5.0F, 0.0F));
        PartDefinition right_leg = doll.addOrReplaceChild("right_leg", CubeListBuilder.create()
                .texOffs(0, 39).addBox(-2.0F, -0.2F, -2.0F, 4.0F, 6.0F, 4.0F)
                .texOffs(17, 39).addBox(-1.5F, 5.0F, -1.5F, 3.0F, 2.0F, 3.0F)
                .texOffs(30, 39).addBox(-2.0F, 6.0F, -3.5F, 4.0F, 3.0F, 6.0F),
                PartPose.offset(-2.5F, 15.0F, 0.0F));
        PartDefinition left_leg = doll.addOrReplaceChild("left_leg", CubeListBuilder.create()
                .texOffs(51, 39).addBox(-2.0F, -0.2F, -2.0F, 4.0F, 6.0F, 4.0F)
                .texOffs(68, 39).addBox(-1.5F, 5.0F, -1.5F, 3.0F, 2.0F, 3.0F)
                .texOffs(81, 39).addBox(-2.0F, 6.0F, -3.5F, 4.0F, 3.0F, 6.0F),
                PartPose.offset(2.5F, 15.0F, 0.0F));
        return LayerDefinition.create(mesh, 128, 128);
    }

    @Override
    public ModelPart root() {
        return root;
    }

    @Override
    public void setupAnim(TestOneEntity entity, float limbSwing, float limbSwingAmount,
                          float ageInTicks, float netHeadYaw, float headPitch) {
        // Reset first: multiple entities share the renderer/model instance.
        root.getAllParts().forEach(ModelPart::resetPose);
        float walk = Mth.clamp(limbSwingAmount, 0.0F, 1.0F);
        float phase = limbSwing * 0.6662F;
        float stride = Mth.cos(phase) * 0.82F * walk;
        float idle = Mth.sin(ageInTicks * 0.065F);
        head.yRot = netHeadYaw * (Mth.PI / 180.0F);
        head.xRot = headPitch * (Mth.PI / 180.0F);
        head.zRot = idle * 0.025F * (1.0F - walk);
        torso.zRot = Mth.cos(phase) * 0.035F * walk;
        rightLeg.xRot = stride;
        leftLeg.xRot = -stride;
        rightArm.xRot = -stride * 0.75F;
        leftArm.xRot = stride * 0.75F;
        // The elbows really bend; no zombie arms-out pose is used.
        rightArm.zRot = 0.035F + idle * 0.012F;
        leftArm.zRot = -0.035F - idle * 0.012F;
        rightForearm.xRot = -0.08F - Math.max(0.0F, stride) * 0.24F;
        leftForearm.xRot = -0.08F - Math.max(0.0F, -stride) * 0.24F;
        if (riding) {
            rightLeg.xRot = -1.15F;
            leftLeg.xRot = -1.15F;
            rightLeg.yRot = 0.22F;
            leftLeg.yRot = -0.22F;
        }
        if (attackTime > 0.0F) {
            float swing = Mth.sin(Mth.sqrt(attackTime) * Mth.TWO_PI);
            torso.yRot = swing * 0.12F;
            rightArm.xRot -= Mth.sin(attackTime * Mth.PI) * 1.55F;
            rightForearm.xRot -= Mth.sin(attackTime * Mth.PI) * 0.25F;
        }
    }
}
