package dev.sushi.wooltest.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import dev.sushi.wooltest.WoolTestMod;
import dev.sushi.wooltest.entity.ImperialCastEntity;
import dev.sushi.wooltest.logic.EmperorRules;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.culling.Frustum;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.phys.Vec3;
import org.joml.Quaternionf;
import org.joml.Vector3f;

/** Full-bright textured sigils and a single beam. No damage or RNG on the client. */
public final class ImperialCastRenderer extends EntityRenderer<ImperialCastEntity> {
    private static final ResourceLocation CIRCLE = new ResourceLocation(WoolTestMod.MOD_ID, "textures/effect/imperial_circle.png");
    private static final ResourceLocation BEAM = new ResourceLocation(WoolTestMod.MOD_ID, "textures/effect/imperial_beam.png");
    private static final ResourceLocation GROUND = new ResourceLocation(WoolTestMod.MOD_ID, "textures/effect/imperial_ground.png");
    private static final int LIGHT = 0xF000F0;
    public ImperialCastRenderer(EntityRendererProvider.Context context) { super(context); }
    @Override public ResourceLocation getTextureLocation(ImperialCastEntity entity) { return CIRCLE; }
    @Override public boolean shouldRender(ImperialCastEntity entity, Frustum frustum,
            double x, double y, double z) {
        // The beam and landing marker extend beyond the tiny, non-colliding entity bounds.
        double dx=entity.getX()-x, dy=entity.getY()-y, dz=entity.getZ()-z;
        return entity.shouldRenderAtSqrDistance(dx*dx + dy*dy + dz*dz);
    }
    @Override public void render(ImperialCastEntity entity, float yaw, float partial,
            PoseStack pose, MultiBufferSource buffers, int packedLight) {
        Vec3 delta = entity.targetPoint().subtract(entity.position());
        double length = delta.length();
        if (length < 0.02D) return;
        Vec3 direction = delta.scale(1.0D/length);
        float fade = entity.isCharging() ? 1.0F : Math.max(0.0F,
                1.0F - (entity.flashTicks() + partial) / EmperorRules.FLASH_TICKS);
        float elapsed = entity.chargeTicks() + (entity.isCharging() ? partial : 0.0F);
        // A full ritual footprint, kept inside the ten-block damage radius.
        // Translucent and depth-tested: does not reveal targets through walls.
        VertexConsumer ground = buffers.getBuffer(RenderType.entityTranslucent(GROUND));
        float progress = Math.min(1.0F, elapsed / EmperorRules.CHARGE_TICKS);
        int groundAlpha = (int)((150 + 55 * progress) * fade);
        pose.pushPose();
        pose.translate(delta.x, delta.y + 0.035D, delta.z);
        horizontalDisc(pose, ground, 9.95F, 1.0F, groundAlpha);
        VertexConsumer warning = buffers.getBuffer(RenderType.entityTranslucent(BEAM));
        perimeter(pose, warning, 10.0F, (int)(230 * fade));
        // Eight satellite seals and connecting spokes, not additional charge stages.
        for (int i=0; i<8; i++) {
            double a=i*Math.PI/4.0D;
            float x=(float)Math.cos(a)*7.3F, z=(float)Math.sin(a)*7.3F;
            groundLine(pose, buffers.getBuffer(RenderType.entityTranslucent(BEAM)), x*0.15F,z*0.15F,x,z,0.06F,(int)(180*fade));
            pose.pushPose(); pose.translate(x,0.012D,z);
            horizontalDisc(pose,buffers.getBuffer(RenderType.entityTranslucent(CIRCLE)),0.95F,progress,(int)(235*fade)); pose.popPose();
        }
        if (!entity.isCharging() && entity.isFullRelease())
            perimeter(pose,buffers.getBuffer(RenderType.entityTranslucent(BEAM)),1.0F+9.0F*(entity.flashTicks()+partial)/EmperorRules.FLASH_TICKS,(int)(245*fade));
        pose.popPose();
        // Caster pedestal and two orbiting tiers make charge state visible on the boss itself.
        pose.pushPose(); pose.translate(0,-entity.footOffset()+0.045D,0);
        horizontalDisc(pose,buffers.getBuffer(RenderType.entityTranslucent(GROUND)),2.1F,1.0F,(int)(195*fade));
        for (int tier=0;tier<2;tier++) {
            pose.pushPose(); pose.translate(0,0.65D+tier*0.8D,0);
            pose.mulPose(new Quaternionf().rotationY((tier==0?1:-1)*(entity.tickCount+partial)*0.035F));
            perimeter(pose,buffers.getBuffer(RenderType.entityTranslucent(BEAM)),1.25F+tier*0.15F,(int)(160*fade)); pose.popPose();
        }
        pose.popPose();
        // The emperor uses one five-second seal; player sword keeps its legacy three seals.
        pose.pushPose();
        pose.mulPose(new Vector3f(0,0,1).rotationTo(new Vector3f(
                (float)direction.x,(float)direction.y,(float)direction.z),new Quaternionf()));
        VertexConsumer sigils = buffers.getBuffer(RenderType.entityTranslucent(CIRCLE));
        int seals = entity.isPlayerOwnedCast() ? 3 : 1;
        for (int ring=0; ring<seals; ring++) {
            float ringProgress = Math.max(0.0F, Math.min(1.0F, (elapsed-ring*100.0F)/100.0F));
            if(ringProgress<=0)continue;
            pose.pushPose(); pose.translate(0,0,entity.sealDistance(ring,length));
            pose.mulPose(new Quaternionf().rotationZ((entity.tickCount+partial)*0.006F));
            disc(pose,sigils,2.8F,ringProgress,(int)(245*fade)); pose.popPose();
        }
        if (!entity.isCharging()) {
            VertexConsumer beam = buffers.getBuffer(RenderType.entityTranslucent(BEAM));
            float from=(float)entity.sealDistance(0,length), to=(float)length;
            float width=0.30F+0.04F*(float)Math.sin((entity.flashTicks()+partial)*2.0F);
            beam(pose,beam,from,to,width*2.1F,(int)(75*fade));
            beam(pose,beam,from,to,width,(int)(245*fade));
        }
        pose.popPose();
        super.render(entity,yaw,partial,pose,buffers,packedLight);
    }
    private static void vertex(PoseStack pose,VertexConsumer out,float x,float y,float z,
            float u,float v,int r,int g,int b,int alpha) {
        var last=pose.last();
        out.vertex(last.pose(),x,y,z).color(r,g,b,alpha).uv(u,v)
                .overlayCoords(OverlayTexture.NO_OVERLAY).uv2(LIGHT)
                .normal(last.normal(),0,0,1).endVertex();
    }
    private static void disc(PoseStack pose,VertexConsumer out,float radius,float progress,int alpha) {
        // Degenerate quads make an exact angular reveal with the quad render type.
        int steps=96;
        for(int i=0;i<steps && i/(float)steps<progress;i++) {
            double a=i*Math.PI*2/steps, b=Math.min((i+1)/(double)steps,progress)*Math.PI*2;
            float x1=(float)Math.cos(a),y1=(float)Math.sin(a),x2=(float)Math.cos(b),y2=(float)Math.sin(b);
            vertex(pose,out,0,0,0,.5F,.5F,255,255,255,alpha);
            vertex(pose,out,x1*radius,y1*radius,0,.5F+x1*.5F,.5F-y1*.5F,255,255,255,alpha);
            vertex(pose,out,x2*radius,y2*radius,0,.5F+x2*.5F,.5F-y2*.5F,255,255,255,alpha);
            vertex(pose,out,0,0,0,.5F,.5F,255,255,255,alpha);
        }
    }
    private static void horizontalDisc(PoseStack pose,VertexConsumer out,float r,float progress,int alpha) {
        pose.pushPose(); pose.mulPose(new Quaternionf().rotationX(-(float)Math.PI/2));
        disc(pose,out,r,progress,alpha); pose.popPose();
    }
    private static void groundLine(PoseStack pose,VertexConsumer out,float x1,float z1,float x2,float z2,float w,int a) {
        float dx=x2-x1,dz=z2-z1,len=(float)Math.sqrt(dx*dx+dz*dz);
        if(len<0.001F)return;
        float nx=-dz/len*w,nz=dx/len*w;
        vertex(pose,out,x1-nx,.015F,z1-nz,0,0,255,200,90,a);
        vertex(pose,out,x1+nx,.015F,z1+nz,1,0,255,200,90,a);
        vertex(pose,out,x2+nx,.015F,z2+nz,1,1,255,200,90,a);
        vertex(pose,out,x2-nx,.015F,z2-nz,0,1,255,200,90,a);
    }
    private static void perimeter(PoseStack pose,VertexConsumer out,float r,int alpha) {
        for(int i=0;i<128;i++) {
            double a=i*Math.PI*2/128,b=(i+1)*Math.PI*2/128;
            float ax=(float)Math.cos(a),az=(float)Math.sin(a),bx=(float)Math.cos(b),bz=(float)Math.sin(b);
            vertex(pose,out,ax*(r-.08F),0,az*(r-.08F),0,0,255,110,65,alpha);
            vertex(pose,out,ax*(r+.08F),0,az*(r+.08F),1,0,255,110,65,alpha);
            vertex(pose,out,bx*(r+.08F),0,bz*(r+.08F),1,1,255,110,65,alpha);
            vertex(pose,out,bx*(r-.08F),0,bz*(r-.08F),0,1,255,110,65,alpha);
        }
    }
    private static void beam(PoseStack pose,VertexConsumer out,float from,float to,float width,int alpha) {
        for(int axis=0;axis<2;axis++) {
            float x=axis==0?width:0,y=axis==1?width:0;
            vertex(pose,out,-x,-y,from,0,0,255,255,255,alpha);
            vertex(pose,out,x,y,from,1,0,255,255,255,alpha);
            vertex(pose,out,x,y,to,1,1,255,255,255,alpha);
            vertex(pose,out,-x,-y,to,0,1,255,255,255,alpha);
        }
    }
}
