package dev.sushi.wooltest.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import dev.sushi.wooltest.WoolTestMod;
import dev.sushi.wooltest.entity.ImperialCastEntity;
import dev.sushi.wooltest.logic.EmperorRules;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.culling.Frustum;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.phys.Vec3;
import org.joml.Quaternionf;
import org.joml.Vector3f;

/** Full-bright textured sigils and a single beam. No damage or RNG on the client. */
public final class ImperialCastRenderer extends EntityRenderer<ImperialCastEntity> {
    private static final ResourceLocation CIRCLE = new ResourceLocation(WoolTestMod.MOD_ID, "textures/effect/imperial_circle.png");
    private static final ResourceLocation BEAM = new ResourceLocation(WoolTestMod.MOD_ID, "textures/effect/imperial_beam.png");
    private static final int LIGHT = 0xF000F0;
    public ImperialCastRenderer(EntityRendererProvider.Context context) { super(context); }
    @Override public ResourceLocation getTextureLocation(ImperialCastEntity entity) { return CIRCLE; }
    @Override public boolean shouldRender(ImperialCastEntity entity, Frustum frustum,
            double x, double y, double z) {
        // The beam and landing marker extend beyond the tiny, non-colliding entity bounds.
        double dx=entity.getX()-x, dy=entity.getY()-y, dz=entity.getZ()-z;
        return entity.shouldRenderAtSqrDistance(dx*dx + dy*dy + dz*dz);
    }
    @Override public void render(ImperialCastEntity entity, float yaw, float partial,
            PoseStack pose, MultiBufferSource buffers, int packedLight) {
        Vec3 delta = entity.targetPoint().subtract(entity.position());
        double length = delta.length();
        if (length < 0.02D) return;
        Vec3 direction = delta.scale(1.0D/length);
        float fade = entity.isCharging() ? 1.0F : Math.max(0.0F,
                1.0F - (entity.flashTicks() + partial) / EmperorRules.FLASH_TICKS);
        float elapsed = entity.chargeTicks() + (entity.isCharging() ? partial : 0.0F);
        // Target warning: a horizontal 10-block-radius perimeter, not a filled damage volume.
        pose.pushPose();
        pose.translate(delta.x, delta.y + 0.025D, delta.z);
        VertexConsumer warning = buffers.getBuffer(RenderType.entityTranslucent(BEAM));
        perimeter(pose, warning, (float)EmperorRules.RADIUS, (int)(170*fade));
        pose.popPose();
        pose.pushPose();
        pose.mulPose(new Vector3f(0,0,1).rotationTo(new Vector3f(
                (float)direction.x,(float)direction.y,(float)direction.z),new Quaternionf()));
        VertexConsumer sigils = buffers.getBuffer(RenderType.entityTranslucent(CIRCLE));
        for (int index=0; index<3; index++) {
            float progress = Math.max(0,Math.min(1,(elapsed-index*100)/100.0F));
            if (progress <= 0) continue;
            pose.pushPose();
            pose.translate(0,0,EmperorRules.circleDistance(index,length));
            pose.mulPose(new Quaternionf().rotationZ((index%2==0?1:-1)
                    *(entity.tickCount+partial)*0.008F));
            disc(pose,sigils,1.1F+index*0.18F,progress,(int)(235*fade));
            pose.popPose();
        }
        if (!entity.isCharging()) {
            VertexConsumer beam = buffers.getBuffer(RenderType.entityTranslucent(BEAM));
            float from=(float)EmperorRules.circleDistance(0,length), to=(float)length;
            float width=0.30F+0.04F*(float)Math.sin((entity.flashTicks()+partial)*2.0F);
            beam(pose,beam,from,to,width,(int)(245*fade));
        }
        pose.popPose();
        super.render(entity,yaw,partial,pose,buffers,packedLight);
    }
    private static void vertex(PoseStack pose,VertexConsumer out,float x,float y,float z,
            float u,float v,int r,int g,int b,int alpha) {
        var last=pose.last();
        out.vertex(last.pose(),x,y,z).color(r,g,b,alpha).uv(u,v)
                .overlayCoords(OverlayTexture.NO_OVERLAY).uv2(LIGHT)
                .normal(last.normal(),0,0,1).endVertex();
    }
    private static void disc(PoseStack pose,VertexConsumer out,float radius,float progress,int alpha) {
        // Degenerate quads make an exact angular reveal with the quad render type.
        int steps=96;
        for(int i=0;i<steps && i/(float)steps<progress;i++) {
            double a=i*Math.PI*2/steps, b=Math.min((i+1)/(double)steps,progress)*Math.PI*2;
            float x1=(float)Math.cos(a),y1=(float)Math.sin(a),x2=(float)Math.cos(b),y2=(float)Math.sin(b);
            vertex(pose,out,0,0,0,.5F,.5F,255,255,255,alpha);
            vertex(pose,out,x1*radius,y1*radius,0,.5F+x1*.5F,.5F-y1*.5F,255,255,255,alpha);
            vertex(pose,out,x2*radius,y2*radius,0,.5F+x2*.5F,.5F-y2*.5F,255,255,255,alpha);
            vertex(pose,out,0,0,0,.5F,.5F,255,255,255,alpha);
        }
    }
    private static void perimeter(PoseStack pose,VertexConsumer out,float r,int alpha) {
        for(int i=0;i<128;i++) {
            double a=i*Math.PI*2/128,b=(i+1)*Math.PI*2/128;
            float ax=(float)Math.cos(a),az=(float)Math.sin(a),bx=(float)Math.cos(b),bz=(float)Math.sin(b);
            vertex(pose,out,ax*(r-.08F),0,az*(r-.08F),0,0,255,110,65,alpha);
            vertex(pose,out,ax*(r+.08F),0,az*(r+.08F),1,0,255,110,65,alpha);
            vertex(pose,out,bx*(r+.08F),0,bz*(r+.08F),1,1,255,110,65,alpha);
            vertex(pose,out,bx*(r-.08F),0,bz*(r-.08F),0,1,255,110,65,alpha);
        }
    }
    private static void beam(PoseStack pose,VertexConsumer out,float from,float to,float width,int alpha) {
        for(int axis=0;axis<2;axis++) {
            float x=axis==0?width:0,y=axis==1?width:0;
            vertex(pose,out,-x,-y,from,0,0,255,255,255,alpha);
            vertex(pose,out,x,y,from,1,0,255,255,255,alpha);
            vertex(pose,out,x,y,to,1,1,255,255,255,alpha);
            vertex(pose,out,-x,-y,to,0,1,255,255,255,alpha);
        }
    }
}
