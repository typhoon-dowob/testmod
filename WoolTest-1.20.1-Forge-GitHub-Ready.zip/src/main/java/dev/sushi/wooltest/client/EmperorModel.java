package dev.sushi.wooltest.client;
import com.mojang.blaze3d.vertex.PoseStack;
import dev.sushi.wooltest.WoolTestMod;
import dev.sushi.wooltest.entity.EmperorEntity;
import net.minecraft.client.model.HierarchicalModel;
import net.minecraft.client.model.ArmedModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.HumanoidArm;
public final class EmperorModel extends HierarchicalModel<EmperorEntity> implements ArmedModel {
    public static final ModelLayerLocation LAYER = new ModelLayerLocation(new ResourceLocation(WoolTestMod.MOD_ID, "emperor"), "main");
    private final ModelPart root, torso, head, rightArm, leftArm, rightLeg, leftLeg;
    public EmperorModel(ModelPart root) {
        this.root=root; torso=root.getChild("torso"); head=torso.getChild("head");
        rightArm=torso.getChild("right_arm"); leftArm=torso.getChild("left_arm");
        rightLeg=root.getChild("right_leg"); leftLeg=root.getChild("left_leg");
    }
    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh=new MeshDefinition(); PartDefinition root=mesh.getRoot();
        PartDefinition torso = root.addOrReplaceChild("torso", CubeListBuilder.create()
                .texOffs(0, 0).addBox(-8.0F, 0.0F, -5.0F, 16.0F, 17.0F, 10.0F)
                .texOffs(53, 0).addBox(-6.0F, -1.0F, -5.5F, 12.0F, 3.0F, 11.0F)
                .texOffs(100, 0).addBox(-9.0F, 14.0F, -6.0F, 18.0F, 3.0F, 12.0F)
                .texOffs(161, 0).addBox(-3.0F, 5.0F, -6.0F, 6.0F, 7.0F, 1.0F)
                .texOffs(176, 0).addBox(-10.0F, 17.0F, -6.0F, 20.0F, 10.0F, 12.0F)
                .texOffs(0, 28).addBox(-8.0F, 24.0F, -7.0F, 16.0F, 3.0F, 1.0F)
                , PartPose.offset(0.0F, -8.0F, 0.0F));
        PartDefinition head = torso.addOrReplaceChild("head", CubeListBuilder.create()
                .texOffs(35, 28).addBox(-5.0F, -11.0F, -5.0F, 10.0F, 11.0F, 10.0F)
                .texOffs(76, 28).addBox(-3.0F, -3.0F, -6.0F, 6.0F, 5.0F, 1.0F)
                .texOffs(91, 28).addBox(-6.0F, -14.0F, -6.0F, 12.0F, 3.0F, 12.0F)
                .texOffs(140, 28).addBox(-9.0F, -16.0F, -7.0F, 18.0F, 2.0F, 14.0F)
                .texOffs(205, 28).addBox(-2.0F, -13.0F, -6.2F, 4.0F, 3.0F, 1.0F)
                , PartPose.offset(0.0F, 0.0F, 0.0F));
        PartDefinition bead_0_0 = head.addOrReplaceChild("bead_0_0", CubeListBuilder.create()
                .texOffs(216, 28).addBox(0.0F, 0.0F, 0.0F, 1.0F, 5.0F, 1.0F)
                , PartPose.offset(-7.0F, -14.0F, -7.0F));
        PartDefinition bead_0_13 = head.addOrReplaceChild("bead_0_13", CubeListBuilder.create()
                .texOffs(221, 28).addBox(0.0F, 0.0F, 0.0F, 1.0F, 5.0F, 1.0F)
                , PartPose.offset(-7.0F, -14.0F, 6.0F));
        PartDefinition bead_2_0 = head.addOrReplaceChild("bead_2_0", CubeListBuilder.create()
                .texOffs(226, 28).addBox(0.0F, 0.0F, 0.0F, 1.0F, 5.0F, 1.0F)
                , PartPose.offset(-5.0F, -14.0F, -7.0F));
        PartDefinition bead_2_13 = head.addOrReplaceChild("bead_2_13", CubeListBuilder.create()
                .texOffs(231, 28).addBox(0.0F, 0.0F, 0.0F, 1.0F, 5.0F, 1.0F)
                , PartPose.offset(-5.0F, -14.0F, 6.0F));
        PartDefinition bead_4_0 = head.addOrReplaceChild("bead_4_0", CubeListBuilder.create()
                .texOffs(236, 28).addBox(0.0F, 0.0F, 0.0F, 1.0F, 5.0F, 1.0F)
                , PartPose.offset(-3.0F, -14.0F, -7.0F));
        PartDefinition bead_4_13 = head.addOrReplaceChild("bead_4_13", CubeListBuilder.create()
                .texOffs(241, 28).addBox(0.0F, 0.0F, 0.0F, 1.0F, 5.0F, 1.0F)
                , PartPose.offset(-3.0F, -14.0F, 6.0F));
        PartDefinition bead_6_0 = head.addOrReplaceChild("bead_6_0", CubeListBuilder.create()
                .texOffs(246, 28).addBox(0.0F, 0.0F, 0.0F, 1.0F, 5.0F, 1.0F)
                , PartPose.offset(-1.0F, -14.0F, -7.0F));
        PartDefinition bead_6_13 = head.addOrReplaceChild("bead_6_13", CubeListBuilder.create()
                .texOffs(251, 28).addBox(0.0F, 0.0F, 0.0F, 1.0F, 5.0F, 1.0F)
                , PartPose.offset(-1.0F, -14.0F, 6.0F));
        PartDefinition bead_8_0 = head.addOrReplaceChild("bead_8_0", CubeListBuilder.create()
                .texOffs(0, 50).addBox(0.0F, 0.0F, 0.0F, 1.0F, 5.0F, 1.0F)
                , PartPose.offset(1.0F, -14.0F, -7.0F));
        PartDefinition bead_8_13 = head.addOrReplaceChild("bead_8_13", CubeListBuilder.create()
                .texOffs(5, 50).addBox(0.0F, 0.0F, 0.0F, 1.0F, 5.0F, 1.0F)
                , PartPose.offset(1.0F, -14.0F, 6.0F));
        PartDefinition bead_10_0 = head.addOrReplaceChild("bead_10_0", CubeListBuilder.create()
                .texOffs(10, 50).addBox(0.0F, 0.0F, 0.0F, 1.0F, 5.0F, 1.0F)
                , PartPose.offset(3.0F, -14.0F, -7.0F));
        PartDefinition bead_10_13 = head.addOrReplaceChild("bead_10_13", CubeListBuilder.create()
                .texOffs(15, 50).addBox(0.0F, 0.0F, 0.0F, 1.0F, 5.0F, 1.0F)
                , PartPose.offset(3.0F, -14.0F, 6.0F));
        PartDefinition bead_12_0 = head.addOrReplaceChild("bead_12_0", CubeListBuilder.create()
                .texOffs(20, 50).addBox(0.0F, 0.0F, 0.0F, 1.0F, 5.0F, 1.0F)
                , PartPose.offset(5.0F, -14.0F, -7.0F));
        PartDefinition bead_12_13 = head.addOrReplaceChild("bead_12_13", CubeListBuilder.create()
                .texOffs(25, 50).addBox(0.0F, 0.0F, 0.0F, 1.0F, 5.0F, 1.0F)
                , PartPose.offset(5.0F, -14.0F, 6.0F));
        PartDefinition bead_14_0 = head.addOrReplaceChild("bead_14_0", CubeListBuilder.create()
                .texOffs(30, 50).addBox(0.0F, 0.0F, 0.0F, 1.0F, 5.0F, 1.0F)
                , PartPose.offset(7.0F, -14.0F, -7.0F));
        PartDefinition bead_14_13 = head.addOrReplaceChild("bead_14_13", CubeListBuilder.create()
                .texOffs(35, 50).addBox(0.0F, 0.0F, 0.0F, 1.0F, 5.0F, 1.0F)
                , PartPose.offset(7.0F, -14.0F, 6.0F));
        PartDefinition right_arm = torso.addOrReplaceChild("right_arm", CubeListBuilder.create()
                .texOffs(40, 50).addBox(-4.0F, -1.0F, -5.0F, 8.0F, 11.0F, 10.0F)
                .texOffs(77, 50).addBox(-4.0F, 10.0F, -5.0F, 8.0F, 3.0F, 10.0F)
                .texOffs(114, 50).addBox(-2.0F, 13.0F, -2.0F, 4.0F, 4.0F, 4.0F)
                , PartPose.offset(-12.0F, 2.0F, 0.0F));
        PartDefinition right_leg = root.addOrReplaceChild("right_leg", CubeListBuilder.create()
                .texOffs(131, 50).addBox(-3.0F, 0.0F, -3.0F, 6.0F, 3.0F, 6.0F)
                .texOffs(156, 50).addBox(-3.0F, 3.0F, -5.0F, 6.0F, 4.0F, 9.0F)
                , PartPose.offset(-5.0F, 17.0F, 0.0F));
        PartDefinition left_arm = torso.addOrReplaceChild("left_arm", CubeListBuilder.create()
                .texOffs(187, 50).addBox(-4.0F, -1.0F, -5.0F, 8.0F, 11.0F, 10.0F)
                .texOffs(0, 72).addBox(-4.0F, 10.0F, -5.0F, 8.0F, 3.0F, 10.0F)
                .texOffs(37, 72).addBox(-2.0F, 13.0F, -2.0F, 4.0F, 4.0F, 4.0F)
                , PartPose.offset(12.0F, 2.0F, 0.0F));
        PartDefinition left_leg = root.addOrReplaceChild("left_leg", CubeListBuilder.create()
                .texOffs(54, 72).addBox(-3.0F, 0.0F, -3.0F, 6.0F, 3.0F, 6.0F)
                .texOffs(79, 72).addBox(-3.0F, 3.0F, -5.0F, 6.0F, 4.0F, 9.0F)
                , PartPose.offset(5.0F, 17.0F, 0.0F));
        return LayerDefinition.create(mesh, 256, 256);
    }
    @Override public ModelPart root() { return root; }
    @Override public void setupAnim(EmperorEntity entity,float swing,float amount,float age,float yaw,float pitch) {
        root.getAllParts().forEach(ModelPart::resetPose);
        head.yRot=Mth.clamp(yaw,-45,45)*Mth.DEG_TO_RAD;
        head.xRot=Mth.clamp(pitch,-20,20)*Mth.DEG_TO_RAD;
        float stride=Mth.cos(swing*0.6662F)*0.55F*amount;
        rightLeg.xRot=stride; leftLeg.xRot=-stride;
        rightArm.xRot=-stride*0.4F-0.15F; leftArm.xRot=stride*0.4F;
        if(entity.isChargingSpell()) {
            rightArm.xRot=-1.15F; leftArm.xRot=-0.95F;
            rightArm.zRot=0.12F; leftArm.zRot=-0.12F;
        } else if(attackTime>0) {
            rightArm.xRot-=Mth.sin(Mth.sqrt(attackTime)*Mth.PI)*1.3F;
        }
    }
    @Override public void translateToHand(HumanoidArm arm,PoseStack pose) {
        root.translateAndRotate(pose); torso.translateAndRotate(pose);
        (arm==HumanoidArm.RIGHT?rightArm:leftArm).translateAndRotate(pose);
        pose.translate(0.0D,5.0D/16.0D,0.0D);
    }
}
