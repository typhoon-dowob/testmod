package dev.sushi.wooltest.client;
import com.mojang.blaze3d.vertex.PoseStack;
import dev.sushi.wooltest.WoolTestMod;
import dev.sushi.wooltest.entity.EmperorEntity;
import net.minecraft.client.model.HierarchicalModel;
import net.minecraft.client.model.ArmedModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.HumanoidArm;
/** Emperor 3: individually fitted proportions; fixed 2 x 2 x 3 gameplay bounds are unchanged. */
public final class EmperorModel extends HierarchicalModel<EmperorEntity> implements ArmedModel {
    public static final ModelLayerLocation LAYER = new ModelLayerLocation(new ResourceLocation(WoolTestMod.MOD_ID, "emperor"), "main");
    private final ModelPart root, torso, head, rightArm, leftArm, rightLeg, leftLeg;
    public EmperorModel(ModelPart root) {
        this.root=root; torso=root.getChild("torso"); head=torso.getChild("head");
        rightArm=torso.getChild("right_arm"); leftArm=torso.getChild("left_arm");
        rightLeg=root.getChild("right_leg"); leftLeg=root.getChild("left_leg");
    }
    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh=new MeshDefinition(); PartDefinition root=mesh.getRoot();
        PartDefinition torso = root.addOrReplaceChild("torso", CubeListBuilder.create()
                .texOffs(0, 0).addBox(-5.5F, 0.0F, -3.5F, 11.0F, 10.0F, 7.0F)
                .texOffs(37, 0).addBox(-5.0F, -1.0F, -4.5F, 10.0F, 3.0F, 9.0F)
                .texOffs(76, 0).addBox(-5.5F, 15.0F, -3.5F, 11.0F, 2.0F, 7.0F)
                .texOffs(113, 0).addBox(-2.0F, 4.0F, -4.5F, 4.0F, 6.0F, 1.0F)
                .texOffs(124, 0).addBox(-6.5F, 17.0F, -4.0F, 13.0F, 5.0F, 8.0F)
                .texOffs(167, 0).addBox(-6.5F, 25.0F, -5.5F, 13.0F, 2.0F, 1.0F)
                .texOffs(196, 0).addBox(-4.5F, 10.0F, -3.0F, 9.0F, 7.0F, 6.0F)
                .texOffs(0, 18).addBox(-7.0F, 22.0F, -4.5F, 14.0F, 5.0F, 9.0F)
                , PartPose.offset(0.0F, -8.0F, 0.0F));
        PartDefinition head = torso.addOrReplaceChild("head", CubeListBuilder.create()
                .texOffs(47, 18).addBox(-4.0F, -11.0F, -4.0F, 8.0F, 11.0F, 8.0F)
                .texOffs(80, 18).addBox(-2.0F, -3.0F, -5.0F, 4.0F, 5.0F, 1.0F)
                .texOffs(91, 18).addBox(-5.0F, -14.0F, -5.0F, 10.0F, 3.0F, 10.0F)
                .texOffs(132, 18).addBox(-7.0F, -16.0F, -6.0F, 14.0F, 2.0F, 12.0F)
                .texOffs(185, 18).addBox(-1.5F, -13.0F, -5.2F, 3.0F, 3.0F, 1.0F)
                , PartPose.offset(0.0F, 0.0F, 0.0F));
        PartDefinition bead_0_0 = head.addOrReplaceChild("bead_0_0", CubeListBuilder.create()
                .texOffs(194, 18).addBox(-0.5F, 0.0F, -0.5F, 1.0F, 1.0F, 1.0F)
                .texOffs(199, 18).addBox(-0.5F, 1.0F, -0.5F, 1.0F, 1.0F, 1.0F)
                .texOffs(204, 18).addBox(-0.5F, 2.0F, -0.5F, 1.0F, 1.0F, 1.0F)
                .texOffs(209, 18).addBox(-0.5F, 3.0F, -0.5F, 1.0F, 1.0F, 1.0F)
                .texOffs(214, 18).addBox(-0.5F, 4.0F, -0.5F, 1.0F, 1.0F, 1.0F)
                , PartPose.offset(-5.5F, -14.0F, -5.5F));
        PartDefinition bead_0_13 = head.addOrReplaceChild("bead_0_13", CubeListBuilder.create()
                .texOffs(219, 18).addBox(-0.5F, 0.0F, -0.5F, 1.0F, 1.0F, 1.0F)
                .texOffs(224, 18).addBox(-0.5F, 1.0F, -0.5F, 1.0F, 1.0F, 1.0F)
                .texOffs(229, 18).addBox(-0.5F, 2.0F, -0.5F, 1.0F, 1.0F, 1.0F)
                .texOffs(234, 18).addBox(-0.5F, 3.0F, -0.5F, 1.0F, 1.0F, 1.0F)
                .texOffs(239, 18).addBox(-0.5F, 4.0F, -0.5F, 1.0F, 1.0F, 1.0F)
                , PartPose.offset(-5.5F, -14.0F, 5.5F));
        PartDefinition bead_3_0 = head.addOrReplaceChild("bead_3_0", CubeListBuilder.create()
                .texOffs(244, 18).addBox(-0.5F, 0.0F, -0.5F, 1.0F, 1.0F, 1.0F)
                .texOffs(249, 18).addBox(-0.5F, 1.0F, -0.5F, 1.0F, 1.0F, 1.0F)
                .texOffs(0, 38).addBox(-0.5F, 2.0F, -0.5F, 1.0F, 1.0F, 1.0F)
                .texOffs(5, 38).addBox(-0.5F, 3.0F, -0.5F, 1.0F, 1.0F, 1.0F)
                .texOffs(10, 38).addBox(-0.5F, 4.0F, -0.5F, 1.0F, 1.0F, 1.0F)
                , PartPose.offset(-3.3F, -14.0F, -5.5F));
        PartDefinition bead_3_13 = head.addOrReplaceChild("bead_3_13", CubeListBuilder.create()
                .texOffs(15, 38).addBox(-0.5F, 0.0F, -0.5F, 1.0F, 1.0F, 1.0F)
                .texOffs(20, 38).addBox(-0.5F, 1.0F, -0.5F, 1.0F, 1.0F, 1.0F)
                .texOffs(25, 38).addBox(-0.5F, 2.0F, -0.5F, 1.0F, 1.0F, 1.0F)
                .texOffs(30, 38).addBox(-0.5F, 3.0F, -0.5F, 1.0F, 1.0F, 1.0F)
                .texOffs(35, 38).addBox(-0.5F, 4.0F, -0.5F, 1.0F, 1.0F, 1.0F)
                , PartPose.offset(-3.3F, -14.0F, 5.5F));
        PartDefinition bead_6_0 = head.addOrReplaceChild("bead_6_0", CubeListBuilder.create()
                .texOffs(40, 38).addBox(-0.5F, 0.0F, -0.5F, 1.0F, 1.0F, 1.0F)
                .texOffs(45, 38).addBox(-0.5F, 1.0F, -0.5F, 1.0F, 1.0F, 1.0F)
                .texOffs(50, 38).addBox(-0.5F, 2.0F, -0.5F, 1.0F, 1.0F, 1.0F)
                .texOffs(55, 38).addBox(-0.5F, 3.0F, -0.5F, 1.0F, 1.0F, 1.0F)
                .texOffs(60, 38).addBox(-0.5F, 4.0F, -0.5F, 1.0F, 1.0F, 1.0F)
                , PartPose.offset(-1.1F, -14.0F, -5.5F));
        PartDefinition bead_6_13 = head.addOrReplaceChild("bead_6_13", CubeListBuilder.create()
                .texOffs(65, 38).addBox(-0.5F, 0.0F, -0.5F, 1.0F, 1.0F, 1.0F)
                .texOffs(70, 38).addBox(-0.5F, 1.0F, -0.5F, 1.0F, 1.0F, 1.0F)
                .texOffs(75, 38).addBox(-0.5F, 2.0F, -0.5F, 1.0F, 1.0F, 1.0F)
                .texOffs(80, 38).addBox(-0.5F, 3.0F, -0.5F, 1.0F, 1.0F, 1.0F)
                .texOffs(85, 38).addBox(-0.5F, 4.0F, -0.5F, 1.0F, 1.0F, 1.0F)
                , PartPose.offset(-1.1F, -14.0F, 5.5F));
        PartDefinition bead_9_0 = head.addOrReplaceChild("bead_9_0", CubeListBuilder.create()
                .texOffs(90, 38).addBox(-0.5F, 0.0F, -0.5F, 1.0F, 1.0F, 1.0F)
                .texOffs(95, 38).addBox(-0.5F, 1.0F, -0.5F, 1.0F, 1.0F, 1.0F)
                .texOffs(100, 38).addBox(-0.5F, 2.0F, -0.5F, 1.0F, 1.0F, 1.0F)
                .texOffs(105, 38).addBox(-0.5F, 3.0F, -0.5F, 1.0F, 1.0F, 1.0F)
                .texOffs(110, 38).addBox(-0.5F, 4.0F, -0.5F, 1.0F, 1.0F, 1.0F)
                , PartPose.offset(1.1F, -14.0F, -5.5F));
        PartDefinition bead_9_13 = head.addOrReplaceChild("bead_9_13", CubeListBuilder.create()
                .texOffs(115, 38).addBox(-0.5F, 0.0F, -0.5F, 1.0F, 1.0F, 1.0F)
                .texOffs(120, 38).addBox(-0.5F, 1.0F, -0.5F, 1.0F, 1.0F, 1.0F)
                .texOffs(125, 38).addBox(-0.5F, 2.0F, -0.5F, 1.0F, 1.0F, 1.0F)
                .texOffs(130, 38).addBox(-0.5F, 3.0F, -0.5F, 1.0F, 1.0F, 1.0F)
                .texOffs(135, 38).addBox(-0.5F, 4.0F, -0.5F, 1.0F, 1.0F, 1.0F)
                , PartPose.offset(1.1F, -14.0F, 5.5F));
        PartDefinition bead_12_0 = head.addOrReplaceChild("bead_12_0", CubeListBuilder.create()
                .texOffs(140, 38).addBox(-0.5F, 0.0F, -0.5F, 1.0F, 1.0F, 1.0F)
                .texOffs(145, 38).addBox(-0.5F, 1.0F, -0.5F, 1.0F, 1.0F, 1.0F)
                .texOffs(150, 38).addBox(-0.5F, 2.0F, -0.5F, 1.0F, 1.0F, 1.0F)
                .texOffs(155, 38).addBox(-0.5F, 3.0F, -0.5F, 1.0F, 1.0F, 1.0F)
                .texOffs(160, 38).addBox(-0.5F, 4.0F, -0.5F, 1.0F, 1.0F, 1.0F)
                , PartPose.offset(3.3F, -14.0F, -5.5F));
        PartDefinition bead_12_13 = head.addOrReplaceChild("bead_12_13", CubeListBuilder.create()
                .texOffs(165, 38).addBox(-0.5F, 0.0F, -0.5F, 1.0F, 1.0F, 1.0F)
                .texOffs(170, 38).addBox(-0.5F, 1.0F, -0.5F, 1.0F, 1.0F, 1.0F)
                .texOffs(175, 38).addBox(-0.5F, 2.0F, -0.5F, 1.0F, 1.0F, 1.0F)
                .texOffs(180, 38).addBox(-0.5F, 3.0F, -0.5F, 1.0F, 1.0F, 1.0F)
                .texOffs(185, 38).addBox(-0.5F, 4.0F, -0.5F, 1.0F, 1.0F, 1.0F)
                , PartPose.offset(3.3F, -14.0F, 5.5F));
        PartDefinition bead_15_0 = head.addOrReplaceChild("bead_15_0", CubeListBuilder.create()
                .texOffs(190, 38).addBox(-0.5F, 0.0F, -0.5F, 1.0F, 1.0F, 1.0F)
                .texOffs(195, 38).addBox(-0.5F, 1.0F, -0.5F, 1.0F, 1.0F, 1.0F)
                .texOffs(200, 38).addBox(-0.5F, 2.0F, -0.5F, 1.0F, 1.0F, 1.0F)
                .texOffs(205, 38).addBox(-0.5F, 3.0F, -0.5F, 1.0F, 1.0F, 1.0F)
                .texOffs(210, 38).addBox(-0.5F, 4.0F, -0.5F, 1.0F, 1.0F, 1.0F)
                , PartPose.offset(5.5F, -14.0F, -5.5F));
        PartDefinition bead_15_13 = head.addOrReplaceChild("bead_15_13", CubeListBuilder.create()
                .texOffs(215, 38).addBox(-0.5F, 0.0F, -0.5F, 1.0F, 1.0F, 1.0F)
                .texOffs(220, 38).addBox(-0.5F, 1.0F, -0.5F, 1.0F, 1.0F, 1.0F)
                .texOffs(225, 38).addBox(-0.5F, 2.0F, -0.5F, 1.0F, 1.0F, 1.0F)
                .texOffs(230, 38).addBox(-0.5F, 3.0F, -0.5F, 1.0F, 1.0F, 1.0F)
                .texOffs(235, 38).addBox(-0.5F, 4.0F, -0.5F, 1.0F, 1.0F, 1.0F)
                , PartPose.offset(5.5F, -14.0F, 5.5F));
        PartDefinition right_arm = torso.addOrReplaceChild("right_arm", CubeListBuilder.create()
                .texOffs(0, 41).addBox(-3.0F, -1.0F, -3.5F, 6.0F, 11.0F, 7.0F)
                .texOffs(27, 41).addBox(-3.0F, 10.0F, -3.5F, 6.0F, 3.0F, 7.0F)
                .texOffs(54, 41).addBox(-1.5F, 13.0F, -1.5F, 3.0F, 4.0F, 3.0F)
                .texOffs(67, 41).addBox(-3.5F, -3.0F, -3.5F, 7.0F, 2.0F, 7.0F)
                .texOffs(96, 41).addBox(-2.5F, -4.0F, -2.5F, 5.0F, 1.0F, 5.0F)
                .texOffs(117, 41).addBox(-2.0F, 6.0F, -4.5F, 4.0F, 4.0F, 1.0F)
                .texOffs(128, 41).addBox(-2.0F, 11.0F, -4.5F, 4.0F, 2.0F, 1.0F)
                , PartPose.offset(-8.5F, 2.0F, 0.0F));
        PartDefinition right_leg = root.addOrReplaceChild("right_leg", CubeListBuilder.create()
                .texOffs(139, 41).addBox(-2.0F, 0.0F, -2.0F, 4.0F, 3.0F, 4.0F)
                .texOffs(156, 41).addBox(-2.0F, 3.0F, -4.0F, 4.0F, 4.0F, 7.0F)
                , PartPose.offset(-3.5F, 17.0F, 0.0F));
        PartDefinition left_arm = torso.addOrReplaceChild("left_arm", CubeListBuilder.create()
                .texOffs(179, 41).addBox(-3.0F, -1.0F, -3.5F, 6.0F, 11.0F, 7.0F)
                .texOffs(206, 41).addBox(-3.0F, 10.0F, -3.5F, 6.0F, 3.0F, 7.0F)
                .texOffs(233, 41).addBox(-1.5F, 13.0F, -1.5F, 3.0F, 4.0F, 3.0F)
                .texOffs(0, 60).addBox(-3.5F, -3.0F, -3.5F, 7.0F, 2.0F, 7.0F)
                .texOffs(29, 60).addBox(-2.5F, -4.0F, -2.5F, 5.0F, 1.0F, 5.0F)
                .texOffs(50, 60).addBox(-2.0F, 6.0F, -4.5F, 4.0F, 4.0F, 1.0F)
                .texOffs(61, 60).addBox(-2.0F, 11.0F, -4.5F, 4.0F, 2.0F, 1.0F)
                , PartPose.offset(8.5F, 2.0F, 0.0F));
        PartDefinition left_leg = root.addOrReplaceChild("left_leg", CubeListBuilder.create()
                .texOffs(72, 60).addBox(-2.0F, 0.0F, -2.0F, 4.0F, 3.0F, 4.0F)
                .texOffs(89, 60).addBox(-2.0F, 3.0F, -4.0F, 4.0F, 4.0F, 7.0F)
                , PartPose.offset(3.5F, 17.0F, 0.0F));
        PartDefinition cape = torso.addOrReplaceChild("cape", CubeListBuilder.create()
                .texOffs(112, 60).addBox(-6.5F, 0.0F, 3.5F, 13.0F, 22.0F, 2.0F)
                .texOffs(143, 60).addBox(-7.5F, 1.0F, 3.5F, 1.0F, 20.0F, 2.0F)
                .texOffs(150, 60).addBox(6.5F, 1.0F, 3.5F, 1.0F, 20.0F, 2.0F)
                .texOffs(157, 60).addBox(-6.5F, 22.0F, 3.5F, 13.0F, 1.0F, 2.0F)
                , PartPose.offset(0.0F, 1.0F, 0.0F));
        PartDefinition pendant_left = torso.addOrReplaceChild("pendant_left", CubeListBuilder.create()
                .texOffs(188, 60).addBox(-0.5F, 0.0F, 0.0F, 1.0F, 6.0F, 2.0F)
                .texOffs(195, 60).addBox(-1.5F, 5.0F, -0.5F, 3.0F, 3.0F, 2.0F)
                .texOffs(206, 60).addBox(-0.5F, 8.0F, 0.0F, 1.0F, 2.0F, 1.0F)
                , PartPose.offset(5.5F, 16.0F, -4.6F));
        PartDefinition pendant_right = torso.addOrReplaceChild("pendant_right", CubeListBuilder.create()
                .texOffs(211, 60).addBox(-0.5F, 0.0F, 0.0F, 1.0F, 6.0F, 2.0F)
                .texOffs(218, 60).addBox(-1.5F, 5.0F, -0.5F, 3.0F, 3.0F, 2.0F)
                .texOffs(229, 60).addBox(-0.5F, 8.0F, 0.0F, 1.0F, 2.0F, 1.0F)
                , PartPose.offset(-5.5F, 16.0F, -4.6F));
        PartDefinition front_skirt = torso.addOrReplaceChild("front_skirt", CubeListBuilder.create()
                .texOffs(234, 60).addBox(-3.0F, 0.0F, 0.0F, 6.0F, 9.0F, 2.0F)
                .texOffs(0, 85).addBox(-4.0F, 0.0F, 0.0F, 1.0F, 9.0F, 2.0F)
                .texOffs(7, 85).addBox(3.0F, 0.0F, 0.0F, 1.0F, 9.0F, 2.0F)
                .texOffs(14, 85).addBox(-3.0F, 9.0F, 0.0F, 6.0F, 1.0F, 2.0F)
                , PartPose.offset(0.0F, 17.0F, -5.7F));
        PartDefinition crown_trim = head.addOrReplaceChild("crown_trim", CubeListBuilder.create()
                .texOffs(31, 85).addBox(-6.0F, -15.0F, -6.05F, 12.0F, 1.0F, 1.0F)
                .texOffs(58, 85).addBox(-6.0F, -15.0F, 5.05F, 12.0F, 1.0F, 1.0F)
                .texOffs(85, 85).addBox(-6.0F, -14.0F, -5.5F, 12.0F, 1.0F, 11.0F)
                , PartPose.offset(0.0F, 0.0F, 0.0F));
        PartDefinition beard_tip = head.addOrReplaceChild("beard_tip", CubeListBuilder.create()
                .texOffs(132, 85).addBox(-1.5F, 0.0F, 0.0F, 3.0F, 3.0F, 1.0F)
                .texOffs(141, 85).addBox(-0.5F, 3.0F, 0.0F, 1.0F, 2.0F, 1.0F)
                , PartPose.offset(0.0F, 1.0F, -5.2F));
        return LayerDefinition.create(mesh, 256, 256);
    }
    @Override public ModelPart root() { return root; }
    @Override public void setupAnim(EmperorEntity entity,float swing,float amount,float age,float yaw,float pitch) {
        root.getAllParts().forEach(ModelPart::resetPose);
        head.yRot=Mth.clamp(yaw,-45,45)*Mth.DEG_TO_RAD;
        head.xRot=Mth.clamp(pitch,-20,20)*Mth.DEG_TO_RAD;
        float stride=Mth.cos(swing*0.6662F)*0.55F*amount;
        rightLeg.xRot=stride; leftLeg.xRot=-stride;
        rightArm.xRot=-stride*0.4F-0.15F; leftArm.xRot=stride*0.4F;
        if(entity.isChargingSpell()) {
            rightArm.xRot=-1.15F; leftArm.xRot=-0.95F;
            rightArm.zRot=0.12F; leftArm.zRot=-0.12F;
        } else if(attackTime>0) {
            rightArm.xRot-=Mth.sin(Mth.sqrt(attackTime)*Mth.PI)*1.3F;
        }
    }
    @Override public void translateToHand(HumanoidArm arm,PoseStack pose) {
        root.translateAndRotate(pose); torso.translateAndRotate(pose);
        (arm==HumanoidArm.RIGHT?rightArm:leftArm).translateAndRotate(pose);
        pose.translate(0.0D,5.0D/16.0D,0.0D);
    }
}
