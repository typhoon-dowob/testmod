package dev.sushi.wooltest.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import dev.sushi.wooltest.WoolTestMod;
import dev.sushi.wooltest.entity.EmperorEntity;
import net.minecraft.client.model.HierarchicalModel;
import net.minecraft.client.model.ArmedModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.HumanoidArm;
import java.util.ArrayList;
import java.util.List;

/** Emperor 5: chamfered planar cloth and a compact face. Model geometry, not a whole-entity scale trick.
 * Only client drawing changes; the entity, hitbox, AI and item data are untouched.
 */
public final class EmperorModel extends HierarchicalModel<EmperorEntity> implements ArmedModel {
    public static final ModelLayerLocation LAYER = new ModelLayerLocation(
            new ResourceLocation(WoolTestMod.MOD_ID, "emperor"), "main");
    private final ModelPart root, torso, head, rightArm, leftArm, rightLeg, leftLeg;
    private final ModelPart cape, frontSkirt, leftPendant, rightPendant;
    private final List<Binding> bindings = new ArrayList<>();
    private final List<ModelPart> strands = new ArrayList<>();
    private record Binding(ModelPart[] path, float[] vertices) { }

    public EmperorModel(ModelPart root) {
        this.root=root; torso=root.getChild("torso"); head=torso.getChild("head");
        rightArm=torso.getChild("right_arm"); leftArm=torso.getChild("left_arm");
        rightLeg=root.getChild("right_leg"); leftLeg=root.getChild("left_leg");
        cape=torso.getChild("cape"); frontSkirt=torso.getChild("front_skirt");
        leftPendant=torso.getChild("pendant_left"); rightPendant=torso.getChild("pendant_right");
        EmperorMeshData data=EmperorMeshData.loadBundled();
        bind(data, "torso", "torso");
        bind(data, "head", "torso", "head");
        bind(data, "right_arm", "torso", "right_arm");
        bind(data, "left_arm", "torso", "left_arm");
        bind(data, "right_leg", "right_leg");
        bind(data, "left_leg", "left_leg");
        bind(data, "cape", "torso", "cape");
        bind(data, "front_skirt", "torso", "front_skirt");
        bind(data, "pendant_right", "torso", "pendant_right");
        bind(data, "pendant_left", "torso", "pendant_left");
        bind(data, "bead_front0", "torso", "head", "bead_front0");
        bind(data, "bead_front1", "torso", "head", "bead_front1");
        bind(data, "bead_front2", "torso", "head", "bead_front2");
        bind(data, "bead_front3", "torso", "head", "bead_front3");
        bind(data, "bead_front4", "torso", "head", "bead_front4");
        bind(data, "bead_back0", "torso", "head", "bead_back0");
        bind(data, "bead_back1", "torso", "head", "bead_back1");
        bind(data, "bead_back2", "torso", "head", "bead_back2");
        bind(data, "bead_back3", "torso", "head", "bead_back3");
        bind(data, "bead_back4", "torso", "head", "bead_back4");
        if (bindings.size() != data.boneNames().size())
            throw new IllegalStateException("Unbound emperor mesh bones");
        for (int i=0;i<5;i++) {
            strands.add(head.getChild("bead_front"+i));
            strands.add(head.getChild("bead_back"+i));
        }
    }
    private void bind(EmperorMeshData data,String name,String... names) {
        ModelPart[] path=new ModelPart[names.length+1]; path[0]=root;
        for (int i=0;i<names.length;i++) path[i+1]=path[i].getChild(names[i]);
        bindings.add(new Binding(path,data.mesh(name)));
    }
    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh=new MeshDefinition(); PartDefinition root=mesh.getRoot();
        PartDefinition torso = root.addOrReplaceChild("torso", CubeListBuilder.create(), PartPose.offset(0.000000F, -9.000000F, 0.000000F));
        PartDefinition head = torso.addOrReplaceChild("head", CubeListBuilder.create(), PartPose.offset(0.000000F, 2.200000F, 0.000000F));
        PartDefinition right_arm = torso.addOrReplaceChild("right_arm", CubeListBuilder.create(), PartPose.offsetAndRotation(-5.500000F, 1.000000F, 0.000000F, 0.000000F, 0.000000F, 0.060000F));
        PartDefinition left_arm = torso.addOrReplaceChild("left_arm", CubeListBuilder.create(), PartPose.offsetAndRotation(5.500000F, 1.000000F, 0.000000F, 0.000000F, 0.000000F, -0.060000F));
        PartDefinition right_leg = root.addOrReplaceChild("right_leg", CubeListBuilder.create(), PartPose.offset(-2.450000F, 17.000000F, 0.000000F));
        PartDefinition left_leg = root.addOrReplaceChild("left_leg", CubeListBuilder.create(), PartPose.offset(2.450000F, 17.000000F, 0.000000F));
        PartDefinition cape = torso.addOrReplaceChild("cape", CubeListBuilder.create(), PartPose.offset(0.000000F, 1.000000F, 0.000000F));
        PartDefinition front_skirt = torso.addOrReplaceChild("front_skirt", CubeListBuilder.create(), PartPose.offset(0.000000F, 13.500000F, 0.000000F));
        PartDefinition pendant_right = torso.addOrReplaceChild("pendant_right", CubeListBuilder.create(), PartPose.offset(-4.100000F, 13.200000F, -2.900000F));
        PartDefinition pendant_left = torso.addOrReplaceChild("pendant_left", CubeListBuilder.create(), PartPose.offset(4.100000F, 13.200000F, -2.900000F));
        PartDefinition bead_front0 = head.addOrReplaceChild("bead_front0", CubeListBuilder.create(), PartPose.offset(-3.800000F, -14.450000F, -5.000000F));
        PartDefinition bead_front1 = head.addOrReplaceChild("bead_front1", CubeListBuilder.create(), PartPose.offset(-1.900000F, -14.450000F, -5.000000F));
        PartDefinition bead_front2 = head.addOrReplaceChild("bead_front2", CubeListBuilder.create(), PartPose.offset(0.000000F, -14.450000F, -5.000000F));
        PartDefinition bead_front3 = head.addOrReplaceChild("bead_front3", CubeListBuilder.create(), PartPose.offset(1.900000F, -14.450000F, -5.000000F));
        PartDefinition bead_front4 = head.addOrReplaceChild("bead_front4", CubeListBuilder.create(), PartPose.offset(3.800000F, -14.450000F, -5.000000F));
        PartDefinition bead_back0 = head.addOrReplaceChild("bead_back0", CubeListBuilder.create(), PartPose.offset(-3.800000F, -14.450000F, 5.000000F));
        PartDefinition bead_back1 = head.addOrReplaceChild("bead_back1", CubeListBuilder.create(), PartPose.offset(-1.900000F, -14.450000F, 5.000000F));
        PartDefinition bead_back2 = head.addOrReplaceChild("bead_back2", CubeListBuilder.create(), PartPose.offset(0.000000F, -14.450000F, 5.000000F));
        PartDefinition bead_back3 = head.addOrReplaceChild("bead_back3", CubeListBuilder.create(), PartPose.offset(1.900000F, -14.450000F, 5.000000F));
        PartDefinition bead_back4 = head.addOrReplaceChild("bead_back4", CubeListBuilder.create(), PartPose.offset(3.800000F, -14.450000F, 5.000000F));
        return LayerDefinition.create(mesh,512,512);
    }
    @Override public ModelPart root() { return root; }

    @Override public void renderToBuffer(PoseStack pose,VertexConsumer out,int light,int overlay,
            float red,float green,float blue,float alpha) {
        // Uses the same transformed geometry for the normal pass and charge overlay.
        for (Binding binding : bindings) {
            boolean visible=true;
            for (ModelPart part : binding.path()) if (!part.visible) { visible=false; break; }
            if (!visible) continue;
            pose.pushPose();
            for (ModelPart part : binding.path()) part.translateAndRotate(pose);
            PoseStack.Pose last=pose.last();
            float[] v=binding.vertices();
            for (int i=0;i<v.length;i+=EmperorMeshData.FLOATS_PER_VERTEX) {
                out.vertex(last.pose(),v[i]/16.0F,v[i+1]/16.0F,v[i+2]/16.0F)
                        .color(red,green,blue,alpha).uv(v[i+6],v[i+7])
                        .overlayCoords(overlay).uv2(light)
                        .normal(last.normal(),v[i+3],v[i+4],v[i+5]).endVertex();
            }
            pose.popPose();
        }
    }
    @Override public void setupAnim(EmperorEntity entity,float swing,float amount,float age,float yaw,float pitch) {
        root.getAllParts().forEach(ModelPart::resetPose);
        head.yRot=Mth.clamp(yaw,-45,45)*Mth.DEG_TO_RAD;
        head.xRot=Mth.clamp(pitch,-20,20)*Mth.DEG_TO_RAD;
        float stride=Mth.cos(swing*0.6662F)*0.55F*amount;
        rightLeg.xRot=stride; leftLeg.xRot=-stride;
        rightArm.xRot=-stride*0.4F-0.15F; leftArm.xRot=stride*0.4F;
        cape.xRot=0.025F+Mth.sin(age*0.07F)*0.018F+amount*0.045F;
        frontSkirt.xRot=-0.015F+Mth.sin(swing*0.6662F)*0.020F*amount;
        leftPendant.zRot=Mth.sin(age*0.08F)*0.018F+stride*0.035F;
        rightPendant.zRot=-leftPendant.zRot;
        for (int i=0;i<strands.size();i++)
            strands.get(i).xRot=Mth.sin(age*0.08F+i*0.27F)*0.022F;
        if(entity.isChargingSpell()) {
            rightArm.xRot=-1.15F; leftArm.xRot=-0.95F;
            rightArm.zRot=0.12F; leftArm.zRot=-0.12F;
        } else if(attackTime>0) {
            rightArm.xRot-=Mth.sin(Mth.sqrt(attackTime)*Mth.PI)*1.3F;
        }
    }
    @Override public void translateToHand(HumanoidArm arm,PoseStack pose) {
        root.translateAndRotate(pose); torso.translateAndRotate(pose);
        (arm==HumanoidArm.RIGHT?rightArm:leftArm).translateAndRotate(pose);
        // Hand remains at Y=13..17 in arm-local space, preserving the previous grip anchor.
        pose.translate(0.0D,5.0D/16.0D,0.0D);
    }
}
