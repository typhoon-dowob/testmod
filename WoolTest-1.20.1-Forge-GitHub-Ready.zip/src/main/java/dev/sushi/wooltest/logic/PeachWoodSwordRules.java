package dev.sushi.wooltest.logic;

import java.util.function.IntUnaryOperator;

/** Pure Java rules: store integer hundredths, not a repeatedly rounded float. */
public final class PeachWoodSwordRules {
    public static final int MIN_DAMAGE_HUNDREDTHS = 500;
    public static final int MAX_DAMAGE_HUNDREDTHS = 700;
    public static final int DEFAULT_DAMAGE_HUNDREDTHS = 600;
    public static final int DAMAGE_OUTCOMES = MAX_DAMAGE_HUNDREDTHS - MIN_DAMAGE_HUNDREDTHS + 1;
    public static final int DROP_OUTCOMES = 10;
    public static final int SUCCESSFUL_DROP_OUTCOMES = 9;
    public static final double ATTACK_SPEED = 1.6D;
    public static final int DURABILITY = 250;

    private PeachWoodSwordRules() { }

    public static boolean shouldDrop(IntUnaryOperator nextInt) {
        return checkedRoll(nextInt, DROP_OUTCOMES) < SUCCESSFUL_DROP_OUTCOMES;
    }

    public static int rollDamageHundredths(IntUnaryOperator nextInt) {
        return MIN_DAMAGE_HUNDREDTHS + checkedRoll(nextInt, DAMAGE_OUTCOMES);
    }

    private static int checkedRoll(IntUnaryOperator nextInt, int bound) {
        int value = nextInt.applyAsInt(bound);
        if (value < 0 || value >= bound) {
            throw new IllegalArgumentException("Random value outside [0, " + bound + "): " + value);
        }
        return value;
    }

    public static int clampDamageHundredths(int value) {
        return Math.max(MIN_DAMAGE_HUNDREDTHS, Math.min(MAX_DAMAGE_HUNDREDTHS, value));
    }

    /** The usual player's total, before enchantments, effects, cooldown and mitigation. */
    public static double baseAttackDamage(int hundredths) {
        return clampDamageHundredths(hundredths) / 100.0D;
    }

    public static double attackDamageModifier(int hundredths) {
        return baseAttackDamage(hundredths) - 1.0D;
    }

    public static double attackSpeedModifier() {
        return ATTACK_SPEED - 4.0D;
    }

    public static String formatDamage(int hundredths) {
        int value = clampDamageHundredths(hundredths);
        int fraction = value % 100;
        return (value / 100) + "." + (fraction < 10 ? "0" : "") + fraction;
    }
}
