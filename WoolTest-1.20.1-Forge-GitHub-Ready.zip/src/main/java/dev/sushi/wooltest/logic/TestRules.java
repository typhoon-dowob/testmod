package dev.sushi.wooltest.logic;

/** Pure Java rules, intentionally independent of Minecraft for offline unit testing. */
public final class TestRules {
    private TestRules() { }
    public static final int MIN_Y = 0;
    public static final int HEIGHT = 128;
    public static final int GROUND_TOP_EXCLUSIVE = 64;
    public static final int TILE_SIZE = 8;
    public static final int COLOUR_COUNT = 16;
    public static final int PILLAR_COUNT = 3;
    public static final int PILLAR_HEIGHT = 4;
    public static final double PILLAR_RADIUS = 5.0;
    public static final int CAST_COOLDOWN_TICKS = 120;
    public static final int PILLAR_LIFETIME_TICKS = 80;
    public static final int HIT_COOLDOWN_TICKS = 20;
    public static final float MAX_HEALTH = 20.0F;
    public static final float MELEE_DAMAGE = 1.0F;
    public static final float PILLAR_DAMAGE = 3.0F;
    public static final double KNOCKBACK_STRENGTH = 1.2;

    /** Every 32 x 32 patch shows all 16 colours, including at negative coordinates. */
    public static int colourIndex(int x, int y, int z) {
        int tx = Math.floorDiv(x, TILE_SIZE);
        int tz = Math.floorDiv(z, TILE_SIZE);
        return Math.floorMod(tx, 4) + 4 * Math.floorMod(tz, 4);
    }

    public static boolean isTerrainY(int y) {
        return y >= MIN_Y && y < GROUND_TOP_EXCLUSIVE;
    }

    /** Radius is measured in the horizontal plane, to a pillar's block centre. */
    public static boolean insidePillarRadius(double casterX, double casterZ, int x, int z) {
        double dx = x + 0.5 - casterX;
        double dz = z + 0.5 - casterZ;
        return dx * dx + dz * dz <= PILLAR_RADIUS * PILLAR_RADIUS + 1.0E-9;
    }

    /** Maximum build height is exclusive: a pillar at Y=124 occupies 124..127. */
    public static boolean pillarFits(int baseY, int minY, int maxY) {
        return baseY > minY && (long) baseY + PILLAR_HEIGHT <= maxY;
    }
}
