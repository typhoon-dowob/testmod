package dev.sushi.wooltest.logic;

import java.util.Locale;
import java.util.function.IntUnaryOperator;

/** Server rolls in integer hundredths: no rounding bias and no client-side RNG. */
public final class ImperialArmorRules {
    private ImperialArmorRules() { }
    public static final int ARMOR_MIN = 100, ARMOR_MAX = 300;
    public static final int TOUGHNESS_MIN = 100, TOUGHNESS_MAX = 200;
    public static boolean drops(IntUnaryOperator random) { return random.applyAsInt(10) < 9; }
    public static int rollArmor(IntUnaryOperator random) { return 100 + random.applyAsInt(201); }
    public static int rollToughness(IntUnaryOperator random) { return 100 + random.applyAsInt(101); }
    public static int clampArmor(int value) { return Math.max(100, Math.min(300, value)); }
    public static int clampToughness(int value) { return Math.max(100, Math.min(200, value)); }
    public static String format(int value) { return String.format(Locale.ROOT, "%.2f", value / 100.0D); }
}
