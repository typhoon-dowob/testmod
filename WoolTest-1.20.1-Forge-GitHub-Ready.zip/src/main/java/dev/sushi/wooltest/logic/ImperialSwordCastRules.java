package dev.sushi.wooltest.logic;

/** Legacy player-sword casting rules, intentionally independent of Emperor 2 AI; ticks use Minecraft game time. */
public final class ImperialSwordCastRules {
    private ImperialSwordCastRules() { }
    public static final float HEALTH = 50.0F;
    public static final float ATTACK = 10.0F;
    public static final float WIDTH = 2.0F, HEIGHT = 3.0F;
    public static final int MIN_CHARGE = 100, MAX_CHARGE = 300, CIRCLE_TICKS = 100;
    public static final int COOLDOWN = 160, FLASH_TICKS = 12;
    public static final double RANGE = 32.0D, RADIUS = 10.0D, BEAM_RADIUS = 0.35D;
    public static final float BEAM_DAMAGE = 6.0F;
    public static int clampTicks(int ticks) { return Math.max(0, Math.min(MAX_CHARGE, ticks)); }
    public static int completedCircles(int ticks) { return clampTicks(ticks) / CIRCLE_TICKS; }
    public static float circleProgress(int ticks, int index) {
        if (index < 0 || index > 2) return 0.0F;
        return Math.max(0.0F, Math.min(1.0F, (clampTicks(ticks) - index * CIRCLE_TICKS) / 100.0F));
    }
    public static float areaDamage(int ticks) {
        int t = clampTicks(ticks);
        return t < MIN_CHARGE ? 0.0F : (float)(t / 20.0D * ATTACK * 1.2D);
    }
    /** A victim hit by both components receives a single combined hurt() call. */
    public static float damage(int ticks, boolean area, boolean beam) {
        return (area ? areaDamage(ticks) : 0.0F) + (beam ? BEAM_DAMAGE : 0.0F);
    }
    public static double circleDistance(int index, double beamLength) {
        return Math.min(1.2D + index * 1.2D, Math.max(0.0D, beamLength) * (index + 1) / 4.0D);
    }
}
