package dev.sushi.wooltest.city;

import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.Property;
import java.io.IOException;
import java.util.List;

/** State palette is resolved only after registries are ready, on first terrain request. */
public final class CityBlueprint {
    private CityBlueprint() { }
    private static final class Holder {
        private static final CityLayoutData DATA = load();
        private static final BlockState[] STATES = resolve(DATA.palette());
    }
    private static CityLayoutData load() {
        try {
            return CityLayoutData.read(CityBlueprint.class.getResourceAsStream(
                    "/data/wooltest/city/capital_v2.wct.gz"));
        } catch (IOException e) {
            throw new IllegalStateException("WoolTest city blueprint could not be read", e);
        }
    }
    public static BlockState stateAt(int x, int y, int z) {
        return Holder.STATES[Holder.DATA.paletteIndex(x, y, z)];
    }
    private static BlockState[] resolve(List<String> palette) {
        return palette.stream().map(CityBlueprint::parseState).toArray(BlockState[]::new);
    }
    private static BlockState parseState(String text) {
        int bracket = text.indexOf('[');
        ResourceLocation id = new ResourceLocation(bracket < 0 ? text : text.substring(0, bracket));
        if (!BuiltInRegistries.BLOCK.containsKey(id))
            throw new IllegalStateException("Unknown city block: " + id);
        Block block = BuiltInRegistries.BLOCK.get(id);
        BlockState state = block.defaultBlockState();
        if (bracket >= 0) {
            if (!text.endsWith("]")) throw new IllegalStateException("Malformed block state: " + text);
            for (String assignment : text.substring(bracket + 1, text.length() - 1).split(",")) {
                String[] pair = assignment.split("=", 2);
                if (pair.length != 2) throw new IllegalStateException("Malformed property: " + text);
                Property<?> property = block.getStateDefinition().getProperty(pair[0]);
                if (property == null) throw new IllegalStateException("Missing property: " + text);
                state = withValue(state, property, pair[1]);
            }
        }
        return state;
    }
    private static <T extends Comparable<T>> BlockState withValue(BlockState state,
            Property<T> property, String value) {
        T parsed = property.getValue(value).orElseThrow(() ->
                new IllegalStateException("Invalid " + property.getName() + "=" + value));
        return state.setValue(property, parsed);
    }
}
