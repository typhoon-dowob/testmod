package dev.sushi.wooltest.city;

import dev.sushi.wooltest.WoolTestMod;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.block.*;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.material.MapColor;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;
import java.util.*;

/** Independent registered blocks/items; no replacement of vanilla assets. */
public final class CityBlocks {
    private CityBlocks() { }
    private static final DeferredRegister<Block> BLOCKS = DeferredRegister.create(ForgeRegistries.BLOCKS, WoolTestMod.MOD_ID);
    private static final DeferredRegister<Item> ITEMS = DeferredRegister.create(ForgeRegistries.ITEMS, WoolTestMod.MOD_ID);
    private static final Map<String, RegistryObject<Block>> MATERIALS = new LinkedHashMap<>();
    public static final List<RegistryObject<Item>> ALL_ITEMS = new ArrayList<>();
    private static void add(String id, java.util.function.Supplier<Block> block) {
        RegistryObject<Block> entry = BLOCKS.register(id, block); MATERIALS.put(id, entry);
        ALL_ITEMS.add(ITEMS.register(id, () -> new BlockItem(entry.get(), new Item.Properties())));
    }
    private static BlockBehaviour.Properties props(String kind) {
        BlockBehaviour.Properties p = BlockBehaviour.Properties.of().mapColor(MapColor.STONE).strength(2.0F, 6.0F);
        if (kind.equals("wood")) return p.sound(SoundType.WOOD);
        if (kind.equals("cloth")) return p.sound(SoundType.WOOL);
        if (kind.equals("leaves")) return p.sound(SoundType.GRASS).strength(0.2F).noOcclusion();
        if (kind.equals("lantern")) return p.sound(SoundType.LANTERN).lightLevel(s -> 14).noOcclusion();
        return p.sound(SoundType.STONE);
    }
    static {
        add("capital_gray_brick", () -> new Block(props("stone")));
        add("capital_dark_brick", () -> new Block(props("stone")));
        add("capital_red_wall", () -> new Block(props("stone")));
        add("capital_white_wall", () -> new Block(props("stone")));
        add("capital_marble", () -> new Block(props("stone")));
        add("capital_carved_marble", () -> new Block(props("stone")));
        add("capital_paving", () -> new Block(props("stone")));
        add("capital_floor", () -> new Block(props("stone")));
        add("capital_timber", () -> new Block(props("wood")));
        add("capital_red_timber", () -> new Block(props("wood")));
        add("capital_gilded_beam", () -> new Block(props("wood")));
        add("capital_jade_beam", () -> new Block(props("wood")));
        add("capital_gold_tiles", () -> new Block(props("stone")));
        add("capital_dark_tiles", () -> new Block(props("stone")));
        add("capital_jade_tiles", () -> new Block(props("stone")));
        add("capital_gold_ridge", () -> new Block(props("stone")));
        add("capital_red_lattice", () -> new Block(props("wood")));
        add("capital_dark_lattice", () -> new Block(props("wood")));
        add("capital_red_lantern", () -> new CityDecorBlock("lantern", props("lantern")));
        add("capital_gold_lantern", () -> new CityDecorBlock("lantern", props("lantern")));
        add("capital_banner", () -> new Block(props("stone")));
        add("capital_red_awning", () -> new Block(props("cloth")));
        add("capital_jade_awning", () -> new Block(props("cloth")));
        add("capital_grass", () -> new Block(props("stone")));
        add("capital_peach_log", () -> new Block(props("wood")));
        add("capital_peach_leaves", () -> new Block(props("leaves")));
        add("capital_willow_leaves", () -> new Block(props("leaves")));
        add("capital_bronze", () -> new Block(props("stone")));
        add("capital_lotus", () -> new Block(props("stone")));
        add("capital_dragon_panel", () -> new Block(props("stone")));
        add("capital_marble_stairs", () -> new StairBlock(() -> MATERIALS.get("capital_marble").get().defaultBlockState(), props("stone")));
        add("capital_marble_slab", () -> new SlabBlock(props("stone")));
        add("capital_paving_stairs", () -> new StairBlock(() -> MATERIALS.get("capital_paving").get().defaultBlockState(), props("stone")));
        add("capital_paving_slab", () -> new SlabBlock(props("stone")));
        add("capital_gold_tiles_stairs", () -> new StairBlock(() -> MATERIALS.get("capital_gold_tiles").get().defaultBlockState(), props("stone")));
        add("capital_gold_tiles_slab", () -> new SlabBlock(props("stone")));
        add("capital_dark_tiles_stairs", () -> new StairBlock(() -> MATERIALS.get("capital_dark_tiles").get().defaultBlockState(), props("stone")));
        add("capital_dark_tiles_slab", () -> new SlabBlock(props("stone")));
        add("capital_jade_tiles_stairs", () -> new StairBlock(() -> MATERIALS.get("capital_jade_tiles").get().defaultBlockState(), props("stone")));
        add("capital_jade_tiles_slab", () -> new SlabBlock(props("stone")));
        add("capital_column_shaft", () -> new CityDecorBlock("shaft", props("wood").noOcclusion()));
        add("capital_column_foot", () -> new CityDecorBlock("foot", props("stone").noOcclusion()));
        add("capital_hanging_lantern", () -> new CityDecorBlock("hanging", props("stone").lightLevel(s -> 15).noOcclusion()));
        add("capital_stone_lamp", () -> new CityDecorBlock("stone_lamp", props("stone").lightLevel(s -> 15).noOcclusion()));
        add("capital_inlaid_lamp", () -> new CityDecorBlock("inlaid", props("stone").lightLevel(s -> 15)));
        add("capital_red_column", () -> new CityDecorBlock("column", props("stone").noOcclusion()));
        add("capital_marble_rail", () -> new CityDecorBlock("rail", props("stone").noOcclusion()));
        add("capital_bracket", () -> new CityDecorBlock("bracket", props("stone").noOcclusion()));
        add("capital_finial", () -> new CityDecorBlock("finial", props("stone").noOcclusion()));
    }
    public static void register(IEventBus bus) { BLOCKS.register(bus); ITEMS.register(bus); }
}
