package dev.sushi.wooltest.city;

import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import dev.sushi.wooltest.world.DimensionTravel;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.phys.Vec3;
import java.util.Locale;

public final class CityCommands {
    private CityCommands() { }
    public static LiteralArgumentBuilder<CommandSourceStack> command() {
        return Commands.literal("city").requires(s -> s.hasPermission(2))
                .executes(c -> go(c.getSource()))
                .then(Commands.literal("status").executes(c -> status(c.getSource())))
                .then(Commands.literal("pause").executes(c -> pause(c.getSource())))
                .then(Commands.literal("build").executes(c -> warning(c.getSource()))
                        .then(Commands.literal("confirm").executes(c -> start(c.getSource()))));
    }
    private static ServerLevel level(CommandSourceStack source) {
        return source.getServer().getLevel(DimensionTravel.WOOL_WORLD);
    }
    private static int go(CommandSourceStack source) throws CommandSyntaxException {
        ServerPlayer player = source.getPlayerOrException();
        ServerLevel target = level(source);
        if (target == null) { source.sendFailure(Component.literal("羊毛維度不存在。")); return 0; }
        if (!player.level().dimension().equals(DimensionTravel.WOOL_WORLD)
                && DimensionTravel.enter(player) == 0) return 0;
        Vec3 spot = DimensionTravel.findSafe(target, player, 0.5D, 64.0D, 124.5D);
        if (spot == null) { source.sendFailure(Component.literal("南門附近沒有安全落點。")); return 0; }
        player.stopRiding(); player.teleportTo(target, spot.x, spot.y, spot.z, 180.0F, 0.0F);
        player.setDeltaMovement(Vec3.ZERO); player.fallDistance = 0.0F;
        source.sendSuccess(() -> Component.literal(
                "已到承天城南門位置。城市中心 X=0、Z=0。舊區域不會自動覆寫；詳見 /wooltest city status。"), false);
        return 1;
    }
    private static int warning(CommandSourceStack source) {
        source.sendFailure(Component.literal(
                "警告：補建會覆寫羊毛維度 X/Z=-125..125、Y=60..127，包含你的建築及容器。"
                + "先備份存檔，再用 /wooltest city build confirm。只在原點補建，不會新增第二座城。"));
        return 0;
    }
    private static int start(CommandSourceStack source) {
        ServerLevel level = level(source);
        if (level == null) { source.sendFailure(Component.literal("羊毛維度不存在。")); return 0; }
        if (!level.getWorldBorder().isWithinBounds(new BlockPos(-125,64,-125))
                || !level.getWorldBorder().isWithinBounds(new BlockPos(125,64,125))) {
            source.sendFailure(Component.literal("世界邊界不足以容納 251×251 的城市。")); return 0;
        }
        CityBuildData data = CityBuildData.get(level);
        if (data.completed) {
            source.sendFailure(Component.literal("此存檔已完成一次原點補建，不再重建或覆寫玩家修改。")); return 0;
        }
        if (data.running) { source.sendFailure(Component.literal("補建已在進行，不會重複啟動。")); return 0; }
        // Keep players outside the edited volume until walls/air and water are in place.
        for (ServerPlayer p : level.players()) {
            if (CityLayoutData.contains(p.blockPosition().getX(), p.blockPosition().getZ())) {
                Vec3 safe = DimensionTravel.findSafe(level,p,0.5D,64.0D,134.5D);
                if (safe == null) { source.sendFailure(Component.literal("無法安全移出範圍，未開始補建。")); return 0; }
                p.stopRiding(); p.teleportTo(level,safe.x,safe.y,safe.z,180.0F,0.0F);
                p.setDeltaMovement(Vec3.ZERO);p.fallDistance=0;
            }
        }
        data.running=true; data.error=""; data.setDirty();
        source.sendSuccess(() -> Component.literal(
                "已開始／續接原點補建。請勿進入施工範圍；/wooltest city status 查看進度，/wooltest city pause 暫停。"), true);
        return 1;
    }
    private static int pause(CommandSourceStack source) {
        ServerLevel level=level(source); if(level==null)return 0;
        CityBuildData data=CityBuildData.get(level); data.running=false;data.setDirty();
        source.sendSuccess(() -> Component.literal("已暫停；不會回復已修改的方塊。build confirm 可從紀錄位置續接。"), false);
        return 1;
    }
    private static int status(CommandSourceStack source) {
        ServerLevel level=level(source);if(level==null)return 0;
        CityBuildData data=CityBuildData.get(level);
        String text=String.format(Locale.ROOT,
                "承天城：中心 X=0,Z=0；邊界 -125..125；舊存檔補建 %s（%.1f%%）。"
                + "新區塊自動生成；已探索區域須備份後 build confirm。%s",
                data.completed?"完成":data.running?"進行中":"尚未啟動／暫停",data.percent(),data.error);
        source.sendSuccess(()->Component.literal(text),false);return 1;
    }
}
