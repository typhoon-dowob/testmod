package dev.sushi.wooltest.city;

import net.minecraft.core.BlockPos;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.Shapes;
import net.minecraft.world.phys.shapes.VoxelShape;

/** Static decorations: block models and collision, no ticking block entities. */
public final class CityDecorBlock extends Block {
    private final VoxelShape shape;
    public CityDecorBlock(String kind, Properties properties) {
        super(properties.dynamicShape());
        shape = switch (kind) {
            case "column" -> Shapes.or(box(4,0,4,12,16,12),box(2,0,2,14,2,14),box(2,14,2,14,16,14));
            case "rail" -> Shapes.or(box(6,0,6,10,16,10),box(0,10,6,16,13,10),
                    box(6,10,0,10,13,16),box(0,3,6,16,5,10),box(6,3,0,10,5,16));
            case "bracket" -> Shapes.or(box(5,0,5,11,6,11),box(2,6,3,14,10,13),
                    box(0,10,5,16,13,11),box(4,13,0,12,16,16));
            case "finial" -> Shapes.or(box(3,0,3,13,3,13),box(5,3,5,11,10,11),
                    box(7,10,5,13,15,11),box(2,6,7,6,13,9));
            case "lantern" -> Shapes.or(box(3,3,3,13,13,13),box(4,1,4,12,3,12),
                    box(4,13,4,12,15,12),box(7,0,7,9,1,9));
            default -> Shapes.block();
        };
    }
    @Override public VoxelShape getShape(BlockState state, BlockGetter level,
            BlockPos pos, CollisionContext context) {
        // The superclass may query shape while constructing cached block states.
        return shape == null ? Shapes.block() : shape;
    }
}
