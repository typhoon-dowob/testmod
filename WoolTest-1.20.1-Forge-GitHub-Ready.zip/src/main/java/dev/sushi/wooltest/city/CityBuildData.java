package dev.sushi.wooltest.city;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.saveddata.SavedData;

/** Opt-in City 4 migration. Separate saved data from V1/V2; never starts on install/load. */
public final class CityBuildData extends SavedData {
    public boolean running;
    public boolean completed;
    public int phase;  // 0: stone/air, 1: water; prevents transient water flooding during placement.
    public int chunk;
    public int cell;
    public long changed;
    public String error = "";
    public static CityBuildData get(ServerLevel level) {
        return level.getDataStorage().computeIfAbsent(CityBuildData::load, CityBuildData::new,
                "wooltest_capital_migration_v4");
    }
    public static CityBuildData load(CompoundTag tag) {
        CityBuildData data = new CityBuildData();
        data.running = tag.getBoolean("Running"); data.completed = tag.getBoolean("Completed");
        data.phase = Math.max(0, Math.min(1, tag.getInt("Phase")));
        data.chunk = Math.max(0, Math.min(255, tag.getInt("Chunk")));
        data.cell = Math.max(0, Math.min(16 * 16 * CityLayoutData.HEIGHT - 1, tag.getInt("Cell")));
        data.changed = Math.max(0L, tag.getLong("Changed")); data.error = tag.getString("Error");
        if (data.completed) data.running = false;
        return data;
    }
    @Override public CompoundTag save(CompoundTag tag) {
        tag.putBoolean("Running", running); tag.putBoolean("Completed", completed);
        tag.putInt("Phase", phase); tag.putInt("Chunk", chunk); tag.putInt("Cell", cell);
        tag.putLong("Changed", changed); tag.putString("Error", error); return tag;
    }
    public double percent() {
        if (completed) return 100.0D;
        return 100.0D * (phase * 256.0D + chunk + cell / (256.0D * CityLayoutData.HEIGHT)) / 512.0D;
    }
}
