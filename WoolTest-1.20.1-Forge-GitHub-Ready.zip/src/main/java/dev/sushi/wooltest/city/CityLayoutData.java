package dev.sushi.wooltest.city;

import java.io.*;
import java.util.*;
import java.util.zip.GZIPInputStream;

/** Pure-Java, immutable, bounded blueprint. No world/client APIs or mutable global progress. */
public final class CityLayoutData {
    public static final int SIZE = 251;
    public static final int MIN = -125;
    public static final int MAX = 125;
    public static final int MIN_Y = 60;
    public static final int HEIGHT = 68;
    private final List<String> palette;
    private final char[] cells;

    private CityLayoutData(List<String> palette, char[] cells) {
        this.palette = List.copyOf(palette);
        this.cells = cells;
    }
    public static boolean contains(int x, int z) {
        return x >= MIN && x <= MAX && z >= MIN && z <= MAX;
    }
    public static boolean intersectsChunk(int cx, int cz) {
        // Long math keeps arbitrary command/world coordinates from wrapping.
        long x = (long) cx * 16L, z = (long) cz * 16L;
        return x <= MAX && x + 15 >= MIN && z <= MAX && z + 15 >= MIN;
    }
    public static boolean reservesStructureChunk(int cx, int cz) {
        // Existing 21x21 trial grounds have a 64-block jigsaw radius. Keep
        // their starts >64 blocks away from the city on both horizontal axes.
        long x = (long) cx * 16L, z = (long) cz * 16L;
        return x <= MAX + 80 && x + 15 >= MIN - 80
                && z <= MAX + 80 && z + 15 >= MIN - 80;
    }
    public int paletteIndex(int x, int y, int z) {
        if (!contains(x, z) || y < MIN_Y || y >= MIN_Y + HEIGHT) return 0;
        return cells[((x - MIN) * SIZE + z - MIN) * HEIGHT + y - MIN_Y];
    }
    public List<String> palette() { return palette; }
    public static CityLayoutData read(InputStream raw) throws IOException {
        if (raw == null) throw new FileNotFoundException("Missing city blueprint");
        try (DataInputStream in = new DataInputStream(new BufferedInputStream(new GZIPInputStream(raw)))) {
            if (in.readInt() != 0x57435431 || in.readInt() != 1)
                throw new IOException("Unsupported city blueprint format");
            if (in.readInt() != SIZE || in.readInt() != MIN_Y || in.readInt() != HEIGHT)
                throw new IOException("City dimensions do not match fixed 251x251 bounds");
            int count = in.readInt();
            if (count < 2 || count > 1024) throw new IOException("Invalid palette length: " + count);
            List<String> palette = new ArrayList<>(count);
            for (int i = 0; i < count; i++) palette.add(in.readUTF());
            if (!palette.get(0).equals("minecraft:air")) throw new IOException("Palette zero must be air");
            char[] cells = new char[SIZE * SIZE * HEIGHT];
            for (int i = 0; i < cells.length; i++) {
                int value = in.readUnsignedShort();
                if (value >= count) throw new IOException("Invalid block palette index at " + i);
                cells[i] = (char) value;
            }
            if (in.read() != -1) throw new IOException("Trailing city blueprint data");
            return new CityLayoutData(palette, cells);
        }
    }
}
