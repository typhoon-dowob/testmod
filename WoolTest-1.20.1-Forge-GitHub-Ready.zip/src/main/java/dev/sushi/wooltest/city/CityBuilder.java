package dev.sushi.wooltest.city;

import dev.sushi.wooltest.world.DimensionTravel;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraftforge.event.TickEvent;
import java.util.Locale;

/** Server-thread migration with bounded work, durable cursor and no user-defined origin. */
public final class CityBuilder {
    private CityBuilder() { }
    private static final int CELL_BUDGET = 4096;
    private static final int WRITE_BUDGET = 1024;
    public static void onServerTick(TickEvent.ServerTickEvent event) {
        if (event.phase != TickEvent.Phase.END) return;
        ServerLevel level = event.getServer().getLevel(DimensionTravel.WOOL_WORLD);
        if (level == null) return;
        CityBuildData job = CityBuildData.get(level);
        if (!job.running || job.completed) return;
        int before = (int) (job.percent() / 10);
        try {
            int cx = -8 + job.chunk / 16, cz = -8 + job.chunk % 16;
            // At most one target chunk is loaded in one tick. No recursive work from ChunkEvent.Load.
            level.getChunk(cx, cz);
            BlockPos.MutableBlockPos cursor = new BlockPos.MutableBlockPos();
            int visits = 0, writes = 0;
            int total = 16 * 16 * CityLayoutData.HEIGHT;
            while (job.cell < total && visits < CELL_BUDGET && writes < WRITE_BUDGET) {
                int i = job.cell;
                visits++;
                int column = i / CityLayoutData.HEIGHT;
                int x = cx * 16 + column / 16, z = cz * 16 + column % 16;
                int y = CityLayoutData.MIN_Y + i % CityLayoutData.HEIGHT;
                if (!CityLayoutData.contains(x, z)) { job.cell++; continue; }
                cursor.set(x, y, z);
                if (!level.getWorldBorder().isWithinBounds(cursor))
                    throw new IllegalStateException("World border excludes city coordinates " + x + "," + z);
                BlockState target = CityBlueprint.stateAt(x, y, z);
                boolean water = target.is(Blocks.WATER);
                if (job.phase == 1 && !water) { job.cell++; continue; }
                if (job.phase == 0 && water) target = Blocks.AIR.defaultBlockState();
                if (level.getBlockState(cursor) != target) {
                    // Notify clients and lighting, keep explicitly authored stair/rail shapes.
                    if (!level.setBlock(cursor, target, 2 | 16))
                        throw new IllegalStateException("Cannot set city block at " + cursor);
                    writes++; job.changed++;
                }
                job.cell++;
            }
            if (job.cell >= total) {
                job.cell = 0; job.chunk++;
                if (job.chunk >= 256) {
                    job.chunk = 0; job.phase++;
                    if (job.phase >= 2) {
                        job.running = false; job.completed = true;
                        level.players().forEach(p -> p.sendSystemMessage(Component.literal(
                                "承天城 City 2 對稱版更新完成。中心 X=0、Z=0；可用 /wooltest city 前往南門。")));
                    }
                }
            }
            if (!job.completed && (int)(job.percent()/10) > before) {
                String status = String.format(Locale.ROOT, "承天城 City 2 更新：%.1f%%", job.percent());
                level.players().forEach(p -> p.sendSystemMessage(Component.literal(status)));
            }
        } catch (RuntimeException e) {
            job.running = false; job.error = e.toString();
            level.players().forEach(p -> p.sendSystemMessage(Component.literal(
                    "承天城更新已暫停：" + job.error + "。請查看 /wooltest city status。")));
        }
        job.setDirty();
    }
}
