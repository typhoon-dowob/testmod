package dev.sushi.wooltest;

import dev.sushi.wooltest.command.TestCommands;
import dev.sushi.wooltest.city.CityBlocks;
import dev.sushi.wooltest.city.CityBuilder;
import dev.sushi.wooltest.entity.TestOneEntity;
import dev.sushi.wooltest.entity.EmperorEntity;
import dev.sushi.wooltest.world.PalaceEmperorSpawner;
import dev.sushi.wooltest.world.DimensionTravel;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.event.entity.EntityAttributeCreationEvent;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;

@Mod(WoolTestMod.MOD_ID)
public final class WoolTestMod {
    public static final String MOD_ID = "wooltest";

    public WoolTestMod() {
        IEventBus bus = FMLJavaModLoadingContext.get().getModEventBus();
        ModContent.register(bus);
        CityBlocks.register(bus);
        dev.sushi.wooltest.fallen.FallenRealm.register(bus);
        bus.addListener(this::registerAttributes);
        MinecraftForge.EVENT_BUS.addListener(TestCommands::register);
        MinecraftForge.EVENT_BUS.addListener(CityBuilder::onServerTick);
        MinecraftForge.EVENT_BUS.addListener(PalaceEmperorSpawner::onServerTick);
        MinecraftForge.EVENT_BUS.addListener(DimensionTravel::onPlayerClone);
    }

    private void registerAttributes(EntityAttributeCreationEvent event) {
        event.put(ModContent.TEST_ONE.get(), TestOneEntity.createAttributes().build());
        event.put(ModContent.EMPEROR.get(), EmperorEntity.createAttributes().build());
    }
}
