package dev.sushi.wooltest.fallen;

import java.io.*;
import java.util.*;
import java.util.zip.GZIPInputStream;

/** Strict immutable reader, deliberately independent of Minecraft for offline tests. */
public record FallenLayoutData(List<String> palette, List<Site> sites) {
    public record Site(String id,int minX,int minZ,int minY,int width,int depth,int height,char[] cells) {
        public Site {cells=cells.clone();}
        @Override public char[] cells(){return cells.clone();}
        public boolean contains(int x,int z) { return x>=minX && x<minX+width && z>=minZ && z<minZ+depth; }
        public int index(int x,int y,int z) {
            if(!contains(x,z)||y<minY||y>=minY+height)return 0;
            return cells[((x-minX)*depth+z-minZ)*height+y-minY];
        }
    }
    public static FallenLayoutData read(InputStream raw) throws IOException {
        if(raw==null)throw new FileNotFoundException("Missing fallen realm layout");
        try(DataInputStream in=new DataInputStream(new BufferedInputStream(new GZIPInputStream(raw)))) {
            if(in.readInt()!=0x46525031 || in.readInt()!=1)throw new IOException("Unsupported fallen realm layout");
            int n=in.readInt(); if(n<2||n>1024)throw new IOException("Invalid palette");
            List<String> pal=new ArrayList<>(); for(int i=0;i<n;i++)pal.add(in.readUTF());
            if(!pal.get(0).equals("minecraft:air"))throw new IOException("Palette 0 must be air");
            int count=in.readInt();if(count!=3)throw new IOException("Expected three landmarks");
            List<Site> sites=new ArrayList<>();Set<String> ids=new HashSet<>();
            for(int i=0;i<count;i++) {
                String id=in.readUTF();if(!ids.add(id))throw new IOException("Duplicate landmark");
                int x=in.readInt(),z=in.readInt(),y=in.readInt(),w=in.readInt(),d=in.readInt(),h=in.readInt();
                if(w<1||w>256||d<1||d>256||h<1||h>128||y<0||y+h>256)throw new IOException("Invalid landmark bounds");
                char[] cells=new char[w*d*h];
                for(int j=0;j<cells.length;j++) { int value=in.readUnsignedShort();if(value>=n)throw new IOException("Invalid palette index");cells[j]=(char)value; }
                sites.add(new Site(id,x,z,y,w,d,h,cells));
            }
            if(in.read()!=-1)throw new IOException("Trailing layout data");
            return new FallenLayoutData(List.copyOf(pal),List.copyOf(sites));
        }
    }
}
