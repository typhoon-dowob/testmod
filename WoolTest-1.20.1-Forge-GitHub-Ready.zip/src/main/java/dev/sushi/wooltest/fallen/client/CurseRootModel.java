package dev.sushi.wooltest.fallen.client;
import dev.sushi.wooltest.fallen.CurseRootEntity;
import net.minecraft.client.model.HierarchicalModel;
import net.minecraft.client.model.geom.*;
import net.minecraft.client.model.geom.builders.*;
import net.minecraft.resources.ResourceLocation;

public final class CurseRootModel extends HierarchicalModel<CurseRootEntity> {
    public static final ModelLayerLocation LAYER=new ModelLayerLocation(new ResourceLocation("wooltest","cursed_root"),"main");
    private final ModelPart root;
    public CurseRootModel(ModelPart p){root=p;}
    public static LayerDefinition layer(){
        MeshDefinition m=new MeshDefinition();PartDefinition base=m.getRoot().addOrReplaceChild("trunk",
                CubeListBuilder.create().texOffs(0,0).addBox(-3,-34,-3,6,34,6)
                    .texOffs(24,32).addBox(-5,-3,-5,10,3,10),PartPose.offset(0,24,0));
        for(int i=0;i<5;i++){
            float a=(float)(2*Math.PI*i/5);
            base.addOrReplaceChild("branch"+i,CubeListBuilder.create().texOffs(28,0).addBox(-1,-14,-1,2,14,2),
                PartPose.offsetAndRotation((float)Math.sin(a)*3,-12-i*3,(float)Math.cos(a)*3,(float)Math.cos(a)*.5F,0,(float)Math.sin(a)*.5F));
        }
        base.addOrReplaceChild("cursed_tip",CubeListBuilder.create().texOffs(40,0).addBox(-2,-5,-2,4,5,4),PartPose.offset(0,-34,0));
        return LayerDefinition.create(m,64,64);
    }
    @Override public ModelPart root(){return root;}
    @Override public void setupAnim(CurseRootEntity e,float walk,float amount,float age,float yaw,float pitch){}
}
