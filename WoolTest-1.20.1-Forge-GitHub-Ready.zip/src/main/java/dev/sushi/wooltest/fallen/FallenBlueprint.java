package dev.sushi.wooltest.fallen;

import java.io.IOException;
import javax.annotation.Nullable;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.Property;

public final class FallenBlueprint {
    private FallenBlueprint() { }
    private static final class Cache {
        static final FallenLayoutData DATA=load();
        static final BlockState[] STATES=DATA.palette().stream().map(FallenBlueprint::parse).toArray(BlockState[]::new);
    }
    private static FallenLayoutData load() {
        try { return FallenLayoutData.read(FallenBlueprint.class.getResourceAsStream("/data/wooltest/fallen/landmarks.frp.gz")); }
        catch(IOException e) { throw new IllegalStateException("Cannot read Fallen Realm landmarks",e); }
    }
    @Nullable public static FallenLayoutData.Site siteAt(int x,int z) {
        for(var site:Cache.DATA.sites()) if(site.contains(x,z))return site; return null;
    }
    public static BlockState state(FallenLayoutData.Site site,int x,int y,int z) { return Cache.STATES[site.index(x,y,z)]; }
    private static BlockState parse(String text) {
        int start=text.indexOf('[');
        ResourceLocation id=new ResourceLocation(start<0?text:text.substring(0,start));
        if(!BuiltInRegistries.BLOCK.containsKey(id))throw new IllegalStateException("Unknown Fallen Realm block "+id);
        BlockState state=BuiltInRegistries.BLOCK.get(id).defaultBlockState();
        if(start>=0)for(String s:text.substring(start+1,text.length()-1).split(",")) {
            String[] parts=s.split("=",2);Property<?> p=state.getBlock().getStateDefinition().getProperty(parts[0]);
            if(p==null)throw new IllegalStateException("Unknown property in "+text);state=apply(state,p,parts[1]);
        }
        return state;
    }
    private static <T extends Comparable<T>> BlockState apply(BlockState state,Property<T> p,String text) {
        return state.setValue(p,p.getValue(text).orElseThrow(()->new IllegalStateException("Invalid state value "+text)));
    }
}
