package dev.sushi.wooltest.fallen;

/** Pure encounter rules. User-specified counts/times/damage live here, not in render code. */
public final class FallenRules {
    private FallenRules() { }
    public static final int PALADINS = 3, ROOTS = 5;
    public static final int ROOT_WINDOW = 15 * 20, DETONATION_WINDUP = 2 * 20;
    public static final int DAMAGE_PER_ROOT = 70;
    public static int curseDamage(int roots) {
        return Math.max(0, Math.min(ROOTS, roots)) * DAMAGE_PER_ROOT;
    }
    public static float desiredShare(float damage, double perGuard) {
        if (!Float.isFinite(damage) || damage <= 0) return 0;
        return (float)(damage * Math.max(0, Math.min(0.30, perGuard)));
    }
    public static float damageAfterShare(float damage, float[] acceptedShares) {
        float used = 0;
        for (float share : acceptedShares) if (Float.isFinite(share)) used += Math.max(0, share);
        return Math.max(0, damage - Math.min(damage, used));
    }
    /** Half-open arena bounds, checked in addition to dimension and player eligibility. */
    public static boolean inside(double x, double y, double z, double ax, double ay, double az) {
        return Math.abs(x-ax) <= 21 && y >= ay-2 && y <= ay+13 && Math.abs(z-az) <= 24;
    }
    public static int remainingTicks(int now, int deadline) { return Math.max(0, deadline-now); }
}
