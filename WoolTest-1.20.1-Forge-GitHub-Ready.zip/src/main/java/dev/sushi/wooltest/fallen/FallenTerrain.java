package dev.sushi.wooltest.fallen;

/** Deterministic authored-region prototype. Shared by biome source and generator.
 * Layout seed is intentionally fixed for first-stage testing, not the world's random seed. */
public final class FallenTerrain {
    private FallenTerrain() { }
    public static final int[][] SITES = { {0,0,72,88}, {-320,160,47,47}, {288,224,32,32} };
    public static double noise(double x, double z) {
        int ix = (int)Math.floor(x), iz = (int)Math.floor(z);
        double fx=x-ix, fz=z-iz; fx=fx*fx*(3-2*fx); fz=fz*fz*(3-2*fz);
        return lerp(lerp(hash(ix,iz),hash(ix+1,iz),fx),lerp(hash(ix,iz+1),hash(ix+1,iz+1),fx),fz);
    }
    public static double hash(int x, int z) {
        long h = (long)x * 341873128712L + (long)z * 132897987541L + 67231L;
        h = (h ^ (h >>> 30)) * 0xbf58476d1ce4e5b9L;
        h = (h ^ (h >>> 27)) * 0x94d049bb133111ebL;
        return ((h ^ (h >>> 31)) & 0xffffffL) / (double)0xffffffL;
    }
    private static double lerp(double a,double b,double t) { return a+(b-a)*t; }
    private static double smooth(double a,double b,double n) {
        double t=Math.max(0,Math.min(1,(n-a)/(b-a))); return t*t*(3-2*t);
    }
    public static double mountains(int x,int z) {
        double geographic = (x-z-300.0)/900.0;
        return smooth(-0.10,0.48,geographic + (noise(x/330.0,z/330.0)-0.5)*0.55);
    }
    public static double forest(int x,int z) {
        return smooth(0.32,0.62,noise(x/280.0-3,z/280.0+7));
    }
    public static int distanceToSite(int x,int z,int[] s) {
        return Math.max(Math.max(0,Math.abs(x-s[0])-s[2]),Math.max(0,Math.abs(z-s[1])-s[3]));
    }
    public static int biome(int x,int z) {
        if(distanceToSite(x,z,SITES[0])<32) return 0;
        if(distanceToSite(x,z,SITES[1])<48 || distanceToSite(x,z,SITES[2])<48) return 1;
        return mountains(x,z)>0.5 ? 2 : forest(x,z)>0.5 ? 1 : 0;
    }
    public static int height(int x,int z) {
        double m=mountains(x,z);
        double ridges=1-Math.abs(2*noise(x/65.0,z/65.0)-1);
        double h=65 + 10*noise(x/150.0,z/150.0) + 6*noise(x/38.0,z/38.0)
                + m*(28+62*ridges+10*noise(x/17.0,z/17.0));
        for(int[] s:SITES) { int d=distanceToSite(x,z,s); if(d<48) h=lerp(72,h,smooth(0,48,d)); }
        return (int)Math.round(h);
    }
    public static boolean vegetationAllowed(int x,int z) {
        for(int[] s:SITES) if(distanceToSite(x,z,s)<12) return false;
        return true;
    }
    public static boolean treeCell(int gx,int gz) {
        int x=gx*8+4,z=gz*8+4;
        return vegetationAllowed(x,z) && biome(x,z)==1 && hash(gx+273,gz-81)>.20;
    }
}
