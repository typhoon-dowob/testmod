package dev.sushi.wooltest.fallen.client;
import com.mojang.blaze3d.vertex.PoseStack;
import dev.sushi.wooltest.fallen.*;
import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.renderer.entity.*;
import net.minecraft.client.renderer.entity.layers.ItemInHandLayer;
import net.minecraft.resources.ResourceLocation;

/** Prototype visuals: five original skins on the built-in humanoid skeleton, not final bespoke meshes. */
public final class FallenMobRenderer<T extends FallenMob> extends HumanoidMobRenderer<T,HumanoidModel<T>> {
    public FallenMobRenderer(EntityRendererProvider.Context c){
        super(c,new HumanoidModel<T>(c.bakeLayer(ModelLayers.ZOMBIE)),.55F);
        addLayer(new ItemInHandLayer<>(this,c.getItemInHandRenderer()));
    }
    @Override public ResourceLocation getTextureLocation(T entity){
        String path=switch(entity.role){case KNIGHT->"slot_knight";case PRIEST->"central_priest";case APOSTLE->"dark_apostle";case PALADIN->"slot_paladin";case BOSS->"eskarchi";};
        return new ResourceLocation("wooltest","textures/entity/fallen/"+path+".png");
    }
    @Override protected void scale(T entity,PoseStack pose,float partial){
        float s=entity.role==FallenMob.Role.BOSS?1.35F:entity.role==FallenMob.Role.PALADIN?1.1F:1F;
        pose.scale(s,s,s);
    }
}
