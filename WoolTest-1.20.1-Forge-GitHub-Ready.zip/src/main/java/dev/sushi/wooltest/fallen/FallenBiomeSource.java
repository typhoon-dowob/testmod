package dev.sushi.wooltest.fallen;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import java.util.stream.Stream;
import net.minecraft.core.Holder;
import net.minecraft.world.level.biome.Biome;
import net.minecraft.world.level.biome.BiomeSource;
import net.minecraft.world.level.biome.Climate;

public final class FallenBiomeSource extends BiomeSource {
    public static final Codec<FallenBiomeSource> CODEC = RecordCodecBuilder.create(i -> i.group(
            Biome.CODEC.fieldOf("darklands").forGetter(s -> s.darklands),
            Biome.CODEC.fieldOf("densewood").forGetter(s -> s.densewood),
            Biome.CODEC.fieldOf("peaks").forGetter(s -> s.peaks)).apply(i, FallenBiomeSource::new));
    private final Holder<Biome> darklands, densewood, peaks;
    public FallenBiomeSource(Holder<Biome> d,Holder<Biome> f,Holder<Biome> p) {
        super(); darklands=d; densewood=f; peaks=p;
    }
    @Override protected Stream<Holder<Biome>> collectPossibleBiomes() { return Stream.of(darklands,densewood,peaks); }
    @Override protected Codec<? extends BiomeSource> codec() { return CODEC; }
    @Override public Holder<Biome> getNoiseBiome(int x,int y,int z,Climate.Sampler sampler) {
        return switch(FallenTerrain.biome(x*4,z*4)) { case 1 -> densewood; case 2 -> peaks; default -> darklands; };
    }
}
