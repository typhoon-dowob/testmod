package dev.sushi.wooltest.fallen;

import com.mojang.serialization.Codec;
import dev.sushi.wooltest.WoolTestMod;
import net.minecraft.core.registries.Registries;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.SwordItem;
import net.minecraft.world.item.Tiers;
import net.minecraft.world.level.biome.BiomeSource;
import net.minecraft.world.level.chunk.ChunkGenerator;
import net.minecraftforge.common.ForgeSpawnEggItem;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.event.entity.EntityAttributeCreationEvent;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.ModLoadingContext;
import net.minecraftforge.fml.config.ModConfig;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public final class FallenRealm {
    private FallenRealm() { }
    private static final DeferredRegister<EntityType<?>> ENTITIES=DeferredRegister.create(ForgeRegistries.ENTITY_TYPES,WoolTestMod.MOD_ID);
    private static final DeferredRegister<Item> ITEMS=DeferredRegister.create(ForgeRegistries.ITEMS,WoolTestMod.MOD_ID);
    private static final DeferredRegister<Codec<? extends ChunkGenerator>> GENERATORS=DeferredRegister.create(Registries.CHUNK_GENERATOR,WoolTestMod.MOD_ID);
    private static final DeferredRegister<Codec<? extends BiomeSource>> BIOMES=DeferredRegister.create(Registries.BIOME_SOURCE,WoolTestMod.MOD_ID);
    private static RegistryObject<EntityType<FallenMob>> mob(String name,FallenMob.Role role,float w,float h) {
        return ENTITIES.register(name,()->EntityType.Builder.<FallenMob>of((t,l)->new FallenMob(t,l,role),MobCategory.MONSTER)
                .sized(w,h).clientTrackingRange(8).build("wooltest:"+name));
    }
    public static final RegistryObject<EntityType<FallenMob>> KNIGHT=mob("slot_knight",FallenMob.Role.KNIGHT,.7F,2F);
    public static final RegistryObject<EntityType<FallenMob>> PRIEST=mob("central_priest",FallenMob.Role.PRIEST,.6F,1.95F);
    public static final RegistryObject<EntityType<FallenMob>> APOSTLE=mob("dark_apostle",FallenMob.Role.APOSTLE,.6F,1.95F);
    public static final RegistryObject<EntityType<FallenMob>> PALADIN=mob("slot_paladin",FallenMob.Role.PALADIN,.8F,2.2F);
    public static final RegistryObject<EntityType<EskarchiEntity>> ESKARCHI=ENTITIES.register("eskarchi",()->EntityType.Builder.of(EskarchiEntity::new,MobCategory.MONSTER)
            .sized(1.2F,2.8F).clientTrackingRange(10).build("wooltest:eskarchi"));
    public static final RegistryObject<EntityType<CurseRootEntity>> ROOT=ENTITIES.register("cursed_root",()->EntityType.Builder.of(CurseRootEntity::new,MobCategory.MONSTER)
            .sized(.9F,2.6F).clientTrackingRange(10).build("wooltest:cursed_root"));
    public static final RegistryObject<Item> ARMOR_SHARD=ITEMS.register("armor_shard",()->new Item(new Item.Properties()));
    public static final RegistryObject<Item> EMBER_PAGE=ITEMS.register("ember_page",()->new Item(new Item.Properties()));
    public static final RegistryObject<Item> DARK_PENDANT=ITEMS.register("dark_pendant",()->new Item(new Item.Properties()));
    public static final RegistryObject<Item> CHRONICLE=ITEMS.register("empire_chronicle",()->new Item(new Item.Properties()));
    public static final RegistryObject<Item> DOSSIER=ITEMS.register("fallen_dossier",()->new Item(new Item.Properties()));
    public static final RegistryObject<SwordItem> HOLY_SWORD=ITEMS.register("slot_holy_sword",FallenSwordItem::new);
    public static final RegistryObject<SoulHelmetItem> SOUL_HELMET=ITEMS.register("eskarchi_soul",SoulHelmetItem::new);
    public static final RegistryObject<Item> KNIGHT_EGG=ITEMS.register("slot_knight_spawn_egg",()->new ForgeSpawnEggItem(KNIGHT,0x353b44,0x8b6a3c,new Item.Properties()));
    public static final RegistryObject<Item> PRIEST_EGG=ITEMS.register("central_priest_spawn_egg",()->new ForgeSpawnEggItem(PRIEST,0x372b36,0xd29245,new Item.Properties()));
    public static final RegistryObject<Item> APOSTLE_EGG=ITEMS.register("dark_apostle_spawn_egg",()->new ForgeSpawnEggItem(APOSTLE,0x151c24,0x65628f,new Item.Properties()));
    public static final RegistryObject<Item> BOSS_EGG=ITEMS.register("eskarchi_spawn_egg",()->new ForgeSpawnEggItem(ESKARCHI,0x171a21,0xc2a160,new Item.Properties()));
    public static final RegistryObject<Codec<? extends ChunkGenerator>> GENERATOR=GENERATORS.register("fallen_realm",()->FallenChunkGenerator.CODEC);
    public static final RegistryObject<Codec<? extends BiomeSource>> SOURCE=BIOMES.register("fallen_regions",()->FallenBiomeSource.CODEC);
    public static void register(IEventBus bus) {
        ENTITIES.register(bus);ITEMS.register(bus);GENERATORS.register(bus);BIOMES.register(bus);
        bus.addListener(FallenRealm::attributes);
        ModLoadingContext.get().registerConfig(ModConfig.Type.SERVER,FallenConfig.SPEC,"wooltest-fallen-realm-server.toml");
        MinecraftForge.EVENT_BUS.addListener(FallenCommands::register);
        MinecraftForge.EVENT_BUS.addListener(FallenWorldEvents::tick);
        MinecraftForge.EVENT_BUS.addListener(FallenWorldEvents::shareDamage);
        MinecraftForge.EVENT_BUS.addListener(FallenTravel::onClone);
    }
    private static void attributes(EntityAttributeCreationEvent e) {
        e.put(KNIGHT.get(),FallenMob.attributes(FallenMob.Role.KNIGHT).build());
        e.put(PRIEST.get(),FallenMob.attributes(FallenMob.Role.PRIEST).build());
        e.put(APOSTLE.get(),FallenMob.attributes(FallenMob.Role.APOSTLE).build());
        e.put(PALADIN.get(),FallenMob.attributes(FallenMob.Role.PALADIN).build());
        e.put(ESKARCHI.get(),FallenMob.attributes(FallenMob.Role.BOSS).build());
        e.put(ROOT.get(),CurseRootEntity.attributes().build());
    }
}
