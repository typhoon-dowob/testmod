package dev.sushi.wooltest.fallen;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.Difficulty;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.phys.AABB;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.living.LivingDamageEvent;

public final class FallenWorldEvents {
    private FallenWorldEvents(){}
    // First pass: guards are specific to the imperial center, not global biome spawns.
    private static final int[][] MARKERS={ {-12,60,0},{12,60,0},{-16,40,1},{16,40,1},
            {-12,18,2},{12,18,2},{-42,-30,0},{42,-30,0},{-44,-48,1},{44,-48,1},
            {-12,-69,2},{12,-69,2} };
    public static void tick(TickEvent.ServerTickEvent e){
        if(e.phase!=TickEvent.Phase.END||e.getServer().getTickCount()%20!=0)return;
        ServerLevel s=e.getServer().getLevel(FallenTravel.REALM);
        if(s==null||s.getDifficulty()==Difficulty.PEACEFUL||s.players().isEmpty())return;
        FallenProgress data=FallenProgress.get(s);
        for(int i=0;i<MARKERS.length;i++){
            if(data.spawned.contains(i))continue;
            int[] m=MARKERS[i];double x=m[0]+.5,z=m[1]+.5;
            if(s.players().stream().noneMatch(p->!p.isSpectator()&&p.distanceToSqr(x,73,z)<48*48))continue;
            BlockPos floor=new BlockPos(m[0],72,m[1]);if(!safeFloor(s,floor))continue;
            // Recover from an interrupted save without creating a second copy.
            final int marker=i;
            var nearby=s.getEntitiesOfClass(FallenMob.class,new AABB(floor).inflate(48),v->v.getPersistentData().getBoolean("FallenGarrison")&&v.getPersistentData().getInt("FallenMarker")==marker);
            if(!nearby.isEmpty()){data.mark(i);continue;}
            FallenMob mob=(m[2]==0?FallenRealm.KNIGHT:m[2]==1?FallenRealm.PRIEST:FallenRealm.APOSTLE).get().create(s);
            if(mob==null)continue;mob.moveTo(x,73,z,180,0);
            if(!s.noCollision(mob)||!s.getEntities((Entity)null,mob.getBoundingBox(),o->!o.isSpectator()).isEmpty())continue;
            mob.getPersistentData().putBoolean("FallenGarrison",true);mob.getPersistentData().putInt("FallenMarker",i);
            if(s.addFreshEntity(mob))data.mark(i);
        }
        if(data.bossSpawned||data.defeated)return;
        double x=.5,y=73,z=-28.5;
        if(s.players().stream().noneMatch(p->!p.isSpectator()&&p.distanceToSqr(x,y,z)<56*56))return;
        BlockPos floor=new BlockPos(0,72,-29);if(!safeFloor(s,floor))return;
        for(var boss:s.getEntitiesOfClass(EskarchiEntity.class,new AABB(floor).inflate(48)))if(boss.isNatural()){data.markBoss(boss.getUUID());return;}
        EskarchiEntity boss=FallenRealm.ESKARCHI.get().create(s);if(boss==null)return;
        boss.moveTo(x,y,z,0,0);boss.anchor(x,y,z,true);
        if(s.noCollision(boss)&&s.getEntities((Entity)null,boss.getBoundingBox(),o->!o.isSpectator()).isEmpty()&&s.addFreshEntity(boss))data.markBoss(boss.getUUID());
    }
    private static boolean safeFloor(ServerLevel l,BlockPos p){return l.hasChunkAt(p)&&l.getBlockState(p).isFaceSturdy(l,p,Direction.UP)&&l.getBlockState(p.above()).isAir()&&l.getBlockState(p.above(2)).isAir()&&l.getBlockState(p.above(3)).isAir();}
    public static void shareDamage(LivingDamageEvent e){
        if(!(e.getEntity() instanceof EskarchiEntity boss)||boss.level().isClientSide||!boss.isAlive()||e.getAmount()<=0||!Float.isFinite(e.getAmount()))return;
        var guards=boss.livingPaladins();if(guards.isEmpty())return;
        float incoming=e.getAmount(),request=FallenRules.desiredShare(incoming,FallenConfig.GUARD_SHARE.get());
        float[] taken=new float[Math.min(FallenRules.PALADINS,guards.size())];
        for(int i=0;i<taken.length;i++){
            FallenMob guard=guards.get(i);float before=guard.getHealth();
            float share=Math.min(request,before);
            if(share>0&&guard.hurt(FallenDamage.source(boss.level(),"slot_oath_share",e.getSource().getEntity()),share))
                taken[i]=Math.min(share,Math.max(0,before-guard.getHealth()));
        }
        // No phantom reduction: cancelled or resisted redirected damage stays on the boss.
        e.setAmount(FallenRules.damageAfterShare(incoming,taken));
    }
}
