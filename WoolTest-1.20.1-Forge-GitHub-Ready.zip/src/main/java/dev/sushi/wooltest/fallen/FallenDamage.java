package dev.sushi.wooltest.fallen;
import javax.annotation.Nullable;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.damagesource.*;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.Level;
public final class FallenDamage {
    private FallenDamage(){}
    public static DamageSource source(Level level,String path,@Nullable Entity attacker) {
        ResourceKey<DamageType> key=ResourceKey.create(Registries.DAMAGE_TYPE,new ResourceLocation("wooltest",path));
        return new DamageSource(level.registryAccess().registryOrThrow(Registries.DAMAGE_TYPE).getHolderOrThrow(key),attacker);
    }
}
