package dev.sushi.wooltest.fallen;

import java.util.*;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.network.syncher.*;
import net.minecraft.server.level.*;
import net.minecraft.sounds.*;
import net.minecraft.world.BossEvent;
import net.minecraft.world.Difficulty;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.*;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.effect.*;
import net.minecraft.world.item.*;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.*;

/** Server-authoritative arena encounter. Rehydration cancels pending spells instead of replaying stale damage. */
public final class EskarchiEntity extends FallenMob {
    private static final EntityDataAccessor<Integer> PHASE=SynchedEntityData.defineId(EskarchiEntity.class,EntityDataSerializers.INT);
    private static final EntityDataAccessor<Integer> ROOT_COUNT=SynchedEntityData.defineId(EskarchiEntity.class,EntityDataSerializers.INT);
    private final ServerBossEvent bar=new ServerBossEvent(Component.translatable("entity.wooltest.eskarchi"),BossEvent.BossBarColor.PURPLE,BossEvent.BossBarOverlay.PROGRESS);
    private UUID encounter=UUID.randomUUID();
    private final List<UUID> rootIds=new ArrayList<>();
    private final Set<UUID> brokenRoots=new HashSet<>();
    private final List<UUID> paladinIds=new ArrayList<>();
    private final Set<UUID> deadPaladins=new HashSet<>();
    private double arenaX,arenaY,arenaZ;
    private boolean anchored,natural,active;
    private int deadline,lockedRoots,idleTicks,curseCooldown=160,summonCooldown=20;
    public EskarchiEntity(EntityType<? extends EskarchiEntity> type,Level level){
        super(type,level,Role.BOSS);xpReward=60;
        if(!level.isClientSide){getAttribute(Attributes.MAX_HEALTH).setBaseValue(FallenConfig.BOSS_HEALTH.get());setHealth(getMaxHealth());}
        setItemSlot(EquipmentSlot.MAINHAND,new ItemStack(FallenRealm.HOLY_SWORD.get()));setDropChance(EquipmentSlot.MAINHAND,0F);
    }
    @Override protected void defineSynchedData(){super.defineSynchedData();entityData.define(PHASE,0);entityData.define(ROOT_COUNT,0);}
    public UUID encounterId(){return encounter;}
    public int phase(){return entityData.get(PHASE);}
    public boolean hasRoots(){return phase()==1||phase()==2;}
    public boolean rootsAreBreakable(){return phase()==1 && tickCount<deadline;}
    public void rootDestroyed(UUID id){if(rootsAreBreakable()&&rootIds.contains(id))brokenRoots.add(id);}
    @Override public boolean combatLocked(){return !active||phase()!=0;}
    public void anchor(double x,double y,double z,boolean worldBoss){arenaX=x;arenaY=y;arenaZ=z;anchored=true;natural=worldBoss;}
    public boolean isNatural(){return natural;}
    public void paladinDefeated(UUID id){if(paladinIds.contains(id))deadPaladins.add(id);}
    private boolean outstandingPaladins(){return paladinIds.stream().anyMatch(id -> !deadPaladins.contains(id));}
    public boolean inArena(Entity e){return e.level()==level()&&FallenRules.inside(e.getX(),e.getY(),e.getZ(),arenaX,arenaY,arenaZ);}
    private List<ServerPlayer> players(){
        if(!(level() instanceof ServerLevel s))return List.of();
        return s.players().stream().filter(p->eligible(p)&&inArena(p)).toList();
    }
    @Override public void tick(){
        super.tick();if(!(level() instanceof ServerLevel s)||!isAlive())return;
        if(!anchored)anchor(getX(),getY(),getZ(),false);
        if(level().getDifficulty()==Difficulty.PEACEFUL){if(active)resetFight();bar.removeAllPlayers();return;}
        List<ServerPlayer> players=players();
        for(ServerPlayer p:s.players()) {if(eligible(p)&&inArena(p))bar.addPlayer(p);else bar.removePlayer(p);}
        bar.setProgress(Math.max(0,Math.min(1,getHealth()/getMaxHealth())));
        if(players.isEmpty()) {
            setTarget(null);getNavigation().stop();
            if(!active)return;
            if(++idleTicks>=200){resetFight();return;}
        }else {active=true;idleTicks=0;}
        if(!inArena(this)){teleportTo(arenaX,arenaY,arenaZ);getNavigation().stop();}
        if(!players.isEmpty()&&(getTarget()==null||!getTarget().isAlive()||!inArena(getTarget())))
            setTarget(players.stream().min(Comparator.comparingDouble(p -> distanceToSqr(p))).orElse(players.get(0)));
        if(phase()==1){
            int remaining=rootIds.size()-brokenRoots.size();entityData.set(ROOT_COUNT,remaining);
            int left=FallenRules.remainingTicks(tickCount,deadline);
            bar.setName(Component.translatable("entity.wooltest.eskarchi").append(" | 纏咒木根 "+remaining+"/5 | "+((left+19)/20)+"s"));
            if(tickCount%10==0)rootLinks(s);
            if(remaining==0){tell(players,"木根已全部破壞，黯法禁咒取消！");finishCurse();}
            else if(tickCount>=deadline){
                lockedRoots=remaining;entityData.set(PHASE,2);deadline=tickCount+FallenRules.DETONATION_WINDUP;
                tell(players,"禁咒成形！剩餘 "+lockedRoots+" 根，2 秒後造成 "+FallenRules.curseDamage(lockedRoots)+" 點基礎傷害。");
                for(ServerPlayer p:players)p.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN,60,FallenConfig.SLOW_AMPLIFIER.get()));
                s.playSound(null,blockPosition(),SoundEvents.EVOKER_PREPARE_ATTACK,SoundSource.HOSTILE,1.4F,.55F);
            }
        }else if(phase()==2){
            bar.setName(Component.translatable("entity.wooltest.eskarchi").append(" | 黯法禁咒 "+lockedRoots+"×70"));
            // Late entrants receive the warning debuff, but never damage repeatedly.
            for(ServerPlayer p:players)if(p.getEffect(MobEffects.MOVEMENT_SLOWDOWN)==null || p.getEffect(MobEffects.MOVEMENT_SLOWDOWN).getAmplifier()<FallenConfig.SLOW_AMPLIFIER.get())
                p.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN,Math.max(1,deadline-tickCount)+20,FallenConfig.SLOW_AMPLIFIER.get()));
            if(tickCount%4==0)s.sendParticles(ParticleTypes.SOUL,getX(),getY()+1.5,getZ(),12,1,1,1,.04);
            if(tickCount>=deadline){
                int damage=FallenRules.curseDamage(lockedRoots);
                // Fresh arena membership: every living survival/adventure player currently inside, not only aggro target.
                for(ServerPlayer p:players){
                    p.hurt(FallenDamage.source(s,"fallen_curse",this),damage);
                    s.sendParticles(ParticleTypes.SOUL_FIRE_FLAME,p.getX(),p.getY()+1,p.getZ(),30,.6,1,.6,.08);
                }
                s.playSound(null,blockPosition(),SoundEvents.WITHER_SHOOT,SoundSource.HOSTILE,1.2F,.6F);
                finishCurse();
            }
        }else{
            if(players.isEmpty())return;
            bar.setName(Component.translatable("entity.wooltest.eskarchi").append(" | 聖騎士 "+livingPaladins().size()+"/3"));
            if(summonCooldown>0)summonCooldown--;
            if(curseCooldown>0)curseCooldown--;
            if(summonCooldown==0&&!outstandingPaladins()){
                if(summonPaladins())tell(players,"亡靈復甦：三名帝國聖騎士與厄斯卡奇締結分傷誓約。");
                summonCooldown=600;
            }
            if(curseCooldown==0){if(beginCurse())tell(players,"黯法禁咒：15 秒內擊破五根纏咒木根！");else curseCooldown=40;}
        }
    }
    public boolean beginCurse(){
        if(!(level() instanceof ServerLevel s)||!isAlive()||phase()!=0||players().isEmpty())return false;
        if(!anchored)anchor(getX(),getY(),getZ(),false);
        // Keep the caster inside the open objective arena before selecting a ring.
        teleportTo(arenaX,arenaY,arenaZ);getNavigation().stop();
        List<CurseRootEntity> created=new ArrayList<>();
        for(int k=0;k<FallenRules.ROOTS;k++){
            double angle=2*Math.PI*k/FallenRules.ROOTS;
            CurseRootEntity root=FallenRealm.ROOT.get().create(s);
            if(root==null){created.forEach(Entity::discard);return false;}
            root.bind(this);boolean placed=false;
            search: for(int radius:new int[]{10,12,8})for(double offset:new double[]{0,.18,-.18}){
                double x=arenaX+Math.round(Math.sin(angle+offset)*radius),z=arenaZ+Math.round(Math.cos(angle+offset)*radius);
                root.moveTo(x,arenaY,z,0,0);
                if(safe(s,root)&&s.addFreshEntity(root)){placed=true;break search;}
            }
            if(!placed){root.discard();created.forEach(Entity::discard);return false;}
            created.add(root);
        }
        rootIds.clear();brokenRoots.clear();created.forEach(r->rootIds.add(r.getUUID()));lockedRoots=0;
        entityData.set(ROOT_COUNT,FallenRules.ROOTS);entityData.set(PHASE,1);deadline=tickCount+FallenRules.ROOT_WINDOW;
        active=true;s.playSound(null,blockPosition(),SoundEvents.EVOKER_PREPARE_SUMMON,SoundSource.HOSTILE,1F,.7F);
        return true;
    }
    public boolean summonPaladins(){
        if(!(level() instanceof ServerLevel s)||outstandingPaladins()||!isAlive())return false;
        List<FallenMob> made=new ArrayList<>();
        for(int i=0;i<FallenRules.PALADINS;i++){
            double angle=2*Math.PI*i/3;
            FallenMob p=FallenRealm.PALADIN.get().create(s);if(p==null){made.forEach(Entity::discard);return false;}
            p.bind(this);boolean placed=false;
            for(int radius:new int[]{6,8,5}){
                p.moveTo(arenaX+Math.sin(angle)*radius,arenaY,arenaZ+Math.cos(angle)*radius,0,0);
                if(safe(s,p)&&s.addFreshEntity(p)){placed=true;break;}
            }
            if(!placed){p.discard();made.forEach(Entity::discard);return false;}
            made.add(p);s.sendParticles(ParticleTypes.SOUL,p.getX(),p.getY()+1,p.getZ(),20,.4,1,.4,.04);
        }
        paladinIds.clear();deadPaladins.clear();made.forEach(p->paladinIds.add(p.getUUID()));return true;
    }
    private static boolean safe(ServerLevel s,Entity e){
        BlockPos floor=BlockPos.containing(e.getX(),e.getY()-.1,e.getZ());
        return s.hasChunkAt(floor)&&s.getBlockState(floor).isFaceSturdy(s,floor,net.minecraft.core.Direction.UP)
                &&s.noCollision(e)&&s.getEntities((Entity)null,e.getBoundingBox(),o->!o.isSpectator()).isEmpty();
    }
    private List<CurseRootEntity> livingRoots(){
        if(!(level() instanceof ServerLevel s))return List.of();
        List<CurseRootEntity> result=new ArrayList<>();
        for(UUID id:rootIds)if(s.getEntity(id) instanceof CurseRootEntity r&&r.isAlive()&&r.belongsTo(this))result.add(r);
        return result;
    }
    public List<FallenMob> livingPaladins(){
        if(!(level() instanceof ServerLevel s))return List.of();
        List<FallenMob> result=new ArrayList<>();
        for(UUID id:paladinIds)if(s.getEntity(id) instanceof FallenMob p&&p.isAlive()&&p.belongsTo(this)&&inArena(p))result.add(p);
        return result;
    }
    private void rootLinks(ServerLevel s){
        for(var root:livingRoots()){
            Vec3 a=position().add(0,.3,0),delta=root.position().add(0,.3,0).subtract(a);
            for(int i=0;i<=10;i++){Vec3 p=a.add(delta.scale(i/10D));s.sendParticles(ParticleTypes.WITCH,p.x,p.y,p.z,1,0,0,0,0);}
        }
    }
    private void finishCurse(){
        if(level() instanceof ServerLevel s)for(UUID id:rootIds)if(s.getEntity(id) instanceof CurseRootEntity root&&root.belongsTo(this))root.discard();
        rootIds.clear();brokenRoots.clear();entityData.set(PHASE,0);entityData.set(ROOT_COUNT,0);lockedRoots=0;curseCooldown=FallenConfig.CURSE_COOLDOWN.get();
    }
    private void clearAdds(){
        finishCurse();
        if(level() instanceof ServerLevel s)for(UUID id:paladinIds)if(s.getEntity(id) instanceof FallenMob p&&p.belongsTo(this))p.discard();
        paladinIds.clear();deadPaladins.clear();encounter=UUID.randomUUID();
    }
    private void resetFight(){clearAdds();active=false;idleTicks=0;summonCooldown=20;curseCooldown=160;setHealth(getMaxHealth());setTarget(null);getNavigation().stop();if(anchored)teleportTo(arenaX,arenaY,arenaZ);bar.removeAllPlayers();}
    private static void tell(List<ServerPlayer> p,String text){for(ServerPlayer v:p)v.displayClientMessage(Component.literal(text),false);}
    @Override public boolean hurt(DamageSource source,float amount){
        // Administrative /kill must remain usable even outside ordinary encounter rules.
        if(source.is(net.minecraft.world.damagesource.DamageTypes.GENERIC_KILL))return super.hurt(source,amount);
        if(level().getDifficulty()==Difficulty.PEACEFUL)return false;
        if(source.getEntity() instanceof net.minecraft.world.entity.player.Player p&&anchored&&!inArena(p))return false;
        return super.hurt(source,amount);
    }
    @Override protected void dropCustomDeathLoot(DamageSource source,int looting,boolean recent){
        if(level().isClientSide || !level().getGameRules().getBoolean(net.minecraft.world.level.GameRules.RULE_DOMOBLOOT))return;
        Item[] items={FallenRealm.CHRONICLE.get(),FallenRealm.DOSSIER.get(),FallenRealm.HOLY_SWORD.get(),FallenRealm.SOUL_HELMET.get()};
        double[] chances={FallenConfig.CHRONICLE_DROP.get(),FallenConfig.DOSSIER_DROP.get(),FallenConfig.SWORD_DROP.get(),FallenConfig.HELMET_DROP.get()};
        for(int i=0;i<items.length;i++)if(getRandom().nextDouble()<chances[i])spawnAtLocation(new ItemStack(items[i]));
    }
    @Override public void die(DamageSource source){
        if(!level().isClientSide){clearAdds();bar.removeAllPlayers();if(natural&&level() instanceof ServerLevel s)FallenProgress.get(s).defeat();}
        super.die(source);
    }
    @Override public void remove(RemovalReason reason){if(!level().isClientSide){clearAdds();bar.removeAllPlayers();}super.remove(reason);}
    @Override public void startSeenByPlayer(ServerPlayer p){super.startSeenByPlayer(p);if(eligible(p)&&inArena(p)&&isAlive())bar.addPlayer(p);}
    @Override public void stopSeenByPlayer(ServerPlayer p){super.stopSeenByPlayer(p);bar.removePlayer(p);}
    @Override public void addAdditionalSaveData(CompoundTag t){
        super.addAdditionalSaveData(t);t.putBoolean("FallenNatural",natural);t.putBoolean("Anchored",anchored);
        t.putDouble("ArenaX",arenaX);t.putDouble("ArenaY",arenaY);t.putDouble("ArenaZ",arenaZ);
    }
    @Override public void readAdditionalSaveData(CompoundTag t){
        super.readAdditionalSaveData(t);natural=t.getBoolean("FallenNatural");anchored=t.getBoolean("Anchored");
        arenaX=t.getDouble("ArenaX");arenaY=t.getDouble("ArenaY");arenaZ=t.getDouble("ArenaZ");
        encounter=UUID.randomUUID();rootIds.clear();brokenRoots.clear();paladinIds.clear();deadPaladins.clear();active=false;entityData.set(PHASE,0);entityData.set(ROOT_COUNT,0);
        setHealth(getMaxHealth());summonCooldown=20;curseCooldown=160;
    }
}
