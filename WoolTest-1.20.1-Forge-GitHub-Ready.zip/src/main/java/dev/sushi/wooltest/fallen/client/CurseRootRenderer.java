package dev.sushi.wooltest.fallen.client;
import dev.sushi.wooltest.fallen.CurseRootEntity;
import net.minecraft.client.renderer.entity.*;
import net.minecraft.resources.ResourceLocation;
public final class CurseRootRenderer extends MobRenderer<CurseRootEntity,CurseRootModel>{
    private static final ResourceLocation TEXTURE=new ResourceLocation("wooltest","textures/entity/fallen/cursed_root.png");
    public CurseRootRenderer(EntityRendererProvider.Context c){super(c,new CurseRootModel(c.bakeLayer(CurseRootModel.LAYER)),.4F);}
    @Override public ResourceLocation getTextureLocation(CurseRootEntity e){return TEXTURE;}
}
