package dev.sushi.wooltest.fallen;
import java.util.*;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.saveddata.SavedData;

/** One-time authored garrisons and boss; neither repopulate just because a chunk reloads. */
public final class FallenProgress extends SavedData {
    public final Set<Integer> spawned=new HashSet<>();
    public UUID boss;
    public boolean bossSpawned,defeated;
    public static FallenProgress get(ServerLevel l){return l.getDataStorage().computeIfAbsent(FallenProgress::load,FallenProgress::new,"wooltest_fallen_realm_v1");}
    private static FallenProgress load(CompoundTag t){
        FallenProgress p=new FallenProgress();for(int id:t.getIntArray("Spawned"))p.spawned.add(id);
        p.boss=t.hasUUID("Boss")?t.getUUID("Boss"):null;p.bossSpawned=t.getBoolean("BossSpawned");p.defeated=t.getBoolean("Defeated");return p;
    }
    public void mark(int marker){spawned.add(marker);setDirty();}
    public void markBoss(UUID id){boss=id;bossSpawned=true;setDirty();}
    public void defeat(){defeated=true;setDirty();}
    @Override public CompoundTag save(CompoundTag t){
        t.putIntArray("Spawned",spawned.stream().mapToInt(Integer::intValue).sorted().toArray());
        if(boss!=null)t.putUUID("Boss",boss);t.putBoolean("BossSpawned",bossSpawned);t.putBoolean("Defeated",defeated);return t;
    }
}
