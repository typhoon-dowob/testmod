package dev.sushi.wooltest.fallen.client;
import dev.sushi.wooltest.WoolTestMod;
import dev.sushi.wooltest.fallen.*;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.event.BuildCreativeModeTabContentsEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid=WoolTestMod.MOD_ID,bus=Mod.EventBusSubscriber.Bus.MOD,value=Dist.CLIENT)
public final class FallenClient {
    private FallenClient(){}
    @SubscribeEvent public static void layers(EntityRenderersEvent.RegisterLayerDefinitions e){e.registerLayerDefinition(CurseRootModel.LAYER,CurseRootModel::layer);}
    @SubscribeEvent public static void renderers(EntityRenderersEvent.RegisterRenderers e){
        e.registerEntityRenderer(FallenRealm.KNIGHT.get(),c->new FallenMobRenderer<FallenMob>(c));
        e.registerEntityRenderer(FallenRealm.PRIEST.get(),c->new FallenMobRenderer<FallenMob>(c));
        e.registerEntityRenderer(FallenRealm.APOSTLE.get(),c->new FallenMobRenderer<FallenMob>(c));
        e.registerEntityRenderer(FallenRealm.PALADIN.get(),c->new FallenMobRenderer<FallenMob>(c));
        e.registerEntityRenderer(FallenRealm.ESKARCHI.get(),c->new FallenMobRenderer<EskarchiEntity>(c));
        e.registerEntityRenderer(FallenRealm.ROOT.get(),CurseRootRenderer::new);
    }
    @SubscribeEvent public static void tabs(BuildCreativeModeTabContentsEvent e){
        if(e.getTabKey()==CreativeModeTabs.COMBAT){e.accept(FallenRealm.HOLY_SWORD.get());e.accept(FallenRealm.SOUL_HELMET.get());}
        if(e.getTabKey()==CreativeModeTabs.INGREDIENTS){e.accept(FallenRealm.ARMOR_SHARD.get());e.accept(FallenRealm.EMBER_PAGE.get());e.accept(FallenRealm.DARK_PENDANT.get());e.accept(FallenRealm.CHRONICLE.get());e.accept(FallenRealm.DOSSIER.get());}
        if(e.getTabKey()==CreativeModeTabs.SPAWN_EGGS){e.accept(FallenRealm.KNIGHT_EGG.get());e.accept(FallenRealm.PRIEST_EGG.get());e.accept(FallenRealm.APOSTLE_EGG.get());e.accept(FallenRealm.BOSS_EGG.get());}
    }
}
