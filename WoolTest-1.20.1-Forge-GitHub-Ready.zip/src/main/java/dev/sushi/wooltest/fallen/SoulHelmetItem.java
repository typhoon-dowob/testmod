package dev.sushi.wooltest.fallen;
import java.util.List;
import javax.annotation.Nullable;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.item.*;
import net.minecraft.world.item.crafting.Ingredient;
import net.minecraft.world.level.Level;
import net.minecraft.sounds.*;

public final class SoulHelmetItem extends ArmorItem {
    public SoulHelmetItem(){super(Material.INSTANCE,Type.HELMET,new Item.Properties().fireResistant());}
    @Override public String getArmorTexture(ItemStack s,Entity e,EquipmentSlot slot,@Nullable String type) {
        return "wooltest:textures/models/armor/eskarchi_layer_1.png";
    }
    @Override public void appendHoverText(ItemStack s,@Nullable Level l,List<Component> text,TooltipFlag f) {
        super.appendHoverText(s,l,text,f);
        text.add(Component.translatable("tooltip.wooltest.soul_helmet.armor").withStyle(ChatFormatting.GOLD));
        text.add(Component.translatable("tooltip.wooltest.soul_helmet.toughness").withStyle(ChatFormatting.AQUA));
    }
    private enum Material implements ArmorMaterial {
        INSTANCE;
        @Override public int getDurabilityForType(ArmorItem.Type t){return 407;}
        @Override public int getDefenseForType(ArmorItem.Type t){return 3;}
        @Override public int getEnchantmentValue(){return 15;}
        @Override public SoundEvent getEquipSound(){return SoundEvents.ARMOR_EQUIP_NETHERITE;}
        @Override public Ingredient getRepairIngredient(){return Ingredient.of(FallenRealm.ARMOR_SHARD.get());}
        @Override public String getName(){return "wooltest:eskarchi";}
        @Override public float getToughness(){return 2F;}
        @Override public float getKnockbackResistance(){return 0F;}
    }
}
