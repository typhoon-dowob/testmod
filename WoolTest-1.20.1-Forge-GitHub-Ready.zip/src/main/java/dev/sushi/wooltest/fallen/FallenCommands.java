package dev.sushi.wooltest.fallen;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import net.minecraft.commands.*;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.*;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.event.RegisterCommandsEvent;

public final class FallenCommands {
    private FallenCommands(){}
    public static void register(RegisterCommandsEvent e){
        e.getDispatcher().register(Commands.literal("fallen").requires(s->s.hasPermission(2))
            .executes(c->{c.getSource().sendSuccess(()->Component.literal("/fallen enter | leave | center | miteye | kers | peaks | status | loot | boss test | curse | paladins"),false);return 1;})
            .then(Commands.literal("enter").executes(c->FallenTravel.enter(c.getSource().getPlayerOrException(),288.5,246.5)))
            .then(Commands.literal("kers").executes(c->FallenTravel.enter(c.getSource().getPlayerOrException(),288.5,246.5)))
            .then(Commands.literal("center").executes(c->FallenTravel.enter(c.getSource().getPlayerOrException(),.5,76.5)))
            .then(Commands.literal("miteye").executes(c->FallenTravel.enter(c.getSource().getPlayerOrException(),-319.5,196.5)))
            .then(Commands.literal("peaks").executes(c->FallenTravel.enter(c.getSource().getPlayerOrException(),720.5,-420.5)))
            .then(Commands.literal("leave").executes(c->FallenTravel.leave(c.getSource().getPlayerOrException())))
            .then(Commands.literal("status").executes(c->{
                ServerLevel l=c.getSource().getServer().getLevel(FallenTravel.REALM);if(l==null)return 0;var d=FallenProgress.get(l);
                c.getSource().sendSuccess(()->Component.literal("落王遺境原型1 | 帝國中心(0,0) | 米特耶(-320,160) | 克爾斯(288,224) | 已生成守衛 "+d.spawned.size()+"/12 | 厄斯卡奇："+(d.defeated?"已擊敗，不自動重生":d.bossSpawned?"已生成":"尚未靠近生成點")),false);return 1;
            }))
            .then(Commands.literal("loot").executes(c->{
                ServerPlayer p=c.getSource().getPlayerOrException();
                for(var item:java.util.List.of(FallenRealm.ARMOR_SHARD.get(),FallenRealm.EMBER_PAGE.get(),FallenRealm.DARK_PENDANT.get(),FallenRealm.CHRONICLE.get(),FallenRealm.DOSSIER.get(),FallenRealm.HOLY_SWORD.get(),FallenRealm.SOUL_HELMET.get())){
                    ItemStack stack=new ItemStack(item);if(!p.getInventory().add(stack))p.drop(stack,false);
                }return 7;
            }))
            .then(Commands.literal("boss").then(Commands.literal("test").executes(c->test(c.getSource()))))
            .then(Commands.literal("curse").executes(c->force(c.getSource(),true)))
            .then(Commands.literal("paladins").executes(c->force(c.getSource(),false))));
    }
    private static int force(CommandSourceStack src,boolean curse)throws CommandSyntaxException {
        ServerPlayer p=src.getPlayerOrException();
        var bosses=p.serverLevel().getEntitiesOfClass(EskarchiEntity.class,p.getBoundingBox().inflate(48),Entity::isAlive);
        if(bosses.isEmpty()){src.sendFailure(Component.literal("附近沒有厄斯卡奇。"));return 0;}
        bosses.sort(java.util.Comparator.comparingDouble(b->b.distanceToSqr(p)));
        boolean ok=curse?bosses.get(0).beginCurse():bosses.get(0).summonPaladins();
        if(!ok)src.sendFailure(Component.literal("未施放：需要生存/冒險玩家在場內、足夠空間，且不可與既有同類召喚重疊。"));
        return ok?1:0;
    }
    private static int test(CommandSourceStack src)throws CommandSyntaxException {
        ServerPlayer p=src.getPlayerOrException();ServerLevel s=p.serverLevel();
        Vec3 v=p.position().add(Vec3.directionFromRotation(0,p.getYRot()).scale(6));
        EskarchiEntity boss=FallenRealm.ESKARCHI.get().create(s);if(boss==null)return 0;
        boss.moveTo(v.x,v.y,v.z,p.getYRot()+180,0);boss.anchor(v.x,v.y,v.z,false);
        var ground=net.minecraft.core.BlockPos.containing(v.x,v.y-.1,v.z);
        if(!s.getBlockState(ground).isFaceSturdy(s,ground,net.minecraft.core.Direction.UP)||!s.noCollision(boss)||!s.getEntities((Entity)null,boss.getBoundingBox(),q->!q.isSpectator()).isEmpty()){
            src.sendFailure(Component.literal("面前沒有安全空間。測試技能另需至少 25×25 的平坦空地。"));return 0;
        }
        if(!s.addFreshEntity(boss))return 0;
        src.sendSuccess(()->Component.literal("已生成額外測試主宰，不修改帝國中心的一次性生成紀錄。"),false);return 1;
    }
}
