package dev.sushi.wooltest.fallen;

import java.util.EnumSet;
import java.util.UUID;
import javax.annotation.Nullable;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ClientGamePacketListener;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.Difficulty;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.effect.*;
import net.minecraft.world.entity.*;
import net.minecraft.world.entity.ai.attributes.*;
import net.minecraft.world.entity.ai.goal.*;
import net.minecraft.world.entity.ai.goal.target.*;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.*;
import net.minecraft.world.level.Level;
import net.minecraftforge.network.NetworkHooks;

public class FallenMob extends Monster {
    public enum Role { KNIGHT, PRIEST, APOSTLE, PALADIN, BOSS }
    public final Role role;
    @Nullable private UUID ownerId,encounterId;
    private int ownerGrace=200;
    private int priestWindup,priestCooldown;
    public FallenMob(EntityType<? extends FallenMob> type,Level level,Role role) {
        super(type,level);this.role=role;xpReward=role==Role.PALADIN?0:8;setPersistenceRequired();
        if(role==Role.KNIGHT||role==Role.PALADIN)setItemSlot(EquipmentSlot.MAINHAND,new ItemStack(Items.IRON_SWORD));
        if(role==Role.PRIEST)setItemSlot(EquipmentSlot.MAINHAND,new ItemStack(Items.BLAZE_ROD));
        if(role==Role.APOSTLE)setItemSlot(EquipmentSlot.MAINHAND,new ItemStack(Items.IRON_AXE));
        setDropChance(EquipmentSlot.MAINHAND,0F);
    }
    public static AttributeSupplier.Builder attributes(Role role) {
        double hp=switch(role){case KNIGHT->30;case PRIEST->24;case APOSTLE->22;case PALADIN->60;case BOSS->300;};
        double attack=switch(role){case KNIGHT->5;case PRIEST->3;case APOSTLE->4;case PALADIN->7;case BOSS->12;};
        return Monster.createMonsterAttributes().add(Attributes.MAX_HEALTH,hp).add(Attributes.ATTACK_DAMAGE,attack)
                .add(Attributes.MOVEMENT_SPEED,role==Role.APOSTLE?.30:.23).add(Attributes.FOLLOW_RANGE,32)
                .add(Attributes.ARMOR,role==Role.PALADIN?6:role==Role.KNIGHT?4:role==Role.BOSS?8:0)
                .add(Attributes.KNOCKBACK_RESISTANCE,role==Role.BOSS?.6:.15);
    }
    @Override public MobType getMobType(){return role==Role.PALADIN?MobType.UNDEAD:MobType.UNDEFINED;}
    public boolean combatLocked(){return false;}
    public void bind(EskarchiEntity boss){ownerId=boss.getUUID();encounterId=boss.encounterId();}
    public boolean belongsTo(EskarchiEntity boss){return boss.getUUID().equals(ownerId)&&boss.encounterId().equals(encounterId);}
    public boolean isBound(){return ownerId!=null;}
    @Override protected void registerGoals() {
        goalSelector.addGoal(0,new FloatGoal(this));
        goalSelector.addGoal(1,new Goal(){
            {setFlags(EnumSet.of(Flag.MOVE,Flag.LOOK,Flag.JUMP));}
            @Override public boolean canUse(){return combatLocked()||level().getDifficulty()==Difficulty.PEACEFUL;}
            @Override public void tick(){getNavigation().stop();setDeltaMovement(0,getDeltaMovement().y,0);}
        });
        goalSelector.addGoal(2,new Goal(){
            {setFlags(EnumSet.of(Flag.MOVE,Flag.LOOK));}
            @Override public boolean canUse(){return role==Role.PRIEST&&!combatLocked()&&getTarget() instanceof Player p&&eligible(p)&&distanceToSqr(p)<400&&distanceToSqr(p)>9&&getSensing().hasLineOfSight(p);}
            @Override public void tick(){getNavigation().stop();getLookControl().setLookAt(getTarget(),30,30);}
        });
        goalSelector.addGoal(3,new MeleeAttackGoal(this,1.0,true){
            @Override public boolean canUse(){return !combatLocked()&&super.canUse();}
            @Override public boolean canContinueToUse(){return !combatLocked()&&super.canContinueToUse();}
        });
        goalSelector.addGoal(5,new WaterAvoidingRandomStrollGoal(this,.7));
        goalSelector.addGoal(6,new LookAtPlayerGoal(this,Player.class,12));
        goalSelector.addGoal(7,new RandomLookAroundGoal(this));
        targetSelector.addGoal(1,new HurtByTargetGoal(this));
        targetSelector.addGoal(2,new NearestAttackableTargetGoal<>(this,Player.class,true));
    }
    protected static boolean eligible(Player p){return p.isAlive()&&!p.isCreative()&&!p.isSpectator();}
    @Override public void tick() {
        super.tick();if(level().isClientSide)return;
        if(ownerId!=null&&level() instanceof ServerLevel s){
            Entity owner=s.getEntity(ownerId);
            if(owner instanceof EskarchiEntity boss){if(!boss.isAlive()||!belongsTo(boss)){discard();return;}ownerGrace=200;
                if(!boss.inArena(this) || (getTarget()!=null&&!boss.inArena(getTarget()))){setTarget(null);getNavigation().moveTo(boss,1.1);}}
            else if(--ownerGrace<=0){discard();return;}
        }
        if(role!=Role.PRIEST)return;
        if(priestCooldown>0)priestCooldown--;
        LivingEntity target=getTarget();
        if(!(target instanceof Player p)||!eligible(p)||level().getDifficulty()==Difficulty.PEACEFUL||distanceToSqr(p)>400||!getSensing().hasLineOfSight(p)) {priestWindup=0;return;}
        if(priestCooldown==0&&level() instanceof ServerLevel s){
            priestWindup++;
            if(priestWindup%5==0)s.sendParticles(ParticleTypes.SOUL_FIRE_FLAME,getX(),getEyeY(),getZ(),4,.2,.15,.2,.01);
            if(priestWindup>=30){
                p.hurt(FallenDamage.source(s,"fallen_magic",this),5F);
                var from=getEyePosition();var delta=p.getEyePosition().subtract(from);
                for(int i=0;i<=12;i++){var q=from.add(delta.scale(i/12D));s.sendParticles(ParticleTypes.WITCH,q.x,q.y,q.z,1,0,0,0,0);}
                priestWindup=0;priestCooldown=60;
            }
        }
    }
    @Override public boolean doHurtTarget(Entity target){
        if(combatLocked()||level().getDifficulty()==Difficulty.PEACEFUL)return false;
        // Explicit damage avoids adding vanilla held-item damage for a second time.
        float amount=(float)(role==Role.BOSS?FallenConfig.BOSS_ATTACK.get():switch(role){case KNIGHT->5;case PRIEST->3;case APOSTLE->4;case PALADIN->7;default->12;});
        boolean hit=target.hurt(FallenDamage.source(level(),"fallen_melee",this),amount);
        if(hit){setLastHurtMob(target);if(role==Role.APOSTLE&&target instanceof LivingEntity l)l.addEffect(new MobEffectInstance(MobEffects.BLINDNESS,40,0));}
        return hit;
    }
    @Override public void die(DamageSource source){
        if(ownerId!=null && level() instanceof ServerLevel s && s.getEntity(ownerId) instanceof EskarchiEntity boss && belongsTo(boss))boss.paladinDefeated(getUUID());
        super.die(source);
    }
    @Override protected void dropCustomDeathLoot(DamageSource source,int looting,boolean recentlyHit){
        if(level().isClientSide||role==Role.PALADIN||role==Role.BOSS)return;
        if(getRandom().nextDouble()>=FallenConfig.MOB_DROP.get())return;
        Item item=switch(role){case KNIGHT->FallenRealm.ARMOR_SHARD.get();case PRIEST->FallenRealm.EMBER_PAGE.get();default->FallenRealm.DARK_PENDANT.get();};
        spawnAtLocation(new ItemStack(item));
    }
    @Override public void addAdditionalSaveData(CompoundTag t){super.addAdditionalSaveData(t);if(ownerId!=null)t.putUUID("FallenOwner",ownerId);if(encounterId!=null)t.putUUID("FallenEncounter",encounterId);}
    @Override public void readAdditionalSaveData(CompoundTag t){super.readAdditionalSaveData(t);ownerId=t.hasUUID("FallenOwner")?t.getUUID("FallenOwner"):null;encounterId=t.hasUUID("FallenEncounter")?t.getUUID("FallenEncounter"):null;ownerGrace=200;}
    @Override protected boolean shouldDespawnInPeaceful(){return false;}
    @Override public boolean removeWhenFarAway(double d){return false;}
    @Override public Packet<ClientGamePacketListener> getAddEntityPacket(){return NetworkHooks.getEntitySpawningPacket(this);}
}
