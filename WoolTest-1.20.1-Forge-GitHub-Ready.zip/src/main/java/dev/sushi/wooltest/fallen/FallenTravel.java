package dev.sushi.wooltest.fallen;
import dev.sushi.wooltest.world.DimensionTravel;
import net.minecraft.core.registries.Registries;
import net.minecraft.nbt.*;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.*;
import net.minecraft.server.level.*;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.event.entity.player.PlayerEvent;

public final class FallenTravel {
    public static final ResourceKey<Level> REALM=ResourceKey.create(Registries.DIMENSION,new ResourceLocation("wooltest","fallen_realm"));
    private static final String KEY="WoolTestFallenReturn";
    private FallenTravel(){}
    public static int enter(ServerPlayer p,double x,double z){
        ServerLevel l=p.server.getLevel(REALM);if(l==null){p.sendSystemMessage(Component.literal("落王遺境未載入，請重新啟動世界並檢查資料包錯誤。"));return 0;}
        Vec3 spot=DimensionTravel.findSafe(l,p,x,73,z);if(spot==null){p.sendSystemMessage(Component.literal("目的地沒有安全落腳點，未移動玩家。"));return 0;}
        if(!p.level().dimension().equals(REALM)){
            CompoundTag t=new CompoundTag();t.putString("Dimension",p.level().dimension().location().toString());
            t.putDouble("X",p.getX());t.putDouble("Y",p.getY());t.putDouble("Z",p.getZ());t.putFloat("Yaw",p.getYRot());t.putFloat("Pitch",p.getXRot());
            p.getPersistentData().put(KEY,t);
        }
        move(p,l,spot,180,0);
        p.sendSystemMessage(Component.literal("落王遺境——往昔盛大的斯洛特帝國，如今卻只能以這般模樣存續。"));return 1;
    }
    public static int leave(ServerPlayer p){
        if(!p.level().dimension().equals(REALM)){p.sendSystemMessage(Component.literal("你不在落王遺境。"));return 0;}
        CompoundTag t=p.getPersistentData().getCompound(KEY);ServerLevel l=null;
        ResourceLocation id=ResourceLocation.tryParse(t.getString("Dimension"));
        if(id!=null)l=p.server.getLevel(ResourceKey.create(Registries.DIMENSION,id));
        if(l==null||l.dimension().equals(REALM)){
            l=p.server.overworld();var spawn=l.getSharedSpawnPos();t=new CompoundTag();t.putDouble("X",spawn.getX()+.5);t.putDouble("Y",spawn.getY());t.putDouble("Z",spawn.getZ()+.5);
        }
        Vec3 spot=DimensionTravel.findSafe(l,p,t.getDouble("X"),t.getDouble("Y"),t.getDouble("Z"));
        if(spot==null){p.sendSystemMessage(Component.literal("返回位置不安全，未移動玩家。"));return 0;}
        move(p,l,spot,t.getFloat("Yaw"),t.getFloat("Pitch"));p.getPersistentData().remove(KEY);return 1;
    }
    private static void move(ServerPlayer p,ServerLevel l,Vec3 v,float yaw,float pitch){p.stopRiding();p.teleportTo(l,v.x,v.y,v.z,yaw,pitch);p.setDeltaMovement(Vec3.ZERO);p.fallDistance=0;p.hurtMarked=true;}
    public static void onClone(PlayerEvent.Clone e){if(e.getOriginal().getPersistentData().contains(KEY,Tag.TAG_COMPOUND))e.getEntity().getPersistentData().put(KEY,e.getOriginal().getPersistentData().getCompound(KEY).copy());}
}
