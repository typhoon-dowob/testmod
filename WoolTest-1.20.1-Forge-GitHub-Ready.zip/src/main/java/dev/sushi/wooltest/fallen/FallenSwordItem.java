package dev.sushi.wooltest.fallen;
import java.util.List;
import javax.annotation.Nullable;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.*;
import net.minecraft.world.level.Level;
/** Diamond tier adds 3, this adds 8, normal player base adds 1: total 12, speed 1.6. */
public final class FallenSwordItem extends SwordItem {
    public FallenSwordItem(){super(Tiers.DIAMOND,8,-2.4F,new Item.Properties().fireResistant());}
    @Override public void appendHoverText(ItemStack s,@Nullable Level l,List<Component> lines,TooltipFlag flag) {
        super.appendHoverText(s,l,lines,flag);
        lines.add(Component.translatable("tooltip.wooltest.fallen_sword.attack").withStyle(ChatFormatting.GOLD));
        lines.add(Component.translatable("tooltip.wooltest.fallen_sword.speed").withStyle(ChatFormatting.GRAY));
    }
}
