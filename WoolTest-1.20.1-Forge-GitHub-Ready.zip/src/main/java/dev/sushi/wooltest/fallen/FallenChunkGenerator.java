package dev.sushi.wooltest.fallen;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.Executor;
import net.minecraft.core.BlockPos;
import net.minecraft.core.RegistryAccess;
import net.minecraft.server.level.WorldGenRegion;
import net.minecraft.world.level.*;
import net.minecraft.world.level.biome.*;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.LeavesBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.chunk.*;
import net.minecraft.world.level.levelgen.*;
import net.minecraft.world.level.levelgen.blending.Blender;
import net.minecraft.world.level.levelgen.structure.templatesystem.StructureTemplateManager;

/** Chunk-local deterministic generation: never places outside the current chunk, never rewrites loaded chunks. */
public final class FallenChunkGenerator extends ChunkGenerator {
    public static final Codec<FallenChunkGenerator> CODEC=RecordCodecBuilder.create(i->i.group(
            BiomeSource.CODEC.fieldOf("biome_source").forGetter(FallenChunkGenerator::getBiomeSource)).apply(i,FallenChunkGenerator::new));
    public FallenChunkGenerator(BiomeSource source) {super(source);}
    @Override protected Codec<? extends ChunkGenerator> codec(){return CODEC;}
    @Override public int getMinY(){return 0;}
    @Override public int getGenDepth(){return 256;}
    @Override public int getSeaLevel(){return 62;}
    @Override public int getSpawnHeight(LevelHeightAccessor h){return 73;}
    private record Tree(int x,int z,int base,int length){}
    private static Tree[] trees(int x,int z) {
        java.util.ArrayList<Tree> result=new java.util.ArrayList<>();
        int gx=Math.floorDiv(x,8),gz=Math.floorDiv(z,8);
        for(int dx=-1;dx<=1;dx++)for(int dz=-1;dz<=1;dz++)if(FallenTerrain.treeCell(gx+dx,gz+dz)) {
            int tx=(gx+dx)*8+4,tz=(gz+dz)*8+4;
            if(Math.abs(x-tx)<=4&&Math.abs(z-tz)<=4)
                result.add(new Tree(tx,tz,FallenTerrain.height(tx,tz)+1,8+(int)(FallenTerrain.hash(gx+dx+13,gz+dz)*5)));
        }
        return result.toArray(Tree[]::new);
    }
    private static BlockState at(int x,int y,int z,int h,int biome,FallenLayoutData.Site site,Tree[] trees) {
        if(y==0)return Blocks.BEDROCK.defaultBlockState();
        if(site!=null && y>=site.minY()) return FallenBlueprint.state(site,x,y,z);
        if(y<=h) {
            if(y<h-3)return (y<40?Blocks.DEEPSLATE:Blocks.STONE).defaultBlockState();
            if(biome==2)return (y==h&&h>120?Blocks.SNOW_BLOCK:Blocks.ANDESITE).defaultBlockState();
            if(biome==1)return (y==h?Blocks.PODZOL:Blocks.DIRT).defaultBlockState();
            return (y==h?(FallenTerrain.hash(x,z)>.80?Blocks.GRAVEL:Blocks.COARSE_DIRT):Blocks.DIRT).defaultBlockState();
        }
        for(Tree t:trees) {
            int dy=y-t.base,dx=Math.abs(x-t.x),dz=Math.abs(z-t.z);
            if(dx==0&&dz==0&&dy>=0&&dy<t.length)return Blocks.DARK_OAK_LOG.defaultBlockState();
            int tip=t.base+t.length;
            if(y>=tip-4&&y<=tip+1 && dx+dz<=6 && dx<=4 && dz<=4)
                return Blocks.DARK_OAK_LEAVES.defaultBlockState().setValue(LeavesBlock.PERSISTENT,true);
        }
        if(y==h+1&&FallenTerrain.vegetationAllowed(x,z)&&biome==0&&FallenTerrain.hash(x+73,z+117)>.983)
            return Blocks.DEAD_BUSH.defaultBlockState();
        return Blocks.AIR.defaultBlockState();
    }
    @Override public CompletableFuture<ChunkAccess> fillFromNoise(Executor executor,Blender blender,RandomState random,StructureManager structures,ChunkAccess chunk) {
        Heightmap a=chunk.getOrCreateHeightmapUnprimed(Heightmap.Types.OCEAN_FLOOR_WG);
        Heightmap b=chunk.getOrCreateHeightmapUnprimed(Heightmap.Types.WORLD_SURFACE_WG);
        BlockPos.MutableBlockPos p=new BlockPos.MutableBlockPos();
        for(int lx=0;lx<16;lx++)for(int lz=0;lz<16;lz++) {
            int x=chunk.getPos().getMinBlockX()+lx,z=chunk.getPos().getMinBlockZ()+lz;
            int h=FallenTerrain.height(x,z),biome=FallenTerrain.biome(x,z);
            var site=FallenBlueprint.siteAt(x,z);Tree[] trees=trees(x,z);
            int top=site==null?h+20:site.minY()+site.height();
            if(site==null)for(Tree t:trees)top=Math.max(top,t.base+t.length+2);
            for(int y=Math.max(0,chunk.getMinBuildHeight());y<Math.min(top,chunk.getMaxBuildHeight());y++) {
                BlockState s=at(x,y,z,h,biome,site,trees);if(s.isAir())continue;
                chunk.setBlockState(p.set(x,y,z),s,false);a.update(lx,y,lz,s);b.update(lx,y,lz,s);
            }
        }
        return CompletableFuture.completedFuture(chunk);
    }
    @Override public int getBaseHeight(int x,int z,Heightmap.Types type,LevelHeightAccessor height,RandomState random) {
        var column=getBaseColumn(x,z,height,random);
        for(int y=Math.min(255,height.getMaxBuildHeight()-1);y>=height.getMinBuildHeight();y--)
            if(type.isOpaque().test(column.getBlock(y)))return y+1;
        return height.getMinBuildHeight();
    }
    @Override public NoiseColumn getBaseColumn(int x,int z,LevelHeightAccessor height,RandomState random) {
        int min=height.getMinBuildHeight(),h=FallenTerrain.height(x,z),biome=FallenTerrain.biome(x,z);
        var site=FallenBlueprint.siteAt(x,z);Tree[] trees=trees(x,z);
        BlockState[] states=new BlockState[height.getHeight()];
        for(int i=0;i<states.length;i++)states[i]=at(x,min+i,z,h,biome,site,trees);
        return new NoiseColumn(min,states);
    }
    @Override public void applyCarvers(WorldGenRegion r,long seed,RandomState s,BiomeManager b,StructureManager sm,ChunkAccess c,GenerationStep.Carving step){}
    @Override public void buildSurface(WorldGenRegion r,StructureManager sm,RandomState s,ChunkAccess c){}
    @Override public void spawnOriginalMobs(WorldGenRegion r){}
    @Override public void applyBiomeDecoration(WorldGenLevel l,ChunkAccess c,StructureManager s){}
    @Override public void createStructures(RegistryAccess r,ChunkGeneratorStructureState s,StructureManager sm,ChunkAccess c,StructureTemplateManager tm){}
    @Override public void addDebugScreenInfo(List<String> out,RandomState s,BlockPos p) {
        out.add("Fallen Realm prototype | three authored regions | /fallen center, miteye, kers");
    }
}
