package dev.sushi.wooltest.fallen;

import java.util.UUID;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ClientGamePacketListener;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.*;
import net.minecraft.world.entity.ai.attributes.*;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.network.NetworkHooks;

/** An attackable objective, not a placed wood block. No terrain replacement or item drops. */
public final class CurseRootEntity extends Monster {
    private UUID owner,encounter;
    private int grace=200;
    public CurseRootEntity(EntityType<? extends CurseRootEntity> t,Level l){
        super(t,l);setNoAi(true);setNoGravity(true);setPersistenceRequired();xpReward=0;
        setCustomName(net.minecraft.network.chat.Component.translatable("entity.wooltest.cursed_root"));setCustomNameVisible(true);setGlowingTag(true);
    }
    public static AttributeSupplier.Builder attributes(){return Monster.createMonsterAttributes().add(Attributes.MAX_HEALTH,8).add(Attributes.MOVEMENT_SPEED,0).add(Attributes.KNOCKBACK_RESISTANCE,1).add(Attributes.ARMOR,0);}
    public void bind(EskarchiEntity boss){owner=boss.getUUID();encounter=boss.encounterId();}
    public boolean belongsTo(EskarchiEntity boss){return boss.getUUID().equals(owner)&&boss.encounterId().equals(encounter);}
    @Override public void tick(){
        super.tick();setDeltaMovement(Vec3.ZERO);
        if(!(level() instanceof ServerLevel s))return;
        if(owner==null){discard();return;}
        Entity e=s.getEntity(owner);
        if(e instanceof EskarchiEntity b){
            if(!b.isAlive()||!belongsTo(b)||!b.hasRoots()){discard();return;}
            grace=200;
            if(tickCount%10==0)s.sendParticles(ParticleTypes.WITCH,getX(),getY()+1.4,getZ(),3,.35,.9,.35,.01);
        }else if(--grace<=0)discard();
    }
    @Override public boolean hurt(DamageSource source,float amount){
        // Administrative /kill must remain usable even outside ordinary encounter rules.
        if(source.is(net.minecraft.world.damagesource.DamageTypes.GENERIC_KILL))return super.hurt(source,amount);
        if(!(source.getEntity() instanceof Player p)||!p.isAlive()||p.isSpectator())return false;
        if(!(level() instanceof ServerLevel s)||owner==null)return false;
        if(!(s.getEntity(owner) instanceof EskarchiEntity boss)||!belongsTo(boss)||!boss.rootsAreBreakable())return false;
        return super.hurt(source,amount);
    }
    @Override public void die(DamageSource source){
        if(level() instanceof ServerLevel s && owner!=null && s.getEntity(owner) instanceof EskarchiEntity boss && belongsTo(boss))boss.rootDestroyed(getUUID());
        super.die(source);
    }
    @Override protected void dropCustomDeathLoot(DamageSource s,int n,boolean hit){}
    @Override protected void registerGoals(){}
    @Override public boolean isPushable(){return false;}
    @Override public boolean removeWhenFarAway(double d){return false;}
    @Override protected boolean shouldDespawnInPeaceful(){return false;}
    @Override public void addAdditionalSaveData(CompoundTag t){super.addAdditionalSaveData(t);if(owner!=null)t.putUUID("Owner",owner);if(encounter!=null)t.putUUID("Encounter",encounter);}
    @Override public void readAdditionalSaveData(CompoundTag t){super.readAdditionalSaveData(t);owner=t.hasUUID("Owner")?t.getUUID("Owner"):null;encounter=t.hasUUID("Encounter")?t.getUUID("Encounter"):null;grace=200;}
    @Override public Packet<ClientGamePacketListener> getAddEntityPacket(){return NetworkHooks.getEntitySpawningPacket(this);}
}
