package dev.sushi.wooltest.fallen;

import net.minecraftforge.common.ForgeConfigSpec;

/** These are explicitly provisional balance settings, separate from the user's fixed mechanics. */
public final class FallenConfig {
    public static final ForgeConfigSpec SPEC;
    public static final ForgeConfigSpec.DoubleValue BOSS_HEALTH, BOSS_ATTACK, GUARD_SHARE;
    public static final ForgeConfigSpec.DoubleValue MOB_DROP, CHRONICLE_DROP, DOSSIER_DROP, SWORD_DROP, HELMET_DROP;
    public static final ForgeConfigSpec.IntValue CURSE_COOLDOWN, SLOW_AMPLIFIER;
    static {
        ForgeConfigSpec.Builder b = new ForgeConfigSpec.Builder();
        b.comment("Fallen Realm prototype: provisional defaults. Fixed mechanics: 3 paladins, 5 roots, 15 s + 2 s, 70 damage/root.").push("balance");
        BOSS_HEALTH = b.defineInRange("bossHealth", 300.0, 1.0, 10000.0);
        BOSS_ATTACK = b.defineInRange("bossAttack", 12.0, 0.0, 1000.0);
        GUARD_SHARE = b.comment("Fraction of final incoming boss damage requested per living bound paladin, maximum three.").defineInRange("sharePerPaladin", 0.20, 0.0, 0.30);
        CURSE_COOLDOWN = b.defineInRange("curseCooldownTicks", 800, 100, 12000);
        SLOW_AMPLIFIER = b.comment("5 means Slowness VI; applied only after failure, never during the 15-second objective.").defineInRange("failureSlownessAmplifier", 5, 0, 6);
        MOB_DROP = b.defineInRange("minorMaterialDropChance", 1.0, 0.0, 1.0);
        CHRONICLE_DROP = b.defineInRange("chronicleDropChance", 1.0, 0.0, 1.0);
        DOSSIER_DROP = b.defineInRange("dossierDropChance", 1.0, 0.0, 1.0);
        SWORD_DROP = b.defineInRange("holySwordDropChance", 1.0, 0.0, 1.0);
        HELMET_DROP = b.defineInRange("soulHelmetDropChance", 1.0, 0.0, 1.0);
        b.pop(); SPEC = b.build();
    }
    private FallenConfig() { }
}
