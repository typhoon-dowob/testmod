package dev.sushi.wooltest;

import com.mojang.serialization.Codec;
import dev.sushi.wooltest.block.TemporaryPillarBlock;
import dev.sushi.wooltest.block.TemporaryPillarBlockEntity;
import dev.sushi.wooltest.entity.TestOneEntity;
import dev.sushi.wooltest.world.WoolChunkGenerator;
import net.minecraft.core.registries.Registries;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.chunk.ChunkGenerator;
import net.minecraftforge.common.ForgeSpawnEggItem;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public final class ModContent {
    private ModContent() { }

    private static final DeferredRegister<EntityType<?>> ENTITIES =
            DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, WoolTestMod.MOD_ID);
    private static final DeferredRegister<Block> BLOCKS =
            DeferredRegister.create(ForgeRegistries.BLOCKS, WoolTestMod.MOD_ID);
    private static final DeferredRegister<BlockEntityType<?>> BLOCK_ENTITIES =
            DeferredRegister.create(ForgeRegistries.BLOCK_ENTITY_TYPES, WoolTestMod.MOD_ID);
    private static final DeferredRegister<Item> ITEMS =
            DeferredRegister.create(ForgeRegistries.ITEMS, WoolTestMod.MOD_ID);
    private static final DeferredRegister<Codec<? extends ChunkGenerator>> GENERATORS =
            DeferredRegister.create(Registries.CHUNK_GENERATOR, WoolTestMod.MOD_ID);

    public static final RegistryObject<EntityType<TestOneEntity>> TEST_ONE =
            ENTITIES.register("test_one", () -> EntityType.Builder
                    .of(TestOneEntity::new, MobCategory.MONSTER)
                    .sized(0.6F, 1.95F)
                    .clientTrackingRange(8)
                    .build(WoolTestMod.MOD_ID + ":test_one"));

    public static final RegistryObject<TemporaryPillarBlock> TEMPORARY_PILLAR =
            BLOCKS.register("temporary_pillar", TemporaryPillarBlock::new);
    public static final RegistryObject<BlockEntityType<TemporaryPillarBlockEntity>> PILLAR_ENTITY =
            BLOCK_ENTITIES.register("temporary_pillar", () -> BlockEntityType.Builder
                    .of(TemporaryPillarBlockEntity::new, TEMPORARY_PILLAR.get()).build(null));
    public static final RegistryObject<Item> TEST_ONE_SPAWN_EGG = ITEMS.register(
            "test_one_spawn_egg", () -> new ForgeSpawnEggItem(TEST_ONE,
                    0x4CB5C5, 0xC349B9, new Item.Properties()));
    public static final RegistryObject<Codec<? extends ChunkGenerator>> WOOL_GENERATOR =
            GENERATORS.register("wool", () -> WoolChunkGenerator.CODEC);

    public static void register(IEventBus bus) {
        ENTITIES.register(bus);
        BLOCKS.register(bus);
        BLOCK_ENTITIES.register(bus);
        ITEMS.register(bus);
        GENERATORS.register(bus);
    }
}
