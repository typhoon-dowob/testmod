package dev.sushi.wooltest.block;

import dev.sushi.wooltest.ModContent;
import dev.sushi.wooltest.entity.ModDamage;
import dev.sushi.wooltest.logic.TestRules;
import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;
import javax.annotation.Nullable;
import java.util.UUID;

/** Absolute expiry is saved, so reloaded chunks do not leave immortal pillars. */
public final class TemporaryPillarBlockEntity extends BlockEntity {
    private static final String HIT_UNTIL = "wooltest_pillar_hit_until";
    private long expiresAt;
    @Nullable private UUID ownerId;
    @Nullable private UUID castId;

    public TemporaryPillarBlockEntity(BlockPos pos, BlockState state) {
        super(ModContent.PILLAR_ENTITY.get(), pos, state);
    }

    public void initialize(long expiry, UUID owner, UUID cast) {
        expiresAt = expiry;
        ownerId = owner;
        castId = cast;
        setChanged();
    }
    public boolean belongsTo(UUID id) { return id.equals(castId); }

    public static void serverTick(Level level, BlockPos pos, BlockState state,
            TemporaryPillarBlockEntity pillar) {
        if (!(level instanceof ServerLevel server)) return;
        long now = server.getGameTime();
        if (pillar.expiresAt <= now) {
            // Only delete this block entity, never another block placed at its coordinates.
            if (server.getBlockEntity(pos) == pillar) server.removeBlock(pos, false);
            return;
        }
        // Full cubes stop movement before entityInside() runs. Scan a thin contact shell
        // so sides AND the top cause damage, without turning the entire 5-block area into AoE.
        AABB contact = new AABB(pos).inflate(0.025D);
        for (ServerPlayer player : server.getEntitiesOfClass(ServerPlayer.class, contact,
                p -> p.isAlive() && !p.isCreative() && !p.isSpectator())) {
            if (now < player.getPersistentData().getLong(HIT_UNTIL)) continue;
            Entity owner = pillar.ownerId == null ? null : server.getEntity(pillar.ownerId);
            if (player.hurt(ModDamage.source(server, ModDamage.PILLAR, owner),
                    TestRules.PILLAR_DAMAGE)) {
                // One shared cooldown across all 12 blocks, not 12 independent hits.
                player.getPersistentData().putLong(HIT_UNTIL,
                        now + TestRules.HIT_COOLDOWN_TICKS);
                double towardX = pos.getX() + 0.5D - player.getX();
                double towardZ = pos.getZ() + 0.5D - player.getZ();
                if (towardX * towardX + towardZ * towardZ < 1.0E-8D) towardX = 1.0D;
                player.knockback(TestRules.KNOCKBACK_STRENGTH, towardX, towardZ);
                player.hurtMarked = true;
            }
        }
    }

    @Override protected void saveAdditional(CompoundTag tag) {
        super.saveAdditional(tag);
        tag.putLong("ExpiresAt", expiresAt);
        if (ownerId != null) tag.putUUID("Owner", ownerId);
        if (castId != null) tag.putUUID("Cast", castId);
    }
    @Override public void load(CompoundTag tag) {
        super.load(tag);
        expiresAt = tag.getLong("ExpiresAt");
        ownerId = tag.hasUUID("Owner") ? tag.getUUID("Owner") : null;
        castId = tag.hasUUID("Cast") ? tag.getUUID("Cast") : null;
    }
}
