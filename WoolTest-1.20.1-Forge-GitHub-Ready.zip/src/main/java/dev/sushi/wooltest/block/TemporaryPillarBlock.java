package dev.sushi.wooltest.block;

import dev.sushi.wooltest.ModContent;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.BaseEntityBlock;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.RenderShape;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.BlockEntityTicker;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.material.MapColor;
import net.minecraft.world.level.material.PushReaction;
import javax.annotation.Nullable;

/** A solid oak-looking skill block. No item or drops, and not piston movable. */
public final class TemporaryPillarBlock extends BaseEntityBlock {
    public TemporaryPillarBlock() {
        // OAK_LOG's copied map-color function reads RotatedPillarBlock.AXIS.
        // This fixed, vertical skill block has no AXIS state property, so replace
        // that function before BaseEntityBlock creates this block's states.
        super(BlockBehaviour.Properties.copy(Blocks.OAK_LOG)
                .mapColor(MapColor.WOOD).strength(2.0F)
                .noLootTable().pushReaction(PushReaction.BLOCK)
                .isSuffocating((state, level, pos) -> false)
                .isViewBlocking((state, level, pos) -> false));
    }
    @Override public BlockEntity newBlockEntity(BlockPos pos, BlockState state) {
        return new TemporaryPillarBlockEntity(pos, state);
    }
    @Override public RenderShape getRenderShape(BlockState state) { return RenderShape.MODEL; }
    @Nullable
    @Override public <T extends BlockEntity> BlockEntityTicker<T> getTicker(Level level,
            BlockState state, BlockEntityType<T> type) {
        return level.isClientSide ? null : createTickerHelper(type,
                ModContent.PILLAR_ENTITY.get(), TemporaryPillarBlockEntity::serverTick);
    }
}
