# WoolTest — Sword 1 桃木劍整合版

> Tooltip 1 更新：只精簡物品介紹；本次檢查見 `validation/tooltip1-offline-check.txt`。掉落、抽值、保存與戰鬥邏輯未變。

## 交付狀態

這是 Minecraft Java 1.20.1／Forge 47.4.10 的完整原始碼專案，不是已編譯 JAR。以先前的 Model 1 + Pillar 1 + FX 1 為基礎，內建桃木劍物品、專屬材質、掉落判定、每件物品的隨機數值與一般物品說明。

已執行的離線檢查見 `validation/sword1-offline-check.txt`。尚未完成 Forge 編譯、遊戲啟動、真正的存檔／網路同步與戰鬥實測。這裡連到 Forge Maven 的檢查仍回報 DNS 解析失敗；未用測試替身的編譯結果冒充真正 Forge 建置。

## 本版規則

| 項目 | 設定 |
|---|---|
| 新物品 ID | `wooltest:peach_wood_sword` |
| 名稱 | 桃木劍 |
| 掉落來源 | 測試一號死亡時，成功則掉 1 把 |
| 掉落機率 | 每次死亡獨立判定 90%，不受掠奪附魔加成 |
| 攻擊力 | 5.00～7.00，包含兩端；最小間隔 0.01，共 201 個等機率結果 |
| 攻擊速度 | 1.60 |
| 數值保存 | 在掉落產生前，由伺服器抽一次並寫入該把劍的 NBT |
| 物品說明 | 普通滑鼠懸停即可看見描述、攻擊力與攻速，不需 F3+H 或 Shift；已移除抽值範圍、保存說明與基礎數值備註 |
| 材質 | 上一輪原創像素劍圖還原成 32×32 透明 PNG，內建於模組；沒有引用原版木劍材質 |
| 耐久 | 本次補上的測試預設為 250；你尚未指定耐久 |
| 配方與修理 | 本版沒有合成配方或修理材料；停用兩把劍的合成修理，避免重建物品而重抽數值 |

90% 是機率，不是「每十隻一定掉九把」。沒有要求必須玩家擊殺，但仍遵守 `doMobLoot`：設定為 false 時不掉落。和平模式移除生物不等於正常死亡掉落。其他模組取消死亡或掉落事件、物品掉入虛空或被火焰摧毀，也可能使玩家最後拿不到物品。

5.00～7.00 定義為一般玩家主手持劍、未受附魔及狀態加成時的基礎總攻擊力，而不是再額外加上空手傷害。程式用「抽出值 − 1.0」作為攻擊屬性加成，用「1.6 − 4.0」作為攻速加成。實際命中仍走原有戰鬥流程，可能受蓄力、暴擊、防禦或效果影響；這不是固定無視防禦的傷害。

掉落時取得的值會保存在每把劍上；讀取說明、切換欄位、丟出／撿回或重登不會主動重新抽值。未帶數值的 `/give` 或創造模式新物品，會在伺服器首次處理背包時初始化；創造物品清單上的未取得圖示會顯示「尚未抽定」。

之前的大型展示圖是概念示意。本版沒有額外新增攻擊距離、驅邪加成、發光、特殊技能或經驗掉落，也沒有把怪物改成倒地屍體。

## 更新方式：沿用已成功的 GitHub Actions

1. 用本版的 `WoolTest-1.20.1-Forge-GitHub-Ready.zip` 替換 GitHub 儲存庫最外層同名 ZIP，不解壓、不改名。下載名稱若帶有 `(1)`，上傳前去掉。
2. 提交變更，再執行目前已成功的 ZIP 建置 workflow。不必修改 ZIP 外面的 `.github/workflows/build.yml`。
3. 在「本次新提交」的 Actions 成功紀錄下載 `wooltest-minecraft-1.20.1-forge` 產物，取出 `wooltest-1.20.1-0.1.0.jar`。
4. 關閉遊戲，備份存檔，用新 JAR 替換舊 JAR，不要同時保留兩份 WoolTest。多人遊玩時，伺服器和用戶端都換成同一版。

JAR 名稱／內部版本號為相容現有建置流程而保留。Mods 名稱改成：

`Wool Test Dimension (Model 1 + Pillar 1 + FX 1 + Sword 1)`

也可以在 JAR 內查看 `wooltest-build-info.txt` 第一行：`WOOLTEST-MODEL1-PILLAR1-FX1-SWORD1`。

不需要另外裝資源包或新的動畫依賴。生物 Model 1、木柱 Pillar 1 材質、FX 1 生成／消失粒子音效、原有維度與戰鬥設定保留。

## 遊戲內驗收

### 直接取一把劍

使用有權限的玩家／開啟作弊：

```mcfunction
/wooltest sword
```

這個新測試指令每次給一把已經抽好數值的劍。背包滿時掉在腳邊，不會跳過初始化。原生給物品指令也可以：

```mcfunction
/give @s wooltest:peach_wood_sword
```

先關閉進階物品說明，再滑鼠指向桃木劍，確認能看到例如「攻擊力：6.37」「攻擊速度：1.60」。6.37 僅為示例，不是每把都相同。連續取得幾把後比較，允許碰巧重複數值。

將其中一把切換欄位、丟下再撿起、放進箱子、離開世界再重進，核對數值仍相同。

### 檢查實際主手屬性

沒有附魔、力量／虛弱效果或其他模組屬性加成時，主手拿著桃木劍，再執行：

```mcfunction
/attribute @s minecraft:generic.attack_damage get 100
/attribute @s minecraft:generic.attack_speed get 100
/data get entity @s SelectedItem.tag.WoolTestPeachDamageHundredths
```

例如攻擊力 6.37 的劍，攻擊力查詢乘 100 後應接近 637，攻速應接近 160；NBT 整數應為 637。屬性計算內部使用浮點數，命令輸出的取整可能在邊界差 1，因此需要精確判斷時同時檢查原始屬性值與 NBT，不要僅憑乘 100 的整數結果斷言失敗。

### 測試怪物掉落

```mcfunction
/difficulty normal
/gamerule doMobLoot true
/wooltest enter
/wooltest spawn
```

正常擊殺測試一號，確認成功掉落時只有一把新桃木劍，且拾取前已含數值。可以重複幾次檢查；少量次數不適合估計機率。之後設 `doMobLoot false` 再測試，應不出現桃木劍。

## 開發與離線檢查

```text
python tools/check_sword1.py
```

需要 Python 3.11+、Pillow 以及可使用 Java 17 語法的 JDK。此工具會執行原有核心規則、201 種抽值窮舉、90% 機率分支、資源／翻譯引用、原有檔案雜湊及物品邏輯測試。物品邏輯測試使用測試替身，並不是 Minecraft 的真正物品欄或 NBT／網路實作。

舊版的 `check_model1.py`、`check_pillar1.py` 保留歷史版本的雜湊斷言，不適合作為 Sword 1 的整體驗收入口；請使用上面的 `check_sword1.py`。完整編譯仍需原有的 `BUILD.bat`、`build.sh` 或 GitHub Actions。
