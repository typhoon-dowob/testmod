import dev.sushi.wooltest.city.CityLayoutData;
import java.nio.file.*;
import java.util.*;

/** Tests the production decoder, not a reimplementation of its binary reader. */
public final class CitySymmetryTest {
    private static String reflected(String state) {
        return state.replace("facing=east", "facing=TEMP")
                .replace("facing=west", "facing=east")
                .replace("facing=TEMP", "facing=west")
                .replace("shape=inner_left", "shape=inner_TEMP")
                .replace("shape=inner_right", "shape=inner_left")
                .replace("shape=inner_TEMP", "shape=inner_right")
                .replace("shape=outer_left", "shape=outer_TEMP")
                .replace("shape=outer_right", "shape=outer_left")
                .replace("shape=outer_TEMP", "shape=outer_right");
    }
    public static void main(String[] args) throws Exception {
        CityLayoutData data = CityLayoutData.read(Files.newInputStream(Path.of(args[0])));
        List<String> palette = data.palette();
        int[] mirror = new int[palette.size()];
        for (int i=0; i<mirror.length; i++) {
            mirror[i] = palette.indexOf(reflected(palette.get(i)));
            if (mirror[i] < 0) throw new AssertionError("Missing mirror state: "+palette.get(i));
        }
        for (int i=0; i<mirror.length; i++)
            if (mirror[mirror[i]] != i) throw new AssertionError("Mirror is not involutive");
        long tested = 0, palace = 0;
        for (int x=-125; x<=125; x++) for (int z=-125; z<=125; z++)
            for (int y=60; y<=127; y++) {
                int a=data.paletteIndex(x,y,z), b=data.paletteIndex(-x,y,z);
                if (a != mirror[b]) throw new AssertionError("Asymmetric cell: "+x+","+y+","+z);
                tested++;
                if (Math.abs(x)<=29 && z>=-97 && z<=-62) palace++;
            }
        // Keep each of the paired stairways at the north/south gate houses.
        for (int side : new int[]{-1, 1}) for (int x : new int[]{-20, 20})
            for (int i=(side<0 ? 5 : 0); i<13; i++) {
                String state = palette.get(data.paletteIndex(x,64+i,side*(97+i)));
                if (!state.contains("capital_marble_stairs"))
                    throw new AssertionError("Missing gatehouse access stair at "+x+","+i);
            }
        // Entry is not blocked by a column: three head-height cells across the main door.
        for (int x=-1;x<=1;x++) for(int y=74;y<=76;y++)
            if (data.paletteIndex(x,y,-68)!=0) throw new AssertionError("Main hall door blocked");
        System.out.println("PASS: "+tested+" decoded runtime cells including air reflect across X=0.");
        System.out.println("PASS: "+palace+" main-palace cells reflect; all centre-line states reflect to themselves.");
        System.out.println("PASS: north/south gates each have matching east/west access stairs; main entry is clear.");
    }
}
