#!/usr/bin/env python3
"""Original chamfered Emperor 5 geometry and hand-authored pixel atlas.
The JSON, runtime WEM4 mesh and offline renders share exactly the same vertices.
Authoring coordinates: Minecraft model pixels (+Y down); 16 pixels = 1 block.
"""
from pathlib import Path
import math, json, struct, gzip, hashlib
import numpy as np
from PIL import Image, ImageDraw
ROOT=Path(__file__).resolve().parent.parent
OUT=ROOT/'src/main/resources/assets/wooltest'
ART=ROOT/'art_source/emperor5'; ART.mkdir(parents=True,exist_ok=True)
TILE=64; SIZE=512
MATS=['silk','brocade','gold','red','jade','skin','hair','boots','pearl','dragon','cape','hem','cuff','cord','face','lining']
BASE={'silk':(28,33,42),'brocade':(32,36,42),'gold':(207,162,69),'red':(123,29,32),'jade':(50,137,111),'skin':(184,139,101),'hair':(26,25,24),'boots':(24,25,30),'pearl':(213,216,192),'dragon':(30,34,43),'cape':(38,29,35),'hem':(43,30,36),'cuff':(47,34,36),'cord':(146,98,34),'face':(184,139,101),'lining':(86,23,29)}
tex=Image.new('RGBA',(SIZE,SIZE)); mask=Image.new('RGBA',(SIZE,SIZE)); rng=np.random.default_rng(404)
regions={}

def dragon(d,ox=0,oy=0):
    # Hand-authored coiling motif, not a text/font glyph or copied game texture.
    g=(218,173,79,255); h=(247,216,134,255)
    pts=[(15,44),(11,40),(12,31),(19,24),(31,22),(43,27),(46,35),(41,42),(31,43),(24,38),(24,32),(30,29),(37,31),(37,36),(33,38)]
    pts=[(x+ox,y+oy) for x,y in pts];d.line(pts,fill=g,width=3)
    d.line([(x+ox,y+oy) for x,y in [(43,27),(47,20),(44,15),(38,14),(36,18),(40,22)]],fill=h,width=2)
    d.polygon([(43+ox,14+oy),(46+ox,10+oy),(47+ox,16+oy),(52+ox,18+oy),(46+ox,19+oy)],fill=g)
    for pts2 in [[(20,24),(19,18),(14,16)],[(43,36),(49,39),(52,36)],[(25,40),(24,47),(19,49)]]:
        d.line([(x+ox,y+oy) for x,y in pts2],fill=g,width=2)
    d.point((44+ox,17+oy),fill=(25,31,28,255))
    for x,y in [(13,12),(49,48),(13,51)]:
        d.arc((x+ox-4,y+oy-2,x+ox+5,y+oy+4),170,350,fill=(145,115,66,255),width=1)

for i,m in enumerate(MATS):
    x0=(i%8)*TILE;y0=(i//8)*TILE; regions[m]=[x0,y0,TILE,TILE]
    arr=np.zeros((TILE,TILE,4),dtype=np.uint8)
    for y in range(TILE):
        for x in range(TILE):
            noise=int(rng.integers(-4,5)); weave=2 if (x+y)%3==0 else 0
            if m in ('silk','brocade','cape','hem'): noise+=int(4*math.cos(x*.44))+weave
            arr[y,x,:3]=np.clip(np.array(BASE[m])+noise,0,255);arr[y,x,3]=255
    im=Image.fromarray(arr);d=ImageDraw.Draw(im)
    if m=='brocade':
        for yy in range(8,64,14):
            for xx in range(6,64,16):
                d.line([(xx-4,yy),(xx,yy-3),(xx+4,yy),(xx,yy+3),(xx-4,yy)],fill=(71,62,45,255),width=1)
    if m in ('gold','cord'):
        for yy in range(3,64,8):d.line((0,yy,63,yy),fill=(237,199,103,255),width=1)
    if m=='jade':
        d.line((3,14,49,51),fill=(97,184,145,255),width=2);d.line((20,0,63,40),fill=(30,110,91,255),width=1)
    if m=='dragon': dragon(d)
    if m=='cape':
        dragon(d); d.line((4,0,4,63),fill=(153,112,52,255),width=2);d.line((59,0,59,63),fill=(153,112,52,255),width=2)
    if m in ('hem','cuff'):
        for yy in (3,7,55,60): d.line((0,yy,63,yy),fill=(207,160,69,255),width=1)
        for xx in range(0,64,12):d.line([(xx,44),(xx+3,39),(xx+6,44),(xx+9,39),(xx+12,44)],fill=(191,148,63,255),width=1)
    if m=='face':
        # Planar front UV: visibly shorter face with full-width brow and cheeks.
        # The side and rear polygons use skin/hair tiles separately.
        d.rectangle((0,0,63,4),fill=(28,26,25,255))
        d.line([(14,18),(20,19),(27,21)],fill=(43,31,26,255),width=2)
        d.line([(36,21),(43,19),(49,18)],fill=(43,31,26,255),width=2)
        d.rectangle((17,25,26,27),fill=(229,201,162,255))
        d.rectangle((37,25,46,27),fill=(229,201,162,255))
        d.line((17,24,27,24),fill=(49,36,28,255),width=1)
        d.line((36,24,46,24),fill=(49,36,28,255),width=1)
        d.rectangle((23,25,25,27),fill=(23,23,22,255))
        d.rectangle((38,25,40,27),fill=(23,23,22,255))
        d.point((23,25),fill=(250,236,208,255))
        d.point((38,25),fill=(250,236,208,255))
        d.line([(29,43),(27,45),(23,45)],fill=(45,33,28,255),width=1)
        d.line([(34,43),(36,45),(40,45)],fill=(45,33,28,255),width=1)
        d.line((28,49,35,49),fill=(120,69,53,255),width=1)
    tex.paste(im,(x0,y0))
    ma=np.asarray(im).copy();rgb=ma[:,:,:3].astype(int)
    selected=((rgb[:,:,0]>145)&(rgb[:,:,1]>100)&(rgb[:,:,2]<160)) if m in ('dragon','hem','cuff') else np.zeros((64,64),bool)
    if m in ('jade',):selected[:,:]=True
    ma[:,:,:3]=[249,209,116];ma[:,:,3]=np.where(selected,200,0)
    mask.paste(Image.fromarray(ma),(x0,y0))
(OUT/'textures/entity').mkdir(parents=True,exist_ok=True)
tex.save(OUT/'textures/entity/emperor.png');mask.save(OUT/'textures/entity/emperor_charge.png')

nodes=[]; byname={};component_stats=[]
def node(name,parent,offset,rotation=(0,0,0)):
    n={'name':name,'parent':parent,'offset':list(offset),'rotation':list(rotation),'quads':[]}
    nodes.append(n);byname[name]=n;return name
node('torso','root',(0,-9,0))
node('head','torso',(0,2.2,0))
node('right_arm','torso',(-5.5,1,0),(0,0,0.06))
node('left_arm','torso',(5.5,1,0),(0,0,-0.06))
node('right_leg','root',(-2.45,17,0))
node('left_leg','root',(2.45,17,0))
node('cape','torso',(0,1,0))
node('front_skirt','torso',(0,13.5,0))
node('pendant_right','torso',(-4.1,13.2,-2.9))
node('pendant_left','torso',(4.1,13.2,-2.9))

def uv(mat,u,v):
    x,y,w,h=regions[mat];return ((x+.5+(w-1)*u)/SIZE,(y+.5+(h-1)*v)/SIZE)
def quad(bone,pts,mat,coords=None,outward=None):
    p=np.array(pts,float)
    cross=np.cross(p[1]-p[0],p[2]-p[0]);length=np.linalg.norm(cross)
    if length<1e-8:raise ValueError('degenerate first triangle')
    coords=coords or [(0,0),(1,0),(1,1),(0,1)]
    if outward is not None and cross@np.array(outward)<0:
        p=p[[0,3,2,1]];coords=[coords[j] for j in [0,3,2,1]];cross=np.cross(p[1]-p[0],p[2]-p[0]);length=np.linalg.norm(cross)
    normal=cross/length
    byname[bone]['quads'].append({'material':mat,'v':[[*map(float,p[i]),*map(float,normal),*uv(mat,*coords[i])] for i in range(4)]})

def loft(bone,name,rings,mat,n=20,fold=0,cap=True):
    # Ring: y, rx, rz, cx, cz. Corners are replaced by actual polygonal cross-sections.
    start=len(byname[bone]['quads']);grid=[]
    for ri,r in enumerate(rings):
        y,rx,rz,*cent=r;cx,cz=cent or (0,0)
        grid.append([(cx+(rx+fold*math.cos(10*2*math.pi*j/n))*math.sin(2*math.pi*j/n),y,cz+(rz+fold*.6*math.cos(10*2*math.pi*j/n))*math.cos(2*math.pi*j/n)) for j in range(n)])
    for k in range(len(rings)-1):
        v0=k/(len(rings)-1);v1=(k+1)/(len(rings)-1)
        for j in range(n):
            q=[grid[k][j],grid[k][(j+1)%n],grid[k+1][(j+1)%n],grid[k+1][j]]
            t=2*math.pi*(j+.5)/n
            quad(bone,q,mat,[(j/n,v0),((j+1)/n,v0),((j+1)/n,v1),(j/n,v1)],(math.sin(t),0,math.cos(t)))
    if cap:
        for k in (0,len(rings)-1):
            c=np.mean(grid[k],axis=0);up=(0,-1 if k==0 else 1,0)
            for j in range(n):
                # Repeated final vertex makes a triangle in the QUADS buffer.
                a=grid[k][j];b=grid[k][(j+1)%n]
                pp=[c,a,b,b];co=[(.5,.5),(.5+.48*math.sin(j*2*math.pi/n),.5+.48*math.cos(j*2*math.pi/n)),(.5+.48*math.sin((j+1)*2*math.pi/n),.5+.48*math.cos((j+1)*2*math.pi/n))]
                # Orient before quad() to avoid a degenerate first triangle after reversal.
                if np.cross(np.array(a)-c,np.array(b)-c)@np.array(up)<0:pp=[c,b,a,a];co=[co[0],co[2],co[1]]
                quad(bone,pp,mat,co+[co[-1]])
    component_stats.append({'name':name,'bone':bone,'quads':len(byname[bone]['quads'])-start})

def bevel_loft(bone,name,rings,mat,bevel=.24,face_front=False):
    """Wide planar faces plus small clipped corners, not an ellipse.
    First/last samples bisect the back and front for symmetric atlas mapping.
    Rings use y, half-width, half-depth, optional centre x/z.
    """
    begin=len(byname[bone]['quads'])
    b=bevel
    shape=[(0,1),(1-b,1),(1,1-b),(1,-1+b),(1-b,-1),
           (0,-1),(-1+b,-1),(-1,-1+b),(-1,1-b),(-1+b,1)]
    n=len(shape); grid=[]
    for y,rx,rz,*cent in rings:
        cx,cz=cent or (0,0)
        grid.append([(cx+rx*x,y,cz+rz*z) for x,z in shape])
    for k in range(len(rings)-1):
        va=(rings[k][0]-rings[0][0])/(rings[-1][0]-rings[0][0])
        vb=(rings[k+1][0]-rings[0][0])/(rings[-1][0]-rings[0][0])
        for j in range(n):
            jj=(j+1)%n
            pts=[grid[k][j],grid[k][jj],grid[k+1][jj],grid[k+1][j]]
            mx=shape[j][0]+shape[jj][0];mz=shape[j][1]+shape[jj][1]
            tile=mat; coords=[(j/n,va),((j+1)/n,va),((j+1)/n,vb),(j/n,vb)]
            if face_front:
                if j in (4,5):
                    ua=(shape[j][0]/(1-b)+1)/2;ub=(shape[jj][0]/(1-b)+1)/2
                    coords=[(ua,va),(ub,va),(ub,vb),(ua,vb)]
                else:
                    tile='skin' if j in (2,3,6,7) else 'hair'
            quad(bone,pts,tile,coords,(mx,0,mz))
    for k in (0,len(rings)-1):
        c=np.mean(grid[k],axis=0); up=(0,-1 if k==0 else 1,0)
        for j in range(n):
            a=grid[k][j];bb=grid[k][(j+1)%n];pts=[c,a,bb,bb]
            coords=[(.5,.5),(.5+.45*shape[j][0],.5+.45*shape[j][1]),
                    (.5+.45*shape[(j+1)%n][0],.5+.45*shape[(j+1)%n][1])]
            if np.cross(np.array(a)-c,np.array(bb)-c)@np.array(up)<0:
                pts=[c,bb,a,a];coords=[coords[0],coords[2],coords[1]]
            quad(bone,pts,('hair' if k==0 else 'skin') if face_front else mat,coords+[coords[-1]])
    component_stats.append({'name':name,'bone':bone,'quads':len(byname[bone]['quads'])-begin,
                            'profile':'chamfered_rectangle','bevel_fraction':bevel,
                            'start_quad':begin,'rings':rings})

def ribbon(bone,name,rows,mat,n=8,back=False):
    # Curved drapery sheet, each row: y, half-width, centre z, curvature.
    start=len(byname[bone]['quads']);g=[]
    for k,(y,w,z,curve) in enumerate(rows):
        row=[]
        for j in range(n+1):
            t=2*j/n-1; row.append((w*t,y+(abs(t)**2)*.25,z+curve*t*t))
        g.append(row)
    for k in range(len(g)-1):
        for j in range(n):
            quad(bone,[g[k][j],g[k][j+1],g[k+1][j+1],g[k+1][j]],mat,
                 [(j/n,k/(len(g)-1)),((j+1)/n,k/(len(g)-1)),((j+1)/n,(k+1)/(len(g)-1)),(j/n,(k+1)/(len(g)-1))],(0,0,1 if back else -1))
    component_stats.append({'name':name,'bone':bone,'quads':len(byname[bone]['quads'])-start})

def ellipsoid(bone,name,centre,radii,mat,n=8):
    x,y,z=centre;rx,ry,rz=radii
    rings=[]
    for t in [-.92,-.5,0,.5,.92]:
        a=math.sqrt(1-t*t);rings.append((y+ry*t,rx*a,rz*a,x,z))
    loft(bone,name,rings,mat,n=n)

# Main silhouette: broad planar fabric panels, deliberately small chamfers.
bevel_loft('torso','faceted_robe',[(0,3.5,2.2),(1.5,4.8,2.7),(3.4,5.1,2.95),
 (6,4.85,2.85),(10,4.0,2.5),(13,4.0,2.45),(16,4.5,2.85),
 (22,5.8,3.55),(28,6.9,4.15),(30.5,7.3,4.4)],'brocade',bevel=.23)
bevel_loft('torso','short_neck',[(-1.25,1.45,1.4),(.6,1.7,1.6)],'skin',bevel=.25)
bevel_loft('torso','standing_red_collar',[(-.7,1.85,1.65),(.2,2.3,1.95),
 (1.0,3.5,2.35),(2.0,4.3,2.8)],'red',bevel=.25)
bevel_loft('torso','gilt_waist_sash',[(11.8,4.1,2.6),(13.4,4.18,2.65)],'gold',bevel=.23)
bevel_loft('torso','robe_hem',[(29.1,7.16,4.34),(30.5,7.45,4.55)],'hem',bevel=.23)
ribbon('torso','dragon_breast_embroidered',[(2.5,2.9,-3.12,.06),
 (6.0,2.7,-3.04,.06),(10.5,2.35,-2.70,.06)],'dragon',n=2)
# Diagonal lapels sit just above the curved chest rather than projecting box frames.
quad('torso',[(0,1.2,-2.55),(-3.7,2.3,-2.35),(-.8,7.1,-3.05),(.1,5.7,-3.24)],'red',outward=(0,0,-1))
quad('torso',[(0,1.2,-2.57),(3.7,2.3,-2.35),(.5,6.6,-3.12),(-.3,5.2,-3.28)],'red',outward=(0,0,-1))
ellipsoid('torso','waist_jade',(0,12.65,-2.86),(1.15,.75,.28),'jade',n=12)
ribbon('front_skirt','embroidered_front_drape',[(0,2.4,-2.9,.20),(4.5,2.8,-3.8,.30),(9,3.3,-4.45,.40),(14,3.6,-4.95,.55),(16.3,2.9,-5.18,.35)],'dragon',n=4)
# Cape follows the back and flares away from the hem; no thick rectangular board.
ribbon('cape','curved_cape',[(0,3.6,3.0,-.25),(3,4.7,3.6,-.32),(8,4.75,4.0,-.4),(14,5.3,4.7,-.5),(21,6.1,5.3,-.65),(28.9,6.5,5.75,-.75)],'cape',n=4,back=True)
# Tapered head, an actual jaw line, a cap and a thin bevelled crown board.
bevel_loft('head','short_face', [(-10.8,2.85,2.2),(-10.0,3.25,2.5),
 (-7.5,3.4,2.55),(-4.9,3.25,2.45),(-3.7,2.9,2.3),(-3.0,2.45,2.05)],
 'face',bevel=.24,face_front=True)
bevel_loft('head','crown_cap',[(-14.45,2.45,2.25),(-13.4,2.8,2.5),(-12.9,3.35,2.85),
 (-10.6,3.37,2.85)],'hair',bevel=.20)
bevel_loft('head','crown_band',[(-11.3,3.40,2.9),(-10.5,3.4,2.9)],'gold',bevel=.20)
# A bevelled rectangular board has sloped corners, not stacked cuboids.
shape=[(-4.8,-4.6),(-4.2,-5.2),(4.2,-5.2),(4.8,-4.6),(4.8,4.6),(4.2,5.2),(-4.2,5.2),(-4.8,4.6)]
for j in range(8):
    a=shape[j];b=shape[(j+1)%8]
    quad('head',[(a[0],-15,a[1]),(b[0],-15,b[1]),(b[0],-14.45,b[1]),(a[0],-14.45,a[1])],'gold',outward=(a[0]+b[0],0,a[1]+b[1]))
for y,mat,sign in [(-15,'hair',-1),(-14.45,'gold',1)]:
    for j in range(8):
        a=shape[j];b=shape[(j+1)%8];pts=[(0,y,0),(a[0],y,a[1]),(b[0],y,b[1]),(b[0],y,b[1])]
        if np.cross(np.array(pts[1])-pts[0],np.array(pts[2])-pts[0])[1]*sign<0:pts=[pts[0],pts[2],pts[1],pts[1]]
        quad('head',pts,mat,[(.5,.5),(.1,.1),(.9,.9),(.9,.9)])
ellipsoid('head','crown_jewel',(0,-11.8,-2.98),(.65,.85,.25),'jade')
# Compact nasal bridge, broad jaw and short goatee: no elongated chin illusion.
bevel_loft('head','short_nose',[(-7.3,.22,.16,0,-2.56),
 (-6.1,.34,.36,0,-2.65),(-5.7,.30,.24,0,-2.60)],'skin',bevel=.35)
bevel_loft('head','short_beard',[(-4.35,1.17,.32,0,-2.62),
 (-3.0,1.07,.32,0,-2.45),(-1.6,.79,.26,0,-2.30),(-.75,.45,.16,0,-2.21)],
 'hair',bevel=.26)
# Fine strings and round/diamond-like pearl droplets, front and back.
for side,z in [('front',-5.0),('back',5.0)]:
    for i,x in enumerate([-3.8,-1.9,0,1.9,3.8]):
        b=node('bead_'+side+str(i),'head',(x,-14.45,z))
        length=4.0+.45*abs(i-2)
        loft(b,'crown_cord',[(0,.075,.075),(length,.075,.075)],'cord',n=4)
        for k in range(4):ellipsoid(b,'crown_pearl',(0,.55+k*(length-.6)/3,0),(.23,.30,.23),'jade' if k==2 else 'pearl',n=6)
# Draped sleeves have planar faces and sloped hems, not pill-shaped cylinders.
for bone in ('right_arm','left_arm'):
    bevel_loft(bone,'faceted_sleeve',[(-.8,1.35,1.55),(.65,2.05,2.0),
      (4.5,2.45,2.55),(9.9,2.50,2.80),(12.7,1.95,2.05),(13.6,1.85,2.0)],'silk',bevel=.29)
    bevel_loft(bone,'embroidered_cuff',[(11.9,2.16,2.34),(13.6,1.95,2.12)],'cuff',bevel=.29)
    ribbon(bone,'sleeve_motif',[(3.5,1.4,-2.54,.03),(7.5,1.55,-2.78,.03),
      (10.2,1.55,-2.81,.03)],'dragon',n=2)
    bevel_loft(bone,'hand',[(13.35,1.10,1.00),(14.2,1.20,1.05),
      (16.0,1.12,.96),(16.8,.90,.80)],'skin',bevel=.23)
    bevel_loft(bone,'shoulder_hem',[(-.75,1.40,1.60),(.55,2.15,2.10)],'gold',bevel=.29)
for bone in ('right_leg','left_leg'):
    bevel_loft(bone,'leg',[(0,1.55,1.65),(4.0,1.60,1.8)],'silk',bevel=.20)
    bevel_loft(bone,'beveled_boot',[(3.7,1.65,2.0,0,-.1),(4.8,1.85,2.95,0,-.8),
      (6.7,1.9,3.2,0,-1.05),(7,1.78,3.1,0,-1.05)],'boots',bevel=.22)
    bevel_loft(bone,'boot_trim',[(4.0,1.74,2.17,0,-.18),(4.4,1.83,2.52,0,-.45)],'gold',bevel=.22)
for bone in ('pendant_left','pendant_right'):
    loft(bone,'pendant_cord',[(0,.10,.10),(4.5,.10,.10)],'cord',n=6)
    ellipsoid(bone,'pendant_setting',(0,4.9,-.1),(.72,1.05,.25),'gold',n=8)
    ellipsoid(bone,'pendant_jade',(0,4.9,-.32),(.48,.79,.12),'jade',n=8)
    for x in (-.24,0,.24):loft(bone,'tassel',[(5.6,.07,.07,x,0),(8,.06,.06,x,0)],'red',n=4)

# Preserve geometric facet normals. Do not smooth across chamfer corners.
for n in nodes:
    for q in n['quads']:
        for v in q['v']:
            for j in range(8):v[j]=round(v[j],6)

spec={'format':'WEM4','units':'model_pixels_16_per_block','texture_size':[SIZE,SIZE],
      'coordinate_system':'+Y down; feet Y=24; front -Z', 'nodes':nodes,'materials':regions,'components':component_stats}
(ART/'emperor_mesh.json').write_text(json.dumps(spec,ensure_ascii=False,separators=(',',':')))
(ART/'atlas_regions.json').write_text(json.dumps(regions,indent=2))
meshpath=OUT/'geometry/emperor5.wem.gz';meshpath.parent.mkdir(parents=True,exist_ok=True)
buf=bytearray(b'WEM4');buf+=struct.pack('>ii',1,len(nodes))
for n in nodes:
    name=n['name'].encode('ascii');buf+=struct.pack('>H',len(name))+name+struct.pack('>i',len(n['quads']))
    for q in n['quads']:
        for v in q['v']:buf+=struct.pack('>8f',*v)
with open(meshpath,'wb') as f:f.write(gzip.compress(buf,mtime=0))
# Export a skeletal ModelPart definition; the renderer uses the exact runtime mesh.
lines=[]
for n in nodes:
    var=n['name'];parent='root' if n['parent']=='root' else n['parent'];off=n['offset'];rot=n['rotation']
    f=lambda v:f'{float(v):.6f}F'
    if any(rot):pose='PartPose.offsetAndRotation('+', '.join(f(v) for v in [*off,*rot])+')'
    else:pose='PartPose.offset('+', '.join(f(v) for v in off)+')'
    lines.append(f'        PartDefinition {var} = {parent}.addOrReplaceChild("{var}", CubeListBuilder.create(), {pose});')
(ART/'skeleton_java.txt').write_text('\n'.join(lines))
(ART/'asset_provenance.json').write_text(json.dumps({'geometry':'Original flat-panel chamfer lofts, shortened jaw and short beard; actual mod mesh, not concept art.',
 'texture':'Original programmatically hand-authored pixel art; no original Minecraft skin/armour texture copied.',
 'base':'Emperor4 rig/animations retained; WEM4 file format retained, runtime model path upgraded to emperor5.wem.gz. Gameplay unchanged.',
 'image_generation_used':False},ensure_ascii=False,indent=2))
print('Generated',len(nodes),'bones,',sum(len(n['quads']) for n in nodes),'quads,',len(buf),'runtime bytes before gzip')
