#!/usr/bin/env python3
from pathlib import Path
import json,gzip,struct,hashlib,collections,zipfile,re
import numpy as np
from PIL import Image
P=Path(__file__).resolve().parents[1];A=P/'art_source/city2';R=P/'src/main/resources';log=[]
def ok(s):log.append('PASS: '+s);print(log[-1])
v=np.load(A/'city_voxels.npy');palette=json.loads((A/'palette.json').read_text());meta=json.loads((A/'city_manifest.json').read_text());materials=json.loads((A/'materials.json').read_text())
raw=gzip.decompress((R/'data/wooltest/city/capital_v2.wct.gz').read_bytes())
assert struct.unpack('>6i',raw[:24])==(0x57435431,1,251,60,68,len(palette))
o=24;p2=[]
for _ in palette:
 n=struct.unpack('>H',raw[o:o+2])[0];o+=2;p2.append(raw[o:o+n].decode());o+=n
assert p2==palette
assert np.array_equal(np.frombuffer(raw[o:],dtype='>u2').reshape(251,251,68),v)
ok('Compressed runtime blueprint equals all 4,284,068 authored cells; palette decoding and size validated')
assert meta['center_xz']==[0,0] and v.shape[:2]==(251,251)
assert int(np.argwhere(v>0)[:,2].max())+60<128
assert len({(x//16,z//16) for x in range(-125,126) for z in range(-125,126)})==256
ok('Footprint -125..125 on X/Z, central block (0,0), 256 intersecting chunks, no block above Y=127')
custom={a[0] for a in materials['base']+materials['variants']+materials['decorations']}
assert len(custom)==44
for s in palette:
 ns,tail=s.split(':',1);name=tail.split('[',1)[0]
 assert (ns=='minecraft' and name in ('air','water')) or (ns=='wooltest' and name in custom),s
 if '[' in s:
  pr=dict(a.split('=') for a in s.split('[')[1][:-1].split(','))
  if name.endswith('_stairs'):
   assert set(pr)=={'facing','half','shape','waterlogged'} and pr['facing'] in ('east','west','north','south') and pr['half']=='bottom' and pr['shape']=='straight' and pr['waterlogged']=='false'
  else:assert name.endswith('_slab') and pr=={'type':'bottom','waterlogged':'false'}
for name in custom:
 for part in ('blockstates','models/block','models/item'):
  assert (R/'assets/wooltest'/part/(name+'.json')).exists(),(name,part)
 assert (R/'data/wooltest/loot_tables/blocks'/(name+'.json')).exists()
 for lang in ('zh_tw','en_us'):assert 'block.wooltest.'+name in json.loads((R/'assets/wooltest/lang'/(lang+'.json')).read_text())
for name,*_ in materials['base']:
 im=Image.open(R/'assets/wooltest/textures/block'/f'{name}.png');assert im.size==(32,32)
for f in R.rglob('*.json'):json.loads(f.read_text())
ok('44 registered block/item resource sets, 30 original 32x32 textures, both translations, models, loot and state properties')
# Check models/textures resolve entirely within mod assets or known vanilla model parents.
for f in (R/'assets/wooltest/models').rglob('*.json'):
 j=json.loads(f.read_text());parent=j.get('parent','')
 if parent.startswith('wooltest:'):assert (R/'assets/wooltest/models'/(parent.split(':')[1]+'.json')).exists(),f
 for ref in j.get('textures',{}).values():
  if ref.startswith('wooltest:'):assert (R/'assets/wooltest/textures'/(ref.split(':')[1]+'.png')).exists(),(f,ref)
ok('All model/texture references resolve')
# Conservative full-cell traversal test, approximating steps as one block (not a physics integration test).
air=v==0;water=np.array([s.startswith('minecraft:water') for s in palette])[v]
stand=np.zeros_like(air)
stand[:,:,1:-1]=air[:,:,1:-1]&air[:,:,2:]&(~air[:,:,:-2])&(~water[:,:,:-2])
walk={(int(x),int(z),int(y)) for x,z,y in np.argwhere(stand)}
start=(125,249,4);assert start in walk
seen={start};q=collections.deque([start])
while q:
 x,z,y=q.popleft()
 for xx,zz in ((x+1,z),(x-1,z),(x,z+1),(x,z-1)):
  for yy in (y,y+1,y-1,y-2,y-3):
   pos=(xx,zz,yy)
   if pos in walk and pos not in seen:seen.add(pos);q.append(pos)
points={'south gate':(0,124),'central plaza':(0,0),'palace gate':(0,-37),'main hall interior':(0,-75),'west ward':(-46,40),'east ward':(46,40),'west gate':(-112,0),'east gate':(112,0)}
failed=[]
for name,(x,z) in points.items():
 opts=[y+60 for xx,zz,y in seen if xx==x+125 and zz==z+125]
 if not opts:failed.append(name)
 print('WALK',name,opts)
assert not failed, 'Unreachable: '+str(failed)
ok('Conservative ground-path flood fill reaches south gate, center, palace interior, both wards and side gates')
# New chunk generation only, no random/relative city spawn and no automatic ChunkEvent overwrites.
g=(P/'src/main/java/dev/sushi/wooltest/world/WoolChunkGenerator.java').read_text()
assert 'CityLayoutData.contains(x, z)' in g and 'CityBlueprint.stateAt(x, y, z)' in g
assert 'CityLayoutData.reservesStructureChunk' in g
citysrc='\n'.join(f.read_text() for f in (P/'src/main/java/dev/sushi/wooltest/city').glob('*.java'))
assert 'ChunkEvent.Load' not in citysrc.replace('// At most one target chunk is loaded in one tick. No recursive work from ChunkEvent.Load.','')
assert 'setDirty()' in citysrc and 'data.completed' in citysrc and 'literal("confirm")' in citysrc
ok('Fixed-coordinate generation and protected city neighborhood; opt-in migration with persistent progress and no repeat after completion')
# Existing gameplay/assets preserved, excluding explicit integration classes and added text.
prior=P.parents[1]/'WoolTest-structure1/WoolTest-1.20.1-Forge-GitHub-Ready.zip'
if prior.exists():
 allowed={'src/main/java/dev/sushi/wooltest/WoolTestMod.java','src/main/java/dev/sushi/wooltest/client/ClientEvents.java','src/main/java/dev/sushi/wooltest/command/TestCommands.java','src/main/java/dev/sushi/wooltest/world/WoolChunkGenerator.java'}
 unchanged=[]
 with zipfile.ZipFile(prior) as z:
  for name in z.namelist():
   if name.startswith('src/main/java/') and name not in allowed:
    assert (P/name).read_bytes()==z.read(name),name;unchanged.append(name)
  for name in z.namelist():
   if name.startswith('src/main/resources/assets/wooltest/textures/'):
    assert (P/name).read_bytes()==z.read(name)
 ok(f'{len(unchanged)} existing gameplay Java files and every previous texture byte-for-byte unchanged')
(P/'validation/city2-resource-check.txt').write_text('\n'.join(log)+'\nNOT RUN: Forge compilation, actual client/server, lighting/fluid behavior, save/reload migration runtime.\n',encoding='utf-8')
