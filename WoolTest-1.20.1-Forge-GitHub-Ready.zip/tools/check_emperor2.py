from pathlib import Path
from PIL import Image
import numpy as np,json,re,hashlib,tomllib
P=Path(__file__).resolve().parents[1];A=P/'art_source/emperor2';J=P/'src/main/java/dev/sushi/wooltest';R=P/'src/main/resources';out={}
spec=json.loads((A/'emperor_model.json').read_text());tex=Image.open(R/'assets/wooltest/textures/entity/emperor.png').convert('RGBA');assert tex.size==(512,512)
known={'root':(0,0,0)};used=set();boxes=[];count=0
for node in spec['nodes']:
 assert node['parent'] in known and node['name'] not in known
 known[node['name']]=tuple(a+b for a,b in zip(known[node['parent']],node['offset']))
 for c in node['cubes']:
  count+=1;lo=np.array(known[node['name']])+np.array(c['origin']);hi=lo+np.array(c['size']);boxes.append((lo,hi));assert all(v>0 for v in c['size'])
  for face,(x,y,w,h) in c['faces'].items():
   assert 0<=x<x+w<=256 and 0<=y<y+h<=256
   pixels=np.array(tex.crop((x*2,y*2,(x+w)*2,(y+h)*2)));assert (pixels[:,:,3]==255).all(),(c['name'],face)
   for yy in range(y,y+h):
    for xx in range(x,x+w):assert (xx,yy) not in used,(c['name'],face);used.add((xx,yy))
lo=np.min([b[0] for b in boxes],axis=0);hi=np.max([b[1] for b in boxes],axis=0)
assert lo[0]>=-16 and hi[0]<=16 and lo[2]>=-16 and hi[2]<=16 and lo[1]>=-24 and hi[1]<=24,(lo,hi)
model=(J/'client/EmperorModel.java').read_text();assert model.count('.addBox(')==count
out['model']={'nodes':len(spec['nodes']),'cuboids':count,'uv_faces':count*6,'no_uv_overlap':True,'neutral_extent_min':lo.tolist(),'neutral_extent_max':hi.tolist(),'model_and_collision':'neutral cuboids fit 2x2x3; animated pose not separately collision-tested'}
checks=[('item/imperial_sword.png',(32,32)),('effect/imperial_circle.png',(512,512)),('effect/imperial_ground.png',(512,512)),('effect/imperial_beam.png',(32,32)),('entity/emperor_charge.png',(512,512)),('models/armor/imperial_layer_1.png',(256,128)),('models/armor/imperial_layer_2.png',(256,128))]+[('item/imperial_'+n+'.png',(32,32)) for n in ['crown','robe','leggings','boots']]
for name,size in checks:
 im=Image.open(R/'assets/wooltest/textures'/name);assert im.size==size and im.mode=='RGBA';a=np.array(im)[:,:,3];assert a.min()==0 and a.max()>200,name
jsons=0
for p in R.rglob('*.json'):json.loads(p.read_text());jsons+=1
mod=(J/'ModContent.java').read_text();client=(J/'client/ClientEvents.java').read_text();main=(J/'WoolTestMod.java').read_text()
for n in ['emperor','imperial_cast','imperial_sword','emperor_spawn_egg','imperial_crown','imperial_robe','imperial_leggings','imperial_boots']:assert f'"{n}"' in mod
for n in ['CROWN','ROBE','LEGGINGS','BOOTS']:assert 'event.accept(ModContent.IMPERIAL_'+n+'.get())' in client
for locale in ['zh_tw','en_us']:
 l=json.loads((R/f'assets/wooltest/lang/{locale}.json').read_text())
 for n in ['crown','robe','leggings','boots']:assert 'item.wooltest.imperial_'+n in l
for p in J.rglob('*.java'):
 if 'client' not in p.parts:assert 'import net.minecraft.client.' not in p.read_text(),p
source=(J/'entity/ImperialCastEntity.java').read_text();emperor=(J/'entity/EmperorEntity.java').read_text()
assert source.count('victim.hurt(')==1 and 'boolean area = fullRelease' in source
assert 'cast.playerOwned ? ImperialSwordCastRules.MAX_CHARGE : EmperorRules.CHARGE_TICKS' in source and 'release(true)' in source and 'public void release() { release(false); }' in source
assert 'dropCustomDeathLoot(DamageSource source, int lootingLevel, boolean recentlyHit)' in emperor
assert 'dropEquipment(' not in emperor and 'ImperialArmorRules.drops(getRandom()::nextInt)' in emperor
assert 'new EmperorAuraLayer(this)' in (J/'client/EmperorRenderer.java').read_text()
assert 'spellCooldown = EmperorRules.COOLDOWN;' in emperor
assert 'capital_v5.wct.gz' in (J/'city/CityBlueprint.java').read_text()
assert 'wooltest_capital_migration_v5' in (J/'city/CityBuildData.java').read_text()
meta=tomllib.loads((R/'META-INF/mods.toml').read_text());assert meta['mods'][0]['displayName']=='Wool Test Dimension (City 5 + Emperor 2)'
out.update(rgba_assets_checked=len(checks),json_resources=jsons,static_registration_and_side_checks=True,limit='No Forge/Minecraft API compilation or runtime/network/rendering verification.')
(P/'validation/emperor2_resources.json').write_text(json.dumps(out,ensure_ascii=False,indent=2));print(json.dumps(out,ensure_ascii=False,indent=2))
