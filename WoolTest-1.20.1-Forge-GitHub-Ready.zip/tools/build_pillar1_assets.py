#!/usr/bin/env python3
"""Build square, per-block game textures from the generated Pillar 1 design.
Requires Pillow. This tool is optional and is NOT run by Gradle / GitHub Actions.
"""
from pathlib import Path
from PIL import Image, ImageEnhance
import json
ROOT = Path(__file__).resolve().parent.parent
ART = ROOT / "art_source/pillar1"
layout = json.loads((ART / "texture_layout.json").read_text())
source = Image.open(ART / layout["source"]).convert("RGB")
output = ROOT / "src/main/resources/assets/wooltest/textures/block"
output.mkdir(parents=True, exist_ok=True)
for face, box in layout["faces"].items():
    crop = source.crop(tuple(box))
    if face == "end":
        tile = crop.resize((32, 32), Image.Resampling.BOX)
    else:
        strip = crop.resize((32, 96), Image.Resampling.BOX)
        tile = strip.resize((32, 32), Image.Resampling.BOX)
        if face == "front":
            # Keep the 01 badge legible instead of vertically squashing it.
            badge = strip.crop(tuple(layout["badge_source_box_on_32x96_front"]))
            tx, ty, rx, by = layout["badge_target_box"]
            tile.paste(badge.resize((rx-tx, by-ty), Image.Resampling.BOX), (tx, ty))
    # A compact palette keeps the Minecraft pixel-art look without fuzzy edges.
    tile = ImageEnhance.Contrast(tile).enhance(1.10)
    tile = tile.quantize(colors=48, method=Image.Quantize.MEDIANCUT,
                         dither=Image.Dither.NONE).convert("RGBA")
    tile.save(output / ("temporary_pillar_" + face + ".png"))
print("Wrote five 32x32 opaque PNG textures.")
