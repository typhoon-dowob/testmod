from pathlib import Path
import json,csv
from reportlab.pdfgen.canvas import Canvas
from reportlab.lib.pagesizes import A3,landscape,portrait
from reportlab.lib.utils import ImageReader
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
P=Path(__file__).resolve().parents[1];OUT=P.parent;I=P/'art_preview';Q=json.loads((P/'validation/city3_checks.json').read_text());F=json.loads((P/'validation/city3_face_contacts.json').read_text());B=json.loads((P/'art_source/city3/buildings.json').read_text())
pdfmetrics.registerFont(TTFont('CN','/usr/share/fonts/truetype/arphic/uming.ttc',subfontIndex=0))
name=OUT/'承天城_City3_3D與逐棟檢查.pdf';c=Canvas(str(name),pagesize=landscape(A3),pageCompression=1);c.setTitle('承天城 City 3 全城重建｜實際3D與逐棟檢查');c.setAuthor('Su SHI / WoolTest')
INK=(.13,.17,.18);TEAL=(.05,.35,.36);MUTED=(.35,.39,.40)
def txt(x,y,t,size=12,color=INK,font='CN'):
 c.setFillColorRGB(*color);c.setFont(font,size);c.drawString(x,y,t)
def foot(w,label):
 txt(35,23,label,9,MUTED);c.setFont('Helvetica',9);c.drawRightString(w-35,23,str(c.getPageNumber()))
def heading(t,sub=''):
 w,h=landscape(A3);c.setPageSize((w,h));txt(42,h-50,t,27);txt(43,h-80,sub,12,MUTED);c.setStrokeColorRGB(.72,.79,.79);c.line(42,h-96,w-42,h-96);return w,h
for fname in ['city3-overview.png','city3-palace.png','city3-palace-section.png','city3-guild-section.png','city3-plan.png']:
 w,h=landscape(A3);c.setPageSize((w,h));ir=ImageReader(I/fname);iw,ih=ir.getSize();r=min((w-45)/iw,(h-55)/ih);c.drawImage(ir,(w-iw*r)/2,43+(h-55-ih*r)/2,iw*r,ih*r)
 c.bookmarkPage(fname);c.addOutlineEntry(fname.replace('city3-','').replace('.png',''),fname,0,False);foot(w,'CITY 3 / 實際藍圖離線渲染；材質、幾何、照明顯示限制見後頁。');c.showPage()
w,h=heading('檢查結果與範圍','同一份 capital_v3.wct.gz 用於模組、3D 預覽及逐格分層圖冊。')
checks=[('左右對稱',f"{Q['cells_compared']:,} 個位置；方塊狀態鏡像差異 0。"),('建築互撞','30 棟含屋簷與入口台階的用地包圍範圍：重疊 0。'),('通路與入口','30 棟入口、4 處二樓及陽臺通過離線可達性檢查。'),('柱腳與柱頂',f"{Q['columns_checked']} 組柱：連續柱身、落地支承與上方承托檢查通過。"),('道路淨空','保留道路至少 3 格高淨空；占用道路的柱／燈 0。'),('構件接觸',f"{F['solid_cells']:,} 個非水實體格均與地基有面接觸路徑。"),('真實燈具',f"{Q['light_positions_checked']} 處燈具；註冊亮度 15，懸掛或座底支承檢查通過。"),('水域','原始靜態藍圖的水底及側緣無開口；不等於動態水流測試。'),('高度與唯一性','251×251；原點唯一；最高方塊 Y=91，Y=92–127 為空氣。')]
y=h-136
for title,desc in checks:
 txt(48,y,title,15,TEAL);txt(220,y,desc,13);y-=42
for i,t in enumerate(['比例界限是本專案設定，不宣稱符合真實古建築工程規範。','通路檢查採兩格淨空、允許相鄰台階升降的方塊網格；不是 Minecraft 碰撞引擎。','面接觸檢查以 1/16 格模型邊界遮罩計算；僅證明幾何相連，不是力學承載驗證。','3D 圖是離線預覽；原版家具使用代表色，光照不是 Minecraft 光照模擬。','Forge 完整編譯、遊戲啟動、實際光照／碰撞／水流與舊存檔遷移仍待實測。']):txt(48,270-i*29,t,12,MUTED)
txt(48,101,'亮度屬性參考：Forge 1.20.1 Blocks / lightLevel（0–15）',11,TEAL);c.linkURL('https://docs.minecraftforge.net/en/1.20.1/blocks/',(48,98,440,114),relative=0)
txt(48,75,'Blueprint SHA-256: '+Q['sha256'],9,MUTED,'Helvetica');foot(w,'CITY 3 / 已完成離線驗證；不等於完整遊戲驗收。');c.showPage()
# Contact sheets show every building, hiding surrounding foliage for clarity.
for j in range(1,6):
 w,h=portrait(A3);c.setPageSize((w,h));ir=ImageReader(I/f'city3-building-review-{j:02d}.png');iw,ih=ir.getSize();r=min((w-40)/iw,(h-65)/ih);c.drawImage(ir,(w-iw*r)/2,45+(h-65-ih*r)/2,iw*r,ih*r)
 foot(w,'逐棟視圖隱藏周邊樹木；角樓／城門樓下方為共同城牆基座。');c.showPage()
for start in [0,15]:
 w,h=heading(f'逐棟尺寸與入口檢查 {start//15+1}/2','本體尺寸不含屋簷；間距檢查另包含屋簷、台階與陽臺。高差依實際方塊層計算。')
 cols=[45,230,350,440,530,640,800,980];headers=['建築','本體寬×深','地坪 Y','最高 Y','高／長邊','入口可達','二樓／陽臺','比例界限']
 y=h-143
 c.setFillColorRGB(.9,.95,.94);c.rect(40,y-13,w-80,35,fill=1,stroke=0)
 for x,t in zip(cols,headers):txt(x,y,t,13,TEAL)
 for k,row in enumerate(Q['buildings'][start:start+15]):
  yy=y-43-k*32
  fields=[row['name'],row['body'].replace('x','×'),str(row['floor']),str(row['roof_top']),str(row['height_to_long_span_ratio']),'通過' if row['entry_reachable'] else '待修正','通過' if 'balcony_reachable' in row else '不適用','通過' if row['proportion_bounds_ok'] else '待修正']
  for x,t in zip(cols,fields):txt(x,yy,t,12)
  c.setStrokeColorRGB(.88,.90,.90);c.line(40,yy-11,w-40,yy-11)
 txt(45,125,'比例檢查：長短邊比不超過 3；建築高／本體長邊不超過 1.6；室內牆高至少 5 格。',12,MUTED)
 txt(45,99,'以上只是此版的設計界限，另有逐棟 3D 人工目視檢查；正殿重簷夾層不是可居住樓層。',12,MUTED)
 foot(w,'CITY 3 / 方塊網格可達性與尺寸檢查，尚未替代遊戲內碰撞驗收。');c.showPage()
w,h=heading('安裝、舊城更新與圖冊讀法','此交付物為已整合的 Forge 1.20.1 模組原始碼，不是預先編譯完成的 JAR。')
lines=[('安裝',18),('以同名 WoolTest-1.20.1-Forge-GitHub-Ready.zip 替換 GitHub 舊 ZIP；沿用已成功的 Actions。',13),('成功後，關閉遊戲，以新的 wooltest-1.20.1-0.1.0.jar 替換舊檔；不要並存兩份 WoolTest。',13),('Mods 名稱：Wool Test Dimension (Capital City 3 - Rebuilt)。',13),('',9),('舊存檔更新必須先備份',18),('換 JAR 不會自動覆寫已生成的舊城。/wooltest city build 顯示警告；build confirm 才開始。',13),('覆寫範圍：羊毛維度 X/Z=-125..125、Y=60..127。包含玩家建築與容器；沒有撤銷功能。',13),('City 3 使用獨立的遷移進度，已補建過 City 1/2 的存檔也能明確更新一次。',13),('指令：/wooltest city、/wooltest city status、/wooltest city pause。',13),('',9),('分層圖冊',18),('總圖：Y=60–127，每一格高度獨立一頁；Y=60–91 有實體方塊，以上 36 層為清空範圍。',13),('詳圖：32 層各拆 16 區，512 張；每格一方塊，數字對應種類與朝向。空白=00 空氣。',13),('四冊為 Y060–069、Y070–079、Y080–089、Y090–091；CSV 保留所有高度的逐格資料。',13),('3D 圖與分層圖都來自本版初始藍圖，不包含日後玩家改建或遊戲更新後的狀態。',13)]
y=h-134
for s,sz in lines:txt(48,y,s,sz,TEAL if sz==18 else INK);y-=39 if sz==18 else 31
foot(w,'CITY 3 / 建議先在新測試存檔驗收，重要存檔先備份。');c.showPage();c.save();print(name)
