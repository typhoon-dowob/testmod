#!/usr/bin/env python3
"""Runs production per-stack armor logic against small test doubles, NOT Forge.
Does not verify game engine NBT binary serialization, packet sync or damage reduction."""
from pathlib import Path
import tempfile,subprocess,json
P=Path(__file__).resolve().parents[1]
namespace={'__file__':str(P/'tools/check_sword1_behavior.py')}
exec((P/'tools/check_sword1_behavior.py').read_text().split("test=r'''",1)[0],namespace)
stubs=namespace['stubs']
stubs['net/minecraft/world/entity/ai/attributes/Attributes.java']='package net.minecraft.world.entity.ai.attributes; public class Attributes {public static final Attribute ARMOR=new Attribute(), ARMOR_TOUGHNESS=new Attribute();}'
s=stubs['net/minecraft/world/item/Item.java'];s=s.replace('public Properties setNoRepair()', 'public Properties fireResistant(){return this;} public Properties setNoRepair()');s=s.replace(' public void inventoryTick', ' public String getArmorTexture(ItemStack s,Entity e,EquipmentSlot slot,String type){return null;}\n public void inventoryTick');stubs['net/minecraft/world/item/Item.java']=s
stubs['net/minecraft/world/item/ArmorItem.java']='''package net.minecraft.world.item;
import net.minecraft.world.entity.EquipmentSlot;
public class ArmorItem extends Item {
 public enum Type { HELMET(EquipmentSlot.HEAD),CHESTPLATE(EquipmentSlot.CHEST),LEGGINGS(EquipmentSlot.LEGS),BOOTS(EquipmentSlot.FEET);private final EquipmentSlot slot;Type(EquipmentSlot s){slot=s;}public EquipmentSlot getSlot(){return slot;}}
 private final Type type;public ArmorItem(ArmorMaterial m,Type t,Properties p){type=t;}public Type getType(){return type;}
}'''
stubs['net/minecraft/world/item/ArmorMaterial.java']='''package net.minecraft.world.item; public interface ArmorMaterial {int getDurabilityForType(ArmorItem.Type t);int getDefenseForType(ArmorItem.Type t);int getEnchantmentValue();net.minecraft.sounds.SoundEvent getEquipSound();net.minecraft.world.item.crafting.Ingredient getRepairIngredient();String getName();float getToughness();float getKnockbackResistance();}'''
stubs['net/minecraft/sounds/SoundEvent.java']='package net.minecraft.sounds; public class SoundEvent {}'
stubs['net/minecraft/sounds/SoundEvents.java']='package net.minecraft.sounds; public class SoundEvents {public static final SoundEvent ARMOR_EQUIP_IRON=new SoundEvent();}'
test=r'''
import dev.sushi.wooltest.item.*;import net.minecraft.world.item.*;import net.minecraft.world.entity.*;import net.minecraft.world.entity.item.*;import net.minecraft.world.level.*;import net.minecraft.world.entity.ai.attributes.*;import net.minecraft.network.chat.Component;import net.minecraft.util.RandomSource;import java.util.*;
public class ArmorBehaviorTest {
 static void eq(double a,double b){if(Math.abs(a-b)>1e-8)throw new AssertionError(a+" != "+b);}
 static class R implements RandomSource {int calls=0;public int nextInt(int n){calls++;return n-1;}}
 public static void main(String[] a){
  Set<UUID> ids=new HashSet<>();int pairs=0;
  for(ArmorItem.Type type:ArmorItem.Type.values()){
   ImperialArmorItem item=new ImperialArmorItem(type);R r=new R();ItemStack s=item.createRolledStack(r);eq(2,r.calls);eq(300,item.armorHundredths(s));eq(200,item.toughnessHundredths(s));
   for(int n=0;n<50;n++)item.initializeIfNeeded(s,r);eq(2,r.calls);
   ItemStack copy=s.copy();eq(300,item.armorHundredths(copy));eq(200,item.toughnessHundredths(copy));
   ItemStack restored=new ItemStack(item);restored.setTag(s.getTag().copy());item.initializeIfNeeded(restored,r);eq(2,r.calls);
   var mods=item.getAttributeModifiers(type.getSlot(),s);
   for(Attribute k:new Attribute[]{Attributes.ARMOR,Attributes.ARMOR_TOUGHNESS})for(var m:mods.get(k)){if(!ids.add(m.getId()))throw new AssertionError("duplicate UUID across slots or stats");}
   eq(3,mods.get(Attributes.ARMOR).iterator().next().getAmount());eq(2,mods.get(Attributes.ARMOR_TOUGHNESS).iterator().next().getAmount());
   for(EquipmentSlot slot:EquipmentSlot.values())if(slot!=type.getSlot()&&!item.getAttributeModifiers(slot,s).isEmpty())throw new AssertionError("wrong slot");
   for(int ar=100;ar<=300;ar++)for(int to=100;to<=200;to++){
    s.getOrCreateTag().putInt(item.ARMOR_TAG,ar);s.getOrCreateTag().putInt(item.TOUGHNESS_TAG,to);mods=item.getAttributeModifiers(type.getSlot(),s);
    eq(ar/100.0,mods.get(Attributes.ARMOR).iterator().next().getAmount());eq(to/100.0,mods.get(Attributes.ARMOR_TOUGHNESS).iterator().next().getAmount());pairs++;
   }
   s.getOrCreateTag().putInt(item.ARMOR_TAG,237);s.getOrCreateTag().putInt(item.TOUGHNESS_TAG,142);
   List<Component> text=new ArrayList<>();item.appendHoverText(s,null,text,TooltipFlag.NORMAL);eq(2,text.size());if(!text.get(0).args[0].equals("2.37")||!text.get(1).args[0].equals("1.42"))throw new AssertionError("tooltip");
   ItemStack partial=new ItemStack(item);partial.getOrCreateTag().putInt(item.ARMOR_TAG,183);item.initializeIfNeeded(partial,r);eq(183,item.armorHundredths(partial));eq(200,item.toughnessHundredths(partial));eq(3,r.calls);
   ItemStack raw=new ItemStack(item);Level client=new Level(true,r);item.inventoryTick(raw,client,new Entity(client),0,false);eq(3,r.calls);if(raw.getTag()!=null)throw new AssertionError("client modified data");
   item.appendHoverText(raw,null,new ArrayList<>(),TooltipFlag.NORMAL);eq(3,r.calls);if(raw.getTag()!=null)throw new AssertionError("tooltip modified data");
   Level server=new Level(false,r);ItemEntity drop=new ItemEntity(server,raw);item.onEntityItemUpdate(raw,drop);eq(1,drop.updates);eq(5,r.calls);item.onEntityItemUpdate(drop.getItem(),drop);eq(1,drop.updates);eq(5,r.calls);
   ItemStack worn=new ItemStack(item);item.inventoryTick(worn,server,new Entity(server),36,false);eq(7,r.calls);item.inventoryTick(worn,server,new Entity(server),36,false);eq(7,r.calls);
   s.getOrCreateTag().putInt(item.ARMOR_TAG,-5);s.getOrCreateTag().putInt(item.TOUGHNESS_TAG,500);eq(100,item.armorHundredths(s));eq(200,item.toughnessHundredths(s));
   String texture=item.getArmorTexture(s,new Entity(server),type.getSlot(),null);if(!texture.endsWith(type==ArmorItem.Type.LEGGINGS?"layer_2.png":"layer_1.png"))throw new AssertionError("atlas selection");
  }
  eq(8,ids.size());System.out.println("PASS: production ImperialArmorItem/Material with TEST DOUBLES; "+pairs+" stat pairs,8 unique modifiers, correct slots, read-only tooltip/client, one-time server roll, partial-tag preservation, copies, two wearable atlas paths. NOT Forge compilation or real save/load/network test.");
 }
}
'''
with tempfile.TemporaryDirectory(prefix='wooltest-armor-') as td:
 d=Path(td)
 for name,body in stubs.items():p=d/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(body)
 (d/'ArmorBehaviorTest.java').write_text(test)
 sources=[str(p) for p in d.rglob('*.java')]+[str(P/'src/main/java/dev/sushi/wooltest'/s) for s in ['logic/ImperialArmorRules.java','item/ImperialArmorItem.java','item/ImperialArmorMaterial.java']]
 subprocess.run(['javac','--release','17','-encoding','UTF-8','-d',str(d/'classes'),*sources],check=True)
 result=subprocess.run(['java','-cp',str(d/'classes'),'ArmorBehaviorTest'],check=True,text=True,capture_output=True)
 print(result.stdout,end='')
