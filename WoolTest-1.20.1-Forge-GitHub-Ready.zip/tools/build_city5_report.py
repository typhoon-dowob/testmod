"""Source-derived QA report. No conceptual/in-game screenshots are asserted."""
from pathlib import Path
import json, math, io
from PIL import Image,ImageDraw,ImageFont
from reportlab.pdfgen.canvas import Canvas
from reportlab.lib.utils import ImageReader
from reportlab.lib.pagesizes import A4,landscape
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
P=Path(__file__).resolve().parents[1];O=P.parent;A=P/'art_preview';R=P/'src/main/resources/assets/wooltest/textures';V=P/'validation'
F='/usr/share/fonts/truetype/arphic/uming.ttc';pdfmetrics.registerFont(TTFont('CJK',F,subfontIndex=0))
# Show the exact transparent effect resources on a neutral background, not a fake game scene.
im=Image.new('RGB',(1400,820),(236,233,223));d=ImageDraw.Draw(im);font=lambda n:ImageFont.truetype(F,n)
d.text((40,25),'天子敕令｜實際法陣資源',font=font(32),fill=(38,43,47))
d.text((40,70),'左：前方光束法陣；右：落點地紋。此圖不模擬遊戲光照或動畫。',font=font(21),fill=(70,75,78))
for i,(fn,title,desc) in enumerate([('imperial_circle.png','前方法陣','皇帝使用一個直徑約5.6格的法陣，五秒完成。'),('imperial_ground.png','地面儀式圖紋','範圍半徑10格；另外疊加八個副符印與連線。')]):
 x=50+i*680;im.paste((29,33,42),(x,125,x+620,745));tex=Image.open(R/'effect'/fn).convert('RGBA').resize((540,540));im.paste(tex,(x+40,145),tex)
 d.text((x+10,690),title,font=font(25),fill=(245,216,144));d.text((x,770),desc,font=font(18),fill=(45,49,52))
im.save(A/'imperial-fx-assets.png')
W,H=landscape(A4);c=Canvas(str(O/'City5_Emperor2_3D與檢查報告.pdf'),pagesize=(W,H),pageCompression=1);c.setTitle('承天城 City5 + 皇帝2｜實際模型與檢查');c.setAuthor('Su SHI / WoolTest')
def text(x,y,s,size=11):c.setFillColorRGB(.15,.18,.2);c.setFont('CJK',size);c.drawString(x,y,s)
def head(title,sub):text(30,H-35,title,21);text(30,H-58,sub,10);c.setStrokeColorRGB(.75,.78,.78);c.line(30,H-70,W-30,H-70)
def foot():text(30,19,'City 5 + Emperor 2｜離線檢查與源資料預覽；尚未完整 Forge 編譯及遊戲實測。',8);c.setFont('Helvetica',8);c.drawRightString(W-30,19,str(c.getPageNumber()));c.showPage()
def image_page(fn,title,sub):
 head(title,sub);im=Image.open(A/fn);iw,ih=im.size;ratio=min((W-60)/iw,(H-116)/ih);ww,hh=iw*ratio,ih*ratio
 buf=io.BytesIO();im.convert('RGB').save(buf,format='JPEG',quality=92,subsampling=0);buf.seek(0)
 c.drawImage(ImageReader(buf), (W-ww)/2,45+(H-116-hh)/2,ww,hh);foot()
head('City 5 + Emperor 2｜整合更新', 'Minecraft Java 1.20.1 / Forge 47.4.10+ | 城市、皇帝技能、御用裝備')
lines=[('交付範圍',16),('城市仍為251×251，中心(0,0)，東西鏡像，自然生成位置唯一。',12),('門窗分區、城防修補、三重屋面與御座；保留獨立柱廊及32棟建築。',12),('皇帝固定蓄力100刻：完整施放範圍60點＋光束6點；被打斷僅光束6點。',12),('皇帝生命50、攻擊10、碰撞2×2×3、上方頭目血條不變。',12),('天子劍玩家用法仍保留原本5–15秒規則；沒有改成皇帝的單段技能。',12),('',8),('裝備與材質',16),('天子冕、玄龍袍甲、鎮國護腿、踏雲御靴，各自獨立90%掉落。',12),('每件盔甲1.00–3.00、韌性1.00–2.00，間隔0.01，伺服器抽定後保存。',12),('一般物品介紹只有盔甲值與韌性兩行；不用F3+H。',12),('物品圖示與穿戴材質皆為原創；穿戴使用標準人形盔甲網格。',12),('',8),('驗證邊界',16),('本報告的3D圖來自實際城市方塊資料／模型／貼圖，不是遊戲截圖。',12),('離線規則測試和語法解析不能驗證Forge API、渲染、網路同步或AI。',12),('本機對Forge依賴站DNS解析失敗，完整編譯須由GitHub Actions完成。',12)]
y=H-103
for s,n in lines:text(35,y,s,n);y-=24 if n<16 else 31
foot()
for fn,title,sub in [('city5-overview.png','承天城全景','實際初始方塊資料；不含後續水流與玩家改建。'),('city5-palace.png','正殿：屋面與門窗','剔除旁側建築的裁切殘片；主殿地坪Y67、最高Y99。'),('city5-palace-section.png','正殿剖切：藻井、御座與柱廊','只在圖中切除南半部；遊戲內仍為完整殿宇。'),('city5-guild-section.png','兩層會館剖切','展示室內樓梯、二樓與陽臺；原版家具在離線渲染中使用代表色。'),('emperor2-model-preview.png','皇帝2：實際模型','24個節點、96個長方體；中立姿勢，圖中沒有渲染手持劍。'),('imperial-armor-assets.png','四件御用裝備：實際材質','四件獨立物品；兩張穿戴圖集依部位選擇。'),('imperial-fx-assets.png','施法特效：實際資源','貼圖在客戶端以自發光層顯示；不等於新增環境照明方塊。')]:image_page(fn,title,sub)
for i in range(1,7):image_page(f'city5-building-review-{i:02d}.png',f'逐棟幾何檢視 {i}/6','32棟分配包含屋簷的獨立範圍；門窗、柱廊與台基為實際源資料。')
checks=json.loads((V/'city5_checks.json').read_text());fac=json.loads((V/'city5_facades.json').read_text());pdf=json.loads((V/'city5_pdf_check.json').read_text())
head('檢查摘要與限制','數值取自本次程式輸出；完整檔案另附於專案validation目錄。')
rows=[('左右鏡像',f"{checks['cells_compared']:,}個位置，差異{checks['mirrored_cell_mismatches']}"),('建築範圍',f"{len(checks['buildings'])}棟；含屋簷範圍交疊{len(checks['building_envelope_intersections'])}"),('獨立柱與道路',f"{checks['columns_checked']}組柱；公共道路障礙{checks['street_obstructions_count']}"),('門窗及城牆',f"{fac['doorways_checked']}個門洞；{fac['exterior_parapet_edge_cells_checked']}個外側牆頂邊格；錯誤{len(fac['errors'])}"),('照明',f"{checks['light_positions_checked']}處燈具；設定亮度15，安裝錯誤{len(checks['light_mount_or_registry_errors'])}"),('方塊圖冊',f"{pdf['pdf_grid_pages_checked']}張詳圖、{pdf['non_air_cell_codes_checked']:,}個非空氣代碼；差異頁{len(pdf['mismatch_pages'])}"),('裝備規則','四個90%判定；全部201×101組數值範圍測試'),('裝備行為','81,204組數值／修飾器測試；使用測試替身，非Minecraft引擎'),('皇帝規則','100刻完整施放；早放6，完整範圍60；未測AI與實際命中'),('Java','40份遊戲Java原始碼語法解析；未進行Forge API連結')]
y=H-105
for i,(k,val) in enumerate(rows):
 c.setFillColorRGB(*((.94,.95,.95) if i%2==0 else (1,1,1)));c.rect(30,y-17,W-60,31,stroke=0,fill=1);text(40,y,k,11);text(160,y,val,10);y-=34
text(35,y-18,'通路與支承是離線幾何檢查，不是現實力學或Minecraft碰撞引擎驗證。',10);foot()
head('安裝、更新舊城與遊戲驗收','先備份存檔；建置成功不等於實測通過。')
lines=[('1. 替換GitHub根目錄的同名原始碼ZIP；外層workflow沿用目前可執行版本。',12),('2. 下載本次提交的Actions成品；關閉遊戲後替換JAR，不要留下兩份。',12),('3. Mods名稱：Wool Test Dimension (City 5 + Emperor 2)。',12),('4. 新世界用 /wooltest city；已探索城市必須明確確認補建。',12),('',8),('舊城更新（不可撤銷）',16),('/wooltest city build',12),('/wooltest city build confirm',12),('會覆寫羊毛維度X/Z=-125..125、Y=60..127，包括容器與玩家建築。',12),('/wooltest city status 查看進度；/wooltest city pause 只暫停，不回復方塊。',12),('',8),('測試清單',16),('/wooltest armor：直接取得四件已抽值的裝備，方便查看材質與介紹。',12),('/wooltest emperor test：額外生成測試皇帝，不會復活已死亡的宮殿皇帝。',12),('驗證5秒施放、提早打斷、死亡取消、掉落0–4件、存檔與多人同步。',12),('驗證實際窗門、城牆、光照、碰撞及32棟入口；發生錯誤請保留日誌。',12)]
y=H-105
for s,n in lines:text(35,y,s,n);y-=25 if n<16 else 32
foot();c.save();print('Report written:',O/'City5_Emperor2_3D與檢查報告.pdf')
