#!/usr/bin/env python3
"""Execute production sword code with SMALL TEST DOUBLES, NOT Forge/Minecraft.
This checks per-stack logic only. It deliberately does not claim API compatibility,
real NBT binary serialization, network synchronization, combat or game rendering.
All doubles/classes are temporary and excluded from src/main and the mod JAR.
"""
from pathlib import Path
import os, subprocess, tempfile
ROOT=Path(__file__).resolve().parent.parent
stubs={
'javax/annotation/Nullable.java': 'package javax.annotation; public @interface Nullable {}',
'net/minecraft/ChatFormatting.java': 'package net.minecraft; public enum ChatFormatting { GRAY,GOLD,AQUA,DARK_GRAY }',
'net/minecraft/nbt/Tag.java': 'package net.minecraft.nbt; public class Tag { public static final int TAG_INT=3; }',
'net/minecraft/nbt/CompoundTag.java': '''package net.minecraft.nbt;
public class CompoundTag {
 private final java.util.Map<String,Integer> data=new java.util.HashMap<>();
 public boolean contains(String key,int type){return type==3 && data.containsKey(key);}
 public int getInt(String key){return data.getOrDefault(key,0);}
 public void putInt(String key,int value){data.put(key,value);}
 public CompoundTag copy(){var result=new CompoundTag();result.data.putAll(data);return result;}
}''',
'net/minecraft/network/chat/Component.java': '''package net.minecraft.network.chat;
public class Component {
 public final String key; public final Object[] args;
 private Component(String k,Object[] a){key=k;args=a;}
 public static Component translatable(String k,Object... a){return new Component(k,a);}
 public Component withStyle(net.minecraft.ChatFormatting style){return this;}
}''',
'net/minecraft/util/RandomSource.java': 'package net.minecraft.util; public interface RandomSource { int nextInt(int bound); }',
'net/minecraft/world/level/Level.java': '''package net.minecraft.world.level;
public class Level {public final boolean isClientSide; private final net.minecraft.util.RandomSource rng;
 public Level(boolean client,net.minecraft.util.RandomSource random){isClientSide=client;rng=random;}
 public net.minecraft.util.RandomSource getRandom(){return rng;}
}''',
'net/minecraft/world/entity/Entity.java': '''package net.minecraft.world.entity;
public class Entity {private final net.minecraft.world.level.Level level;
 public Entity(net.minecraft.world.level.Level l){level=l;} public net.minecraft.world.level.Level level(){return level;}}
''',
'net/minecraft/world/entity/player/Player.java': '''package net.minecraft.world.entity.player;
public class Player extends net.minecraft.world.entity.Entity {public Player(net.minecraft.world.level.Level l){super(l);}}''',
'net/minecraft/world/entity/item/ItemEntity.java': '''package net.minecraft.world.entity.item;
public class ItemEntity extends net.minecraft.world.entity.Entity {
 private net.minecraft.world.item.ItemStack stack; public int updates;
 public ItemEntity(net.minecraft.world.level.Level l,net.minecraft.world.item.ItemStack s){super(l);stack=s;}
 public void setItem(net.minecraft.world.item.ItemStack s){stack=s;updates++;}
 public net.minecraft.world.item.ItemStack getItem(){return stack;}
}''',
'net/minecraft/world/entity/EquipmentSlot.java': 'package net.minecraft.world.entity; public enum EquipmentSlot {MAINHAND,OFFHAND,HEAD,CHEST,LEGS,FEET}',
'net/minecraft/world/entity/ai/attributes/Attribute.java': 'package net.minecraft.world.entity.ai.attributes; public class Attribute {}',
'net/minecraft/world/entity/ai/attributes/Attributes.java': '''package net.minecraft.world.entity.ai.attributes;
public class Attributes {public static final Attribute ATTACK_DAMAGE=new Attribute(), ATTACK_SPEED=new Attribute();}''',
'net/minecraft/world/entity/ai/attributes/AttributeModifier.java': '''package net.minecraft.world.entity.ai.attributes;
public class AttributeModifier {public enum Operation {ADDITION}
 private final java.util.UUID id; private final double amount;
 public AttributeModifier(java.util.UUID id,String name,double amount,Operation op){this.id=id;this.amount=amount;}
 public double getAmount(){return amount;} public java.util.UUID getId(){return id;}
}''',
'com/google/common/collect/Multimap.java': '''package com.google.common.collect;
public interface Multimap<K,V> {java.util.Collection<V> get(K k);boolean isEmpty();}''',
'com/google/common/collect/ImmutableMultimap.java': '''package com.google.common.collect;
public final class ImmutableMultimap<K,V> implements Multimap<K,V> {
 private final java.util.Map<K,java.util.List<V>> map;
 private ImmutableMultimap(java.util.Map<K,java.util.List<V>> m){map=java.util.Map.copyOf(m);}
 public java.util.Collection<V> get(K k){return map.getOrDefault(k,java.util.List.of());}
 public boolean isEmpty(){return map.isEmpty();}
 public static <K,V> ImmutableMultimap<K,V> of(){return new ImmutableMultimap<>(java.util.Map.of());}
 public static <K,V> Builder<K,V> builder(){return new Builder<>();}
 public static class Builder<K,V>{private final java.util.Map<K,java.util.List<V>> m=new java.util.HashMap<>();
 public Builder<K,V> put(K k,V v){m.computeIfAbsent(k,x->new java.util.ArrayList<>()).add(v);return this;}
 public ImmutableMultimap<K,V> build(){return new ImmutableMultimap<>(m);}}
}''',
'net/minecraft/world/item/crafting/Ingredient.java': 'package net.minecraft.world.item.crafting; public class Ingredient {public static final Ingredient EMPTY=new Ingredient();}',
'net/minecraft/world/item/Tier.java': '''package net.minecraft.world.item;
public interface Tier {int getUses();float getSpeed();float getAttackDamageBonus();int getLevel();int getEnchantmentValue();net.minecraft.world.item.crafting.Ingredient getRepairIngredient();}''',
'net/minecraft/world/item/TooltipFlag.java': 'package net.minecraft.world.item; public interface TooltipFlag {boolean isAdvanced(); TooltipFlag NORMAL=()->false, ADVANCED=()->true;}',
'net/minecraft/world/item/Item.java': '''package net.minecraft.world.item;
import net.minecraft.world.entity.*; import net.minecraft.world.entity.player.Player; import net.minecraft.world.level.Level;
import net.minecraft.world.entity.ai.attributes.*; import com.google.common.collect.*;
public class Item {
 protected static final java.util.UUID BASE_ATTACK_DAMAGE_UUID=new java.util.UUID(0,1),BASE_ATTACK_SPEED_UUID=new java.util.UUID(0,2);
 public static class Properties {public Properties setNoRepair(){return this;}}
 public void inventoryTick(ItemStack s,Level l,Entity e,int slot,boolean selected){}
 public void onCraftedBy(ItemStack s,Level l,Player p){}
 public boolean onEntityItemUpdate(ItemStack s,net.minecraft.world.entity.item.ItemEntity e){return false;}
 public Multimap<Attribute,AttributeModifier> getAttributeModifiers(EquipmentSlot slot,ItemStack s){return ImmutableMultimap.of();}
 public void appendHoverText(ItemStack s,Level l,java.util.List<net.minecraft.network.chat.Component> t,TooltipFlag f){}
}''',
'net/minecraft/world/item/SwordItem.java': 'package net.minecraft.world.item; public class SwordItem extends Item {public SwordItem(Tier t,int damage,float speed,Properties p){}}',
'net/minecraft/world/item/ItemStack.java': '''package net.minecraft.world.item;
public class ItemStack {private final Item item;private net.minecraft.nbt.CompoundTag tag;
 public ItemStack(Item item){this.item=item;} public net.minecraft.nbt.CompoundTag getTag(){return tag;}
 public net.minecraft.nbt.CompoundTag getOrCreateTag(){if(tag==null)tag=new net.minecraft.nbt.CompoundTag();return tag;}
 public void setTag(net.minecraft.nbt.CompoundTag t){tag=t;}
 public ItemStack copy(){var result=new ItemStack(item);if(tag!=null)result.tag=tag.copy();return result;}}
'''
}
test=r'''
import dev.sushi.wooltest.item.PeachWoodSwordItem;
import dev.sushi.wooltest.logic.PeachWoodSwordRules;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.*;
import net.minecraft.world.level.Level;
import net.minecraft.world.entity.*;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.ai.attributes.*;
import java.util.*;

public class SwordBehaviorTest {
 static int checks;
 static void check(boolean ok,String why){checks++;if(!ok)throw new AssertionError(why);}
 static void close(double a,double b){check(Math.abs(a-b)<1e-12,"attribute mismatch");}
 static class CountingRandom implements net.minecraft.util.RandomSource {
  final int result; int calls; CountingRandom(int r){result=r;}
  public int nextInt(int bound){calls++;check(bound==201,"damage roll bound");return result;}
 }
 static final net.minecraft.util.RandomSource NEVER = bound->{throw new AssertionError("unexpected reroll");};
 static double amount(com.google.common.collect.Multimap<Attribute,AttributeModifier> m,Attribute a){
  check(m.get(a).size()==1,"must have one modifier for an attribute");return m.get(a).iterator().next().getAmount();
 }
 public static void main(String[] args){
  var item=new PeachWoodSwordItem();
  for(int roll=0;roll<201;roll++){
   var rng=new CountingRandom(roll);var s=item.createRolledStack(rng);
   check(rng.calls==1,"roll count");check(item.hasRolledDamage(s),"roll not saved");
   check(s.getTag().getInt(PeachWoodSwordItem.DAMAGE_TAG)==500+roll,"wrong saved integer");
   var main=item.getAttributeModifiers(EquipmentSlot.MAINHAND,s);
   close(1+amount(main,Attributes.ATTACK_DAMAGE),(500+roll)/100.0);
   close(4+amount(main,Attributes.ATTACK_SPEED),1.6);
   for(var slot:EquipmentSlot.values())if(slot!=EquipmentSlot.MAINHAND)
     check(item.getAttributeModifiers(slot,s).isEmpty(),"offhand/armor received attributes");
   var normal=new ArrayList<Component>();var advanced=new ArrayList<Component>();
   item.appendHoverText(s,null,normal,TooltipFlag.NORMAL);item.appendHoverText(s,null,advanced,TooltipFlag.ADVANCED);
   check(normal.size()==3 && advanced.size()==3,"tooltip must contain only flavor, damage and speed");
   check(normal.get(0).key.endsWith(".flavor"),"missing flavor");
   check(normal.get(2).key.endsWith(".speed"),"missing speed label");
   for(var line:normal)check(!line.key.endsWith(".range") && !line.key.endsWith(".fixed_roll")
       && !line.key.endsWith(".pending_roll") && !line.key.endsWith(".base_stats"),"removed explanation still present");
   check(normal.get(1).key.endsWith(".damage"),"missing attack label");
   check(normal.get(1).args[0].equals(PeachWoodSwordRules.formatDamage(500+roll)),"display differs from saved value");
   check(normal.get(2).args[0].equals("1.60"),"wrong displayed speed");
   for(int j=0;j<normal.size();j++)check(normal.get(j).key.equals(advanced.get(j).key),"F3+H dependence");
   item.initializeIfNeeded(s,NEVER);
   var server=new Level(false,NEVER);var client=new Level(true,NEVER);
   for(int tick=0;tick<100;tick++)item.inventoryTick(s,server,new Entity(server),0,true);
   var copy=s.copy();item.initializeIfNeeded(copy,NEVER);
   var reloaded=new ItemStack(item);reloaded.setTag(copy.getTag().copy());item.initializeIfNeeded(reloaded,NEVER);
   check(item.getDamageHundredths(reloaded)==500+roll,"saved-tag restoration changed value");
   var dropped=new ItemEntity(server,s);
   check(!item.onEntityItemUpdate(s,dropped),"suppressed ordinary item ticking");
   check(dropped.updates==0,"reinitialized a previously rolled death drop");
   item.inventoryTick(s,client,new Entity(client),0,true);
   check(item.getDamageHundredths(s)==500+roll,"inventory changed roll");
  }
  var unrolled=new ItemStack(item);var client=new Level(true,NEVER);
  item.inventoryTick(unrolled,client,new Entity(client),0,true);
  check(!item.hasRolledDamage(unrolled),"client generated a roll");
  var text=new ArrayList<Component>();item.appendHoverText(unrolled,null,text,TooltipFlag.NORMAL);
  check(text.get(1).key.endsWith(".unrolled_damage"),"creative preview falsely claims a fixed roll");
  check(text.size()==3,"unrolled tooltip still contains explanation lines");
  check(unrolled.getTag()==null,"reading tooltip mutated NBT");
  var rng=new CountingRandom(137);var server=new Level(false,rng);
  item.inventoryTick(unrolled,server,new Entity(server),0,true);
  check(item.getDamageHundredths(unrolled)==637 && rng.calls==1,"/give initialization");
  var ground=new ItemEntity(server,new ItemStack(item));
  item.onEntityItemUpdate(ground.getItem(),ground);
  check(ground.updates==1 && item.getDamageHundredths(ground.getItem())==637,"ground-item update path");
  item.onEntityItemUpdate(ground.getItem(),ground);check(ground.updates==1,"ground item rerolled");
  unrolled.getOrCreateTag().putInt(PeachWoodSwordItem.DAMAGE_TAG,999999);
  check(item.getDamageHundredths(unrolled)==700,"invalid high NBT was not clamped");
  unrolled.getOrCreateTag().putInt(PeachWoodSwordItem.DAMAGE_TAG,-999999);
  check(item.getDamageHundredths(unrolled)==500,"invalid low NBT was not clamped");
  var low=item.createRolledStack(b->0);var high=item.createRolledStack(b->200);
  check(item.getDamageHundredths(low)==500 && item.getDamageHundredths(high)==700,"per-stack isolation");
  System.out.println("PASS: "+checks+" production-item behavior assertions with TEST DOUBLES.");
  System.out.println("Verified logical paths: one-time per-stack rolls, simulated tag copying/restoration, read-only normal tooltip, both attributes, non-mainhand exclusion, server-only initialization.");
  System.out.println("NOT tested: genuine Minecraft NBT IO, Forge API linkage, game launch, networking or actual combat.");
 }
}
'''
env=os.environ.copy();env['LC_ALL']='C.UTF-8';env['LANG']='C.UTF-8'
with tempfile.TemporaryDirectory(prefix='wooltest-sword-test-') as tmp:
 d=Path(tmp);files=[]
 for name,text in stubs.items():
  p=d/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(text);files.append(str(p))
 p=d/'SwordBehaviorTest.java';p.write_text(test);files.append(str(p))
 for rel in ['logic/PeachWoodSwordRules.java','item/PeachWoodTier.java','item/PeachWoodSwordItem.java']:
  files.append(str(ROOT/'src/main/java/dev/sushi/wooltest'/rel))
 classes=d/'classes';classes.mkdir()
 subprocess.run(['javac','--release','17','-encoding','UTF-8','-cp',str(classes),'-d',str(classes),*files],check=True,env=env)
 subprocess.run(['java','-cp',str(classes),'SwordBehaviorTest'],check=True,env=env)
