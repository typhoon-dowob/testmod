#!/usr/bin/env python3
"""Resource and source checks; intentionally not a Forge build or runtime test."""
import json
from pathlib import Path
import re
import subprocess
import sys
import tomllib

root = Path(__file__).resolve().parent.parent
resources = root / 'src/main/resources'
files = list(resources.rglob('*.json')) + list(resources.rglob('*.mcmeta'))
for path in files:
    json.loads(path.read_text(encoding='utf-8'))
metadata = tomllib.loads((resources / 'META-INF/mods.toml').read_text(encoding='utf-8'))
assert metadata['mods'][0]['modId'] == 'wooltest'
dimension = json.loads((resources / 'data/wooltest/dimension/wool_world.json').read_text())
dtype = json.loads((resources / 'data/wooltest/dimension_type/wool_type.json').read_text())
assert dtype['min_y'] == 0 and dtype['height'] == dtype['logical_height'] == 128
assert dtype['height'] % 16 == 0
assert dimension['type'] == 'wooltest:wool_type'
assert dimension['generator']['type'] == 'wooltest:wool'
assert dimension['generator']['biome_source']['biome'] == 'wooltest:wool_fields'
biome = json.loads((resources / 'data/wooltest/worldgen/biome/wool_fields.json').read_text())
assert not biome['spawners'] and not biome['features'] and not biome['carvers']
for damage in ['test_melee', 'wooden_pillar']:
    assert json.loads((resources / f'data/wooltest/damage_type/{damage}.json').read_text())['scaling'] == 'never'
zh = json.loads((resources / 'assets/wooltest/lang/zh_tw.json').read_text(encoding='utf-8'))
en = json.loads((resources / 'assets/wooltest/lang/en_us.json').read_text(encoding='utf-8'))
assert set(zh) == set(en)
for source in (root / 'src/main/java').rglob('*.java'):
    text = source.read_text(encoding='utf-8')
    for key in re.findall(r'"((?:message|entity)\.wooltest\.[a-z_]+)"', text):
        assert key in zh, (source, key)
    if '/client/' not in str(source):
        assert 'import net.minecraft.client.' not in text, source
print(f'PASS: {len(files)} JSON resource files, TOML metadata, references and side-isolation import checks.', flush=True)
build = root / 'build/offline-check'
build.mkdir(parents=True, exist_ok=True)
rule = root / 'src/main/java/dev/sushi/wooltest/logic/TestRules.java'
subprocess.run(['javac', '--release', '17', '-encoding', 'UTF-8', '-d', str(build),
                str(rule), str(root/'tools/CoreRulesTest.java'), str(root/'tools/ParseJava.java')], check=True)
subprocess.run(['java', '-cp', str(build), 'CoreRulesTest'], check=True)
subprocess.run(['java', '-cp', str(build), 'ParseJava', str(root/'src/main/java')], check=True)
print('NOTE: These checks do not compile against Forge or start Minecraft.', flush=True)
