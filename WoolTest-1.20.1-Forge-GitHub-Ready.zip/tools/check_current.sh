#!/usr/bin/env bash
set -euo pipefail
export LANG=C.UTF-8 LC_ALL=C.UTF-8
cd "$(dirname "$0")/.."
TMP="$(mktemp -d)"; trap 'rm -rf "$TMP"' EXIT
J=src/main/java/dev/sushi/wooltest
javac --release 17 -encoding UTF-8 -d "$TMP" tools/ParseJava.java tools/{EmperorRulesTest,PlayerSwordRulesTest,ImperialArmorRulesTest,CoreRulesTest,PeachWoodSwordRulesTest,City5LayoutTest}.java "$J"/logic/{EmperorRules,ImperialSwordCastRules,ImperialArmorRules,TestRules,PeachWoodSwordRules}.java "$J"/city/CityLayoutData.java
java -cp "$TMP" ParseJava src/main/java
javac --release 17 -encoding UTF-8 -d "$TMP" "$J/client/EmperorMeshData.java" tools/EmperorMeshDataTest.java
java -cp "$TMP:src/main/resources" EmperorMeshDataTest src/main/resources/assets/wooltest/geometry/emperor5.wem.gz
for t in EmperorRulesTest PlayerSwordRulesTest ImperialArmorRulesTest CoreRulesTest PeachWoodSwordRulesTest; do java -cp "$TMP" "$t"; done
java -cp "$TMP" City5LayoutTest src/main/resources/data/wooltest/city/capital_v5.wct.gz
python tools/check_armor2_behavior.py
# Fallen Realm's baseline checker below verifies that Emperor 5 runtime files
# remain unchanged; the old Emperor-only allowlist rejects any new entry hook.
bash tools/check_fallenrealm.sh
python tools/check_emperor5_render_contract.py
python tools/check_city5.py
python tools/check_city5_column_clearance.py
python tools/check_city5_contacts.py
python tools/check_city5_facades.py
printf '\nOFFLINE CHECKS ONLY: Forge API compilation and game testing are still required.\n'
