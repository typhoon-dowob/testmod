#!/usr/bin/env python3
"""Exact reflection checks on serialized runtime data and authored model geometry."""
from pathlib import Path
import json,gzip,struct,collections,hashlib,zipfile
import numpy as np
P=Path(__file__).resolve().parents[1]; A=P/'art_source/city2'; R=P/'src/main/resources'
palette=json.loads((A/'palette.json').read_text()); v=np.load(A/'city_voxels.npy')
def mirror(s):
    return s.replace('facing=east','facing=TEMP').replace('facing=west','facing=east').replace('facing=TEMP','facing=west').replace('shape=inner_left','shape=inner_TEMP').replace('shape=inner_right','shape=inner_left').replace('shape=inner_TEMP','shape=inner_right').replace('shape=outer_left','shape=outer_TEMP').replace('shape=outer_right','shape=outer_left').replace('shape=outer_TEMP','shape=outer_right')
idx=np.array([palette.index(mirror(s)) for s in palette]); assert np.array_equal(idx[idx],np.arange(len(palette)))
mismatch=(v!=idx[v[::-1,:,:]])
assert not mismatch.any()
assert (v[125] == idx[v[125]]).all()
# Every custom multi-box model also reflects about the centre of its block.
for name in ('capital_red_column','capital_marble_rail','capital_bracket','capital_finial','capital_red_lantern','capital_gold_lantern'):
    model=json.loads((R/'assets/wooltest/models/block'/f'{name}.json').read_text())
    occupancy=np.zeros((16,16,16),dtype=bool)
    for e in model['elements']:
        x,y,z=e['from'];xx,yy,zz=e['to'];occupancy[x:xx,y:yy,z:zz]=True
    assert np.array_equal(occupancy,occupancy[::-1]),name
# The corrected collision boxes must match the finial model boxes literally.
java=(P/'src/main/java/dev/sushi/wooltest/city/CityDecorBlock.java').read_text()
finial=json.loads((R/'assets/wooltest/models/block/capital_finial.json').read_text())
for e in finial['elements']:
    args=','.join(str(x) for x in e['from']+e['to'])
    assert 'box('+args+')' in java
# Existing-save update is opt-in and does not reuse the old revision cursor.
data=(P/'src/main/java/dev/sushi/wooltest/city/CityBuildData.java').read_text()
commands=(P/'src/main/java/dev/sushi/wooltest/city/CityCommands.java').read_text()
assert 'wooltest_capital_migration_v2' in data and 'wooltest_capital_migration_v1' not in data
assert 'if (data.completed)' in commands and 'literal("confirm")' in commands
assert 'capital_v2.wct.gz' in (P/'src/main/java/dev/sushi/wooltest/city/CityBlueprint.java').read_text()
oldzip=P.parents[1]/'WoolTest-city1/WoolTest-1.20.1-Forge-GitHub-Ready.zip'
unchanged=[]
old=v; old_mismatch=None; old_palace=None; changed=None
if oldzip.exists():
    with zipfile.ZipFile(oldzip) as z:
        import io
        old=np.load(io.BytesIO(z.read('art_source/city1/city_voxels.npy')))
        oldpal=json.loads(z.read('art_source/city1/palette.json'));assert oldpal==palette
        for n in z.namelist():
            # Gameplay outside city: ensure no ability/item/rule/terrain changes.
            if n.startswith('src/main/java/') and '/city/' not in n:
                assert z.read(n)==(P/n).read_bytes(),n;unchanged.append(n)
        for n in z.namelist():
            if n.startswith('src/main/resources/assets/wooltest/textures/'):
                assert z.read(n)==(P/n).read_bytes(),n
    old_mismatch=int(np.count_nonzero(old[:125]!=idx[old[:125:-1]]))
    old_palace=int(np.count_nonzero(old[96:125,28:64]!=idx[old[154:125:-1,28:64]]))
    changed=int(np.count_nonzero(old!=v))
summary={
 'revision':2,'grid':[251,251,68],'axis':'X=0 block column','total_checked_cells':int(v.size),
 'bounds':{'x':[-125,125],'z':[-125,125],'y':[60,127]},
 'mismatched_pairs_before':old_mismatch,
 'mismatched_pairs_after':int(np.count_nonzero(mismatch[:125])),
 'palace_bounds':{'x':[-29,29],'z':[-97,-62],'y':[60,127]},
 'palace_mismatched_pairs_before':old_palace,
 'palace_mismatched_pairs_after':int(np.count_nonzero(mismatch[96:125,28:64])),
 'changed_cells':changed,'non_air_blocks':int(np.count_nonzero(v)),
 'per_layer':[{'y':y+60,'non_air':int(np.count_nonzero(v[:,:,y])),
               'mismatched_pairs':int(np.count_nonzero(mismatch[:125,:,y]))} for y in range(68)],
 'model_geometry':'PASS: all six multi-box decoration models reflect locally along X',
 'old_save_migration':'PASS (source checks): V2 saved-data key, explicit confirm, no automatic start',
 'unchanged_non_city_java_files':unchanged,
 'blueprint_sha256':hashlib.sha256((R/'data/wooltest/city/capital_v2.wct.gz').read_bytes()).hexdigest(),
 'not_tested':['full Forge compilation','Minecraft client/server','world save/load','fluid/light/collision runtime']}
(P/'validation/city2-symmetry.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n')
print('PASS: all 4,284,068 blueprint cells reflect; all 68 layers have zero mismatched pairs.')
print(f"BASELINE (None means unavailable): original mismatched pairs {summary['mismatched_pairs_before']}; main-palace pairs {summary['palace_mismatched_pairs_before']}; corrected both to 0.")
print(f"PASS: {len(unchanged)} non-city Java files and all pre-existing textures are byte-for-byte unchanged.")
print('PASS: local model reflection, finial collision correspondence, source-level opt-in V2 migration checks.')
print('NOT VERIFIED: full Forge compilation or Minecraft runtime.')
