#!/usr/bin/env python3
"""Strict column-body clearance, checked against the serialized runtime blueprint.
Every shaft is covered exactly once by a support-column record. All eight horizontal
neighbours of each shaft must be AIR. Intended bases, capitals, beams, floors and
low balcony rails are handled by the separate support/contact checks, not falsely
classified as embedded wall. This is an offline geometry check, not a game test.
"""
from pathlib import Path
import gzip,struct,json,hashlib
import numpy as np
P=Path(__file__).resolve().parents[1];A=P/'art_source/city5';R=P/'src/main/resources'
source=R/'data/wooltest/city/capital_v5.wct.gz';raw=gzip.decompress(source.read_bytes())
magic,version,n,y0,h,count=struct.unpack('>6i',raw[:24])
assert (magic,version,n,y0,h)==(0x57435431,1,251,60,68)
o=24;pal=[]
for _ in range(count):
 length=struct.unpack('>H',raw[o:o+2])[0];o+=2;pal.append(raw[o:o+length].decode('ascii'));o+=length
v=np.frombuffer(raw[o:],dtype='>u2').reshape(n,n,h)
columns=json.loads((A/'columns.json').read_text());coverage=np.zeros_like(v,dtype=np.uint8)
shaft_id=pal.index('wooltest:capital_column_shaft');foot_id=pal.index('wooltest:capital_column_foot')
errors=[];tested_neighbours=0;rows=[]
for c in columns:
 x,z,low,high=c['x'],c['z'],c['base'],c['top'];bad=[]
 for y in range(low,high+1):
  if v[x+125,z+125,y-y0]!=shaft_id:continue
  coverage[x+125,z+125,y-y0]+=1
  for dx in (-1,0,1):
   for dz in (-1,0,1):
    if dx==dz==0:continue
    tested_neighbours+=1;state=pal[int(v[x+dx+125,z+dz+125,y-y0])]
    if state!='minecraft:air':bad.append({'at':[x,y,z],'neighbour':[x+dx,y,z+dz],'block':state})
 if bad:errors.extend(bad)
 rows.append({'x':x,'z':z,'base':low,'top':high,'owner':c['owner'],'clearance_ok':not bad})
shaft_cells=v==shaft_id
uncovered=np.argwhere(shaft_cells&(coverage!=1))
if len(uncovered):errors.append({'untracked_or_duplicate_shaft_cells':len(uncovered)})
# All placed bases must correspond to a declared column, including street lamps.
actual_bases={tuple(map(int,p)) for p in np.argwhere(v==foot_id)}
recorded_bases={(c['x']+125,c['z']+125,c['base']-y0) for c in columns}
assert actual_bases==recorded_bases,('untracked bases',actual_bases^recorded_bases)
result={'source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),
 'columns_checked':len(columns),'shaft_cells_checked':int(shaft_cells.sum()),
 'horizontal_neighbour_cells_checked':tested_neighbours,
 'clearance_rule':'Each shaft has an 8-neighbour horizontal ring of air; wall/lattice cannot touch or enclose it. Bases/caps deliberately join floors/beams.',
 'untracked_or_duplicate_shaft_cells':len(uncovered),'clearance_violations':errors,'columns':rows}
(P/'validation/city5_column_clearance.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k!='columns'},ensure_ascii=False,indent=2))
assert not errors
