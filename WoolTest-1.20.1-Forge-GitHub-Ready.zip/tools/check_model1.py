#!/usr/bin/env python3
"""Offline Model 1 consistency checks, NOT a Forge compilation/runtime test."""
from pathlib import Path
from PIL import Image
import json, hashlib, re
ROOT=Path(__file__).resolve().parent.parent
spec=json.loads((ROOT/'art_source/model1/test_one_model1.json').read_text())
nodes=spec['nodes']
known={'root'}; positions={'root':(0.0,0.0,0.0)}
count=0; rectangles=[];lo_y=float('inf');hi_y=-float('inf')
with Image.open(ROOT/'src/main/resources/assets/wooltest/textures/entity/test_one_model1.png') as im:
    im.load()
    assert im.size==(256,256) and im.mode=='RGBA'
    used=set()
    for n in nodes:
        assert n['name'] not in known and n['parent'] in known
        known.add(n['name'])
        positions[n['name']]=tuple(a+b for a,b in zip(positions[n['parent']],n['offset']))
        for c in n['cubes']:
            count+=1
            assert all(isinstance(x,int) and x>0 for x in c['size'])
            y=positions[n['name']][1]+c['origin'][1]
            lo_y=min(lo_y,y);hi_y=max(hi_y,y+c['size'][1])
            assert len(c['faces'])==6
            for face,(x,y,w,h) in c['faces'].items():
                assert 0<=x<x+w<=128 and 0<=y<y+h<=128
                for py in range(y*2,(y+h)*2):
                    for px in range(x*2,(x+w)*2):
                        assert (px,py) not in used, (c['name'],face,'UV overlap')
                        assert im.getpixel((px,py))[3]==255,(c['name'],face,'transparent surface')
                        used.add((px,py))
    assert count==26 and len(nodes)==15
    assert hi_y==24 and lo_y==-7,(lo_y,hi_y)
    for py in range(256):
        for px in range(256):
            if (px,py) not in used:assert im.getpixel((px,py))[3]==0
print('PASS: 15-node hierarchy; 26 cuboids / 156 faces; 256x256 RGBA atlas, opaque mapped surfaces, no UV overlap.')
print('PASS: Neutral model spans Y=-7..24 (31/16 blocks); soles at the standard ground plane.')
java=(ROOT/'src/main/java/dev/sushi/wooltest/client/TestOneModel.java').read_text()
assert len(re.findall(r'\.addBox\(',java))==count
assert 'LayerDefinition.create(mesh, 128, 128)' in java
assert 'root.getAllParts().forEach(ModelPart::resetPose)' in java
for n in nodes:
    assert f'PartDefinition {n["name"]} = {n["parent"]}.addOrReplaceChild("{n["name"]}"' in java
for child in re.findall(r'getChild\("([a-z0-9_]+)"\)',java):assert child in known,child
renderer=(ROOT/'src/main/java/dev/sushi/wooltest/client/TestOneRenderer.java').read_text()
events=(ROOT/'src/main/java/dev/sushi/wooltest/client/ClientEvents.java').read_text()
assert 'context.bakeLayer(TestOneModel.LAYER_LOCATION)' in renderer
assert 'textures/entity/test_one_model1.png' in renderer
assert 'ModelLayers.ZOMBIE' not in renderer
assert 'event.registerLayerDefinition(TestOneModel.LAYER_LOCATION, TestOneModel::createBodyLayer)' in events
assert 'value = Dist.CLIENT' in events
assert not (ROOT/'src/main/resources/assets/minecraft').exists()
print('PASS: Dedicated model, texture and layer registration references; client-only subscriber; no vanilla resource override.')
for entry in json.loads((ROOT/'validation/model1-unchanged-files.json').read_text()):
    # Pillar 1 intentionally changes only this recorded appearance resource.
    if entry['path'] == 'src/main/resources/assets/wooltest/models/block/temporary_pillar.json':
        continue
    assert hashlib.sha256((ROOT/entry['path']).read_bytes()).hexdigest()==entry['sha256'],entry['path']
print('PASS: Recorded Model 1 gameplay/world/build/old-texture baseline matches, except the explicitly updated pillar model JSON.')
print('NOTE: Forge API linkage, launch, real rendering, animation and multiplayer remain untested here.')
