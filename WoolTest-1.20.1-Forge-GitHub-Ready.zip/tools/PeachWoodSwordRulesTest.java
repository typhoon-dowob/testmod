import dev.sushi.wooltest.logic.PeachWoodSwordRules;
import java.util.HashSet;
import java.util.Random;
import java.util.Set;

/** Tests the actual production arithmetic/RNG rules, not a separate reimplementation. */
public final class PeachWoodSwordRulesTest {
    private static int assertions;
    private static void check(boolean ok, String message) {
        assertions++;
        if (!ok) throw new AssertionError(message);
    }
    private static void close(double a, double b, String message) {
        check(Math.abs(a - b) < 1.0E-12D, message + ": " + a + " != " + b);
    }
    private static void rejects(Runnable action) {
        boolean rejected = false;
        try { action.run(); } catch (IllegalArgumentException expected) { rejected = true; }
        check(rejected, "invalid RNG value was accepted");
    }
    public static void main(String[] args) {
        int success = 0;
        for (int i = 0; i < 10; i++) {
            final int value = i;
            if (PeachWoodSwordRules.shouldDrop(bound -> {
                check(bound == 10, "drop RNG bound must be 10"); return value;
            })) success++;
        }
        check(success == 9, "drop chance must have exactly 9 of 10 successful outcomes");
        Set<Integer> all = new HashSet<>();
        for (int i = 0; i < 201; i++) {
            final int value = i;
            int roll = PeachWoodSwordRules.rollDamageHundredths(bound -> {
                check(bound == 201, "both endpoints require 201 outcomes"); return value;
            });
            check(roll == 500 + i, "unexpected hundredth value");
            check(all.add(roll), "two RNG outcomes mapped to the same damage");
            String display = PeachWoodSwordRules.formatDamage(roll);
            check(display.matches("[5-7]\\.\\d{2}"), "not exactly two decimal places");
            close(Double.parseDouble(display), roll / 100.0D, "tooltip value mismatch");
            close(1.0D + PeachWoodSwordRules.attackDamageModifier(roll), roll / 100.0D,
                    "player base damage was added twice or omitted");
        }
        check(all.size() == 201 && all.contains(500) && all.contains(700), "missing endpoint");
        close(4.0D + PeachWoodSwordRules.attackSpeedModifier(), 1.6D, "wrong total speed");
        check(PeachWoodSwordRules.formatDamage(500).equals("5.00"), "min display");
        check(PeachWoodSwordRules.formatDamage(501).equals("5.01"), "one hundredth display");
        check(PeachWoodSwordRules.formatDamage(637).equals("6.37"), "fraction display");
        check(PeachWoodSwordRules.formatDamage(700).equals("7.00"), "max display");
        check(PeachWoodSwordRules.clampDamageHundredths(Integer.MIN_VALUE) == 500, "low clamp");
        check(PeachWoodSwordRules.clampDamageHundredths(Integer.MAX_VALUE) == 700, "high clamp");
        rejects(() -> PeachWoodSwordRules.shouldDrop(bound -> -1));
        rejects(() -> PeachWoodSwordRules.shouldDrop(bound -> 10));
        rejects(() -> PeachWoodSwordRules.rollDamageHundredths(bound -> -1));
        rejects(() -> PeachWoodSwordRules.rollDamageHundredths(bound -> 201));
        Random rng = new Random(0x53574F524431L);
        int trials = 1_000_000;
        int drops = 0;
        Set<Integer> observed = new HashSet<>();
        for (int i = 0; i < trials; i++) {
            if (PeachWoodSwordRules.shouldDrop(rng::nextInt)) {
                drops++;
                int value = PeachWoodSwordRules.rollDamageHundredths(rng::nextInt);
                check(value >= 500 && value <= 700, "roll outside allowed interval");
                observed.add(value);
            }
        }
        check(observed.size() == 201, "seeded sampling did not cover all possible values");
        System.out.println("PASS: " + assertions + " pure-Java sword assertions.");
        System.out.println("Exhaustive: 9/10 drop outcomes; 201/201 distinct attack values, including 5.00 and 7.00.");
        System.out.println("Seeded simulation: " + drops + "/" + trials + " deaths produced a sword. Simulation is not an in-game drop test.");
    }
}
