#!/usr/bin/env python3
"""Reproducible City 2 symmetric assets and fixed-origin voxel blueprint. Pillow + NumPy.
The blueprint is the implemented design, not a conversion of the concept illustration.
"""
from pathlib import Path
from PIL import Image, ImageDraw
import numpy as np
import json, math, gzip, struct, random, hashlib
from collections import Counter

ROOT=Path(__file__).resolve().parents[1]
RES=ROOT/'src/main/resources'
AS=RES/'assets/wooltest'
DATA=RES/'data/wooltest'
ART=ROOT/'art_source/city2'; ART.mkdir(parents=True, exist_ok=True)
N=251; LO=-125; Y0=60; H=68
# All pixels below are authored algorithmically here, not copied from Minecraft.
MATERIALS=[
 ('capital_gray_brick','帝都青磚','Capital Gray Brick',(104,112,119),'brick','stone'),
 ('capital_dark_brick','帝都玄磚','Capital Dark Brick',(58,63,69),'brick','stone'),
 ('capital_red_wall','宮城朱牆','Vermilion Palace Wall',(153,47,38),'plaster','stone'),
 ('capital_white_wall','白灰粉牆','White Plaster Wall',(222,211,185),'plaster','stone'),
 ('capital_marble','漢白玉','White Marble',(224,224,211),'marble','stone'),
 ('capital_carved_marble','雲紋漢白玉','Cloud Carved Marble',(210,212,201),'cloud','stone'),
 ('capital_paving','青石路磚','Bluestone Paving',(113,128,134),'paving','stone'),
 ('capital_floor','宮殿金磚','Palace Floor Tiles',(119,103,80),'paving','stone'),
 ('capital_timber','深色榫卯木','Dark Joinery Timber',(78,48,31),'wood','wood'),
 ('capital_red_timber','朱漆木','Red Lacquer Timber',(161,42,27),'wood','wood'),
 ('capital_gilded_beam','描金彩梁','Gilded Painted Beam',(140,39,29),'beam','wood'),
 ('capital_jade_beam','青綠彩梁','Jade Painted Beam',(38,111,108),'beam','wood'),
 ('capital_gold_tiles','金黃琉璃瓦','Golden Glazed Tiles',(216,154,38),'tile','stone'),
 ('capital_dark_tiles','青灰瓦','Blue Gray Roof Tiles',(63,77,88),'tile','stone'),
 ('capital_jade_tiles','碧色琉璃瓦','Jade Glazed Tiles',(40,128,113),'tile','stone'),
 ('capital_gold_ridge','鎏金屋脊','Gilded Roof Ridge',(235,180,52),'ridge','stone'),
 ('capital_red_lattice','朱漆格窗','Red Lattice Window',(128,40,29),'lattice','wood'),
 ('capital_dark_lattice','烏木格窗','Dark Lattice Window',(71,48,31),'lattice','wood'),
 ('capital_red_lantern','宮城紅燈籠','Capital Red Lantern',(196,51,24),'lantern','lantern'),
 ('capital_gold_lantern','宮城金燈籠','Capital Gold Lantern',(224,158,42),'lantern','lantern'),
 ('capital_banner','朱金旗飾','Vermilion Gold Banner',(156,25,29),'banner','stone'),
 ('capital_red_awning','紅色市集篷布','Red Market Awning',(177,58,42),'cloth','cloth'),
 ('capital_jade_awning','青色市集篷布','Jade Market Awning',(45,128,120),'cloth','cloth'),
 ('capital_grass','園林青苔','Garden Moss',(88,117,62),'moss','stone'),
 ('capital_peach_log','庭園桃木','Garden Peach Trunk',(108,62,41),'wood','wood'),
 ('capital_peach_leaves','庭園桃花','Garden Peach Blossoms',(220,135,155),'leaves','leaves'),
 ('capital_willow_leaves','庭園柳葉','Garden Willow Foliage',(91,133,60),'leaves','leaves'),
 ('capital_bronze','古銅飾塊','Aged Bronze Ornament',(132,106,48),'bronze','stone'),
 ('capital_lotus','蓮紋磚','Lotus Inlay',(200,166,154),'lotus','stone'),
 ('capital_dragon_panel','金龍壁飾','Golden Dragon Panel',(153,45,29),'dragon','stone'),
]
VARIANTS=[]
for n,zh,en,col,pat,kind in MATERIALS:
 if n in ('capital_gold_tiles','capital_dark_tiles','capital_jade_tiles','capital_marble','capital_paving'):
  VARIANTS.extend([(n+'_stairs',zh+'階梯',en+' Stairs',n,'stairs'),(n+'_slab',zh+'半磚',en+' Slab',n,'slab')])
# Solid worldgen-friendly decorations; no block entities or random ticks.
DECOR=[('capital_red_column','朱漆圓柱','Vermilion Pillar','capital_red_timber','column'),
       ('capital_marble_rail','白玉欄杆','Marble Balustrade','capital_marble','rail'),
       ('capital_bracket','彩繪斗栱','Painted Bracket','capital_jade_beam','bracket'),
       ('capital_finial','鎏金脊獸','Gilded Ridge Finial','capital_gold_ridge','finial')]

def js(path,obj):
 path.parent.mkdir(parents=True,exist_ok=True); path.write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
def texture(name,col,pat):
 rng=random.Random(int(hashlib.sha256(name.encode()).hexdigest()[:8],16)); s=32
 im=Image.new('RGB',(s,s)); p=im.load()
 for y in range(s):
  for x in range(s):
   d=rng.randint(-7,7); p[x,y]=tuple(max(0,min(255,c+d)) for c in col)
 d=ImageDraw.Draw(im)
 dark=tuple(max(0,int(c*.64)) for c in col); light=tuple(min(255,int(c*1.15+10)) for c in col)
 if pat=='brick':
  for y in range(0,32,8):
   d.line((0,y,31,y),fill=dark); d.line((0,y+1,31,y+1),fill=light)
   for x in range((-8 if (y//8)%2 else 0),32,16): d.line((x,y,x,y+7),fill=dark)
 elif pat in ('paving','marble'):
  d.rectangle((0,0,31,31),outline=dark); d.line((1,1,30,1),fill=light)
  if pat=='paving': d.line((16,0,16,31),fill=dark); d.line((0,16,31,16),fill=dark)
  else:
   for q in (6,18,25): d.line([(q,0),(q+2,8),(q-1,18),(q+3,31)], fill=tuple(int(c*.94) for c in col))
 elif pat=='wood':
  for x in (2,8,14,23,29): d.line([(x,0),(x+1,8),(x,17),(x+1,31)],fill=dark)
  d.ellipse((9,11,15,23),outline=light)
 elif pat=='tile':
  for x in range(0,32,8):
   d.line((x,0,x,31),fill=dark,width=2); d.line((x+3,0,x+3,31),fill=light)
  for y in (7,15,23,31): d.line((0,y,31,y),fill=dark)
 elif pat in ('beam','ridge'):
  d.rectangle((0,2,31,29),outline=(229,178,66),width=2)
  for x in range(0,32,8): d.line((x,8,x+4,16,x,24),fill=(236,189,85),width=2)
 elif pat=='lattice':
  d.rectangle((1,1,30,30),fill=(218,197,151)); d.rectangle((0,0,31,31),outline=dark,width=3)
  for x in range(2,32,7): d.line((x,2,x,29),fill=col,width=2)
  for y in range(2,32,7): d.line((2,y,29,y),fill=col,width=2)
 elif pat=='lantern':
  d.rectangle((0,0,31,3),fill=(124,87,25));d.rectangle((0,28,31,31),fill=(124,87,25))
  for x in range(3,32,6):d.line((x,4,x,27),fill=light)
  d.rectangle((10,10,21,21),outline=(247,204,79),width=2)
 elif pat in ('cloud','lotus','dragon'):
  d.rectangle((1,1,30,30),outline=dark,width=2)
  ink=(234,185,64) if pat=='dragon' else dark
  if pat=='lotus':
   for x,y in ((8,14),(16,8),(24,14),(16,21)):
    d.polygon([(16,16),(x-4,y),(x,y-5),(x+4,y)],fill=(238,175,182),outline=ink)
  else:
   d.arc((4,7,19,22),0,300,fill=ink,width=2);d.arc((12,11,27,26),160,450,fill=ink,width=2)
   d.line((5,22,25,6),fill=ink,width=2)
 elif pat=='banner':
  d.rectangle((1,0,30,31),outline=(225,176,56),width=2);d.polygon([(16,5),(24,15),(16,25),(8,15)],outline=(242,204,99))
 elif pat=='cloth':
  for y in range(0,32,4):d.line((0,y,31,y),fill=light)
  for x in range(0,32,8):d.line((x,0,x,31),fill=dark)
 elif pat=='leaves':
  for _ in range(45):
   x,y=rng.randrange(32),rng.randrange(32);d.rectangle((x,y,x+2,y+2),fill=rng.choice([light,dark,col]))
 elif pat=='bronze':
  d.rectangle((2,2,29,29),outline=dark,width=3);d.ellipse((8,8,23,23),outline=(67,107,82),width=2)
 out=AS/'textures/block'/f'{name}.png';out.parent.mkdir(parents=True,exist_ok=True);im.save(out)
 return im

def element(a,b,tex='#all',cull=False):
 return {'from':a,'to':b,'faces':{f:({'texture':tex,'cullface':f} if cull else {'texture':tex}) for f in ('north','south','east','west','up','down')}}

for n,zh,en,col,pat,kind in MATERIALS:
 texture(n,col,pat)
 if kind=='lantern':
  model={'parent':'minecraft:block/block','textures':{'all':f'wooltest:block/{n}','particle':f'wooltest:block/{n}'},'elements':[
   element([3,3,3],[13,13,13]),element([4,1,4],[12,3,12]),element([4,13,4],[12,15,12]),element([7,0,7],[9,1,9])]}
 else:model={'parent':'minecraft:block/cube_all','textures':{'all':f'wooltest:block/{n}'}}
 js(AS/'models/block'/f'{n}.json',model);js(AS/'blockstates'/f'{n}.json',{'variants':{'':{'model':f'wooltest:block/{n}'}}})
 js(AS/'models/item'/f'{n}.json',{'parent':f'wooltest:block/{n}'})
for n,zh,en,base,kind in VARIANTS:
 if kind=='slab':
  for suf,parent in [('', 'slab'),('_top','slab_top')]:
   js(AS/'models/block'/f'{n}{suf}.json',{'parent':'minecraft:block/'+parent,'textures':{f:f'wooltest:block/{base}' for f in ('top','bottom','side')}})
  variants={f'type={t}':{'model':f'wooltest:block/{m}'} for t,m in [('bottom',n),('top',n+'_top'),('double',base)]}
 else:
  for suf,parent in [('', 'stairs'),('_inner','inner_stairs'),('_outer','outer_stairs')]:
   js(AS/'models/block'/f'{n}{suf}.json',{'parent':'minecraft:block/'+parent,'textures':{f:f'wooltest:block/{base}' for f in ('top','bottom','side')}})
  variants={}
  for facing,rot in [('east',0),('south',90),('west',180),('north',270)]:
   for half in ('bottom','top'):
    for shape in ('straight','inner_left','inner_right','outer_left','outer_right'):
     suf='' if shape=='straight' else ('_inner' if shape.startswith('inner') else '_outer')
     y=rot
     if shape.endswith('left'): y-=90
     if half=='top' and shape!='straight':y+=90
     v={'model':f'wooltest:block/{n}{suf}','uvlock':True}
     if y%360:v['y']=y%360
     if half=='top':v['x']=180
     variants[f'facing={facing},half={half},shape={shape}']=v
 js(AS/'blockstates'/f'{n}.json',{'variants':variants});js(AS/'models/item'/f'{n}.json',{'parent':f'wooltest:block/{n}'})
SHAPES={
 'column': [([4,0,4],[12,16,12]),([2,0,2],[14,2,14]),([2,14,2],[14,16,14])],
 'rail': [([6,0,6],[10,16,10]),([0,10,6],[16,13,10]),([6,10,0],[10,13,16]),([0,3,6],[16,5,10]),([6,3,0],[10,5,16])],
 'bracket': [([5,0,5],[11,6,11]),([2,6,3],[14,10,13]),([0,10,5],[16,13,11]),([4,13,0],[12,16,16])],
 'finial': [([3,0,3],[13,3,13]),([5,3,5],[11,10,11]),([5,10,7],[11,15,13]),([7,6,2],[9,13,6])]}
for n,zh,en,base,kind in DECOR:
 js(AS/'models/block'/f'{n}.json',{'parent':'minecraft:block/block','textures':{'all':f'wooltest:block/{base}','particle':f'wooltest:block/{base}'},'elements':[element(a,b) for a,b in SHAPES[kind]]})
 js(AS/'blockstates'/f'{n}.json',{'variants':{'':{'model':f'wooltest:block/{n}'}}});js(AS/'models/item'/f'{n}.json',{'parent':f'wooltest:block/{n}'})
allblocks=[a[0] for a in MATERIALS+VARIANTS+DECOR]
for n in allblocks:
 js(DATA/'loot_tables/blocks'/f'{n}.json',{'type':'minecraft:block','pools':[{'rolls':1,'entries':[{'type':'minecraft:item','name':f'wooltest:{n}'}],'conditions':[{'condition':'minecraft:survives_explosion'}]}]})
js(RES/'data/minecraft/tags/blocks/mineable/pickaxe.json',{'replace':False,'values':['wooltest:'+n for n in allblocks if n not in {a[0] for a in MATERIALS if a[-1] in ('wood','leaves','cloth')}]})
js(RES/'data/minecraft/tags/blocks/mineable/axe.json',{'replace':False,'values':['wooltest:'+a[0] for a in MATERIALS if a[-1]=='wood']+['wooltest:capital_red_column','wooltest:capital_bracket']})
for lang,ix in [('zh_tw',1),('en_us',2)]:
 p=AS/'lang'/f'{lang}.json'; obj=json.loads(p.read_text('utf-8'))
 for a in MATERIALS+VARIANTS+DECOR:obj['block.wooltest.'+a[0]]=a[ix]
 obj['itemGroup.wooltest.capital']='帝都建材' if lang=='zh_tw' else 'Capital Building Materials'
 js(p,obj)
# Java registry file is emitted alongside the authoritative material list.
j=['package dev.sushi.wooltest.city;','',
'import dev.sushi.wooltest.WoolTestMod;', 'import net.minecraft.world.item.BlockItem;', 'import net.minecraft.world.item.Item;',
'import net.minecraft.world.level.block.*;', 'import net.minecraft.world.level.block.state.BlockBehaviour;',
'import net.minecraft.world.level.material.MapColor;', 'import net.minecraftforge.eventbus.api.IEventBus;',
'import net.minecraftforge.registries.DeferredRegister;', 'import net.minecraftforge.registries.ForgeRegistries;',
'import net.minecraftforge.registries.RegistryObject;', 'import java.util.*;', '',
'/** Independent registered blocks/items; no replacement of vanilla assets. */',
'public final class CityBlocks {', '    private CityBlocks() { }',
'    private static final DeferredRegister<Block> BLOCKS = DeferredRegister.create(ForgeRegistries.BLOCKS, WoolTestMod.MOD_ID);',
'    private static final DeferredRegister<Item> ITEMS = DeferredRegister.create(ForgeRegistries.ITEMS, WoolTestMod.MOD_ID);',
'    private static final Map<String, RegistryObject<Block>> MATERIALS = new LinkedHashMap<>();',
'    public static final List<RegistryObject<Item>> ALL_ITEMS = new ArrayList<>();',
'    private static void add(String id, java.util.function.Supplier<Block> block) {',
'        RegistryObject<Block> entry = BLOCKS.register(id, block); MATERIALS.put(id, entry);',
'        ALL_ITEMS.add(ITEMS.register(id, () -> new BlockItem(entry.get(), new Item.Properties())));',
'    }',
'    private static BlockBehaviour.Properties props(String kind) {',
'        BlockBehaviour.Properties p = BlockBehaviour.Properties.of().mapColor(MapColor.STONE).strength(2.0F, 6.0F);',
'        if (kind.equals("wood")) return p.sound(SoundType.WOOD);',
'        if (kind.equals("cloth")) return p.sound(SoundType.WOOL);',
'        if (kind.equals("leaves")) return p.sound(SoundType.GRASS).strength(0.2F).noOcclusion();',
'        if (kind.equals("lantern")) return p.sound(SoundType.LANTERN).lightLevel(s -> 14).noOcclusion();',
'        return p.sound(SoundType.STONE);', '    }', '    static {']
for n,zh,en,col,pat,kind in MATERIALS:
 ctor=f'new CityDecorBlock("lantern", props("{kind}"))' if kind=='lantern' else f'new Block(props("{kind}"))'
 j.append(f'        add("{n}", () -> {ctor});')
for n,zh,en,base,kind in VARIANTS:
 ctor=f'new StairBlock(() -> MATERIALS.get("{base}").get().defaultBlockState(), props("stone"))' if kind=='stairs' else 'new SlabBlock(props("stone"))'
 j.append(f'        add("{n}", () -> {ctor});')
for n,zh,en,base,kind in DECOR:j.append(f'        add("{n}", () -> new CityDecorBlock("{kind}", props("stone").noOcclusion()));')
j+=['    }','    public static void register(IEventBus bus) { BLOCKS.register(bus); ITEMS.register(bus); }','}']
(ROOT/'src/main/java/dev/sushi/wooltest/city/CityBlocks.java').write_text('\n'.join(j)+'\n',encoding='utf-8')
js(ART/'materials.json',{'base':MATERIALS,'variants':VARIANTS,'decorations':DECOR,'shapes':SHAPES})
# Dense block palette; Y-fastest layout enables cheap worldgen column reads.
palette=['minecraft:air']; ids={palette[0]:0}
vox=np.zeros((N,N,H),dtype=np.uint16)
def pid(name):
 if ':' not in name:name='wooltest:'+name
 if name not in ids:ids[name]=len(palette);palette.append(name)
 return ids[name]
def put(x,y,z,b):
 if not(LO<=x<=125 and LO<=z<=125 and Y0<=y<128):raise ValueError(('out of bounds',x,y,z,b))
 vox[x-LO,z-LO,y-Y0]=pid(b)
def box(x1,y1,z1,x2,y2,z2,b):
 if x1>x2 or y1>y2 or z1>z2:return
 if not(LO<=x1<=x2<=125 and LO<=z1<=z2<=125 and Y0<=y1<=y2<128):raise ValueError(('box bounds',x1,y1,z1,x2,y2,z2))
 vox[x1-LO:x2-LO+1,z1-LO:z2-LO+1,y1-Y0:y2-Y0+1]=pid(b)
def clear(x1,y1,z1,x2,y2,z2):box(x1,y1,z1,x2,y2,z2,'minecraft:air')
def rail(x1,y,z1,x2,z2):
 for x in range(x1,x2+1):put(x,y,z1,'capital_marble_rail');put(x,y,z2,'capital_marble_rail')
 for z in range(z1,z2+1):put(x1,y,z,'capital_marble_rail');put(x2,y,z,'capital_marble_rail')
def stair(x1,x2,z_start,z_end,y_start,step=1):
 # Travel toward negative Z, 1 block rise per two horizontal blocks.
 for d,z in enumerate(range(z_start,z_end-1,-1)):
  y=y_start+d//2
  box(x1,63,z,x2,y-1,z,'capital_marble')
  box(x1,y,z,x2,y,z,'capital_marble_stairs[facing=north,half=bottom,shape=straight,waterlogged=false]' if d%2==0 else 'capital_marble')
  clear(x1,y+1,z,x2,y+3,z)

def roof(cx,cz,rx,rz,y,mat='capital_dark_tiles'):
 for dx in range(-rx,rx+1):
  for dz in range(-rz,rz+1):
   k=min(rx-abs(dx),rz-abs(dz)); yy=y+k//2
   facing=('west' if dx>0 else 'east') if rx-abs(dx)<rz-abs(dz) else ('north' if dz>0 else 'south')
   b=mat+'_stairs[facing='+facing+',half=bottom,shape=straight,waterlogged=false]' if k%2==0 else mat
   put(cx+dx,yy,cz+dz,b)
   if k==0 and abs(dx)>=rx-2 and abs(dz)>=rz-2: put(cx+dx,yy+1,cz+dz,mat+'_slab[type=bottom,waterlogged=false]')
 # Ridge follows the longer axis, including north-south palace wings.
 ridge_y=y+min(rx,rz)//2+1
 ridge='capital_gold_ridge' if mat!='capital_dark_tiles' else 'capital_dark_tiles'
 if rx>=rz:
  for x in range(cx-(rx-rz),cx+(rx-rz)+1):put(x,ridge_y,cz,ridge)
  for x in (cx-(rx-rz)-1,cx+(rx-rz)+1):put(x,ridge_y+1,cz,'capital_finial')
 else:
  for z in range(cz-(rz-rx),cz+(rz-rx)+1):put(cx,ridge_y,z,ridge)
  for z in (cz-(rz-rx)-1,cz+(rz-rx)+1):put(cx,ridge_y+1,z,'capital_finial')

buildings=[]
def hall(cx,cz,w,d,floor=64,height=6,mat='capital_dark_tiles',palace=False,name='院落屋舍',double=False,open_hall=False):
 rx=w//2;rz=d//2
 x1,x2=cx-rx,cx+rx;z1,z2=cz-rz,cz+rz
 box(x1,floor-1,z1,x2,floor-1,z2,'capital_floor' if palace else 'capital_timber')
 clear(x1,floor,z1,x2,floor+height+2,z2)
 wall='capital_red_wall' if palace else 'capital_white_wall'
 if not open_hall:
  box(x1,floor,z1,x2,floor+height-1,z1,wall);box(x1,floor,z2,x2,floor+height-1,z2,wall)
  box(x1,floor,z1,x1,floor+height-1,z2,wall);box(x2,floor,z1,x2,floor+height-1,z2,wall)
  clear(cx-1,floor,z2,cx+1,floor+3,z2)
  lattice='capital_red_lattice' if palace else 'capital_dark_lattice'
  for x in range(x1+3,x2-1,5):
   if abs(x-cx)>2:box(x,floor+2,z2,x+1,floor+3,z2,lattice)
   box(x,floor+2,z1,x+1,floor+3,z1,lattice)
  for z in range(z1+2,z2-1,5):
   box(x1,floor+2,z,x1,floor+3,z+1,lattice);box(x2,floor+2,z,x2,floor+3,z+1,lattice)
 # Axis buildings use paired pillars; do not leave an off-centre column in a doorway.
 column_x = list(range(x1, x2+1, max(4,(w-1)//4)))
 if cx == 0:
  offsets = {rx, max(3, rx//2)}
  if rx >= 20: offsets.add(4)
  column_x = sorted({cx + side*offset for offset in offsets for side in (-1, 1)})
 for x in column_x:
  for z in (z1,z2):
   box(x,floor,z,x,floor+height,z,'capital_red_column' if palace else 'capital_timber')
   put(x,floor+height+1,z,'capital_bracket')
 for z in range(z1,z2+1,5):
  for x in (x1,x2):box(x,floor,z,x,floor+height,z,'capital_red_column' if palace else 'capital_timber')
 box(x1-1,floor+height,z1-1,x2+1,floor+height,z2+1,'capital_gilded_beam' if palace else 'capital_jade_beam')
 # Keep interior overhead clearance, beam ceiling remains above human height.
 roof(cx,cz,rx+2,rz+2,floor+height+2,mat)
 for x in (cx-rx+2,cx+rx-2):put(x,floor+height-1,z2+1,'capital_red_lantern')
 if double:
  rw=max(5,rx-4);rd=max(4,rz-3);ry=floor+height+7
  box(cx-rw,ry-3,cz-rd,cx+rw,ry-1,cz+rd,'capital_red_wall')
  roof(cx,cz,rw+2,rd+2,ry,mat)
 buildings.append({'name':name,'center':[cx,floor,cz],'size':[w,d],'roof':mat})

def pavilion(cx,cz,r=4,floor=64,mat='capital_jade_tiles',name='水榭'):
 box(cx-r,floor-1,cz-r,cx+r,floor-1,cz+r,'capital_marble')
 for x in (cx-r+1,cx+r-1):
  for z in (cz-r+1,cz+r-1):box(x,floor,z,x,floor+4,z,'capital_red_column');put(x,floor+5,z,'capital_bracket')
 roof(cx,cz,r+1,r+1,floor+6,mat);buildings.append({'name':name,'center':[cx,floor,cz],'size':[2*r+1,2*r+1],'roof':mat})

def tree(cx,cz,floor=64,willow=False):
 leaves='capital_willow_leaves' if willow else 'capital_peach_leaves'
 box(cx,floor,cz,cx,floor+4,cz,'capital_peach_log')
 for dy,r in ((3,2),(4,3),(5,3),(6,2)):
  for dx in range(-r,r+1):
   for dz in range(-r,r+1):
    if abs(dx)+abs(dz)<=r+1:put(cx+dx,floor+dy,cz+dz,leaves)
 if willow:
  for dx,dz in [(3,0),(-3,0),(0,3),(0,-3)]:box(cx+dx,floor+1,cz+dz,cx+dx,floor+3,cz+dz,leaves)

def lamp(x,z,y=64):
 box(x,y,z,x,y+2,z,'capital_timber');put(x,y+3,z,'capital_gilded_beam')
 put(x,y+4,z,'capital_red_lantern')

def compound(cx,cz,w=33,d=29,name='民居坊'):
 rx=w//2;rz=d//2
 box(cx-rx,63,cz-rz,cx+rx,63,cz+rz,'capital_paving')
 for z in (cz-rz,cz+rz):box(cx-rx,64,z,cx+rx,66,z,'capital_white_wall')
 for x in (cx-rx,cx+rx):box(x,64,cz-rz,x,66,cz+rz,'capital_white_wall')
 clear(cx-2,64,cz+rz,cx+2,67,cz+rz)
 hall(cx,cz-rz+6,w-8,9,name=name+'正屋')
 # Smaller wings leave a traversable open central yard.
 hall(cx-rx+5,cz+3,7,11,height=5,name=name+'西廂')
 hall(cx+rx-5,cz+3,7,11,height=5,name=name+'東廂')
 box(cx-2,63,cz-2,cx+2,63,cz+2,'capital_lotus')
 tree(cx+3,cz+6);lamp(cx-4,cz+9)

# Foundation and entire footprint, with moat included inside 251 x 251.
box(-125,60,-125,125,62,125,'capital_gray_brick')
box(-125,63,-125,125,63,125,'capital_grass')
box(-107,63,-107,107,63,107,'capital_paving')
# Continuous shallow moat; retaining bed/banks use custom stone.
for z in range(-125,126):
 for x in range(-125,126):
  edge=max(abs(x),abs(z))
  if 119<=edge<=123:
   put(x,61,z,'capital_dark_brick');put(x,62,z,'minecraft:water');put(x,63,z,'minecraft:water')
  if edge in (118,124,125):put(x,63,z,'capital_carved_marble' if edge==118 else 'capital_gray_brick')
# Four walls and their crenellations.
for side in (-1,1):
 z=side*112
 box(-114,64,z-2,114,75,z+2,'capital_red_wall');box(-114,64,z-2,114,67,z+2,'capital_gray_brick')
 box(-114,76,z-2,114,76,z+2,'capital_paving')
 for x in range(-112,113):
  for zz in (z-2,z+2):put(x,77,zz,'capital_marble_rail')
  if x%4<2:put(x,78,z+side*2,'capital_marble')
 x=side*112
 box(x-2,64,-114,x+2,75,114,'capital_red_wall');box(x-2,64,-114,x+2,67,114,'capital_gray_brick')
 box(x-2,76,-114,x+2,76,114,'capital_paving')
 for z in range(-112,113):
  for xx in (x-2,x+2):put(xx,77,z,'capital_marble_rail')
  if z%4<2:put(x+side*2,78,z,'capital_marble')
# Four corners, accessible lower supports and roofed watchtowers.
for x in (-111,111):
 for z in (-111,111):
  box(x-5,64,z-5,x+5,76,z+5,'capital_gray_brick')
  hall(x,z,9,9,floor=77,height=5,palace=True,mat='capital_gold_tiles',double=True,name='角樓')
# Gate houses, front/back and side. Door arches remain open.
for z in (-112,112):
 clear(-6,64,z-3,6,73,z+3)
 box(-14,74,z-4,14,76,z+4,'capital_gray_brick')
 hall(0,z,25,9,floor=77,height=6,palace=True,mat='capital_gold_tiles',double=True,name='南城門' if z>0 else '北城門')
 box(-3,74,z+(3 if z>0 else -3),3,75,z+(3 if z>0 else -3),'capital_dragon_panel')
 for zz in range(z-12,z+14):
  if -125<=zz<=125:box(-6,63,zz,6,63,zz,'capital_marble')
 # Side stairs on city interior side reach the parapet.
 for i in range(13):
  zz=(97+i if z>0 else -97-i)
  box(18,64,zz,21,64+i,zz,'capital_gray_brick')
  box(18,64+i,zz,21,64+i,zz,'capital_marble_stairs[facing='+('south' if z>0 else 'north')+',half=bottom,shape=straight,waterlogged=false]')
for x in (-112,112):
 clear(x-3,64,-5,x+3,73,5)
 box(x-4,74,-11,x+4,76,11,'capital_gray_brick')
 hall(x,0,9,19,floor=77,height=5,palace=True,mat='capital_gold_tiles',name='側城門')
 for xx in range(max(-125,x-14),min(125,x+14)+1):box(xx,63,-5,xx,63,5,'capital_marble')
 # Rotated stair access from the inside.
 for i in range(13):
  xx=97+i if x>0 else -97-i
  box(xx,64,15,xx,64+i,18,'capital_gray_brick')
  box(xx,64+i,15,xx,64+i,18,'capital_marble_stairs[facing='+('east' if x>0 else 'west')+',half=bottom,shape=straight,waterlogged=false]')
# Axial avenues.
box(-7,63,-108,7,63,125,'capital_marble')
box(-107,63,-5,107,63,5,'capital_marble')
for x in (-8,8):box(x,63,-107,x,63,107,'capital_dark_brick')
for z in (-6,6,15,49,86):box(-105,63,z,105,63,z,'capital_dark_brick')
box(-15,63,-15,15,63,15,'capital_paving')
for x in range(-13,14):
 for z in range(-13,14):
  rr=x*x+z*z
  if 95<rr<145:put(x,63,z,'capital_carved_marble')
  elif rr<20:put(x,63,z,'capital_lotus')
# Canals along the west/east neighborhoods and southern cross-channel.
for x in (-77,77):
 box(x-3,61,12,x+3,63,96,'capital_marble');box(x-2,62,12,x+2,63,96,'minecraft:water')
for z in (96,):
 box(-103,61,z-3,103,63,z+3,'capital_marble');box(-103,62,z-2,103,63,z+2,'minecraft:water')
# Flat bridges, railings, navigable beneath/open sides.
for cx in (-77,77):
 for cz in (27,51,76):
  box(cx-4,64,cz-2,cx+4,64,cz+2,'capital_marble')
  for zz in (cz-3,cz+3):box(cx-4,65,zz,cx+4,65,zz,'capital_marble_rail')
for cx in (-93,-45,0,45,93):
 box(cx-3,64,91,cx+3,64,101,'capital_marble');box(cx-4,65,92,cx-4,65,100,'capital_marble_rail');box(cx+4,65,92,cx+4,65,100,'capital_marble_rail')
# Courtyard residential wards.
for x in (-46,46):
 for z in (32,69):compound(x,z,name='西坊' if x<0 else '東坊')
for x in (-94,94):
 for z in (24,50,76):hall(x,z,15,13,height=6,name='臨河民居')
# Market stalls flank the main avenue without blocking it.
for x in (-18,18):
 for iz,z in enumerate((24,39,57,74,86)):
  box(x-3,63,z-2,x+3,63,z+2,'capital_floor')
  for xx in (x-3,x+3):
   for zz in (z-2,z+2):box(xx,64,zz,xx,67,zz,'capital_timber')
  box(x-4,68,z-3,x+4,68,z+3,'capital_red_awning' if iz%2==0 else 'capital_jade_awning')
  box(x-2,64,z+1,x+2,64,z+1,'capital_timber');put(x,65,z+1,'capital_lotus')
  put(x,67,z+3,'capital_red_lantern');buildings.append({'name':'市集攤位','center':[x,64,z],'size':[7,5]})
# Administration halls and two civic courtyards.
for x in (-42,42):
 box(x-20,63,-29,x+20,63,-9,'capital_floor');rail(x-20,64,-29,x+20,-9)
 clear(x-2,64,-9,x+2,65,-9)
 hall(x,-22,27,11,height=7,mat='capital_dark_tiles',name='官署正堂')
# Imperial palace raised courtyards.
box(-66,64,-105,66,65,-34,'capital_marble')
box(-63,66,-103,63,67,-36,'capital_marble')
box(-61,68,-101,61,68,-38,'capital_floor')
rail(-65,66,-104,65,-35)
for x in (-62,62):box(x,69,-102,x,73,-37,'capital_red_wall');box(x,74,-102,x,74,-37,'capital_gold_tiles')
box(-62,69,-102,62,73,-102,'capital_red_wall');box(-62,74,-102,62,74,-102,'capital_gold_tiles')
for x1,x2 in [(-62,-15),(15,62)]:box(x1,69,-37,x2,73,-37,'capital_red_wall');box(x1,74,-37,x2,74,-37,'capital_gold_tiles')
hall(0,-37,27,9,floor=69,height=6,mat='capital_gold_tiles',palace=True,open_hall=True,name='宮城午門')
# Entrance steps and a clear 9-wide gate approach.
stair(-6,6,-27,-36,64)
clear(-4,69,-43,4,73,-33)
# Main dais and grand hall.
box(-29,69,-97,29,71,-62,'capital_marble');box(-27,72,-95,27,73,-64,'capital_carved_marble')
hall(0,-80,47,25,floor=74,height=11,mat='capital_gold_tiles',palace=True,double=True,name='承天殿')
stair(-7,7,-54,-63,69)
# Throne and ceremonial furnishings, accessible from main hall doors.
box(-4,74,-86,4,75,-82,'capital_red_timber');box(-2,76,-86,2,76,-84,'capital_bronze');box(-2,77,-86,2,79,-86,'capital_dragon_panel')
for x in (-16,16):
 box(x,74,-86,x,78,-86,'capital_red_column');put(x,79,-86,'capital_gold_lantern')
# Side palaces and rear garden strips.
for x in (-47,47):
 hall(x,-80,17,29,floor=69,height=7,mat='capital_gold_tiles',palace=True,name='東配殿' if x>0 else '西配殿')
 # Palace courtyard side garden with pavilion.
 box(x-9,69,-57,x+9,69,-45,'capital_grass')
 pavilion(x,-51,r=4,floor=70,mat='capital_jade_tiles',name='御苑亭')
 for xx in (x-8,x+8):tree(xx,-46,70)
# Processional courtyard markers and lights.
for x in (-18,18):
 for z in (-48,-57):
  put(x,69,z,'capital_marble');box(x,70,z,x,73,z,'capital_red_column');put(x,74,z,'capital_bronze')
for x in (-56,56):
 for z in (-42,-62,-98):lamp(x,z,69)
# West military yard and east granaries outside palace walls.
box(-104,63,-101,-73,63,-63,'capital_floor');rail(-104,64,-101,-73,-63)
clear(-89,64,-63,-85,65,-63)
hall(-89,-92,23,11,height=6,palace=False,name='校場營房')
for x in (-99,-91,-83,-75):
 box(x,64,-70,x,66,-70,'capital_timber');put(x,67,-70,'capital_banner')
for z in (-92,-70):hall(89,z,23,13,height=6,name='糧倉')
# Gardens, ponds, bridge and pavilions on the north flanks.
for x in (-90,90):
 box(x-15,63,-57,x+15,63,-12,'capital_grass')
 box(x-10,61,-46,x+10,63,-27,'capital_marble')
 box(x-9,62,-45,x+9,63,-28,'minecraft:water')
 box(x-2,64,-47,x+2,64,-26,'capital_marble')
 for xx in (x-3,x+3):box(xx,65,-43,xx,65,-30,'capital_marble_rail')
 if x<0:pavilion(x,-37,r=4,floor=65,name='曲水亭')
 else:
  # Three-tier temple pagoda, simple interior stairs available via side opening.
  for k,r in enumerate((6,5,4)):
   hall(x,-37,2*r+1,2*r+1,floor=65+k*8,height=4,mat='capital_jade_tiles',palace=True,name='望月樓第'+str(k+1)+'層')
 for xx,zz in [(x-12,-51),(x+12,-51),(x-12,-18),(x+12,-18)]:tree(xx,zz,64,willow=zz==-18)
# Roadside trees and lamps.
for z in (16,47,82,103):
 for x in (-10,10):lamp(x,z)
for x in (-102,-67,-32,32,67,102):
 for z in (105,9):tree(x,z)
# Bell/drum gateway pavilions, a pair on central axis.
for x in (-19,19):pavilion(x,6,r=3,floor=64,mat='capital_gold_tiles',name='鐘鼓亭')
# Continuity fixes: keep the central avenue clear at entrances and allow crossing.
clear(-5,64,108,5,72,116);clear(-5,64,-116,5,72,-108)
# Centre (0,0) is the plaza, not the palace throne.
assert palette[vox[125,125,64-Y0]]=='minecraft:air'
# City 2: strict west/east symmetry through the X=0 block column.
# Restore paired wall access stairs before mirroring. The north staircase
# starts from the raised palace terrace (floor block Y=68), not beneath it.
for side in (-1, 1):
 for i in range(5 if side < 0 else 0, 13):
  zz = side * (97+i)
  box(-21, 64, zz, -18, 64+i, zz, 'capital_gray_brick')
  box(-21, 64+i, zz, -18, 64+i, zz,
      'capital_marble_stairs[facing='+('north' if side < 0 else 'south')+
      ',half=bottom,shape=straight,waterlogged=false]')
  clear(-21, 65+i, zz, -18, 67+i, zz)

def mirror_x_state(state):
 if '[' not in state: return state
 name, text = state[:-1].split('[', 1)
 pairs = [item.split('=', 1) for item in text.split(',')]
 for pair in pairs:
  if pair[0] == 'facing': pair[1] = {'east':'west','west':'east'}.get(pair[1],pair[1])
  elif pair[0] == 'shape':
   pair[1] = {'inner_left':'inner_right','inner_right':'inner_left',
              'outer_left':'outer_right','outer_right':'outer_left'}.get(pair[1],pair[1])
 return name+'['+','.join(k+'='+v for k,v in pairs)+']'

# Only stairs and slabs have state properties in this blueprint. Fail instead of
# silently mishandling a future door/fence/rail whose reflection needs more rules.
for state in palette:
 if '[' in state:
  name = state.split('[',1)[0]
  if not name.endswith(('_stairs','_slab')):
   raise ValueError('Unsupported mirror state: '+state)
mirror_index = np.asarray([pid(mirror_x_state(s)) for s in list(palette)], dtype=np.uint16)
vox[126:,:,:] = mirror_index[vox[124::-1,:,:]]
assert np.array_equal(vox, mirror_index[vox[::-1,:,:]])
assert np.array_equal(mirror_index[mirror_index], np.arange(len(palette)))
# All source descriptions must correspond to buildings that actually survive the
# mirror: west buildings and axis buildings, plus mirrored west counterparts.
paired_buildings = []
for building in buildings:
 x = building['center'][0]
 if x > 0: continue
 left = dict(building)
 left['name'] = ('西側・' if x < 0 else '') + building['name']
 paired_buildings.append(left)
 if x < 0:
  right = dict(building)
  right['center'] = [-x, building['center'][1], building['center'][2]]
  right['name'] = '東側・' + building['name'].replace('西','東')
  right['mirror_of_x'] = x
  paired_buildings.append(right)
buildings = paired_buildings

# Export compact endian-stable custom blueprint. Outside this footprint nothing is emitted.
out=RES/'data/wooltest/city/capital_v2.wct.gz';out.parent.mkdir(parents=True,exist_ok=True)
raw=bytearray(struct.pack('>6i',0x57435431,1,N,Y0,H,len(palette)))
for s in palette:
 b=s.encode('utf-8');raw+=struct.pack('>H',len(b))+b
raw+=vox.astype('>u2').tobytes()
out.write_bytes(gzip.compress(bytes(raw),compresslevel=9,mtime=0))
np.save(ART/'city_voxels.npy',vox)
js(ART/'palette.json',palette)
occupied=np.argwhere(vox!=0)
counts=Counter(palette[int(i)] for i in vox.flatten() if i)
meta={'name':'承天城','size':[251,251],'bounds':{'min_x':-125,'max_x':125,'min_z':-125,'max_z':125,'min_y':Y0,'max_y':int(occupied[:,2].max()+Y0)},'center_xz':[0,0], 'palace_center_xz':[0,-80],'south_gate_xz':[0,112], 'custom_block_types':len(allblocks),'palette_entries':len(palette),'non_air_blocks':int(np.count_nonzero(vox)), 'water_blocks':sum(c for k,c in counts.items() if k.startswith('minecraft:water')), 'buildings':buildings,'block_counts':dict(counts),'sha256':hashlib.sha256(out.read_bytes()).hexdigest(),'note':'Blueprint authored from the concept; not an exact recreation of every visual element in the generated concept image.'}
meta['revision']=2
meta['symmetry']={'axis':'X=0 block column','transform':'(x,y,z) -> (-x,y,z), east/west facing reflected','basis':'west half mirrored east','all_cells_verified':True}
js(ART/'city_manifest.json',meta)
print(json.dumps({k:v for k,v in meta.items() if k not in ('buildings','block_counts')},ensure_ascii=False,indent=2))
