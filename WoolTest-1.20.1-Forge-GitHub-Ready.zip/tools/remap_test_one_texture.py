#!/usr/bin/env python3
"""Remap the generated design to exact UVs. Only Pillow is needed to regenerate.
The PNG is already included in src/main/resources; Gradle needs no Pillow.
"""
from pathlib import Path
import json
from PIL import Image, ImageDraw

root = Path(__file__).resolve().parent.parent
art = root / 'art_source'
spec = json.loads((art / 'uv_regions.json').read_text(encoding='utf-8'))
source = Image.open(art / 'test_one_generated.png').convert('RGBA')
scale = spec['output_size'][0] // spec['logical_size'][0]
atlas = Image.new('RGBA', tuple(spec['output_size']), (0, 0, 0, 0))

for name, face in spec['faces'].items():
    x, y, width, height = face['uv']
    crop = source.crop(tuple(face['source']))
    # Make every rendered base face opaque; transparent unused/hat UVs stay clear.
    base = Image.new('RGBA', crop.size, (127, 98, 70, 255))
    crop = Image.alpha_composite(base, crop).convert('RGB')
    # Downsample once to real game texels, then use a discrete palette, no dithering.
    face_image = crop.resize((width * scale, height * scale), Image.Resampling.BOX)
    face_image = face_image.quantize(colors=24, method=Image.Quantize.MEDIANCUT,
                                    dither=Image.Dither.NONE).convert('RGBA')
    atlas.paste(face_image, (x * scale, y * scale))

# Pixel-exact clean-up of the label. At native resolution text must remain '01'.
# This is on the torso front only, not a new mesh, item, or gameplay mechanic.
draw = ImageDraw.Draw(atlas)
draw.rectangle((43, 46, 54, 54), fill=(230, 214, 174, 255))
draw.line((43,46,54,46), fill=(251,235,195,255))
draw.line((43,54,54,54), fill=(159,135,103,255))
glyphs = {'0': ['111','101','101','101','111'],
          '1': ['010','110','010','010','111']}
for digit, ox in [('0',45), ('1',49)]:
    for oy, row in enumerate(glyphs[digit]):
        for dx, cell in enumerate(row):
            if cell == '1':
                draw.point((ox + dx, 48 + oy), fill=(35,32,29,255))

output = root / 'src/main/resources/assets/wooltest/textures/entity/test_one.png'
output.parent.mkdir(parents=True, exist_ok=True)
atlas.save(output, optimize=True)
print(f'Wrote {output.relative_to(root)} ({atlas.width}x{atlas.height} RGBA)')
