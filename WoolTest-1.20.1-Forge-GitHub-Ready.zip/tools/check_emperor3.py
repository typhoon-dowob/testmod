#!/usr/bin/env python3
"""Static/source validation of the shipped Emperor 3 data, NOT a Forge runtime test."""
from pathlib import Path
import json,re,hashlib,tomllib
import numpy as np
from PIL import Image
P=Path(__file__).resolve().parents[1];A=P/'art_source/emperor3';R=P/'src/main/resources';J=P/'src/main/java/dev/sushi/wooltest'
spec=json.loads((A/'emperor_model.json').read_text());old=json.loads((A/'baseline/emperor_model.json').read_text())
texture=Image.open(R/'assets/wooltest/textures/entity/emperor.png').convert('RGBA')
mask=Image.open(R/'assets/wooltest/textures/entity/emperor_charge.png').convert('RGBA')
assert texture.size==mask.size==(512,512)
code=(J/'client/EmperorModel.java').read_text()
known={'root':np.zeros(3)};boxes=[];used=set();count=0;mask_pixels=0
for node in spec['nodes']:
 assert node['parent'] in known and node['name'] not in known
 known[node['name']]=known[node['parent']]+np.array(node['offset'])
 pat=rf'PartDefinition {node["name"]} = {node["parent"]}\.addOrReplaceChild\("{node["name"]}", CubeListBuilder\.create\(\)(.*?)PartPose\.offset\((.*?)\)\);'
 m=re.search(pat,code,re.S);assert m,node['name']
 fl=lambda text:[float(v.strip().rstrip('F')) for v in text.split(',')]
 assert np.allclose(fl(m[2]),node['offset'],rtol=0,atol=1e-7)
 jc=re.findall(r'\.texOffs\((\d+), (\d+)\)\.addBox\((.*?)\)',m[1]);assert len(jc)==len(node['cubes'])
 for c,(u,v,nums) in zip(node['cubes'],jc):
  assert [int(u),int(v)]==c['uv'];assert np.allclose(fl(nums),c['origin']+c['size'],rtol=0,atol=1e-7)
  lo=known[node['name']]+np.array(c['origin']);hi=lo+np.array(c['size']);boxes.append((lo,hi));count+=1
  assert all(q>0 for q in c['size'])
  for name,(x,y,w,h) in c['faces'].items():
   assert 0<=x<x+w<=256 and 0<=y<y+h<=256
   rgba=np.array(texture.crop((2*x,2*y,2*(x+w),2*(y+h))));assert (rgba[:,:,3]==255).all(),(c['name'],name)
   ma=np.array(mask.crop((2*x,2*y,2*(x+w),2*(y+h))));mask_pixels+=int((ma[:,:,3]>0).sum())
   for yy in range(y,y+h):
    for xx in range(x,x+w):assert (xx,yy) not in used,(c['name'],name);used.add((xx,yy))
lo=np.min([p for p,q in boxes],axis=0);hi=np.max([q for p,q in boxes],axis=0)
assert lo[0]>=-16 and hi[0]<=16 and lo[1]==-24 and hi[1]==24 and lo[2]>=-16 and hi[2]<=16
assert np.isclose(hi[0]-lo[0],24.0)
assert mask_pixels>0
basecode=(A/'baseline/EmperorModel.java.txt').read_text()
# Animation and held-item transforms have not changed; hand Y extents also match.
assert basecode[basecode.index('    @Override public ModelPart root()'):]==code[code.index('    @Override public ModelPart root()'):]
by={n['name']:n for n in spec['nodes']};ob={n['name']:n for n in old['nodes']}
for s in ['right','left']:
 hand=by[s+'_arm']['cubes'][2];before=ob[s+'_arm']['cubes'][2]
 assert hand['origin'][1]==before['origin'][1]==13
 assert hand['size'][1]==before['size'][1]==4
 assert by[s+'_arm']['offset'][1:]==ob[s+'_arm']['offset'][1:]
 assert 'new EmperorAuraLayer(this)' in (J/'client/EmperorRenderer.java').read_text()
# All gameplay classes, city data, dropped armor etc. must be byte-identical to the
# Emperor 2 archive. Only two graphics classes, their images and build metadata change.
baseline=json.loads((A/'baseline/runtime_sha256.json').read_text())
allowed={'src/main/java/dev/sushi/wooltest/client/EmperorModel.java',
 'src/main/java/dev/sushi/wooltest/client/EmperorRenderer.java',
 'src/main/resources/assets/wooltest/textures/entity/emperor.png',
 'src/main/resources/assets/wooltest/textures/entity/emperor_charge.png',
 'src/main/resources/META-INF/mods.toml','src/main/resources/wooltest-build-info.txt'}
changed=[];same=[]
for rel,digest in baseline.items():
 assert (P/rel).is_file(),rel
 now=hashlib.sha256((P/rel).read_bytes()).hexdigest()
 if now!=digest:assert rel in allowed,rel;changed.append(rel)
 else:same.append(rel)
assert not [p for p in (P/'src').rglob('*') if p.is_file() and p.relative_to(P).as_posix() not in baseline]
jsons=0
for f in R.rglob('*.json'):json.loads(f.read_text());jsons+=1
meta=tomllib.loads((R/'META-INF/mods.toml').read_text());assert meta['mods'][0]['displayName']=='Wool Test Dimension (City 5 + Emperor 3 - Slim)'
for f in J.rglob('*.java'):
 if 'client' not in f.parts:assert 'import net.minecraft.client.' not in f.read_text(),f
report={'status':'PASS','model_nodes':len(spec['nodes']),'cuboids':count,'faces_checked':count*6,
 'uv_overlap':0,'java_mesh_matches_spec':True,'original_animation_and_hand_transform_unchanged':True,
 'neutral_bounds_model_units':{'min':lo.tolist(),'max':hi.tolist()},
 'neutral_visual_width_blocks':float((hi[0]-lo[0])/16),'visual_height_blocks':3,
 'gameplay_collision_blocks':[2,2,3],
 'original_runtime_files_unchanged':len(same),'changed_runtime_files':changed,
 'resource_jsons_decoded':jsons,'charge_mask_mapped_nontransparent_face_pixels':mask_pixels,
 'limit':'Offline checks only. No full Forge API build, in-game rendering, animation, collision, AI or multiplayer test.'}
(P/'validation/emperor3-checks.json').write_text(json.dumps(report,indent=2,ensure_ascii=False)+'\n')
print(json.dumps(report,indent=2,ensure_ascii=False))
