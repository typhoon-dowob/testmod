from pathlib import Path
import json,math,random
from PIL import Image,ImageDraw,ImageFont
P=Path(__file__).resolve().parent.parent;J=P/'src/main/java/dev/sushi/wooltest/client';A=P/'art_source/emperor2';T=P/'src/main/resources/assets/wooltest/textures';A.mkdir(parents=True,exist_ok=True)
for d in ['entity','item','effect']: (T/d).mkdir(parents=True,exist_ok=True)
nodes=[]
def node(name,parent,off,cubes):
 nodes.append(dict(name=name,parent=parent,offset=off,cubes=[dict(name=f'{name}_{i}',origin=o,size=s,material=m) for i,(o,s,m) in enumerate(cubes)]))
node('torso','root',[0,-8,0],[([-8,0,-5],[16,17,10],'robe'),([-6,-1,-5.5],[12,3,11],'red'),([-9,14,-6],[18,3,12],'gold'),([-3,5,-6],[6,7,1],'seal'),([-10,17,-6],[20,10,12],'robe'),([-8,24,-7],[16,3,1],'red')])
node('head','torso',[0,0,0],[([-5,-11,-5],[10,11,10],'skin'),([-3,-3,-6],[6,5,1],'beard'),([-6,-14,-6],[12,3,12],'gold'),([-9,-16,-7],[18,2,14],'crown'),([-2,-13,-6.25],[4,3,1],'jade')])
for x in [-8,-5,-2,1,4,7]:
 # Bead strings along the front and rear of the rigid crown. Skin face stays visible below.
 for z in [-7,6]: node(f'bead_{x+8}_{z+7}','head',[x,-14,z],[([0,0,0],[1,5,1],'beads')])
for side,x in [('right',-12),('left',12)]:
 node(side+'_arm','torso',[x,2,0],[([-4,-1,-5],[8,11,10],'robe'),([-4,10,-5],[8,3,10],'gold'),([-2,13,-2],[4,4,4],'skinhand')])
 node(side+'_leg','root',[-5 if side=='right' else 5,17,0],[([-3,0,-3],[6,3,6],'red'),([-3,3,-5],[6,4,9],'boots')])
# Emperor 2: new layered mantle, split hems, jade pendants, shoulder plates and bead caps.
node('cape','torso',[0,1,0],[([-10,0,5],[20,22,2],'robe'),([-11,1,5],[1,20,2],'gold'),([10,1,5],[1,20,2],'gold'),([-9,22,5],[18,1,2],'red')])
for n in list(nodes):
 if n['name'].startswith('bead_'):
  for yy in [0,2,4]:n['cubes'].append(dict(name=n['name']+'_jewel'+str(yy),origin=[-.5,yy,-.5],size=[2,1,2],material='jade' if yy==2 else 'beads'))
 if n['name'].endswith('_arm'):
  for origin,size,mat in [([-4,-3,-5],[8,2,10],'gold'),([-3,-4,-4],[6,1,8],'robe'),([-3,6,-6],[6,4,1],'seal'),([-3,11,-6],[6,2,1],'jade')]:
   n['cubes'].append(dict(name=n['name']+'_detail'+str(len(n['cubes'])),origin=origin,size=size,material=mat))
node('pendant_left','torso',[7,16,-7],[([-1,0,0],[2,6,1],'gold'),([-2,5,-.5],[4,3,2],'jade'),([-1,8,0],[2,2,1],'red')])
node('pendant_right','torso',[-7,16,-7],[([-1,0,0],[2,6,1],'gold'),([-2,5,-.5],[4,3,2],'jade'),([-1,8,0],[2,2,1],'red')])
node('front_skirt','torso',[0,17,-7.2],[([-4,0,0],[8,9,1],'robe'),([-5,0,0],[1,9,1],'gold'),([4,0,0],[1,9,1],'gold'),([-4,9,0],[8,1,1],'red')])
node('crown_trim','head',[0,0,0],[([-9,-15,-7],[18,1,1],'gold'),([-9,-15,6],[18,1,1],'gold'),([-7,-14,-6],[14,1,12],'red')])
node('beard_tip','head',[0,1,-6.2],[([-2,0,0],[4,3,1],'beard'),([-1,3,0],[2,2,1],'beard')])

# Generate non-overlapping vanilla cuboid UV nets.
x=y=rowh=0;W=256
for n in nodes:
 for c in n['cubes']:
  w,h,d=c['size'];rw=2*(w+d);rh=h+d
  if x+rw>W: x=0;y+=rowh+1;rowh=0
  u,v=x,y;c['uv']=[u,v]
  c['faces']={'top':[u+d,v,w,d],'bottom':[u+d+w,v,w,d], 'right':[u,v+d,d,h], 'front':[u+d,v+d,w,h], 'left':[u+d+w,v+d,d,h], 'back':[u+2*d+w,v+d,w,h]}
  x+=rw+1;rowh=max(rowh,rh)
assert y+rowh<=256,(y,rowh)
img=Image.new('RGBA',(256,256),(0,0,0,0));rng=random.Random(404)
base={'robe':(35,38,45),'red':(133,29,34),'gold':(213,164,66),'seal':(212,161,53),'skin':(204,160,119),'skinhand':(204,160,119),'hair':(28,26,28),'beard':(32,28,25),'crown':(49,37,29),'jade':(45,149,123),'beads':(225,193,109),'boots':(27,29,34)}
for n in nodes:
 for c in n['cubes']:
  mat=c['material']
  for face,(px,py,w,h) in c['faces'].items():
   im=Image.new('RGBA',(w,h));dr=ImageDraw.Draw(im)
   for yy in range(h):
    for xx in range(w):
     k=rng.randrange(-8,9);rgb=tuple(max(0,min(255,v+k)) for v in base[mat]); im.putpixel((xx,yy),rgb+(255,))
   if mat=='robe':
    dr.rectangle((0,0,w-1,h-1),outline=(180,127,38,255))
    if face in ['front','back']:
     dr.line([(w//2,2),(w//2-2,4),(w//2+2,6),(w//2-2,8),(w//2+1,min(h-2,10))],fill=(237,184,57,255),width=1)
     for xx in range(3,w-2,5):dr.line((xx,h-4,xx+1,h-3),fill=(180,127,38,255))
   if mat=='seal':
    dr.rectangle((0,0,w-1,h-1),outline=(255,225,129,255));dr.line((1,1,4,1),fill=(85,39,22,255));dr.line((1,3,4,3),fill=(85,39,22,255));dr.line((3,1,3,5),fill=(85,39,22,255));dr.line((3,4,1,6),fill=(85,39,22,255));dr.line((3,4,4,6),fill=(85,39,22,255))
   if mat=='skin' and face!='front':
    if face in ['top','back']:dr.rectangle((0,0,w-1,h-1),fill=(29,25,27,255))
    elif face in ['left','right']:
     dr.rectangle((0,0,w-1,3),fill=(29,25,27,255));dr.rectangle((1,4,2,8),fill=(29,25,27,255))
   if mat=='skin' and face=='front':
    dr.rectangle((0,0,w-1,1),fill=(29,25,27,255))
    dr.line((1,3,3,3),fill=(37,26,23,255));dr.line((6,3,8,3),fill=(37,26,23,255));dr.point((2,4),fill=(18,18,20,255));dr.point((7,4),fill=(18,18,20,255));dr.line((4,5,4,7),fill=(164,111,80,255));dr.line((2,8,7,8),fill=(35,23,20,255))
   if mat in ['gold','crown']:
    dr.rectangle((0,0,w-1,h-1),outline=(246,207,107,255))
    for xx in range(2,w-1,4):dr.point((xx,min(h-1,1)),fill=(137,74,27,255))
   if mat=='beads':
    for yy in range(h):dr.line((0,yy,w-1,yy),fill=(245,222,151,255) if yy%2==0 else (155,109,37,255))
   if mat=='jade':
    if min(w,h)<=2:dr.rectangle((0,0,w-1,h-1),fill=(83,190,150,255))
    else:dr.rectangle((0,0,w-1,h-1),outline=(251,214,126,255))
   img.paste(im,(px,py))
img.resize((512,512),Image.Resampling.NEAREST).save(T/'entity/emperor.png')
spec=dict(format='WoolTest Emperor 2 exact cuboid geometry',coordinates='Minecraft: +Y down, front -Z, ground Y=24, 16 units/block',texture_logical_size=[256,256],texture_png_size=[512,512],texture='wooltest:textures/entity/emperor.png',nodes=nodes)
(A/'emperor_model.json').write_text(json.dumps(spec,indent=2))
# Build Java from same exact authoring data.
code='''package dev.sushi.wooltest.client;
import com.mojang.blaze3d.vertex.PoseStack;
import dev.sushi.wooltest.WoolTestMod;
import dev.sushi.wooltest.entity.EmperorEntity;
import net.minecraft.client.model.HierarchicalModel;
import net.minecraft.client.model.ArmedModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.HumanoidArm;
public final class EmperorModel extends HierarchicalModel<EmperorEntity> implements ArmedModel {
    public static final ModelLayerLocation LAYER = new ModelLayerLocation(new ResourceLocation(WoolTestMod.MOD_ID, "emperor"), "main");
    private final ModelPart root, torso, head, rightArm, leftArm, rightLeg, leftLeg;
    public EmperorModel(ModelPart root) {
        this.root=root; torso=root.getChild("torso"); head=torso.getChild("head");
        rightArm=torso.getChild("right_arm"); leftArm=torso.getChild("left_arm");
        rightLeg=root.getChild("right_leg"); leftLeg=root.getChild("left_leg");
    }
    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh=new MeshDefinition(); PartDefinition root=mesh.getRoot();
'''
for n in nodes:
 code+=f'        PartDefinition {n["name"]} = {n["parent"]}.addOrReplaceChild("{n["name"]}", CubeListBuilder.create()\n'
 for c in n['cubes']:
  u,v=c['uv'];nums=', '.join(f'{float(q):.1f}F' for q in c['origin']+c['size'])
  code+=f'                .texOffs({u}, {v}).addBox({nums})\n'
 code+='                , PartPose.offset('+', '.join(f'{float(q):.1f}F' for q in n['offset'])+'));\n'
code+='''        return LayerDefinition.create(mesh, 256, 256);
    }
    @Override public ModelPart root() { return root; }
    @Override public void setupAnim(EmperorEntity entity,float swing,float amount,float age,float yaw,float pitch) {
        root.getAllParts().forEach(ModelPart::resetPose);
        head.yRot=Mth.clamp(yaw,-45,45)*Mth.DEG_TO_RAD;
        head.xRot=Mth.clamp(pitch,-20,20)*Mth.DEG_TO_RAD;
        float stride=Mth.cos(swing*0.6662F)*0.55F*amount;
        rightLeg.xRot=stride; leftLeg.xRot=-stride;
        rightArm.xRot=-stride*0.4F-0.15F; leftArm.xRot=stride*0.4F;
        if(entity.isChargingSpell()) {
            rightArm.xRot=-1.15F; leftArm.xRot=-0.95F;
            rightArm.zRot=0.12F; leftArm.zRot=-0.12F;
        } else if(attackTime>0) {
            rightArm.xRot-=Mth.sin(Mth.sqrt(attackTime)*Mth.PI)*1.3F;
        }
    }
    @Override public void translateToHand(HumanoidArm arm,PoseStack pose) {
        root.translateAndRotate(pose); torso.translateAndRotate(pose);
        (arm==HumanoidArm.RIGHT?rightArm:leftArm).translateAndRotate(pose);
        pose.translate(0.0D,5.0D/16.0D,0.0D);
    }
}
'''
(J/'EmperorModel.java').write_text(code)
(J/'EmperorRenderer.java').write_text('''package dev.sushi.wooltest.client;
import dev.sushi.wooltest.WoolTestMod;
import dev.sushi.wooltest.entity.EmperorEntity;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.client.renderer.entity.layers.ItemInHandLayer;
import net.minecraft.resources.ResourceLocation;
public final class EmperorRenderer extends MobRenderer<EmperorEntity, EmperorModel> {
    private static final ResourceLocation TEXTURE=new ResourceLocation(WoolTestMod.MOD_ID,"textures/entity/emperor.png");
    public EmperorRenderer(EntityRendererProvider.Context context) {
        super(context,new EmperorModel(context.bakeLayer(EmperorModel.LAYER)),0.85F);
        addLayer(new ItemInHandLayer<>(this,context.getItemInHandRenderer()));
        addLayer(new EmperorAuraLayer(this));
    }
    @Override public ResourceLocation getTextureLocation(EmperorEntity entity) { return TEXTURE; }
}
''')
# Independent sword sprite: straight double-edged imperial jian, jade hilt, vermilion tassel.
sword=Image.new('RGBA',(32,32),(0,0,0,0));d=ImageDraw.Draw(sword)
d.polygon([(27,1),(30,1),(30,4),(13,21),(10,18)],fill='#55452f')
d.polygon([(28,2),(29,2),(29,4),(13,20),(11,18)],fill='#f3e8ba')
d.line([(28,3),(12,19)],fill='#e0ba58',width=2)
d.line([(29,3),(13,19)],fill='#fff8d9',width=1)
d.polygon([(7,15),(9,14),(17,22),(16,24),(14,23),(6,17)],fill='#744e1c')
d.line([(8,15),(16,23)],fill='#efc24e',width=2)
d.line([(10,21),(5,26)],fill='#172f2b',width=4)
d.line([(10,21),(5,26)],fill='#2d9c81',width=2)
d.rectangle((3,25,6,28),fill='#dcb34e');d.point((4,26),fill='#f9e39a')
d.line([(6,28),(8,30),(12,30)],fill='#9d2634',width=2);d.point((13,31),fill='#d75349')
sword.save(T/'item/imperial_sword.png')
# Precisely radial transparent sigil, not a cropped concept illustration.
N=512;cx=cy=N/2;sigil=Image.new('RGBA',(N,N),(0,0,0,0));d=ImageDraw.Draw(sigil);gold=(255,211,99,245);light=(255,244,191,255)
def pt(r,a):return(cx+math.cos(a)*r,cy+math.sin(a)*r)
for r,w in [(238,3),(228,2),(204,2),(181,3),(117,2),(95,2),(49,3)]:d.ellipse((cx-r,cy-r,cx+r,cy+r),outline=gold,width=w)
for n in range(64):
 a=n*2*math.pi/64;r=218 if n%4 else 208;d.line((pt(r,a),pt(225,a)),fill=light,width=2)
for n in range(8):
 a=n*math.pi/4
 # Seal-like radial glyph, four-sided ornamental knots with no borrowed glyph atlas.
 poly=[pt(191,a-0.035),pt(213,a-0.035),pt(213,a+0.035),pt(191,a+0.035)]
 d.line(poly+[poly[0]],fill=gold,width=2)
 d.line((pt(184,a),pt(201,a)),fill=gold,width=3)
for r,start in [(177,math.pi/4),(157,0),(115,math.pi/4)]:
 q=[pt(r,start+i*math.pi/2) for i in range(4)];d.line(q+[q[0]],fill=gold,width=3)
for n in range(12):
 a=n*math.pi/6;d.line((pt(126,a),pt(146,a)),fill=light,width=2)
# Stylized hand-drawn 'heaven' character at the centre.
d.line((236,237,276,237),fill=light,width=5);d.line((229,251,283,251),fill=light,width=5)
d.line((257,238,257,253,243,270,232,277),fill=light,width=5);d.line((257,253,270,269,281,277),fill=light,width=5)
sigil.save(T/'effect/imperial_circle.png')
# Soft beam ribbon. The renderer uses two crossed quads, not particles as the hitbox.
beam=Image.new('RGBA',(32,32))
for yy in range(32):
 for xx in range(32):
  dist=abs((xx+0.5)/16-1);alpha=int(255*max(0,1-dist)**1.7)
  beam.putpixel((xx,yy),(255,249 if dist<.25 else 204,199 if dist<.25 else 77,alpha))
beam.save(T/'effect/imperial_beam.png')
(A/'asset_provenance.json').write_text(json.dumps({'method':'Original procedural pixel and line art authored for this mod; no original Minecraft skin reused','model_texture':'512x512 RGBA / 256x256 logical UV','sword':'32x32 RGBA','circle':'512x512 RGBA with exact centred radial geometry','beam':'32x32 RGBA'},indent=2))
print('Assets written:',len(nodes),'nodes',sum(len(n['cubes']) for n in nodes),'cuboids; UV used height',y+rowh)
