import dev.sushi.wooltest.client.EmperorMeshData;
import java.io.*;
import java.nio.file.*;
import java.util.zip.GZIPOutputStream;

/** Executes the production mesh decoder against the real payload and malformed data. */
public final class EmperorMeshDataTest {
    private static int checks;
    private static void check(boolean ok,String why) { checks++; if(!ok)throw new AssertionError(why); }
    private static byte[] fixture(int magic,int bones,int quads,float value,int field,boolean extra) throws Exception {
        ByteArrayOutputStream out=new ByteArrayOutputStream();
        try(DataOutputStream d=new DataOutputStream(new GZIPOutputStream(out))) {
            d.writeInt(magic);d.writeInt(1);d.writeInt(bones);
            for(int b=0;b<Math.min(bones,2);b++) {
                d.writeUTF("head");d.writeInt(quads);
                if(quads==1)for(int j=0;j<32;j++) {
                    int f=j%8;d.writeFloat(f==field?value:f==4?1.0F:0.0F);
                }
            }
            if(extra)d.writeByte(7);
        }
        return out.toByteArray();
    }
    private static void rejects(byte[] data,String why) throws Exception {
        boolean failed=false;
        try {EmperorMeshData.read(new ByteArrayInputStream(data));}catch(IOException ex){failed=true;}
        check(failed,why);
    }
    public static void main(String[] args) throws Exception {
        EmperorMeshData actual=EmperorMeshData.read(Files.newInputStream(Path.of(args[0])));
        check(actual.boneNames().size()==20,"20 expected bones");
        check(actual.quadCount()==3124,"actual expected quad count");
        check(actual.mesh("head").length>0,"head payload exists");
        check(EmperorMeshData.loadBundled().quadCount()==actual.quadCount(),"classpath loading");
        rejects(fixture(0,1,1,0,-1,false),"bad magic");
        rejects(fixture(0x57454D34,129,1,0,-1,false),"oversized bones");
        rejects(fixture(0x57454D34,1,20001,0,-1,false),"oversized faces");
        rejects(fixture(0x57454D34,1,1,Float.NaN,0,false),"NaN coordinate");
        rejects(fixture(0x57454D34,1,1,2,6,false),"out of range UV");
        rejects(fixture(0x57454D34,1,1,0,4,false),"zero normal");
        rejects(fixture(0x57454D34,2,1,0,-1,false),"duplicate bone");
        rejects(fixture(0x57454D34,1,1,0,-1,true),"trailing bytes");
        byte[] bytes=Files.readAllBytes(Path.of(args[0]));
        rejects(java.util.Arrays.copyOf(bytes,bytes.length/2),"truncated stream");
        System.out.println("PASS: production WEM4 decoder, "+checks+" checks; "+actual.quadCount()+" quads.");
    }
}
