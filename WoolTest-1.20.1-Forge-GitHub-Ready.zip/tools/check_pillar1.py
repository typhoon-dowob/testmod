#!/usr/bin/env python3
"""Resource-only Pillar 1 checks; NOT a Forge compilation or game runtime test."""
from pathlib import Path
from PIL import Image
import hashlib, json, re, tomllib
ROOT=Path(__file__).resolve().parent.parent
R=ROOT/'src/main/resources'
A=R/'assets/wooltest'
model=json.loads((A/'models/block/temporary_pillar.json').read_text())
assert model['parent']=='minecraft:block/cube'
assert set(model['textures'])=={'particle','up','down','north','south','east','west'}
paths=set()
for key,loc in model['textures'].items():
    namespace,path=loc.split(':',1)
    assert namespace=='wooltest' and re.fullmatch(r'[a-z0-9_/]+',path)
    p=R/f'assets/{namespace}/textures/{path}.png'
    paths.add(p)
    with Image.open(p) as im:
        im.load()
        assert im.size==(32,32) and im.mode=='RGBA',p
        assert im.getchannel('A').getextrema()==(255,255),p
        assert len(im.getcolors(maxcolors=1024))<=48,p
assert len(paths)==5
state=json.loads((A/'blockstates/temporary_pillar.json').read_text())
assert state=={'variants':{'':{'model':'wooltest:block/temporary_pillar'}}}
print('PASS: Model-to-texture references; six cube faces; five 32x32 RGBA opaque PNGs, each <=48 colours.')
print('PASS: Unchanged stateless blockstate; full-cube vanilla parent; no added renderer, lighting, animation or block property.')
manifest=json.loads((ROOT/'validation/pillar1-unchanged-files.json').read_text())
for entry in manifest:
    assert hashlib.sha256((ROOT/entry['path']).read_bytes()).hexdigest()==entry['sha256'],entry['path']
java=[e for e in manifest if e['path'].startswith('src/main/java/')]
assert java
print(f'PASS: {len(manifest)} baseline files identical to Model 1, including all {len(java)} Java files, entity textures, world data and build workflow.')
assert not (R/'assets/minecraft').exists()
meta=tomllib.loads((R/'META-INF/mods.toml').read_text())
assert meta['mods'][0]['modId']=='wooltest'
assert meta['mods'][0]['displayName']=='Wool Test Dimension (Model 1 + Pillar 1)'
assert (R/'wooltest-build-info.txt').read_text().splitlines()[0]=='WOOLTEST-MODEL1-PILLAR1'
print('PASS: Dedicated wooltest assets only; original Minecraft block textures are not replaced.')
print('NOTE: Gameplay remains unchanged by file comparison, not by a new runtime test. Forge compilation, resource reload and in-game appearance have NOT been tested here.')
