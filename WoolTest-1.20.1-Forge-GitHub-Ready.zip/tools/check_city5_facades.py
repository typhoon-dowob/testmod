"""Actual-voxel checks for opaque doorway separation, repaired outer wall base and boss clearance."""
from pathlib import Path
import json,numpy as np
P=Path(__file__).resolve().parents[1];A=P/'art_source/city5';v=np.load(A/'city_voxels.npy');pal=json.loads((A/'palette.json').read_text());doors=json.loads((A/'doors.json').read_text());buildings=json.loads((A/'buildings.json').read_text());errors=[]
def at(x,y,z):return pal[int(v[x+125,z+125,y-60])]
def is_air(s):return s in ['minecraft:air','minecraft:red_carpet']
for d in doors:
 def cell(u,y):return at(d['cx']+u,y,d['z']) if d['axis']=='x' else at(d['z'],y,d['cx']+u)
 r=d['width']//2
 for y in range(d['y'],d['y']+d['height']):
  for u in range(-r,r+1):
   s=cell(u,y)
   if not is_air(s):errors.append(['doorway obstruction',d,u,y,s])
  for u in [-r-1,r+1]:
   s=cell(u,y)
   if is_air(s) or 'lattice' in s or 'window' in s:errors.append(['opaque jamb missing',d,u,y,s])
 for u in range(-r-1,r+2):
  s=cell(u,d['y']+d['height'])
  if is_air(s) or 'lattice' in s or 'window' in s:errors.append(['opaque lintel missing',d,u,s])
# Repaired exterior deck boundary: check exposed outward edge blocks have solid low parapet.
edge=0
for x in range(-116,117):
 for z in range(-116,117):
  if max(abs(x),abs(z))<107 or is_air(at(x,72,z)):continue
  exposed=any(max(abs(x+dx),abs(z+dz))>113 and is_air(at(x+dx,72,z+dz)) for dx,dz in [(1,0),(-1,0),(0,1),(0,-1)])
  if exposed:
   edge+=1
   if is_air(at(x,73,z)):errors.append(['outer deck low parapet gap',x,z])
# Entity center(0.5,-80.5), floor68.0625, collision width2,height3.
# Carpet support at Y68 is 1/16 tall; all intersected blocks above it must be air.
for x in [-1,0,1]:
 for z in [-82,-81,-80]:
  if at(x,68,z)!='minecraft:red_carpet':errors.append(['spawn carpet',x,z,at(x,68,z)])
  for y in [69,70,71]:
   if not is_air(at(x,y,z)):errors.append(['emperor collision clearance',x,y,z,at(x,y,z)])
res={'doorways_checked':len(doors),'rule':'Each actual door opening clear, both jambs and lintel opaque; east metadata mirrors west.','exterior_parapet_edge_cells_checked':edge,'emperor_spawn_collision_checked':'2x2x3 at (0.5,68.0625,-80.5)','errors':errors}
(P/'validation/city5_facades.json').write_text(json.dumps(res,ensure_ascii=False,indent=2));print(json.dumps(res,ensure_ascii=False,indent=2));assert not errors
