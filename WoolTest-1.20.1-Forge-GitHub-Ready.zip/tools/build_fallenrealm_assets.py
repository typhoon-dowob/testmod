#!/usr/bin/env python3
"""Original, deliberately simple prototype pixel assets; no external artwork or game texture copies."""
from pathlib import Path
from PIL import Image,ImageDraw
import random,json
ROOT=Path(__file__).resolve().parents[1];RES=ROOT/'src/main/resources'
T=RES/'assets/wooltest/textures';rng=random.Random(1941)
def save(im,path):
    path.parent.mkdir(parents=True,exist_ok=True);im.save(path)
def canvas():return Image.new('RGBA',(32,32),(0,0,0,0))
# Distinct item silhouettes.
im=canvas();d=ImageDraw.Draw(im);d.polygon([(8,7),(21,3),(27,11),(22,26),(9,29),(3,17)],fill='#263440',outline='#87939a');d.line([(10,8),(20,6),(22,17),(16,24)],fill='#b6b9b3',width=2);d.line([(6,17),(16,13),(12,20),(22,26)],fill='#111a23',width=2);save(im,T/'item/armor_shard.png')
im=canvas();d=ImageDraw.Draw(im);d.polygon([(7,3),(24,4),(23,10),(27,17),(23,28),(6,27),(4,20)],fill='#ad8a58',outline='#392b2c');d.polygon([(4,20),(10,24),(15,23),(18,28),(6,27)],fill='#392125');d.line([(8,22),(12,25),(17,24),(20,27)],fill='#ef9a44',width=2)
for y in(9,13,17):d.line([(9,y),(21,y)],fill='#52404a',width=1)
save(im,T/'item/ember_page.png')
im=canvas();d=ImageDraw.Draw(im);d.arc((5,1,26,22),180,540,fill='#8b8995',width=2);d.polygon([(16,12),(25,21),(16,31),(7,21)],fill='#171727',outline='#a5a0b3');d.polygon([(16,16),(21,21),(16,26),(11,21)],fill='#605681');d.line((16,18,16,24),fill='#be9eeb');save(im,T/'item/dark_pendant.png')
im=canvas();d=ImageDraw.Draw(im);d.polygon([(4,7),(23,2),(28,6),(28,27),(9,31),(4,27)],fill='#3a2830',outline='#181923');d.polygon([(9,8),(27,4),(27,25),(9,29)],fill='#44404b');d.line([(9,9),(9,28)],fill='#baa16e',width=2);d.rectangle((15,12,20,19),fill='#c2a372');d.line((13,21,22,19),fill='#c2a372',width=2);save(im,T/'item/empire_chronicle.png')
im=canvas();d=ImageDraw.Draw(im);d.polygon([(5,6),(26,3),(24,27),(8,29)],fill='#b9ac8e',outline='#55434b');d.rectangle((4,5,9,9),fill='#66555a');d.rectangle((21,24,28,28),fill='#66555a');d.ellipse((11,13,21,23),fill='#542b3a',outline='#9b6268');d.line((13,18,19,18),fill='#c6ab74');save(im,T/'item/fallen_dossier.png')
im=canvas();d=ImageDraw.Draw(im);d.polygon([(10,20),(23,3),(29,1),(29,7),(14,23)],fill='#6c8a94',outline='#202d39');d.line([(13,20),(26,5)],fill='#d2e0d8',width=2);d.line([(8,18),(17,27)],fill='#372c30',width=4);d.line([(8,18),(17,27)],fill='#b49b60',width=2);d.line([(11,23),(5,29)],fill='#332737',width=4);d.line([(11,23),(5,29)],fill='#77624c',width=2);d.rectangle((2,27,6,31),fill='#c1a86a');save(im,T/'item/slot_holy_sword.png')
im=canvas();d=ImageDraw.Draw(im);d.polygon([(5,10),(8,5),(12,7),(16,2),(20,7),(24,5),(27,11),(26,27),(21,30),(20,17),(12,17),(11,30),(6,27)],fill='#383e4f',outline='#8a90a7');d.line([(8,11),(24,11)],fill='#b69a61',width=2);d.rectangle((10,14,13,15),fill='#aa91ef');d.rectangle((19,14,22,15),fill='#aa91ef');save(im,T/'item/eskarchi_soul.png')
# Five 64px UV skins: plate knight, charred priest, dark hood, oath paladin, crowned boss.
colours={
'slot_knight':('#46505b','#927549','#9fa7ac'),
'central_priest':('#453744','#ba7441','#a59b8b'),
'dark_apostle':('#232736','#655a85','#9a9da8'),
'slot_paladin':('#777975','#bea977','#b9cbd0'),
'eskarchi':('#252938','#bea15f','#a0a5b4')}
for key,(base,trim,face) in colours.items():
    im=Image.new('RGBA',(64,64),(0,0,0,0));d=ImageDraw.Draw(im)
    regions=[(0,0,31,15),(16,16,39,31),(40,16,55,31),(0,16,15,31),(32,48,47,63),(16,48,31,63)]
    for r in regions:d.rectangle(r,fill=base)
    for r in regions:
        for n in range(60):
            x=rng.randint(r[0],r[2]);y=rng.randint(r[1],r[3]);v=im.getpixel((x,y));delta=rng.choice((-8,-4,4,8));im.putpixel((x,y),tuple(max(0,min(255,c+delta))for c in v[:3])+(255,))
    d.rectangle((8,8,15,15),fill=face)
    if key in('slot_knight','slot_paladin','eskarchi'):
        d.rectangle((8,8,15,11),fill=base);d.line((8,11,15,11),fill=trim);d.rectangle((8,13,15,15),fill=base);d.line((11,9,11,15),fill=trim)
    else:d.rectangle((8,8,15,9),fill=base);d.rectangle((8,14,15,15),fill=base)
    glow='#d9c19a' if key in('slot_knight','central_priest')else '#ad9ee7'
    d.point((10,12),fill=glow);d.point((13,12),fill=glow)
    d.rectangle((20,20,27,21),fill=trim);d.line((23,22,23,28),fill=trim,width=2);d.rectangle((20,28,27,29),fill=trim)
    for x,y in((4,20),(44,20),(36,52),(20,52)):
        d.rectangle((x,y,x+3,y+1),fill=trim);d.rectangle((x,y+8,x+3,y+9),fill=trim)
    if key=='eskarchi':
        d.line((8,8,15,8),fill=trim,width=2)
        for x in(8,11,14):d.point((x,7),fill=trim)
        d.polygon([(22,22),(25,22),(26,25),(24,27),(21,25)],fill='#66517e')
    save(im,T/f'entity/fallen/{key}.png')
# Knotty bark atlas for the objective mesh.
im=Image.new('RGBA',(64,64),'#30242d');d=ImageDraw.Draw(im)
for x in range(64):
    for y in range(64):
        b=(x*19+y*7+(x//3)*11)%23
        im.putpixel((x,y),(38+b,27+b//2,34+b//2,255))
for x in range(3,64,9):d.line([(x,0),(x+2,14),(x-1,29),(x+1,50),(x,63)],fill='#7f638c',width=1)
d.polygon([(40,2),(44,0),(47,4),(44,8),(40,5)],fill='#c59bed');save(im,T/'entity/fallen/cursed_root.png')
# Standard armor UV; transparent face opening, only helmet geometry is used.
im=Image.new('RGBA',(64,32),(0,0,0,0));d=ImageDraw.Draw(im);d.rectangle((0,0,31,15),fill='#303645');d.rectangle((8,8,15,15),fill='#39404e');d.rectangle((9,11,14,15),fill=(0,0,0,0));d.rectangle((8,8,15,9),fill='#b39a63');save(im,T/'models/armor/eskarchi_layer_1.png')
# Runtime JSON.
def j(path,data):
    path=RES/path;path.parent.mkdir(parents=True,exist_ok=True);path.write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n')
items=['armor_shard','ember_page','dark_pendant','empire_chronicle','fallen_dossier','slot_holy_sword','eskarchi_soul']
for name in items:j(Path(f'assets/wooltest/models/item/{name}.json'),{'parent':'minecraft:item/handheld' if name=='slot_holy_sword'else'minecraft:item/generated','textures':{'layer0':f'wooltest:item/{name}'}})
for name in['slot_knight','central_priest','dark_apostle','eskarchi']:j(Path(f'assets/wooltest/models/item/{name}_spawn_egg.json'),{'parent':'minecraft:item/template_spawn_egg'})
for name in['slot_knight','central_priest','dark_apostle','slot_paladin','eskarchi','cursed_root']:j(Path(f'data/wooltest/loot_tables/entities/{name}.json'),{'type':'minecraft:entity','pools':[]})
for name in('fallen_melee','fallen_magic','fallen_curse','slot_oath_share'):
    j(Path(f'data/wooltest/damage_type/{name}.json'),{'message_id':'wooltest.'+name,'scaling':'never','exhaustion':.1})
for tag in('bypasses_armor','bypasses_cooldown','bypasses_effects','bypasses_resistance','bypasses_enchantments','bypasses_shield'):
    j(Path(f'data/minecraft/tags/damage_type/{tag}.json'),{'replace':False,'values':['wooltest:slot_oath_share']})
# The curse itself is not tagged to ignore armor/shields/resistance; 70/root is base damage.
for name,col,temp,fol in[
 ('sturm_darklands',0x33363f,.5,0x565b4e),('katese_densewood',0x26352f,.6,0x394d3f),('anchino_peaks',0x484e5c,0,0x586168)]:
    j(Path(f'data/wooltest/worldgen/biome/{name}.json'),{
        'has_precipitation':False,'temperature':temp,'downfall':.0,
        'effects':{'sky_color':0x222633,'fog_color':col,'water_color':0x384851,'water_fog_color':0x1d252c,
        'grass_color':fol,'foliage_color':fol,
        'particle':{'probability':.002,'options':{'type':'minecraft:ash'}}},
        'spawners':{},'spawn_costs':{},'carvers':{},'features':[]})
j(Path('data/wooltest/dimension_type/fallen_type.json'),{
 'ultrawarm':False,'natural':False,'coordinate_scale':1.0,'has_skylight':True,'has_ceiling':False,
 'ambient_light':.12,'fixed_time':16000,'piglin_safe':False,'bed_works':True,'respawn_anchor_works':False,
 'has_raids':False,'min_y':0,'height':256,'logical_height':256,'infiniburn':'#minecraft:infiniburn_overworld',
 'effects':'minecraft:overworld','monster_spawn_block_light_limit':0,'monster_spawn_light_level':0})
j(Path('data/wooltest/dimension/fallen_realm.json'),{'type':'wooltest:fallen_type','generator':{
 'type':'wooltest:fallen_realm','biome_source':{'type':'wooltest:fallen_regions','darklands':'wooltest:sturm_darklands','densewood':'wooltest:katese_densewood','peaks':'wooltest:anchino_peaks'}}})
zh={
 'biome.wooltest.sturm_darklands':'斯特姆暗域','biome.wooltest.katese_densewood':'卡忒塞西密林','biome.wooltest.anchino_peaks':'安奇諾峰群',
 'dimension.wooltest.fallen_realm':'落王遺境',
 'entity.wooltest.slot_knight':'帝國騎士','entity.wooltest.central_priest':'央法祭司','entity.wooltest.dark_apostle':'黯謁使徒',
 'entity.wooltest.slot_paladin':'帝國聖騎士','entity.wooltest.eskarchi':'斯洛特主宰－厄斯卡奇','entity.wooltest.cursed_root':'纏咒木根',
 'item.wooltest.armor_shard':'鎧甲碎塊','item.wooltest.ember_page':'餘燼殘頁','item.wooltest.dark_pendant':'漆暗吊墜',
 'item.wooltest.empire_chronicle':'帝國編年史','item.wooltest.fallen_dossier':'殞落卷宗','item.wooltest.slot_holy_sword':'斯洛特聖劍','item.wooltest.eskarchi_soul':'厄斯卡奇之靈',
 'tooltip.wooltest.fallen_sword.attack':'攻擊力：12.00','tooltip.wooltest.fallen_sword.speed':'攻擊速度：1.60',
 'tooltip.wooltest.soul_helmet.armor':'盔甲值：3.00','tooltip.wooltest.soul_helmet.toughness':'盔甲韌性：2.00'}
for name in('slot_knight','central_priest','dark_apostle','eskarchi'):zh['item.wooltest.'+name+'_spawn_egg']=zh['entity.wooltest.'+name]+'生怪蛋'
for name in('fallen_melee','fallen_magic','fallen_curse','slot_oath_share'):
    zh['death.attack.wooltest.'+name]='%1$s 被落王遺境的力量吞噬了'
    zh['death.attack.wooltest.'+name+'.player']='%1$s 被 %2$s 的禁咒擊倒了'
for lang in('zh_tw','en_us'):
    path=RES/f'assets/wooltest/lang/{lang}.json';old=json.loads(path.read_text());old.update(zh)
    if lang=='en_us':
        names=dict(zip(items,['Armor Shard','Ember Page','Dark Pendant','Empire Chronicle','Fallen Dossier','Slot Holy Sword',"Eskarchi's Spirit"]))
        old.update({'item.wooltest.'+k:v for k,v in names.items()})
    path.write_text(json.dumps(old,ensure_ascii=False,indent=2)+'\n')
print('Created 7 item icons, 5 humanoid skins, 1 root atlas, 1 helmet texture; JSON resources and language entries.')
