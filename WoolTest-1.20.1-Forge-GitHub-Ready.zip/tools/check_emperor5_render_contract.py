#!/usr/bin/env python3
"""Compile/run the ACTUAL renderer model against explicit API test doubles.
Checks Java types, bone binding, animation/reset and vertex emission bookkeeping.
NOT compilation against Minecraft/Forge binaries; NOT visual GPU verification.
"""
from pathlib import Path
import subprocess,tempfile,json
P=Path(__file__).resolve().parent.parent
sources={
'com/mojang/blaze3d/vertex/PoseStack.java':'''package com.mojang.blaze3d.vertex;
public class PoseStack { public int depth=1; private final Pose pose=new Pose(); public void pushPose(){depth++;}
public void popPose(){if(--depth<1)throw new AssertionError("stack underflow");}
public Pose last(){return pose;} public void translate(double x,double y,double z) {if(!Double.isFinite(x+y+z))throw new AssertionError();}
public static class Pose { public Object pose(){return this;}public Object normal(){return this;} } }''',
'com/mojang/blaze3d/vertex/VertexConsumer.java':'''package com.mojang.blaze3d.vertex;
public class VertexConsumer { public int vertices; public VertexConsumer vertex(Object m,float x,float y,float z){if(!Float.isFinite(x+y+z))throw new AssertionError();return this;}
public VertexConsumer color(float r,float g,float b,float a){return this;} public VertexConsumer uv(float u,float v){if(u<0||u>1||v<0||v>1)throw new AssertionError();return this;}
public VertexConsumer overlayCoords(int i){return this;}public VertexConsumer uv2(int i){return this;}
public VertexConsumer normal(Object m,float x,float y,float z){if(!Float.isFinite(x+y+z))throw new AssertionError();return this;}public void endVertex(){vertices++;}}''',
'dev/sushi/wooltest/WoolTestMod.java':'''package dev.sushi.wooltest;public class WoolTestMod{public static final String MOD_ID="wooltest";}''',
'dev/sushi/wooltest/entity/EmperorEntity.java':'''package dev.sushi.wooltest.entity;public class EmperorEntity{public boolean charge;public boolean isChargingSpell(){return charge;}}''',
'net/minecraft/resources/ResourceLocation.java':'''package net.minecraft.resources;public record ResourceLocation(String namespace,String path){}''',
'net/minecraft/world/entity/HumanoidArm.java':'''package net.minecraft.world.entity;public enum HumanoidArm{LEFT,RIGHT}''',
'net/minecraft/util/Mth.java':'''package net.minecraft.util;public class Mth{public static final float PI=(float)Math.PI,DEG_TO_RAD=PI/180;public static float clamp(float x,float a,float b){return Math.max(a,Math.min(x,b));}public static float cos(float x){return (float)Math.cos(x);}public static float sin(float x){return (float)Math.sin(x);}public static float sqrt(float x){return (float)Math.sqrt(x);}}''',
'net/minecraft/client/model/ArmedModel.java':'''package net.minecraft.client.model;import com.mojang.blaze3d.vertex.PoseStack;import net.minecraft.world.entity.HumanoidArm;public interface ArmedModel{void translateToHand(HumanoidArm arm,PoseStack pose);}''',
'net/minecraft/client/model/HierarchicalModel.java':'''package net.minecraft.client.model;import com.mojang.blaze3d.vertex.*;import net.minecraft.client.model.geom.ModelPart;
public abstract class HierarchicalModel<T>{public float attackTime;public abstract ModelPart root();public abstract void setupAnim(T e,float a,float b,float c,float d,float f);public abstract void renderToBuffer(PoseStack p,VertexConsumer v,int l,int o,float r,float g,float b,float a);}''',
'net/minecraft/client/model/geom/ModelLayerLocation.java':'''package net.minecraft.client.model.geom;import net.minecraft.resources.ResourceLocation;public record ModelLayerLocation(ResourceLocation id,String layer){}''',
'net/minecraft/client/model/geom/PartPose.java':'''package net.minecraft.client.model.geom;public record PartPose(float x,float y,float z,float xr,float yr,float zr){public static PartPose offset(float x,float y,float z){return new PartPose(x,y,z,0,0,0);}public static PartPose offsetAndRotation(float x,float y,float z,float a,float b,float c){return new PartPose(x,y,z,a,b,c);}}''',
'net/minecraft/client/model/geom/ModelPart.java':'''package net.minecraft.client.model.geom;import java.util.*;import java.util.stream.*;import com.mojang.blaze3d.vertex.PoseStack;
public class ModelPart{public boolean visible=true;public float xRot,yRot,zRot;public final Map<String,ModelPart> children=new LinkedHashMap<>();public final PartPose initial;public ModelPart(PartPose p){initial=p;resetPose();}public ModelPart getChild(String s){if(!children.containsKey(s))throw new AssertionError("missing bone "+s);return children.get(s);}public Stream<ModelPart> getAllParts(){return Stream.concat(Stream.of(this),children.values().stream().flatMap(ModelPart::getAllParts));}public void resetPose(){xRot=initial.xr();yRot=initial.yr();zRot=initial.zr();}public void translateAndRotate(PoseStack p){p.translate(initial.x(),initial.y(),initial.z());if(!Float.isFinite(xRot+yRot+zRot))throw new AssertionError();}}''',
'net/minecraft/client/model/geom/builders/CubeListBuilder.java':'''package net.minecraft.client.model.geom.builders;public class CubeListBuilder{public static CubeListBuilder create(){return new CubeListBuilder();}}''',
'net/minecraft/client/model/geom/builders/PartDefinition.java':'''package net.minecraft.client.model.geom.builders;import net.minecraft.client.model.geom.*;public class PartDefinition{public final ModelPart p;public PartDefinition(PartPose pose){p=new ModelPart(pose);}public PartDefinition addOrReplaceChild(String n,CubeListBuilder c,PartPose pose){PartDefinition v=new PartDefinition(pose);p.children.put(n,v.p);return v;}}''',
'net/minecraft/client/model/geom/builders/MeshDefinition.java':'''package net.minecraft.client.model.geom.builders;import net.minecraft.client.model.geom.PartPose;public class MeshDefinition{private final PartDefinition r=new PartDefinition(PartPose.offset(0,0,0));public PartDefinition getRoot(){return r;}}''',
'net/minecraft/client/model/geom/builders/LayerDefinition.java':'''package net.minecraft.client.model.geom.builders;import net.minecraft.client.model.geom.ModelPart;public class LayerDefinition{private final MeshDefinition m;private LayerDefinition(MeshDefinition m){this.m=m;}public static LayerDefinition create(MeshDefinition m,int w,int h){return new LayerDefinition(m);}public ModelPart bakeRoot(){return m.getRoot().p;}}''',
'RenderContractTest.java':'''import dev.sushi.wooltest.client.*;import dev.sushi.wooltest.entity.*;import com.mojang.blaze3d.vertex.*;import net.minecraft.world.entity.HumanoidArm;
public class RenderContractTest{public static void main(String[] args){EmperorModel m=new EmperorModel(EmperorModel.createBodyLayer().bakeRoot());EmperorEntity e=new EmperorEntity();PoseStack p=new PoseStack();long vertices=0;int expected=3124*4;
for(int i=0;i<120;i++){e.charge=(i%2==0);m.attackTime=(i%10)/10f;m.setupAnim(e,i*.25f,(i%5)/4f,i,((i%9)-4)*15,((i%9)-4)*7);VertexConsumer v=new VertexConsumer();m.renderToBuffer(p,v,15728880,0,1,1,1,1);if(v.vertices!=expected||p.depth!=1)throw new AssertionError("base draw");vertices+=v.vertices;
VertexConsumer aura=new VertexConsumer();m.renderToBuffer(p,aura,15728880,0,1,.9f,.65f,.7f);if(aura.vertices!=expected||p.depth!=1)throw new AssertionError("aura draw");vertices+=aura.vertices;
for(HumanoidArm a:HumanoidArm.values()){p.pushPose();m.translateToHand(a,p);p.popPose();}if(p.depth!=1)throw new AssertionError("grip stack");}
m.root().visible=false;VertexConsumer hidden=new VertexConsumer();m.renderToBuffer(p,hidden,0,0,1,1,1,1);if(hidden.vertices!=0)throw new AssertionError("visibility");
System.out.println("PASS TEST DOUBLES: actual EmperorModel compiled/run; 120 pose samples, "+vertices+" emitted vertices, normal/aura parity, balanced transforms, hand paths, root visibility. NOT Forge compilation or game rendering.");}}'''
}
with tempfile.TemporaryDirectory(prefix='wooltest-render-contract-') as tmp:
 root=Path(tmp);classes=root/'classes';src=root/'src';files=[]
 for name,text in sources.items():
  f=src/name;f.parent.mkdir(parents=True,exist_ok=True);f.write_text(text);files.append(str(f))
 for name in ['EmperorModel.java','EmperorMeshData.java']:
  files.append(str(P/'src/main/java/dev/sushi/wooltest/client'/name))
 result=subprocess.run(['javac','--release','17','-encoding','UTF-8','-d',str(classes),*files],capture_output=True,text=True)
 if result.returncode:raise RuntimeError(result.stderr)
 result=subprocess.run(['java','-cp',str(classes)+':'+str(P/'src/main/resources'),'RenderContractTest'],capture_output=True,text=True)
 if result.returncode:raise RuntimeError(result.stderr)
 print(result.stdout.strip())
 (P/'validation/emperor5-render-contract.txt').write_text(result.stdout)
