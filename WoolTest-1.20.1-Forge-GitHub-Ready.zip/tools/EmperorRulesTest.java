import dev.sushi.wooltest.logic.EmperorRules;
public final class EmperorRulesTest {
 private static void eq(double e,double a,String l){if(Math.abs(e-a)>.0001)throw new AssertionError(l+": "+a+" != "+e);}
 public static void main(String[] args){
  eq(50,EmperorRules.HEALTH,"health");eq(10,EmperorRules.ATTACK,"attack");eq(100,EmperorRules.CHARGE_TICKS,"fixed five seconds");
  eq(2,EmperorRules.WIDTH,"width");eq(3,EmperorRules.HEIGHT,"height");eq(10,EmperorRules.RADIUS,"radius");
  for(int t=-10;t<=310;t++){
   int c=Math.max(0,Math.min(100,t));
   eq(c,EmperorRules.clampTicks(t),"clamp");eq(c/100,EmperorRules.completedCircles(t),"single seal");
   eq(c/100.0,EmperorRules.circleProgress(t,0),"progress");
   eq(0,EmperorRules.circleProgress(t,1),"no second stage");eq(0,EmperorRules.circleProgress(t,2),"no third stage");
   eq(c<100?0:60,EmperorRules.areaDamage(t),"fixed burst");
   eq(6,EmperorRules.damage(t,false,true),"interrupted beam only");
   eq(c<100?6:66,EmperorRules.damage(t,true,true),"combined single hit");eq(0,EmperorRules.damage(t,false,false),"miss");
  }
  for(double len:new double[]{0,.001,.1,1,5,10,32}){double d=EmperorRules.circleDistance(0,len);if(d<0||d>len)throw new AssertionError("seal placement");}
  System.out.println("PASS: production EmperorRules compiled --release17; 321 boundary ticks; fixed100 ticks, full60+6, interrupted6, one seal only. Not a Minecraft integration test.");
 }
}
