import dev.sushi.wooltest.logic.EmperorRules;

public final class EmperorRulesTest {
    private static void eq(double expected, double actual, String label) {
        if (Math.abs(expected-actual)>0.0001) throw new AssertionError(label+": "+actual+" != "+expected);
    }
    public static void main(String[] args) {
        eq(50,EmperorRules.HEALTH,"health"); eq(10,EmperorRules.ATTACK,"attack");
        eq(2,EmperorRules.WIDTH,"width/depth"); eq(3,EmperorRules.HEIGHT,"height");
        eq(0,EmperorRules.areaDamage(99),"under 5 seconds");
        eq(60,EmperorRules.areaDamage(100),"5 seconds");
        eq(120,EmperorRules.areaDamage(200),"10 seconds");
        eq(180,EmperorRules.areaDamage(300),"15 seconds");
        eq(141,EmperorRules.areaDamage(235),"11.75 seconds");
        eq(6,EmperorRules.damage(50,false,true),"early beam only");
        eq(66,EmperorRules.damage(100,true,true),"5s combined hit");
        eq(186,EmperorRules.damage(300,true,true),"15s combined hit");
        eq(6,EmperorRules.damage(300,false,true),"beam is not multiplied by circles");
        eq(0,EmperorRules.damage(300,false,false),"outside both shapes");
        eq(180,EmperorRules.areaDamage(999),"upper clamp");
        eq(0,EmperorRules.areaDamage(-10),"lower clamp");
        for (int t=0;t<=300;t++) {
            eq(t/100,EmperorRules.completedCircles(t),"circle threshold");
            float sum=0;
            for(int ring=0;ring<3;ring++) {
                float p=EmperorRules.circleProgress(t,ring);
                if(p<0||p>1)throw new AssertionError("progress bounds"); sum+=p;
            }
            eq(t/100.0,sum,"continuous circle drawing");
            double expected=t<100?0:t/20.0*10*1.2;
            eq(expected,EmperorRules.areaDamage(t),"damage at tick "+t);
        }
        for(double length:new double[]{0,.01,.1,1,2,4,16,32}) {
            double previous=-1;
            for(int ring=0;ring<3;ring++) {
                double d=EmperorRules.circleDistance(ring,length);
                if(d<0||d>length||d<previous)throw new AssertionError("invalid ring order");
                previous=d;
            }
        }
        System.out.println("PASS: EmperorRules Java 17 compilation and execution; all 301 charge ticks, thresholds, formulas, combined hits and ring placement boundaries.");
    }
}
