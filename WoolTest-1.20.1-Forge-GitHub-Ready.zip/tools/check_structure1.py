#!/usr/bin/env python3
"""Offline NBT/schema/layout/regression checks. Not a Forge or game test."""
from pathlib import Path
from io import BytesIO
import gzip
import hashlib
import json
import math
import os
import re
import struct
import subprocess
import sys
import tomllib

ROOT=Path(__file__).resolve().parent.parent
RES=ROOT/'src/main/resources'
DATA=RES/'data/wooltest'
JAVA=ROOT/'src/main/java/dev/sushi/wooltest'
checks=0

def expect(condition, detail):
    global checks
    if not condition: raise AssertionError(detail)
    checks += 1

# Decode from the real GZIP NBT bytes, independently of the writer/layout object.
class NbtReader:
    def __init__(self, data): self.stream=BytesIO(data)
    def read(self,n):
        b=self.stream.read(n)
        if len(b)!=n: raise ValueError('Truncated NBT')
        return b
    def number(self,fmt): return struct.unpack(fmt,self.read(struct.calcsize(fmt)))[0]
    def string(self): return self.read(self.number('>H')).decode('utf-8')
    def payload(self,tag):
        if tag in (1,2,3,4,5,6):
            return self.number({1:'>b',2:'>h',3:'>i',4:'>q',5:'>f',6:'>d'}[tag])
        if tag==8: return self.string()
        if tag==9:
            child=self.number('>B'); size=self.number('>i')
            if not 0 <= size <= 100000: raise ValueError('Invalid list size')
            return [self.payload(child) for _ in range(size)]
        if tag==10:
            obj={}
            while True:
                child=self.number('>B')
                if child==0: return obj
                name=self.string()
                if name in obj: raise ValueError('Duplicate tag')
                obj[name]=self.payload(child)
        raise ValueError('Unexpected NBT tag '+str(tag))
    def root(self):
        if self.number('>B') != 10: raise ValueError('Root must be a compound')
        self.string()
        result=self.payload(10)
        if self.stream.read(1): raise ValueError('Trailing bytes')
        return result

def read_template():
    return NbtReader(gzip.decompress((DATA/'structures/doll_trial_ground.nbt').read_bytes())).root()

def main():
    template=read_template()
    expect(template['DataVersion']==3465,'1.20.1 data version')
    expect(template['size']==[21,10,21],'21x21 footprint / height 10')
    palette=[p['Name'] for p in template['palette']]
    allowed={'minecraft:'+c+'_wool' for c in ['white','orange','magenta','light_blue','yellow','lime','pink','gray','light_gray','cyan','purple','blue','brown','green','red','black']}
    expect(set(palette)==allowed|{'minecraft:air'},'only wool and air')
    expect(len(template['blocks'])==4410,'complete template volume')
    cells={}
    for block in template['blocks']:
        pos=tuple(block['pos']); x,y,z=pos
        expect(pos not in cells, 'unique block positions')
        expect(0<=x<21 and 0<=y<10 and 0<=z<21,'bounds')
        expect(0<=block['state']<len(palette),'palette index')
        expect('nbt' not in block,'no chest/spawner/tile entity')
        cells[pos]=palette[block['state']]
    for x in range(21):
        for z in range(21): expect(cells[x,0,z] in allowed,'continuous ground floor')
    for x in range(7,14):
        for y in range(1,4): expect(cells[x,y,0]=='minecraft:air','walkable entrance')
    solid=[p for p,b in cells.items() if b in allowed]
    expect(len(solid)==813,'wool block count')
    expect(max(p[1] for p in solid)==9,'max local Y=9')
    expect(63+max(p[1] for p in solid)==72 and 72<128,'within dimension height')

    # Read the gate from outside the north entrance: screen-right is -X.
    for x0,glyph in [(7,['111','101','101','101','111']),
                     (11,['010','110','010','010','111'])]:
        for row,line in enumerate(glyph):
            for dx,v in enumerate(line):
                expect((cells[20-(x0+dx),8-row,0]=='minecraft:black_wool')==(v=='1'),'north-facing 01 text')

    guards=template['entities']
    expect(len(guards)==2,'exactly two embedded guardians')
    for e in guards:
        nbt=e['nbt']; x,y,z=e['pos']
        expect(nbt['id']=='wooltest:test_one','existing registered entity')
        expect(nbt['Health']==20.0 and nbt['PersistenceRequired']==1,'health/persistence')
        expect('UUID' not in nbt and 'UUIDMost' not in nbt,'no fixed UUID copied across structures')
        expect(e['pos']==nbt['Pos'],'local entity position agrees')
        expect(e['blockPos']==[math.floor(v) for v in e['pos']],'entity bounding-box anchor')
        # Existing hitbox 0.6 x 1.95; inspect every block it overlaps.
        for bx in range(math.floor(x-.3),math.floor(x+.3)+1):
            for bz in range(math.floor(z-.3),math.floor(z+.3)+1):
                expect(cells[bx,math.floor(y)-1,bz] in allowed,'solid footing')
                for by in range(math.floor(y),math.floor(y+1.95)+1):
                    expect(cells[bx,by,bz]=='minecraft:air','guardian body/head clearance')
        expect('Passengers' not in nbt,'no extra hidden mobs')

    # Verify unique chunk assignment across all four rotations and 256 origins.
    # This models vanilla's per-chunk bounding-box clipping, not Minecraft execution.
    def rot(x,z,r):
        return [(x,z),(-z,x),(-x,-z),(z,-x)][r]
    for r in range(4):
        for ox in range(16):
            for oz in range(16):
                owners=[]
                for e in guards:
                    px,pz=rot(e['blockPos'][0],e['blockPos'][2],r)
                    wx,wz=ox+px,oz+pz
                    cx,cz=wx//16,wz//16
                    expect(16*cx<=wx<16*(cx+1) and 16*cz<=wz<16*(cz+1),'unique entity chunk')
                    owners.append((wx,wz))
                expect(len(set(owners))==2,'guard anchors stay separate after rotation')
    print('PASS: GZIP NBT decoded; 21x21x10; 813 wool blocks; entrance 01; two safe, persistent guardians; rotation/chunk-anchor arithmetic.',flush=True)

    load=lambda p:json.loads((DATA/p).read_text())
    s=load('worldgen/structure/doll_trial_ground.json')
    expect(s['type']=='minecraft:jigsaw' and s['size']==1,'single-piece native jigsaw')
    expect(s['biomes']=='#wooltest:has_structure/doll_trial_ground','biome gate')
    expect(s['start_pool']=='wooltest:doll_trial_ground/start','start pool reference')
    expect(s['start_height']=={'absolute':0} and s['project_start_to_heightmap']=='WORLD_SURFACE_WG','surface projection')
    expect(s['terrain_adaptation']=='none' and s['spawn_overrides']=={},'no other terrain/spawn changes')
    tag=load('tags/worldgen/biome/has_structure/doll_trial_ground.json')
    expect(tag=={'replace':False,'values':['wooltest:wool_fields']},'only this project biome')
    pool=load('worldgen/template_pool/doll_trial_ground/start.json')
    expect(pool['fallback']=='minecraft:empty' and len(pool['elements'])==1,'one pool element')
    el=pool['elements'][0]['element']
    expect(el=={'element_type':'minecraft:single_pool_element','location':'wooltest:doll_trial_ground','processors':'minecraft:empty','projection':'rigid'},'NBT template binding')
    st=load('worldgen/structure_set/doll_trial_ground.json')
    expect(st['structures']==[{'structure':'wooltest:doll_trial_ground','weight':1}],'structure set reference')
    p=st['placement'];expect(p['type']=='minecraft:random_spread','native random spread')
    expect(p['spacing']==24 and p['separation']==12 and p['spacing']>p['separation']>=0,'spacing constraints')
    expect(0<=p['salt']<2**31,'placement salt')
    source=(JAVA/'world/WoolChunkGenerator.java').read_text()
    expect('super.createStructures(registries, state, structures, chunk, templates);' in source,'create structure starts')
    expect('super.applyBiomeDecoration(level, chunk, structures);' in source,'place structure templates')
    expect('spawnOriginalMobs(WorldGenRegion region) { }' in source,'no ambient mob generation')
    manifest=json.loads((ROOT/'validation/structure1-unchanged-files.json').read_text())
    for entry in manifest:
        expect(hashlib.sha256((ROOT/entry['path']).read_bytes()).hexdigest()==entry['sha256'],entry['path'])
    print(f'PASS: all structure references, biome restriction, placement parameters; {len(manifest)} baseline source/resource/build files preserved.',flush=True)
    expect(tomllib.loads((RES/'META-INF/mods.toml').read_text())['mods'][0]['displayName']=='Wool Test Dimension (Structure 1)','release marker')

    env=os.environ.copy();env['LANG']='C.UTF-8';env['LC_ALL']='C.UTF-8'
    subprocess.run([sys.executable,str(ROOT/'tools/check_offline.py')],check=True,env=env)
    out=ROOT/'build/offline-check';out.mkdir(parents=True,exist_ok=True)
    subprocess.run(['javac','--release','17','-encoding','UTF-8','-d',str(out),str(JAVA/'logic/PeachWoodSwordRules.java'),str(ROOT/'tools/PeachWoodSwordRulesTest.java')],check=True,env=env)
    subprocess.run(['java','-cp',str(out),'PeachWoodSwordRulesTest'],check=True,env=env)
    subprocess.run([sys.executable,str(ROOT/'tools/check_sword1_behavior.py')],check=True,env=env)
    print(f'PASS: {checks} structure/resource/regression assertions.',flush=True)
    print('NOT VERIFIED: Forge compilation, game/datapack loading, native worldgen/locate, template entity spawning, chunk save/reload, rendering and multiplayer. No playable JAR produced here.',flush=True)

if __name__=='__main__':main()
