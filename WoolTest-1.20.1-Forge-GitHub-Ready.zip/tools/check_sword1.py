#!/usr/bin/env python3
"""Sword 1 offline checks only. No Minecraft/Forge runtime is launched."""
from pathlib import Path
import hashlib, json, os, re, subprocess, sys, tomllib
from PIL import Image
ROOT=Path(__file__).resolve().parent.parent
R=ROOT/'src/main/resources'; J=ROOT/'src/main/java/dev/sushi/wooltest'
env=os.environ.copy();env['LANG']='C.UTF-8';env['LC_ALL']='C.UTF-8'
subprocess.run([sys.executable,str(ROOT/'tools/check_offline.py')],check=True,env=env)
manifest=json.loads((ROOT/'validation/sword1-unchanged-files.json').read_text())
for entry in manifest:
 assert hashlib.sha256((ROOT/entry['path']).read_bytes()).hexdigest()==entry['sha256'],entry['path']
print(f'PASS: {len(manifest)} existing FX1 files unchanged, including dimension, pillar logic/effects, mob model/renderer and existing textures/build configuration.',flush=True)
meta=tomllib.loads((R/'META-INF/mods.toml').read_text())
assert meta['mods'][0]['displayName']=='Wool Test Dimension (Model 1 + Pillar 1 + FX 1 + Sword 1)'
assert (R/'wooltest-build-info.txt').read_text().splitlines()[0]=='WOOLTEST-MODEL1-PILLAR1-FX1-SWORD1'
assert 'ITEMS.register("peach_wood_sword", PeachWoodSwordItem::new)' in (J/'ModContent.java').read_text()
model=json.loads((R/'assets/wooltest/models/item/peach_wood_sword.json').read_text())
assert model=={'parent':'minecraft:item/handheld','textures':{'layer0':'wooltest:item/peach_wood_sword'}}
p=R/'assets/wooltest/textures/item/peach_wood_sword.png'
with Image.open(p) as im:
 im.load();assert im.mode=='RGBA' and im.size==(32,32)
 alpha=list(im.getchannel('A').get_flattened_data())
 assert 0 in alpha and 255 in alpha and set(alpha)=={0,255}
 assert sum(v==255 for v in alpha)>100
# Verify the recovered texture matches the exact previous pixel-art preview, aside from backdrop.
preview=Image.open(ROOT/'art_preview/peach-wood-sword-pixel-preview.png').convert('RGBA')
small=preview.resize((32,32),Image.Resampling.NEAREST)
assert small.resize(preview.size,Image.Resampling.NEAREST).tobytes()==preview.tobytes()
background={small.getpixel((0,0)),small.getpixel((31,0))}
actual=Image.open(p).convert('RGBA')
for y in range(32):
 for x in range(32):
  old=small.getpixel((x,y));new=actual.getpixel((x,y))
  assert new==((0,0,0,0) if old in background else old)
zh=json.loads((R/'assets/wooltest/lang/zh_tw.json').read_text())
en=json.loads((R/'assets/wooltest/lang/en_us.json').read_text())
assert set(zh)==set(en)
for f in J.rglob('*.java'):
 for key in re.findall(r'"((?:tooltip|message|item)\.wooltest\.[a-z_.]+)"',f.read_text()):
  assert key in zh,(f,key)
assert zh['item.wooltest.peach_wood_sword']=='桃木劍'
assert not (R/'assets/minecraft').exists()
tag=json.loads((R/'data/minecraft/tags/items/swords.json').read_text())
assert tag=={'replace':False,'values':['wooltest:peach_wood_sword']}
assert json.loads((R/'data/wooltest/loot_tables/entities/test_one.json').read_text())['pools']==[]
entity=(J/'entity/TestOneEntity.java').read_text()
assert entity.count('spawnAtLocation(ModContent.PEACH_WOOD_SWORD.get().createRolledStack(getRandom()))')==1
assert 'PeachWoodSwordRules.shouldDrop(getRandom()::nextInt)' in entity
assert 'getBoolean(GameRules.RULE_DOMOBLOOT)' in entity
assert 'level().isClientSide' in entity
print('PASS: original transparent 32x32 sword texture, item model/tag, independent registration, bilingual normal tooltip and one death-drop code path.',flush=True)
build=ROOT/'build/offline-check';build.mkdir(parents=True,exist_ok=True)
subprocess.run(['javac','--release','17','-encoding','UTF-8','-cp',str(build),'-d',str(build),
 str(J/'logic/PeachWoodSwordRules.java'),str(ROOT/'tools/PeachWoodSwordRulesTest.java')],check=True,env=env)
subprocess.run(['java','-cp',str(build),'PeachWoodSwordRulesTest'],check=True,env=env)
subprocess.run([sys.executable,str(ROOT/'tools/check_sword1_behavior.py')],check=True,env=env)
print('NOT VERIFIED: full Forge compilation, true NBT disk/network IO, launch, real rendering, combat and multiplayer. No playable JAR has been produced here.',flush=True)
