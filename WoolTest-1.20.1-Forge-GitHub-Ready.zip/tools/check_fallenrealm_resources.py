from pathlib import Path
import json,gzip,struct,zipfile,hashlib,re,tomllib
from PIL import Image
P=Path(__file__).resolve().parents[1];R=P/'src/main/resources';J=P/'src/main/java'
# All actual assets must parse, not only new files.
js=list(R.rglob('*.json'))
for p in js:json.loads(p.read_text())
tomllib.loads((R/'META-INF/mods.toml').read_text())
items=['armor_shard','ember_page','dark_pendant','empire_chronicle','fallen_dossier','slot_holy_sword','eskarchi_soul']
entities=['slot_knight','central_priest','dark_apostle','slot_paladin','eskarchi','cursed_root']
for name in items:
    data=json.loads((R/f'assets/wooltest/models/item/{name}.json').read_text());tex=data['textures']['layer0'].split(':',1)[1]
    p=R/f'assets/wooltest/textures/{tex}.png';im=Image.open(p);assert im.size==(32,32);assert im.mode=='RGBA';assert im.getextrema()[3][1]==255
for name in entities:
    assert Image.open(R/f'assets/wooltest/textures/entity/fallen/{name}.png').size==(64,64)
    assert (R/f'data/wooltest/loot_tables/entities/{name}.json').is_file()
assert Image.open(R/'assets/wooltest/textures/models/armor/eskarchi_layer_1.png').size==(64,32)
lang=json.loads((R/'assets/wooltest/lang/zh_tw.json').read_text())
for name in items:assert 'item.wooltest.'+name in lang
for name in entities:assert 'entity.wooltest.'+name in lang
biomes=['sturm_darklands','katese_densewood','anchino_peaks']
for b in biomes:assert (R/f'data/wooltest/worldgen/biome/{b}.json').is_file() and 'biome.wooltest.'+b in lang
for name in ['fallen_curse','fallen_melee','fallen_magic','slot_oath_share']:
    assert (R/f'data/wooltest/damage_type/{name}.json').is_file();assert 'death.attack.wooltest.'+name in lang
# Root spillover, gameplay isolation, finite packet emissions, no client imports in common classes.
for p in (J/'dev/sushi/wooltest/fallen').glob('*.java'):
    assert 'import net.minecraft.client.' not in p.read_text()
boss=(J/'dev/sushi/wooltest/fallen/EskarchiEntity.java').read_text()
assert 'outstandingPaladins()' in boss and 'brokenRoots' in boss and 'players()' in boss
assert 'setBlock' not in boss and 'explode(' not in boss
assert 'FallenRules.curseDamage(lockedRoots)' in boss
assert 'dropCustomDeathLoot' in boss and 'dropEquipment(' not in boss
# Old user version is the baseline, not an unrelated prior release's expected file list.
baseline=json.loads((P/'art_source/fallenrealm1/baseline_runtime.json').read_text())
allowed={'src/main/java/dev/sushi/wooltest/WoolTestMod.java','src/main/resources/META-INF/mods.toml','src/main/resources/wooltest-build-info.txt',
         'src/main/resources/assets/wooltest/lang/zh_tw.json','src/main/resources/assets/wooltest/lang/en_us.json'}
changed=[]
for name,digest in baseline['files'].items():
    assert (P/name).is_file(),f'Missing prior file: {name}'
    if hashlib.sha256((P/name).read_bytes()).hexdigest()!=digest:assert name in allowed,name;changed.append(name)
for language,before in baseline['languages'].items():
    after=json.loads((R/f'assets/wooltest/lang/{language}.json').read_text());assert all(after[k]==v for k,v in before.items())
name='src/main/java/dev/sushi/wooltest/WoolTestMod.java'
without_hook=(P/name).read_text().replace('        dev.sushi.wooltest.fallen.FallenRealm.register(bus);\n','')
assert hashlib.sha256(without_hook.encode()).hexdigest()==baseline['files'][name]
# Decode and geometrically check every actual spawn marker/backup root position.
f=memoryview(gzip.decompress((R/'data/wooltest/fallen/landmarks.frp.gz').read_bytes()));off=0
def ii():
    global off
    n=struct.unpack_from('>i',f,off)[0];off+=4;return n
def utf():
    global off
    n=struct.unpack_from('>H',f,off)[0];off+=2;s=bytes(f[off:off+n]).decode();off+=n;return s
assert ii()==0x46525031 and ii()==1
palette=[utf()for _ in range(ii())];count=ii();assert count==3
import numpy as np
sites=[]
for _ in range(count):
    name=utf();x,z,y,w,d,h=[ii()for _ in range(6)];n=w*d*h*2;a=np.frombuffer(f[off:off+n],dtype='>u2').reshape(w,d,h);off+=n
    sites.append((name,x,z,y,a))
assert off==len(f)
name,xx,zz,yy,a=sites[0]
markers=[(-12,60),(12,60),(-16,40),(16,40),(-12,18),(12,18),(-42,-30),(42,-30),(-44,-48),(44,-48),(-12,-69),(12,-69),(0,-29)]
for x,z in markers:
    assert a[x-xx,z-zz,72-yy]!=0
    assert not a[x-xx,z-zz,73-yy:77-yy].any(),(x,z)
# Gate and interior nave have three-block-high clear walking columns.
for z in range(-28,89):
    assert not a[-xx,z-zz,73-yy:76-yy].any(),('blocked approach',z)
print('PASS: JSON files',len(js),'| 14 original texture assets | 7 items / 6 entities / 3 biomes / 3 landmarks')
print('PASS: 12 garrison markers + boss spawn + 117-block central approach; objective floor/headroom checked separately in Java.')
print('PASS: baseline runtime changed only:',changed)
print('LIMIT: checks validate data and source contracts only; not a Forge API compile, lighting or game collision test.')
