$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
$root = Split-Path $PSScriptRoot -Parent
Set-Location $root

# Download the ORIGINAL wrapper from a specific, published official Forge MDK.
# Only wrapper files are copied. This never overwrites src/, build.gradle or game saves.
$wrapper = Join-Path $root 'gradle\wrapper\gradle-wrapper.jar'
if (Test-Path $wrapper) { Write-Host 'Gradle wrapper already present.'; return }
$url = 'https://maven.minecraftforge.net/net/minecraftforge/forge/1.20.1-47.4.10/forge-1.20.1-47.4.10-mdk.zip'
$expectedSha1 = '31133abd261aa4d23672d1820db06ccec80326ad'
$cache = Join-Path $root '.bootstrap'
New-Item -ItemType Directory -Force -Path $cache | Out-Null
$zip = Join-Path $cache 'forge-1.20.1-47.4.10-mdk.zip'
if (!(Test-Path $zip)) {
    Write-Host 'Downloading official Forge MDK wrapper...'
    Invoke-WebRequest -UseBasicParsing -Uri $url -OutFile ($zip + '.part')
    Move-Item -Force ($zip + '.part') $zip
}
$actual = (Get-FileHash -Algorithm SHA1 -LiteralPath $zip).Hash.ToLowerInvariant()
if ($actual -ne $expectedSha1) {
    throw "Official MDK checksum mismatch. Delete $zip and retry; download was not executed."
}
$extract = Join-Path $cache 'mdk'
Expand-Archive -LiteralPath $zip -DestinationPath $extract -Force
$sourceWrapper = Join-Path $extract 'gradle\wrapper\gradle-wrapper.jar'
if (!(Test-Path $sourceWrapper)) { throw 'Verified MDK did not contain the expected Gradle wrapper.' }
Copy-Item -LiteralPath (Join-Path $extract 'gradlew') -Destination $root -Force
Copy-Item -LiteralPath (Join-Path $extract 'gradlew.bat') -Destination $root -Force
New-Item -ItemType Directory -Force -Path (Join-Path $root 'gradle\wrapper') | Out-Null
Copy-Item (Join-Path $extract 'gradle\wrapper\*') (Join-Path $root 'gradle\wrapper') -Force
Write-Host 'Official Gradle wrapper installed.'
