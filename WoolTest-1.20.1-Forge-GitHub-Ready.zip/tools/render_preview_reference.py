from PIL import Image, ImageDraw, ImageFont, ImageEnhance
from pathlib import Path
import json, math, numpy as np
R=Path(__file__).resolve().parent.parent
tex=Image.open(R/'src/main/resources/assets/wooltest/textures/entity/test_one.png').convert('RGBA')
spec=json.loads((R/'art_source/uv_regions.json').read_text())
F=spec['faces']

def tile(name):
 x,y,w,h=F[name]['uv']
 return tex.crop((x*2,y*2,(x+w)*2,(y+h)*2))

# Standard humanoid cuboid dimensions, not an in-game screenshot.
parts=[('head',(-4,24,-4),(4,32,4),False),
       ('body',(-4,12,-2),(4,24,2),False),
       ('arm',(-8,12,-2),(-4,24,2),False),
       ('arm',(4,12,-2),(8,24,2),True),
       ('leg',(-4,0,-2),(0,12,2),False),
       ('leg',(0,0,-2),(4,12,2),True)]

def render(yaw,ox,oy,scale=17):
 # Camera ahead of the mob, slightly above it.
 a=math.radians(yaw); e=math.radians(12)
 camera=np.array([math.sin(a)*math.cos(e), math.sin(e), math.cos(a)*math.cos(e)])
 right=np.array([math.cos(a),0,-math.sin(a)])
 up=np.cross(camera,right)
 def proj(point):
  p=np.array(point,float)
  return (ox+float(p@right)*scale, oy-float(p@up)*scale)
 allfaces=[]
 for part,(x0,y0,z0),(x1,y1,z1),mirror in parts:
  faces=[('front',[(x0,y1,z1),(x1,y1,z1),(x1,y0,z1),(x0,y0,z1)],(0,0,1)),
         ('back',[(x1,y1,z0),(x0,y1,z0),(x0,y0,z0),(x1,y0,z0)],(0,0,-1)),
         ('right',[(x0,y1,z0),(x0,y1,z1),(x0,y0,z1),(x0,y0,z0)],(-1,0,0)),
         ('left',[(x1,y1,z1),(x1,y1,z0),(x1,y0,z0),(x1,y0,z1)],(1,0,0)),
         ('top',[(x0,y1,z0),(x1,y1,z0),(x1,y1,z1),(x0,y1,z1)],(0,1,0)),
         ('bottom',[(x0,y0,z1),(x1,y0,z1),(x1,y0,z0),(x0,y0,z0)],(0,-1,0))]
  for face,points,normal in faces:
   if float(camera@np.array(normal))<=0:continue
   nface=({'right':'left','left':'right'}.get(face,face) if mirror else face)
   patch=tile(part+'_'+nface)
   if mirror:patch=patch.transpose(Image.Transpose.FLIP_LEFT_RIGHT)
   light={'front':1.0,'back':0.95,'left':0.78,'right':0.84,'top':1.12,'bottom':0.65}[face]
   patch=ImageEnhance.Brightness(patch).enhance(light)
   projected=[proj(p) for p in points]
   depth=float(np.mean(points,axis=0)@camera)
   allfaces.append((depth,projected,patch))
 canvas=Image.new('RGBA',(1180,740),(0,0,0,0))
 for depth,q,patch in sorted(allfaces,key=lambda t:t[0]):
  p0=np.array(q[0]); vx=np.array(q[1])-p0; vy=np.array(q[3])-p0
  mat=np.column_stack((vx/patch.width,vy/patch.height));inv=np.linalg.inv(mat)
  off=-inv@p0
  coeff=(inv[0,0],inv[0,1],off[0],inv[1,0],inv[1,1],off[1])
  layer=patch.transform(canvas.size,Image.Transform.AFFINE,coeff,resample=Image.Resampling.NEAREST)
  mask=Image.new('L',canvas.size,0);ImageDraw.Draw(mask).polygon(q,fill=255)
  alpha=Image.fromarray((np.asarray(layer.getchannel('A'),dtype=np.uint16)*np.asarray(mask,dtype=np.uint16)//255).astype('uint8'))
  layer.putalpha(alpha)
  canvas=Image.alpha_composite(canvas,layer)
 return canvas
out=Image.new('RGBA',(1180,740),(232,230,221,255))
d=ImageDraw.Draw(out)
d.ellipse((200,622,500,673),fill=(204,202,194,255));d.ellipse((710,622,1010,673),fill=(204,202,194,255))
out=Image.alpha_composite(out,render(25,350,646))
out=Image.alpha_composite(out,render(205,860,646))
fontdir=Path('/usr/share/fonts/truetype/dejavu')
try:
 font=ImageFont.truetype(str(fontdir/'DejaVuSans.ttf'),26)
 small=ImageFont.truetype(str(fontdir/'DejaVuSans.ttf'),17)
except OSError:
 font=ImageFont.load_default(size=26)
 small=ImageFont.load_default(size=17)
d=ImageDraw.Draw(out)
d.text((42,24),'WOOLTEST / TEST ONE',font=font,fill=(47,50,47))
d.text((42,60),'TEXTURE 1  |  Offline UV preview - not an in-game screenshot',font=small,fill=(81,84,79))
d.text((313,691),'FRONT',font=small,fill=(58,61,57));d.text((832,691),'BACK',font=small,fill=(58,61,57))
out.convert('RGB').save(R/'art_preview/test-one-preview.png')
# A strict face-only contact sheet also supports native-resolution review.
front=Image.new('RGBA',(64,80),(0,0,0,0))
front.paste(tile('head_front'),(24,4));front.paste(tile('body_front'),(24,20))
front.paste(tile('arm_front'),(16,20));front.paste(tile('arm_front').transpose(Image.Transpose.FLIP_LEFT_RIGHT),(40,20))
front.paste(tile('leg_front'),(24,44));front.paste(tile('leg_front').transpose(Image.Transpose.FLIP_LEFT_RIGHT),(32,44))
front.resize((512,640),Image.Resampling.NEAREST).save(R/'art_preview/test-one-front.png')
