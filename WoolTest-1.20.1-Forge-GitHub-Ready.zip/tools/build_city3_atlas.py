#!/usr/bin/env python3
"""City 3 atlas, drawn directly from the serialized runtime blueprint.
ReportLab and Pillow render exact cells; this is not a generative concept drawing.
"""
from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED
import json,gzip,struct,hashlib,csv,io,sys,collections
import numpy as np
from PIL import Image
from reportlab.pdfgen.canvas import Canvas
from reportlab.lib.pagesizes import A3, landscape
from reportlab.lib.utils import ImageReader
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont

P=Path(__file__).resolve().parents[1]
OUT=Path(sys.argv[1]) if len(sys.argv)>1 else P.parent/'atlas'
OUT.mkdir(parents=True,exist_ok=True)
R=P/'src/main/resources';source=R/'data/wooltest/city/capital_v3.wct.gz'
raw=gzip.decompress(source.read_bytes());magic,version,N,Y0,H,count=struct.unpack('>6i',raw[:24])
assert (magic,version,N,Y0,H)==(0x57435431,1,251,60,68)
o=24;pal=[]
for _ in range(count):
 n=struct.unpack('>H',raw[o:o+2])[0];o+=2;pal.append(raw[o:o+n].decode());o+=n
v=np.frombuffer(raw[o:],dtype='>u2').reshape(N,N,H)
assert np.array_equal(v,np.load(P/'art_source/city3/city_voxels.npy'))
zh=json.loads((R/'assets/wooltest/lang/zh_tw.json').read_text())
mat=json.loads((P/'art_source/city3/materials.json').read_text())
base={e[0]:e[3] for e in mat['base']}
for name,_,_,b,_ in mat['variants']+mat['decorations']:base[name]=base[b]
base.update(air=[255,255,255],water=[60,139,170],dirt=[117,83,53],oak_planks=[168,131,79],bookshelf=[127,100,65],crafting_table=[154,115,63],red_carpet=[156,34,38],flower_pot=[151,83,58])
actual=np.array([base[s.split(':')[1].split('[')[0]] for s in pal],dtype=np.uint8)
colors=(actual/255*.73+.27).clip(0,1);colors[0]=[1,1,1]
vanilla={'air':'空氣','water':'水','dirt':'泥土','oak_planks':'橡木材','bookshelf':'書櫃','crafting_table':'工作台','red_carpet':'紅色地毯','flower_pot':'花盆'}
names=[vanilla[s.split(':')[1].split('[')[0]] if s.startswith('minecraft:') else zh['block.wooltest.'+s.split(':')[1].split('[')[0]] for s in pal]
MAXY=int(np.nonzero(v)[2].max()+60)
sha=hashlib.sha256(source.read_bytes()).hexdigest()
font='/usr/share/fonts/truetype/arphic/uming.ttc'
pdfmetrics.registerFont(TTFont('CJK',font,subfontIndex=0))
W,HH=landscape(A3);INK=(.12,.16,.19);MUTED=(.36,.40,.43);TEAL=(.05,.36,.39)
page_index=[]

def text(c,x,y,s,size=12,font='CJK',color=INK):
 c.setFillColorRGB(*color);c.setFont(font,size);c.drawString(x,y,s)
def center(c,x,y,s,size=12,font='CJK',color=INK):
 c.setFillColorRGB(*color);c.setFont(font,size);c.drawCentredString(x,y,s)
def header(c,title,sub):
 text(c,42,HH-45,'承天城｜全城重建版',23)
 text(c,42,HH-70,title,13,color=TEAL)
 c.setFont('Helvetica',10);c.setFillColorRGB(*MUTED);c.drawRightString(W-42,HH-43,'CITY 3  /  ACTUAL RUNTIME BLUEPRINT')
 text(c,42,HH-91,sub,10,color=MUTED)
 c.setStrokeColorRGB(.75,.79,.80);c.setLineWidth(.5);c.line(42,HH-101,W-42,HH-101)
def footer(c,label):
 c.setStrokeColorRGB(.8,.82,.83);c.line(42,35,W-42,35)
 text(c,42,20,label,8,color=MUTED)
 c.setFont('Helvetica',8);c.drawRightString(W-42,20,str(c.getPageNumber()))
def page_end(c,label):footer(c,label);c.showPage()
def key(c,key,label):c.bookmarkPage(key);c.addOutlineEntry(label,key,0,False)

def guide(c,label):
 header(c,label,'逐格來自 capital_v3.wct.gz；建築初始資料，不是遊戲截圖。舊版 City 1/2 圖冊已不適用。')
 h=np.max(np.where(v>0,np.arange(H)[None,None,:],-1),axis=2)
 xx,zz=np.indices(h.shape);img=Image.fromarray(actual[v[xx,zz,h]].transpose(1,0,2)).resize((1004,1004),Image.Resampling.NEAREST)
 c.drawImage(ImageReader(img),48,157,500,500)
 c.setStrokeColorRGB(.87,.19,.35);c.setLineWidth(.8);c.line(298,157,298,657)
 center(c,298,668,'北：-Z',12);center(c,298,137,'最高方塊俯視圖｜中軸：X=0 這一列方塊',12)
 x=585;y=650
 lines=[('範圍與對稱',17),('占地 251 × 251；X、Z 都是 -125 至 125。',12),
 ('整城重建；沿 X=0 方塊列保持左右鏡像。',12),('不是南北對稱；宮殿仍在北側。',12),
 ('每一層的空氣、方塊種類與方向狀態均有比對。',12),('',8),
 ('閱讀方式',17),('上北下南；左西右東。格內兩位數是方塊代碼。',12),
 ('00 為空氣，以白色空格表示；水不是空氣。',12),('樓梯東西朝向互換，南北朝向及半磚上下不變。',12),
 ('圖冊代碼維持原順序；請以後三頁圖例查方塊狀態。',12),('',8),
 ('樓層與分區',17),('總圖逐頁列出 Y=60 至 127，共 68 層。',12),
 ('Y=60 至 99 有建築；Y=100 至 127 都是空氣。',12),('詳圖每層 16 區；每小格對應 1 個方塊位置。',12),
 ('32 層實體高度各拆 16 區，共 512 張詳圖。',12),('',8),
 ('驗證',17),('4,284,068 個位置鏡像檢查：不一致數 0。',12),
 ('離線檢查通過；Forge 編譯及遊戲實測仍未完成。',12)]
 for t,sz in lines:
  text(c,x,y,t,sz);y-=24 if sz<17 else 31
 text(c,48,91,'藍圖 SHA-256（本圖冊與模組採同一檔案）',10,color=MUTED)
 text(c,48,73,sha,9,'Helvetica',MUTED)
 page_end(c,'CITY 3 • 規劃尺寸與初始藍圖；建置原始碼 ZIP 不等於已編譯 JAR')
 for j in range(3):
  header(c,f'方塊圖例 {j+1}/3','代碼包含方塊種類與狀態。面向 east/west 的左右一對樓梯，代碼不同仍可能是正確鏡像。')
  y=HH-128
  for i in range(j*19,min((j+1)*19,len(pal))):
   c.setFillColorRGB(*colors[i]);c.rect(45,y-14,28,24,fill=1,stroke=0)
   center(c,59,y-6,f'{i:02d}',10,'Helvetica',INK)
   text(c,86,y,names[i],12)
   text(c,86,y-15,pal[i],8,'Helvetica',MUTED)
   c.setStrokeColorRGB(.87,.89,.9);c.line(45,y-22,W-45,y-22)
   y-=33
  page_end(c,'CITY 3 • 固定代碼 00–56；材質顏色只用於辨識；新燈具發光等級15，非光照模擬')
 header(c,'樓層與分區索引','每冊前 5 頁為說明、圖例與索引。總圖與詳圖採一致的世界座標方向。')
 # Height index in two columns, all 68 levels.
 for k in range(68):
  col=k//34;r=k%34;xx=45+col*285;yy=HH-130-r*17
  n=int(np.count_nonzero(v[:,:,k]));text(c,xx,yy,f'Y={k+60:03d}　非空氣 {n:,} 格',10)
 text(c,660,HH-132,'詳圖分區範圍（含兩端）',15)
 for i,(name,a,b) in enumerate([('A',-125,-63),('B',-62,0),('C',1,63),('D',64,125)]):
  text(c,660,HH-164-i*23,f'{name}：X={a} 至 {b}',12)
 for i,(name,a,b) in enumerate([('1',-125,-63),('2',-62,0),('3',1,63),('4',64,125)]):
  text(c,660,HH-277-i*23,f'{name}：Z={a} 至 {b}',12)
 text(c,660,HH-402,'每層順序：',13)
 for i,t in enumerate(['A1、B1、C1、D1','A2、B2、C2、D2','A3、B3、C3、D3','A4、B4、C4、D4']):text(c,660,HH-433-i*23,t,12)
 text(c,660,HH-558,'頁碼＝5＋16×（Y－本冊起始 Y）＋分區序號',11)
 text(c,660,HH-589,'例如 Y=72、B1：Y070–079 冊第 39 頁。',11)
 page_end(c,'CITY 3 • Y=0–59 是原維度羊毛地層，不屬於城市藍圖')

def runs(c,arr,left,bottom,cell):
 # arr is [row Z, column X]. Consecutive equal cells share a vector fill.
 nr,nc=arr.shape
 for z,row in enumerate(arr):
  ends=np.r_[0,np.flatnonzero(row[1:]!=row[:-1])+1,nc]
  yy=bottom+(nr-1-z)*cell
  for a,b in zip(ends[:-1],ends[1:]):
   code=int(row[a]);
   if code:
    c.setFillColorRGB(*colors[code]);c.rect(left+a*cell,yy,(b-a)*cell,cell,stroke=0,fill=1)

def overview():
 name='承天城_City3_逐層總圖_Y060-127.pdf';c=Canvas(str(OUT/name),pagesize=(W,HH),pageCompression=1)
 c.setTitle('承天城 City 3 全城重建版｜逐層總圖');c.setAuthor('Su SHI / WoolTest')
 guide(c,'逐層總圖｜Y=60–127')
 for iy in range(68):
  y=iy+60;arr=v[:,:,iy].T
  header(c,f'高度 Y={y:03d}｜全城水平切片',f'每格 1 方塊；非空氣 {np.count_nonzero(arr):,} 格；X/Z=-125..125；左右鏡像檢查：0 差異。')
  key(c,f'y{y}',f'Y={y:03d}')
  left=65;bottom=63;cell=2.5;span=N*cell
  runs(c,arr,left,bottom,cell)
  c.setLineWidth(.12);c.setStrokeColorRGB(.82,.84,.85)
  path=c.beginPath()
  for i in range(N+1):
   path.moveTo(left+i*cell,bottom);path.lineTo(left+i*cell,bottom+span)
   path.moveTo(left,bottom+i*cell);path.lineTo(left+span,bottom+i*cell)
  c.drawPath(path)
  c.setLineWidth(.45);c.setStrokeColorRGB(.4,.44,.46);c.rect(left,bottom,span,span)
  for index in list(range(0,251,25))+[250]:
   coord=index-125
   center(c,left+(index+.5)*cell,bottom+span+10,str(coord),8,'Helvetica')
   center(c,left+(index+.5)*cell,bottom-13,str(coord),8,'Helvetica')
   text(c,left-27,bottom+(N-index-.5)*cell-3,str(coord),8,'Helvetica')
  c.setStrokeColorRGB(.8,.1,.25);c.setLineWidth(.55);c.line(left+125.5*cell,bottom,left+125.5*cell,bottom+span)
  text(c,740,HH-134,'北 -Z ↑　東 +X →',14)
  text(c,740,HH-162,'玫紅線穿過 X=0 中心方塊列。',11)
  text(c,740,HH-184,'鏡像位置：(x,y,z) ↔ (-x,y,z)。',11)
  text(c,740,HH-206,'空白為空氣。詳圖中可查每格代碼。',11)
  used=np.unique(arr);used=used[used!=0]
  text(c,740,HH-242,'本層使用的方塊代碼',13)
  yy=HH-266
  for i,code in enumerate(used):
   xx=740+(i//22)*213;yy=HH-266-(i%22)*19
   code=int(code);c.setFillColorRGB(*colors[code]);c.rect(xx,yy-3,13,13,fill=1,stroke=0)
   text(c,xx+20,yy,f'{code:02d}　{names[code]}',9)
  if not len(used):text(c,740,HH-280,'本層全部為空氣；本頁仍完整保留。',12)
  page_index.append([name,c.getPageNumber(),y,'ALL',-125,125,-125,125])
  page_end(c,'CITY 3 • 逐層總圖；完整方塊狀態請對照圖例／詳圖；並非遊戲截圖')
 c.save();print(name,flush=True)

def detail(start):
 name=f'承天城_City3_逐格詳圖_Y{start:03d}-{min(start+9,MAXY):03d}.pdf'
 c=Canvas(str(OUT/name),pagesize=(W,HH),pageCompression=1);c.setTitle(f'承天城 City 3 全城重建版｜逐格詳圖 Y{start}–{min(start+9,MAXY)}')
 guide(c,f'逐格詳圖｜Y={start}–{min(start+9,MAXY)}')
 edges=[0,63,126,189,251]
 for y in range(start,min(start+9,MAXY)+1):
  for iz in range(4):
   for ix in range(4):
    xa,xb=edges[ix:ix+2];za,zb=edges[iz:iz+2];region=f'{chr(65+ix)}{iz+1}';arr=v[xa:xb,za:zb,y-60].T
    title=f'高度 Y={y:03d}｜{region} 區'
    header(c,title,f'X={xa-125}..{xb-126}；Z={za-125}..{zb-126}；每小格 = 1 個方塊；本區非空氣 {np.count_nonzero(arr):,} 格。')
    key(c,f'y{y}{region}',f'Y={y:03d} {region}')
    left=68;bottom=61;cell=9.6;nr,nc=arr.shape;top=bottom+nr*cell
    runs(c,arr,left,bottom,cell)
    c.setStrokeColorRGB(.69,.73,.75);c.setLineWidth(.2);path=c.beginPath()
    for i in range(nc+1):path.moveTo(left+i*cell,bottom);path.lineTo(left+i*cell,top)
    for j in range(nr+1):path.moveTo(left,bottom+j*cell);path.lineTo(left+nc*cell,bottom+j*cell)
    c.drawPath(path)
    # Every occupied cell has a code; zeros intentionally remain blank.
    c.setFont('Helvetica',6.2)
    for j in range(nr):
     yy=bottom+(nr-1-j)*cell+2.55
     for i in np.flatnonzero(arr[j]):
      code=int(arr[j,i]);col=colors[code];lum=.2126*col[0]+.7152*col[1]+.0722*col[2]
      c.setFillColorRGB(*(INK if lum>.5 else (1,1,1)))
      c.drawCentredString(left+(i+.5)*cell,yy,f'{code:02d}')
    for i in range(nc):
     c.saveState();c.translate(left+(i+.5)*cell,top+7);c.rotate(90)
     text(c,0,-2,str(xa+i-125),6,'Helvetica',MUTED);c.restoreState()
     c.saveState();c.translate(left+(i+.5)*cell,bottom-6);c.rotate(90)
     c.setFillColorRGB(*MUTED);c.setFont('Helvetica',6);c.drawRightString(0,-2,str(xa+i-125));c.restoreState()
    for j in range(nr):
     yy=bottom+(nr-j-.5)*cell-2
     c.setFillColorRGB(*MUTED);c.setFont('Helvetica',6.5);c.drawRightString(left-6,yy,str(za+j-125));c.drawString(left+nc*cell+6,yy,str(za+j-125))
    # Mark centre column as an outline without covering cell codes.
    if xa<=125<xb:
     c.setStrokeColorRGB(.8,.12,.28);c.setLineWidth(.75);c.rect(left+(125-xa)*cell,bottom,cell,nr*cell)
    text(c,730,HH-134,'上北（-Z）／右東（+X）',14)
    text(c,730,HH-163,'白色空格：00 空氣',11)
    text(c,730,HH-185,'格內代碼：請對照本冊第 2–4 頁圖例。',11)
    text(c,730,HH-207,'樓梯方向包含在代碼內，不能只按顏色施工。',11)
    # locator diagram
    l=775;b=HH-370;size=27
    for rz in range(4):
     for rx in range(4):
      c.setFillColorRGB(*((.70,.87,.86) if (rx,rz)==(ix,iz) else (.95,.96,.96)))
      c.setStrokeColorRGB(.65,.7,.71);c.rect(l+rx*size,b+(3-rz)*size,size,size,fill=1,stroke=1)
      center(c,l+(rx+.5)*size,b+(3-rz)*size+9,f'{chr(65+rx)}{rz+1}',9,'Helvetica')
    text(c,730,HH-402,'本區方塊代碼',13)
    used,counts=np.unique(arr,return_counts=True)
    usedpairs=[(int(code),int(n)) for code,n in zip(used,counts) if code]
    for j,(code,n) in enumerate(usedpairs):
     # Usually <20 used codes. Two columns safely cover all 54 codes.
     xx=730+(j//18)*215;yy=HH-427-(j%18)*19
     c.setFillColorRGB(*colors[code]);c.rect(xx,yy-3,12,12,fill=1,stroke=0)
     text(c,xx+18,yy,f'{code:02d} {names[code]} ({n})',8.6)
    if not usedpairs:text(c,730,HH-432,'本分區全部為空氣，沒有省略。',12)
    page_index.append([name,c.getPageNumber(),y,region,xa-125,xb-126,za-125,zb-126])
    page_end(c,'CITY 3 • 逐格實際藍圖；數字為 palette 代碼；樓梯、半磚、空氣均依初始狀態繪製')
 c.save();print(name,flush=True)

def rawdata():
 target=OUT/'承天城_City3_逐格原始資料.zip'
 def csv_bytes(rows):
  s=io.StringIO();w=csv.writer(s);w.writerows(rows);return ('\ufeff'+s.getvalue()).encode('utf-8')
 with ZipFile(target,'w',ZIP_DEFLATED,compresslevel=9) as z:
  z.writestr('palette.json',json.dumps(pal,ensure_ascii=False,indent=2))
  z.writestr('palette.csv',csv_bytes([['code','name','block_state']]+[[f'{i:02d}',names[i],s] for i,s in enumerate(pal)]))
  for iy in range(68):
   rows=[['Z/X']+list(range(-125,126))]+[[j-125]+[f'{int(n):02d}' for n in v[:,j,iy]] for j in range(251)]
   z.writestr(f'layers/Y{iy+60:03d}.csv',csv_bytes(rows))
  # Machine-readable every occupied position; all air remains in layer CSVs.
  with z.open('non_air_coordinates.csv','w') as f:
   f.write(b'x,y,z,code\n')
   for x in range(251):
    rows=np.argwhere(v[x]>0)
    f.write(''.join(f'{x-125},{y+60},{zz-125},{int(v[x,zz,y]):02d}\n' for zz,y in rows).encode())
  z.writestr('來源與讀法.txt',f'City 3 全城重建版。X=0 方塊列為鏡像中軸。\n來源：capital_v3.wct.gz\nSHA-256: {sha}\nCSV 列為 Z、欄為 X。Y060-Y127 每層一份。00=空氣。以方塊狀態為準，非圖片推算。\n')
 print(target.name,flush=True)

overview()
for start in (60,70,80,90):detail(start)
rawdata()
with (OUT/'圖頁索引.csv').open('w',encoding='utf-8-sig',newline='') as f:
 w=csv.writer(f);w.writerow(['檔案','頁碼','Y','分區','最小X','最大X','最小Z','最大Z']);w.writerows(page_index)
(OUT/'先讀我.txt').write_text('承天城 City 3 全城重建版。此圖冊取代 City 1/2 舊圖。\n總圖 73 頁（68 層＋5 頁說明圖例）；前三份詳圖各 165 頁，Y090–091 詳圖37頁；共512張逐格分區圖。\nY060–091 實體城市32層；Y092–127全空氣36層仍逐層列出。\n對稱為 X=0 方塊列、東西鏡像，不要求南北相同。\n所有圖及 CSV 直接解碼模組 capital_v3.wct.gz。\n完整實作與遊戲載入仍應以新版模組測試結果為準。\n',encoding='utf-8')
print('DONE atlas',flush=True)
