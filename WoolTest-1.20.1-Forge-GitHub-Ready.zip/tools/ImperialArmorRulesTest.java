import dev.sushi.wooltest.logic.ImperialArmorRules;
public final class ImperialArmorRulesTest {
 public static void main(String[] args){
  for(int i=0;i<201;i++){final int r=i;if(ImperialArmorRules.rollArmor(n->{if(n!=201)throw new AssertionError();return r;})!=100+i)throw new AssertionError();}
  for(int i=0;i<101;i++){final int r=i;if(ImperialArmorRules.rollToughness(n->{if(n!=101)throw new AssertionError();return r;})!=100+i)throw new AssertionError();}
  int[] counts=new int[5];
  for(int mask=0;mask<10000;mask++){int m=mask,total=0;for(int j=0;j<4;j++){final int v=m%10;m/=10;if(ImperialArmorRules.drops(n->{if(n!=10)throw new AssertionError();return v;}))total++;}counts[total]++;}
  int[] expect={1,36,486,2916,6561};if(!java.util.Arrays.equals(counts,expect))throw new AssertionError(java.util.Arrays.toString(counts));
  java.util.Locale.setDefault(java.util.Locale.GERMANY);
  if(!ImperialArmorRules.format(237).equals("2.37"))throw new AssertionError("locale");
  System.out.println("PASS: production armor rules; all201 armor/101 toughness rolls, four independent 90% decisions over10,000 combinations: "+java.util.Arrays.toString(counts)+"; locale-safe decimals.");
 }
}
