#!/usr/bin/env python3
"""Render the actual resource-pack cube textures offline (not a game screenshot).
Optional helper, requires Pillow and NumPy. No generated concept geometry is used.
"""
from pathlib import Path
from PIL import Image, ImageDraw, ImageFont, ImageEnhance
import numpy as np
ROOT=Path(__file__).resolve().parent.parent
DEST=ROOT/'art_preview/pillar1-preview.png'
DEST.parent.mkdir(parents=True,exist_ok=True)
TEX=ROOT/'src/main/resources/assets/wooltest/textures/block'
textures={k:Image.open(TEX/f'temporary_pillar_{k}.png').convert('RGBA')
          for k in ['front','right','back','left','end']}
canvas=Image.new('RGBA',(1280,810),(237,233,221,255))
draw=ImageDraw.Draw(canvas)
fontpath='/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf'
font=lambda n:ImageFont.truetype(fontpath,n)
draw.text((40,26),'WOOLTEST / PILLAR 1',font=font(28),fill=(43,47,45))
draw.text((40,68),'Actual 32 x 32 game textures  |  Offline UV preview, not an in-game screenshot',font=font(17),fill=(85,86,78))

def quad(image, points, light=1.0):
    pts=np.array(points,dtype=float)
    x0=int(np.floor(pts[:,0].min()));y0=int(np.floor(pts[:,1].min()))
    x1=int(np.ceil(pts[:,0].max()));y1=int(np.ceil(pts[:,1].max()))
    w=x1-x0+1;h=y1-y0+1
    rel=pts-np.array([x0,y0])
    # Affine destination-to-source transform for a parallelogram.
    a=np.array([[rel[i,0],rel[i,1],1.0] for i in [0,1,3]])
    u=np.linalg.solve(a,np.array([0.,image.width,0.]))
    v=np.linalg.solve(a,np.array([0.,0.,image.height]))
    tex=ImageEnhance.Brightness(image).enhance(light)
    warped=tex.transform((w,h),Image.Transform.AFFINE,tuple(u)+tuple(v),resample=Image.Resampling.NEAREST)
    mask=Image.new('L',(w,h));ImageDraw.Draw(mask).polygon([tuple(p) for p in rel],fill=255)
    canvas.paste(warped,(x0,y0),mask)

def column(ox,oy,left,right):
    dx,dy,dh=104,42,108
    a=(ox,oy);b=(ox+dx,oy+dy);c=(ox,oy+2*dy);d=(ox-dx,oy+dy)
    draw.ellipse((ox-143,oy+2*dy+4*dh-15,ox+143,oy+2*dy+4*dh+27),fill=(207,203,192))
    for n in range(4):
        yy=n*dh
        quad(textures[left],[(d[0],d[1]+yy),(c[0],c[1]+yy),
                            (c[0],c[1]+yy+dh),(d[0],d[1]+yy+dh)],0.98)
        quad(textures[right],[(c[0],c[1]+yy),(b[0],b[1]+yy),
                             (b[0],b[1]+yy+dh),(c[0],c[1]+yy+dh)],0.77)
    quad(textures['end'],[a,b,c,d],1.08)

column(200,139,'front','right')
column(540,139,'back','left')
draw.text((110,702),'FRONT / RIGHT',font=font(17),fill=(77,80,73))
draw.text((462,702),'BACK / LEFT',font=font(17),fill=(77,80,73))
draw.line((748,133,748,728),fill=(202,199,186),width=1)
for i,key in enumerate(['front','right','back','left','end']):
    col=i%2;row=i//2;x=800+col*216;y=142+row*192
    canvas.paste(textures[key].resize((144,144),Image.Resampling.NEAREST),(x,y))
    draw.text((x,y+151),key.upper() if key!='end' else 'TOP / BOTTOM',font=font(15),fill=(77,80,73))
draw.text((40,765),'One full cube per segment. Textures repeat over the four-block pillar. Geometry and collision are unchanged.',font=font(16),fill=(84,85,78))
canvas.convert('RGB').save(DEST)
print(DEST)
