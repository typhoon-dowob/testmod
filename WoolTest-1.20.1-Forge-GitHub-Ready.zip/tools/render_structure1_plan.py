#!/usr/bin/env python3
"""Render precise orthographic block layout from the shipped NBT, not a game screenshot."""
from pathlib import Path
import sys
from PIL import Image, ImageDraw, ImageFont
from check_structure1 import read_template
ROOT=Path(__file__).resolve().parent.parent
T=read_template();palette=[p['Name'].split(':')[1] for p in T['palette']]
colors={'white_wool':'#E4DFD6','orange_wool':'#D68331','magenta_wool':'#A95FAD','light_blue_wool':'#76ADC5','yellow_wool':'#D6B449','lime_wool':'#85AD43','pink_wool':'#CF90A9','gray_wool':'#555B5C','light_gray_wool':'#A0A49C','cyan_wool':'#407F88','purple_wool':'#735581','blue_wool':'#455A91','brown_wool':'#745442','green_wool':'#526947','red_wool':'#9C494A','black_wool':'#28262B'}
cells={tuple(b['pos']):palette[b['state']] for b in T['blocks']}
W,H=1280,940
im=Image.new('RGB',(W,H),'#F2EFE7');d=ImageDraw.Draw(im)
font_path='/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf'
font=ImageFont.truetype(font_path,24);small=ImageFont.truetype(font_path,16);title=ImageFont.truetype(font_path,32)
d.text((38,25),'WOOLTEST / DOLL TRIAL GROUND',font=title,fill='#27312F')
d.text((38,72),'21 x 21 footprint | 10 blocks high | all solid blocks are wool | two guardians',font=small,fill='#555E58')
d.text((38,98),'Actual NBT layout: schematic colours, not an in-game screenshot.',font=small,fill='#555E58')
S=25; x0,y0=40,185
# Top view: north is up; exact topmost non-air cell, one square per block.
d.text((x0,y0-38),'TOP VIEW / north entrance at top',font=font,fill='#27312F')
for z in range(21):
    for x in range(21):
        h=max(y for y in range(10) if cells[x,y,z]!='air')
        c=colors[cells[x,h,z]]
        x1,y1=x0+x*S,y0+z*S
        d.rectangle((x1,y1,x1+S-1,y1+S-1),fill=c,outline='#6B6B6650')
        if h>0: d.text((x1+4,y1+3),str(h),font=small,fill='#FFFFFF' if h>3 else '#242424')
for e in T['entities']:
    x,y,z=e['pos'];cx=x0+x*S;cy=y0+z*S
    d.ellipse((cx-8,cy-8,cx+8,cy+8),fill='#F6EB9A',outline='#171F1F',width=2)
    d.text((cx-5,cy-9),'G',font=small,fill='#171F1F')
d.text((x0,735),'Numbers = height above the floor; G = guardian position.',font=small,fill='#555E58')
# Entrance elevation: camera is north, so screen-right is -X.
x0,y0=675,260;S=25
d.text((x0,y0-75),'NORTH ENTRANCE',font=font,fill='#27312F')
d.text((x0,y0-42),'View from outside, looking south',font=small,fill='#555E58')
for sx in range(21):
    x=20-sx
    for sy in range(10):
        y=9-sy
        # Only show the gate/front wall (z=0/1), not objects behind it.
        solid=next((cells[x,y,z] for z in (0,1) if cells[x,y,z]!='air'),None)
        x1,y1=x0+sx*S,y0+sy*S
        d.rectangle((x1,y1,x1+S-1,y1+S-1),fill=colors[solid] if solid else '#D4E1E2',outline='#C5C9C0')
d.text((x0,y0+10*S+25),'The black wool sign reads 01 from the entrance.',font=small,fill='#555E58')
d.text((x0,y0+10*S+55),'Floor: natural Y=63. Highest wool block: Y=72.',font=small,fill='#555E58')
d.text((x0,y0+10*S+85),'Guardians use the existing Test One entity.',font=small,fill='#555E58')
d.text((40,832),'Native generation in new wool-field chunks; no chest, spawner block or repeating guard respawn.',font=small,fill='#555E58')
d.text((40,864),'Runtime generation, saving/reloading and entity placement still require in-game verification.',font=small,fill='#555E58')
out=ROOT/'art_preview/structure1-layout-preview.png';out.parent.mkdir(parents=True,exist_ok=True);im.save(out)
print(out)
