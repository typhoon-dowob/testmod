import dev.sushi.wooltest.city.CityLayoutData;
import java.nio.file.*;
import java.io.*;
import java.util.*;

/** Exercises the same Java decoder used in-game, with no Minecraft test doubles. */
public final class CityLayoutDataTest {
    static void require(boolean b,String message) { if(!b)throw new AssertionError(message); }
    public static void main(String[] args) throws Exception {
        Path source=Path.of(args[0]);
        CityLayoutData data=CityLayoutData.read(Files.newInputStream(source));
        long occupied=0;Set<Long> chunks=new HashSet<>();
        for(int x=-125;x<=125;x++)for(int z=-125;z<=125;z++) {
            chunks.add(((long)(x>>4)<<32) ^ ((z>>4)&0xffffffffL));
            for(int y=60;y<128;y++)if(data.paletteIndex(x,y,z)!=0)occupied++;
        }
        require(chunks.size()==256,"coverage");require(occupied>400000,"nonempty city");
        require(CityLayoutData.contains(0,0),"center");
        require(!CityLayoutData.contains(126,0),"east boundary");
        require(!CityLayoutData.contains(-126,0),"west boundary");
        require(!CityLayoutData.contains(Integer.MIN_VALUE,0),"negative overflow");
        require(!CityLayoutData.contains(Integer.MAX_VALUE,0),"positive overflow");
        require(data.paletteIndex(0,64,0)==0,"arrival air");
        require(data.paletteIndex(0,63,0)!=0,"arrival floor");
        require(data.paletteIndex(0,64,124)==0,"south gate arrival");
        require(data.paletteIndex(0,128,0)==0,"height cap");
        int touched=0;
        for(int x=-32;x<=32;x++)for(int z=-32;z<=32;z++)
            if(CityLayoutData.intersectsChunk(x,z)) touched++;
        require(touched==256,"only origin chunks touched");
        for(int c:new int[]{-100000,-999,-32,32,999,100000,Integer.MAX_VALUE,Integer.MIN_VALUE})
            require(!CityLayoutData.intersectsChunk(c,0),"far chunk replicated city");
        // Serialize in another traversal/order: same coordinate state every time.
        Random r=new Random(8673);long checksum=0;
        for(int i=0;i<100000;i++) {
            int x=r.nextInt(251)-125,z=r.nextInt(251)-125,y=r.nextInt(68)+60;
            int id=data.paletteIndex(x,y,z);checksum+=id;
            require(id==data.paletteIndex(x,y,z),"unstable data");
        }
        try { CityLayoutData.read(new ByteArrayInputStream(new byte[]{1,2,3}));throw new AssertionError("bad gzip accepted"); }
        catch(IOException expected) { }
        try { CityLayoutData.read(null);throw new AssertionError("missing input accepted"); }
        catch(FileNotFoundException expected) { }
        System.out.println("PASS: production Java decoder, origin bounds, 256 chunks, Y cap, entry air, deterministic reads, invalid data rejection.");
        System.out.println("Blueprint non-air count="+occupied+"; sampled checksum="+checksum);
    }
}
