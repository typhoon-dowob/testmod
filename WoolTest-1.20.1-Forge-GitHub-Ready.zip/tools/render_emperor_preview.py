#!/usr/bin/env python3
"""Diagnostic orthographic rendering of the shipped cuboids and exact texture atlas.
Not a Minecraft screenshot. Requires Pillow and NumPy only for this authoring preview.
"""
from pathlib import Path
import json, math
import numpy as np
from PIL import Image, ImageDraw, ImageEnhance, ImageFont
ROOT=Path(__file__).resolve().parent.parent
spec=json.loads((ROOT/'art_source/emperor1/emperor_model.json').read_text())
texture=Image.open(ROOT/'src/main/resources/assets/wooltest/textures/entity/emperor.png').convert('RGBA')
SIZE=(1440,900)
# Convert from Minecraft +Y-down / front -Z to preview +Y-up / front +Z.
def world(p): return np.array([p[0],24-p[1],-p[2]],float)
offsets={'root':np.zeros(3)}
cubes=[]
for n in spec['nodes']:
    offsets[n['name']]=offsets[n['parent']]+np.array(n['offset'],float)
    for c in n['cubes']:
        lo=offsets[n['name']]+np.array(c['origin'],float)
        hi=lo+np.array(c['size'],float)
        p=world(lo);q=world(hi)
        cubes.append((c,np.minimum(p,q),np.maximum(p,q)))

def render(yaw,ox,oy,scale=13.5):
    a=math.radians(yaw);e=math.radians(12)
    camera=np.array([math.sin(a)*math.cos(e),math.sin(e),math.cos(a)*math.cos(e)])
    right=np.array([math.cos(a),0,-math.sin(a)])
    up=np.cross(camera,right)
    def project(p): return (ox+float(p@right)*scale,oy-float(p@up)*scale)
    faces=[]
    for c,(x0,y0,z0),(x1,y1,z1) in cubes:
        for face,points,normal in [
            ('front',[(x0,y1,z1),(x1,y1,z1),(x1,y0,z1),(x0,y0,z1)],(0,0,1)),
            ('back',[(x1,y1,z0),(x0,y1,z0),(x0,y0,z0),(x1,y0,z0)],(0,0,-1)),
            ('right',[(x0,y1,z0),(x0,y1,z1),(x0,y0,z1),(x0,y0,z0)],(-1,0,0)),
            ('left',[(x1,y1,z1),(x1,y1,z0),(x1,y0,z0),(x1,y0,z1)],(1,0,0)),
            ('top',[(x0,y1,z0),(x1,y1,z0),(x1,y1,z1),(x0,y1,z1)],(0,1,0)),
            ('bottom',[(x0,y0,z1),(x1,y0,z1),(x1,y0,z0),(x0,y0,z0)],(0,-1,0))]:
            if float(camera@normal)<=0:continue
            x,y,w,h=c['faces'][face]
            patch=texture.crop((x*2,y*2,(x+w)*2,(y+h)*2))
            brightness={'front':1.04,'back':0.97,'right':0.82,'left':0.89,'top':1.13,'bottom':0.7}[face]
            patch=ImageEnhance.Brightness(patch).enhance(brightness)
            faces.append(([project(np.array(p)) for p in points],patch,np.array(points,float)))
    rgba=np.zeros((SIZE[1],SIZE[0],4),dtype=np.uint8)
    zbuffer=np.full((SIZE[1],SIZE[0]),-np.inf)
    for q,patch,points in faces:
        p0=np.array(q[0]);vx=np.array(q[1])-p0;vy=np.array(q[3])-p0
        inv=np.linalg.inv(np.column_stack((vx,vy)))
        bx=max(0,int(min(p[0] for p in q))-1);by=max(0,int(min(p[1] for p in q))-1)
        ex=min(SIZE[0],int(max(p[0] for p in q))+2);ey=min(SIZE[1],int(max(p[1] for p in q))+2)
        if ex<=bx or ey<=by:continue
        xx,yy=np.meshgrid(np.arange(bx,ex)+0.5,np.arange(by,ey)+0.5)
        coords=np.stack((xx-p0[0],yy-p0[1]),axis=0)
        uv=np.einsum('ij,jkl->ikl',inv,coords)
        u,v=uv
        inside=(u>=0)&(u<1)&(v>=0)&(v<1)
        px=np.clip((u*patch.width).astype(int),0,patch.width-1)
        py=np.clip((v*patch.height).astype(int),0,patch.height-1)
        pixels=np.asarray(patch)[py,px]
        depth=float(points[0]@camera)+u*float((points[1]-points[0])@camera)+v*float((points[3]-points[0])@camera)
        visible=inside&(pixels[:,:,3]>0)&(depth>zbuffer[by:ey,bx:ex])
        rgba[by:ey,bx:ex][visible]=pixels[visible]
        zbuffer[by:ey,bx:ex][visible]=depth[visible]
    return Image.fromarray(rgba)


out=Image.new('RGBA',SIZE,(235,231,219,255));d=ImageDraw.Draw(out)
d.ellipse((180,747,570,802),fill=(208,201,187,255));d.ellipse((880,747,1270,802),fill=(208,201,187,255))
out=Image.alpha_composite(out,render(24,375,775))
out=Image.alpha_composite(out,render(204,1075,775))
f='/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf'
try:
    title=ImageFont.truetype(f,29);small=ImageFont.truetype(f,18);tag=ImageFont.truetype(f,21)
except OSError:
    title=ImageFont.load_default();small=title;tag=title
d=ImageDraw.Draw(out)
d.text((48,27),'WOOLTEST / CHENGTIAN EMPEROR',font=title,fill=(43,48,43))
d.text((48,69),'Actual model + texture atlas | Neutral pose, held sword shown separately | NOT an in-game screenshot',font=small,fill=(87,87,75))
d.text((330,838),'FRONT',font=tag,fill=(58,65,56));d.text((1042,838),'BACK',font=tag,fill=(58,65,56))
(ROOT/'art_preview').mkdir(exist_ok=True)
out.convert('RGB').save(ROOT/'art_preview/emperor-model-preview.png')
print('Rendered exact 37-cuboid Emperor model and texture; neutral pose; held item not rendered.')
