import dev.sushi.wooltest.city.CityLayoutData;
import java.nio.file.*;
import java.io.*;
import java.util.*;

/** Tests the exact production decoder. No Minecraft or Forge API stubs. */
public final class City4LayoutTest {
    private static void check(boolean b,String m) { if(!b)throw new AssertionError(m); }
    private static String reflect(String s) {
        return s.replace("facing=east","facing=TEMP").replace("facing=west","facing=east").replace("facing=TEMP","facing=west");
    }
    public static void main(String[] args) throws Exception {
        CityLayoutData d=CityLayoutData.read(Files.newInputStream(Path.of(args[0])));
        List<String> p=d.palette();int[] mirror=new int[p.size()];
        for(int i=0;i<p.size();i++){mirror[i]=p.indexOf(reflect(p.get(i)));check(mirror[i]>=0,"missing mirror");}
        long cells=0, occupied=0;
        for(int x=-125;x<=125;x++)for(int z=-125;z<=125;z++)for(int y=60;y<=127;y++){
            int a=d.paletteIndex(x,y,z);check(a==mirror[d.paletteIndex(-x,y,z)],"mirror at "+x+","+y+","+z);
            if(a!=0)occupied++;cells++;
            if(y>91)check(a==0,"unexpected geometry above actual roof height");
        }
        check(occupied==384256,"city data was modified; regenerate QA and drawings");
        check(d.paletteIndex(0,63,0)!=0 && d.paletteIndex(0,64,0)==0,"arrival position");
        check(d.paletteIndex(0,64,124)==0,"south bridge arrival");
        int chunks=0;
        for(int x=-32;x<=32;x++)for(int z=-32;z<=32;z++)if(CityLayoutData.intersectsChunk(x,z))chunks++;
        check(chunks==256,"fixed origin chunks");
        for(int k:new int[]{-1000,1000,Integer.MIN_VALUE,Integer.MAX_VALUE}){
            check(!CityLayoutData.contains(k,0),"overflow contains");check(!CityLayoutData.intersectsChunk(k,0),"overflow chunks");
        }
        for(int sx:new int[]{-110,110})for(int sg:new int[]{-1,1})for(int t=0;t<9;t++)
            check(p.get(d.paletteIndex(sx,64+t,sg*(92+t))).contains("capital_paving_stairs"),"wall access stairs");
        for(int x=-6;x<=6;x++)for(int z=-58;z<=125;z++)for(int y=64;y<=66;y++)
            check(d.paletteIndex(x,y,z)==0,"main avenue blocked");
        for(int x=-3;x<=3;x++)for(int y=68;y<=71;y++)
            check(d.paletteIndex(x,y,-65)==0,"main palace doorway");
        try {CityLayoutData.read(null);throw new AssertionError("null accepted");} catch(FileNotFoundException expected){}
        try {CityLayoutData.read(new ByteArrayInputStream(new byte[]{0,1,2}));throw new AssertionError("invalid accepted");}catch(IOException expected){}
        System.out.println("PASS production decoder: "+cells+" cells, "+occupied+" non-air, X symmetry, origin-only 256 chunks, entry air, road clearance, four wall stairs, invalid-file rejection.");
    }
}
