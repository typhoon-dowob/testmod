#!/usr/bin/env python3
"""Verify the actual shipped geometry, not a concept picture. No Forge runtime involved."""
from pathlib import Path
import re,sys,json,gzip,struct,hashlib,tomllib
import numpy as np
from PIL import Image
P=Path(__file__).resolve().parent.parent;R=P/'src/main/resources';J=P/'src/main/java/dev/sushi/wooltest'
spec=json.loads((P/'art_source/emperor4/emperor_mesh.json').read_text());code=(J/'client/EmperorModel.java').read_text()
assert '.addBox(' not in code, 'Main model must not silently revert to cuboids'
assert 'EmperorMeshData.loadBundled()' in code
assert 'out.vertex(last.pose()' in code and 'normal(last.normal()' in code
raw=gzip.decompress((R/'assets/wooltest/geometry/emperor4.wem.gz').read_bytes())
assert raw[:4]==b'WEM4';version,count=struct.unpack('>ii',raw[4:12]);assert version==1 and count==len(spec['nodes']);ptr=12
known={'root':np.zeros(3)};allpoints=[];faces=0
for n in spec['nodes']:
 ln=struct.unpack('>H',raw[ptr:ptr+2])[0];ptr+=2;name=raw[ptr:ptr+ln].decode();ptr+=ln
 q=struct.unpack('>i',raw[ptr:ptr+4])[0];ptr+=4
 assert name==n['name'] and q==len(n['quads'])
 v=np.frombuffer(raw[ptr:ptr+q*128],dtype='>f4').astype(float).reshape(q,4,8);ptr+=q*128
 target=np.array([x['v'] for x in n['quads']]);assert np.allclose(v,target,rtol=0,atol=1e-5)
 assert np.isfinite(v).all() and ((v[:,:,6:8]>=0)&(v[:,:,6:8]<=1)).all()
 assert np.allclose(np.linalg.norm(v[:,:,3:6],axis=2),1,atol=1e-5)
 assert (np.linalg.norm(np.cross(v[:,1,:3]-v[:,0,:3],v[:,2,:3]-v[:,0,:3]),axis=1)>1e-7).all()
 known[name]=known[n['parent']]+np.array(n['offset']);allpoints.append(v[:,:,:3]+known[name]);faces+=q
 # Skeleton in the actual Java must match the exported pivots and resting rotations.
 pattern=rf'{name} = {n["parent"]}\.addOrReplaceChild\("{name}", CubeListBuilder.create\(\), PartPose\.(offsetAndRotation|offset)\((.*?)\)\);'
 m=re.search(pattern,code);assert m,name
 actual=[float(x.strip().rstrip('F')) for x in m[2].split(',')]
 expected=n['offset']+(n['rotation'] if m[1]=='offsetAndRotation' else [])
 assert np.allclose(actual,expected,atol=1e-7)
assert ptr==len(raw)
allv=np.concatenate([x.reshape(-1,3) for x in allpoints]);bounds=[allv.min(axis=0).tolist(),allv.max(axis=0).tolist()]
assert abs(bounds[0][1]+24)<1e-6 and abs(bounds[1][1]-24)<1e-6
assert bounds[0][0]>=-16 and bounds[1][0]<=16
tex=np.array(Image.open(R/'assets/wooltest/textures/entity/emperor.png').convert('RGBA'))
mask=np.array(Image.open(R/'assets/wooltest/textures/entity/emperor_charge.png').convert('RGBA'))
assert tex.shape==mask.shape==(512,512,4) and (mask[:,:,3]>0).any()
assert np.all(mask[:,:,3]<=tex[:,:,3])
# All referenced face UVs must sample opaque base atlas data, no accidental holes.
for n in spec['nodes']:
 for q in n['quads']:
  verts=np.array(q['v']);uv=verts[:,6:8]
  for u,v in list(uv)+[uv.mean(axis=0)]:assert tex[min(511,int(v*512)),min(511,int(u*512)),3]==255
base=json.loads((P/'art_source/emperor4/baseline_runtime_sha256.json').read_text())
allowed={'src/main/java/dev/sushi/wooltest/client/EmperorModel.java',
 'src/main/resources/assets/wooltest/textures/entity/emperor.png',
 'src/main/resources/assets/wooltest/textures/entity/emperor_charge.png',
 'src/main/resources/META-INF/mods.toml','src/main/resources/wooltest-build-info.txt'}
changed=[];same=[]
for rel,h in base.items():
 assert (P/rel).is_file(),rel
 if hashlib.sha256((P/rel).read_bytes()).hexdigest()!=h:
  assert rel in allowed,rel;changed.append(rel)
 else:same.append(rel)
new=[f.relative_to(P).as_posix() for f in (P/'src').rglob('*') if f.is_file() and f.relative_to(P).as_posix() not in base]
assert set(new)=={'src/main/java/dev/sushi/wooltest/client/EmperorMeshData.java','src/main/resources/assets/wooltest/geometry/emperor4.wem.gz'},new
for f in J.rglob('*.java'):
 if 'client' not in f.parts:assert 'import net.minecraft.client.' not in f.read_text(),f
jsons=0
for f in R.rglob('*.json'):json.loads(f.read_text());jsons+=1
meta=tomllib.loads((R/'META-INF/mods.toml').read_text());assert 'Emperor 4 - Flowing' in meta['mods'][0]['displayName']
report={'status':'PASS','bones':count,'quads':faces,'runtime_mesh_matches_authoring':True,
 'mesh_parser_version':version,'minecraft_uv_bounds_valid':True,'uv_alpha_samples_valid':True,
 'finite_vertices_and_unit_normals':True,'java_skeleton_matches_mesh':True,'large_box_primitives':0,
 'bind_pose_bounds_model_pixels':bounds,'height_blocks':3,'collision_preserved':[2,2,3],
 'original_runtime_files_unchanged':len(same),'changed_existing_runtime_files':changed,'added_runtime_files':new,
 'resource_jsons_parsed':jsons,
 'limits':'Offline data/source checks only. Not a complete Forge API compile or an in-game test. Cloth movement is skeletal, not physics simulation.'}
(P/'validation/emperor4-checks.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
