param([ValidateSet('build', 'client', 'server')][string]$Task = 'build')
$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest
$root = Split-Path $PSScriptRoot -Parent
Set-Location $root
try {
    if ($env:JAVA_HOME) {
        $java = Join-Path $env:JAVA_HOME 'bin\java.exe'
        $javac = Join-Path $env:JAVA_HOME 'bin\javac.exe'
        if (!(Test-Path $java) -or !(Test-Path $javac)) {
            throw 'JAVA_HOME must point to a JDK 17 installation, not a JRE.'
        }
        $env:PATH = (Join-Path $env:JAVA_HOME 'bin') + ';' + $env:PATH
    } else {
        $java = (Get-Command java.exe -ErrorAction Stop).Source
        $javac = (Get-Command javac.exe -ErrorAction Stop).Source
    }
    # Native stderr is redirected through cmd to avoid PowerShell 5 treating java -version as an error.
    $version = (& cmd /c ('"' + $java + '" -version 2>&1')) -join "`n"
    if ($version -notmatch 'version "17[\."]') {
        throw "Use a 64-bit JDK 17 and set JAVA_HOME to it. Detected:`n$version"
    }
    & (Join-Path $PSScriptRoot 'bootstrap.ps1')
    if (!(Test-Path (Join-Path $root 'gradle\wrapper\gradle-wrapper.jar'))) {
        throw 'Gradle bootstrap failed.'
    }
    $gradleTasks = @('clean','build')
    if ($Task -eq 'client') { $gradleTasks = @('runClient') }
    if ($Task -eq 'server') { $gradleTasks = @('runServer') }
    Write-Host ('Running Gradle: ' + ($gradleTasks -join ' '))
    $ErrorActionPreference = 'Continue'
    & (Join-Path $root 'gradlew.bat') --no-daemon --console=plain @gradleTasks 2>&1 |
        Tee-Object -FilePath (Join-Path $root 'build-log.txt')
    $code = $LASTEXITCODE
    $ErrorActionPreference = 'Stop'
    if ($code -ne 0) { throw "Gradle failed (exit $code). See build-log.txt." }
    if ($Task -eq 'build') {
        $jar = Join-Path $root 'build\libs\wooltest-1.20.1-0.1.0.jar'
        if (!(Test-Path $jar)) { throw 'Gradle returned success but the expected mod JAR was not found.' }
        Write-Host "`nBuilt mod: $jar"
        Write-Host 'Copy this JAR to the mods folder of your Minecraft 1.20.1 Forge 47.4.10 instance.'
    }
    exit 0
} catch {
    Write-Host "`nBUILD FAILED: $($_.Exception.Message)" -ForegroundColor Red
    $_ | Out-String | Add-Content -LiteralPath (Join-Path $root 'build-error.txt')
    exit 1
}
