import dev.sushi.wooltest.fallen.*;
import java.io.*;
import java.nio.file.*;
import java.util.*;
public final class FallenRulesTest {
    private static int tests;
    private static void check(boolean ok,String message){tests++;if(!ok)throw new AssertionError(message);}
    public static void main(String[] args)throws Exception {
        check(FallenRules.PALADINS==3,"three paladins");check(FallenRules.ROOTS==5,"five roots");
        check(FallenRules.ROOT_WINDOW==300,"15 seconds at20TPS");check(FallenRules.DETONATION_WINDUP==40,"two-second windup");
        for(int r=-5;r<=10;r++)check(FallenRules.curseDamage(r)==Math.max(0,Math.min(5,r))*70,"damage "+r);
        for(int t=0;t<=500;t++)check(FallenRules.remainingTicks(t,300)==Math.max(0,300-t),"clock "+t);
        for(int hundredths=0;hundredths<=10000;hundredths++){
            float d=hundredths/100F,each=FallenRules.desiredShare(d,.2);
            for(int count=0;count<=3;count++){
                float[] shares=new float[count];Arrays.fill(shares,each);
                float actual=FallenRules.damageAfterShare(d,shares);
                check(Math.abs(actual-d*(1-.2*count))<.0001,"share conservation");
            }
        }
        check(FallenRules.damageAfterShare(100,new float[]{1,20,20})==59,"dying guard cannot absorb phantom damage");
        check(FallenRules.damageAfterShare(100,new float[]{0,0,0})==100,"cancelled redirects");
        check(FallenRules.desiredShare(Float.NaN,.2)==0,"NaN safety");
        check(FallenRules.inside(21,0,24,0,0,0),"arena inclusive border");
        check(!FallenRules.inside(21.01,0,24,0,0,0),"outside arena");
        check(!FallenRules.inside(0,14,0,0,0,0),"not a dimension-wide curse");
        for(int[] site:FallenTerrain.SITES){
            check(FallenTerrain.height(site[0],site[1])==72,"landmark plateau");
            check(!FallenTerrain.vegetationAllowed(site[0],site[1]),"no trees inside buildings");
        }
        int[] biomeCounts=new int[3];int low=256,high=0;
        for(int x=-1600;x<=1600;x+=16)for(int z=-1600;z<=1600;z+=16){
            int h=FallenTerrain.height(x,z),b=FallenTerrain.biome(x,z);low=Math.min(low,h);high=Math.max(high,h);biomeCounts[b]++;
            check(h>=1&&h<220,"height safety");check(b>=0&&b<=2,"biome id");
            check(h==FallenTerrain.height(x,z),"determinism");
        }
        check(Arrays.stream(biomeCounts).allMatch(n->n>100),"all three biomes reachable");
        FallenLayoutData data;try(InputStream in=Files.newInputStream(Path.of(args[0]))){data=FallenLayoutData.read(in);}
        check(data.sites().size()==3,"landmark count");
        long nonAir=0;
        for(var site:data.sites()){
            check(!site.contains(site.minX()-1,site.minZ()),"west exterior");
            check(site.index(site.minX(),255,site.minZ())==0,"above landmark");
            for(char c:site.cells()){check(c<data.palette().size(),"palette range");if(c!=0)nonAir++;}
        }
        var center=data.sites().get(0);
        for(int x=-14;x<=14;x++)for(int z=-43;z<=-15;z++){
            check(center.index(x,72,z)!=0,"solid objective floor");
            for(int y=73;y<=76;y++)check(center.index(x,y,z)==0,"clear root/guardian arena");
        }
        System.out.println("PASS: "+tests+" pure-Java rule/layout assertions; biome samples "+Arrays.toString(biomeCounts)+", height "+low+".."+high+", non-air landmark cells "+nonAir);
        System.out.println("NOT a Forge compile or in-game integration test.");
    }
}
