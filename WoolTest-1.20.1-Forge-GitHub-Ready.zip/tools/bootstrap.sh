#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"
if [[ -s gradle/wrapper/gradle-wrapper.jar ]]; then
  echo 'Gradle wrapper already present.'
  exit 0
fi
URL='https://maven.minecraftforge.net/net/minecraftforge/forge/1.20.1-47.4.10/forge-1.20.1-47.4.10-mdk.zip'
SHA1='31133abd261aa4d23672d1820db06ccec80326ad'
mkdir -p .bootstrap
ZIP='.bootstrap/forge-1.20.1-47.4.10-mdk.zip'
if [[ ! -s "$ZIP" ]]; then
  curl --fail --location --retry 2 --connect-timeout 20 "$URL" -o "$ZIP.part"
  mv "$ZIP.part" "$ZIP"
fi
if command -v sha1sum >/dev/null 2>&1; then
  ACTUAL="$(sha1sum "$ZIP" | cut -d ' ' -f 1)"
else
  ACTUAL="$(shasum -a 1 "$ZIP" | cut -d ' ' -f 1)"
fi
if [[ "$ACTUAL" != "$SHA1" ]]; then
  echo "MDK checksum mismatch. Delete $ZIP and retry." >&2
  exit 1
fi
# Extract only the original build wrapper, not the example mod.
unzip -o "$ZIP" gradlew gradlew.bat 'gradle/wrapper/*' >/dev/null
chmod +x gradlew
echo 'Official Gradle wrapper installed.'
