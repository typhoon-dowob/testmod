"""Source regression guard only. This is not a Minecraft/Forge API compilation."""
from pathlib import Path
import re

root = Path(__file__).resolve().parent.parent
source = (root / 'src/main/java/dev/sushi/wooltest/entity/EmperorEntity.java').read_text(encoding='utf-8')
assert not re.search(r'\bvoid\s+dropEquipment\s*\(', source), "Wrong-mapping dropEquipment hook returned"
pattern = r'@Override\s+protected\s+void\s+dropCustomDeathLoot\s*\(\s*DamageSource\s+source\s*,\s*int\s+lootingLevel\s*,\s*boolean\s+recentlyHit\s*\)\s*\{([^}]*)\}'
match = re.search(pattern, source, re.S)
assert match, "Expected Forge 1.20.1 Mojmap death-drop hook missing"
body = re.sub(r'//[^\n]*', '', match.group(1))
assert not body.strip(), "Death-drop suppression policy changed"
assert "mappings channel: 'official'" in (root/'build.gradle').read_text(encoding='utf-8')
assert 'minecraft_version=1.20.1' in (root/'gradle.properties').read_text(encoding='utf-8')
assert 'forge_version=47.4.10' in (root/'gradle.properties').read_text(encoding='utf-8')
print('PASS: expected override name/signature, retained @Override, empty hook body, unchanged version/mapping settings.')
print('LIMITATION: source assertions only; actual inherited API is checked by compileJava in the real Forge build.')
