import javax.tools.*;
import com.sun.source.util.JavacTask;
import java.io.File;
import java.nio.file.*;
import java.util.*;

/** Syntax-only validation: no Forge/Minecraft type resolution occurs. */
public final class ParseJava {
    public static void main(String[] args) throws Exception {
        JavaCompiler compiler = ToolProvider.getSystemJavaCompiler();
        if (compiler == null) throw new IllegalStateException("Requires a JDK");
        DiagnosticCollector<JavaFileObject> diagnostics = new DiagnosticCollector<>();
        try (StandardJavaFileManager manager = compiler.getStandardFileManager(diagnostics, null, null)) {
            List<File> files;
            try (var paths = Files.walk(Path.of(args[0]))) {
                files = paths.filter(p -> p.toString().endsWith(".java")).map(Path::toFile).toList();
            }
            JavacTask task = (JavacTask) compiler.getTask(null, manager, diagnostics,
                    List.of("-proc:none", "--release", "17", "-encoding", "UTF-8"), null,
                    manager.getJavaFileObjectsFromFiles(files));
            task.parse();
            boolean error = false;
            for (var d : diagnostics.getDiagnostics()) {
                if (d.getKind() == Diagnostic.Kind.ERROR) { error = true; System.err.println(d); }
            }
            if (error) System.exit(1);
            System.out.println("PASS: Java 17 syntax parsing for " + files.size()
                    + " source files. API/linkage NOT verified.");
        }
    }
}
