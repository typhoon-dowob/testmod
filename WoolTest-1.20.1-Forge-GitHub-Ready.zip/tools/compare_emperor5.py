#!/usr/bin/env python3
"""Render exact meshes from an Emperor 4 source ZIP and this Emperor 5 project.
Comparisons use the same camera, physical model scale and resting animation.
Not concept art or Minecraft screenshots. No held sword or spell entity rendering.
"""
from pathlib import Path
import json,struct,gzip,zipfile,io,math,sys
import numpy as np
from PIL import Image,ImageDraw
import render_emperor5 as R

def old_data(path):
    with zipfile.ZipFile(path) as z:
        spec=json.loads(z.read('art_source/emperor4/emperor_mesh.json'))
        data=gzip.decompress(z.read('src/main/resources/assets/wooltest/geometry/emperor4.wem.gz'))
        texture=np.array(Image.open(io.BytesIO(z.read('src/main/resources/assets/wooltest/textures/entity/emperor.png'))).convert('RGBA'))
    meshes={};pos=12
    for _ in range(struct.unpack('>i',data[8:12])[0]):
        n=struct.unpack('>H',data[pos:pos+2])[0];pos+=2
        name=data[pos:pos+n].decode('ascii');pos+=n
        q=struct.unpack('>i',data[pos:pos+4])[0];pos+=4
        meshes[name]=np.frombuffer(data[pos:pos+128*q],dtype='>f4').astype(float).reshape(q,4,8);pos+=128*q
    assert pos==len(data)
    return spec,meshes,texture

def exact_scene(data):
    saved=R.spec,R.meshes,R.texture
    try:
        R.spec,R.meshes,R.texture=data
        return R.scene(),R.texture
    finally:
        R.spec,R.meshes,R.texture=saved

def focused_render(tris,tex,yaw=8,size=(740,670),focus=(0,40.0,0),scale=37):
    a=math.radians(yaw);el=math.radians(5)
    cam=np.array([math.sin(a)*math.cos(el),math.sin(el),math.cos(a)*math.cos(el)])
    right=np.array([math.cos(a),0,-math.sin(a)]);up=np.cross(cam,right)
    p=tris[:,:,:3]-np.array(focus);depth=p@cam
    screen=np.stack([p@right,-p@up],axis=-1)*scale+np.array([size[0]/2,size[1]/2])
    return Image.fromarray(R.raster(screen,depth,tris[:,:,3:6],tris[:,:,6:8],tex,*size))

def main(path):
    old=old_data(path);new=R.spec,R.meshes,R.texture
    outdir=R.P/'art_preview';outdir.mkdir(exist_ok=True)
    out=Image.new('RGBA',(1600,1080),(237,233,222,255));d=ImageDraw.Draw(out)
    d.text((45,25),'EMPEROR 4  >  EMPEROR 5',font=R.font(30),fill='#292d31')
    d.text((45,72),'Same camera and physical scale | Actual runtime meshes | Offline comparison; held item omitted',font=R.font(17),fill='#626464')
    for i,data in enumerate((old,new)):
        R.spec,R.meshes,R.texture=data
        img=R.render(22)
        x=20+800*i
        d.ellipse((x+240,900,x+560,945),fill=(210,204,192,255));out.alpha_composite(img,(x,0));d=ImageDraw.Draw(out)
    R.spec,R.meshes,R.texture=new
    d.text((190,1010),'BEFORE / ROUND, LONG FACE',font=R.font(21),fill='#454a4a')
    d.text((960,1010),'AFTER / FACETED, SHORT FACE',font=R.font(21),fill='#454a4a')
    out.convert('RGB').save(outdir/'emperor5-before-after.png')
    close=Image.new('RGBA',(1600,890),(237,233,222,255));d=ImageDraw.Draw(close)
    d.text((45,25),'FACE DETAIL / SAME MODEL SCALE',font=R.font(30),fill='#292d31')
    d.text((45,72),'Actual mesh geometry + texture | Face height: 10.7 > 7.8 model pixels | Beard also shortened',font=R.font(17),fill='#626464')
    for i,data in enumerate((old,new)):
        tri,tex=exact_scene(data)
        img=focused_render(tri,tex)
        close.alpha_composite(img,(30+800*i,90))
    d=ImageDraw.Draw(close)
    d.text((280,817),'EMPEROR 4',font=R.font(22),fill='#454a4a')
    d.text((1080,817),'EMPEROR 5',font=R.font(22),fill='#454a4a')
    close.convert('RGB').save(outdir/'emperor5-face-detail.png')
    print('Created exact, same-scale comparison renders.')
if __name__=='__main__':main(sys.argv[1])
