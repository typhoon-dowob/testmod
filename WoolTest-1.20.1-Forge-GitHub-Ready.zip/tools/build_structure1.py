#!/usr/bin/env python3
"""Build the original 21x21x10 all-wool arena as a Java 1.20.1 NBT template.
Only Python's standard library is required. This is an asset generator, not
Minecraft runtime code. Run from any directory; generated assets are committed.
"""
from pathlib import Path
import gzip
import json
import struct

ROOT = Path(__file__).resolve().parent.parent
RES = ROOT / 'src/main/resources/data/wooltest'
SIZE = (21, 10, 21)
ID = 'doll_trial_ground'
COLORS = ['white','orange','magenta','light_blue','yellow','lime','pink','gray',
          'light_gray','cyan','purple','blue','brown','green','red','black']
PALETTE = ['minecraft:air'] + [f'minecraft:{c}_wool' for c in COLORS]
GRID = {}

def put(x, y, z, color):
    if not (0 <= x < SIZE[0] and 0 <= y < SIZE[1] and 0 <= z < SIZE[2]):
        raise ValueError((x,y,z))
    GRID[x,y,z] = PALETTE.index(f'minecraft:{color}_wool')

def box(x0,y0,z0,x1,y1,z1,color):
    for x in range(x0,x1+1):
        for y in range(y0,y1+1):
            for z in range(z0,z1+1):
                put(x,y,z,color)

# Flush-with-ground patchwork floor. Stitch lines are wool, not carpets.
patches = ['cyan','yellow','purple','red','light_gray','pink']
for x in range(21):
    for z in range(21):
        color = patches[((x//4)*3 + z//4 + x//9) % len(patches)]
        if x in (0,20) or z in (0,20):
            color = 'brown'
        elif x % 4 == 0 or z % 4 == 0:
            color = 'black' if (x+z) % 3 == 0 else 'white'
        put(x,0,z,color)
# A clear path from the entrance to the altar.
box(9,0,0,11,0,8,'light_gray')
for z in range(0,9):
    put(8,0,z,'red'); put(12,0,z,'red')
    if z % 2 == 0:
        put(8,0,z,'white'); put(12,0,z,'white')

# Broken low walls: perimeter only; front entry stays open.
for x in range(21):
    for z in range(21):
        if x not in (0,20) and z not in (0,20):
            continue
        if z == 0 and 6 <= x <= 14:
            continue
        height = 1 + ((x*11 + z*7) % 3)
        for y in range(1,height+1):
            c = 'gray' if y == 1 else ('cyan' if (x+z+y)%2 else 'red')
            if (x+z) % 4 == 0 and y == 2:
                c = 'white'
            put(x,y,z,c)

# Four stitched wool corner posts; varying heights give the ruin a silhouette.
for x,z,h in [(0,0,5),(19,0,4),(0,19,5),(19,19,6)]:
    box(x,1,z,x+1,h,z+1,'brown')
    box(x,2,z,x+1,2,z+1,'red')
    box(x,h,z,x+1,h,z+1,'cyan')
    put(x,h,z,'yellow')

# Entrance frame and raised sign. Local y=1..3 is unobstructed in the entry.
box(4,1,0,5,9,1,'cyan')
box(15,1,0,16,9,1,'red')
for y in (2,5,8):
    box(4,y,0,5,y,1,'white')
    box(15,y,0,16,y,1,'white')
box(6,4,0,14,9,0,'white')
box(6,9,0,14,9,0,'yellow')
for y in range(4,9):
    put(6,y,0,'brown'); put(14,y,0,'brown')
zero = ['111','101','101','101','111']
one  = ['010','110','010','010','111']
for x0,glyph in ((7,zero),(11,one)):
    for row,line in enumerate(glyph):
        for dx,pixel in enumerate(line):
            # Viewed from outside the north entrance, screen-right is world -X.
            if pixel == '1': put(20-(x0+dx),8-row,0,'black')

# Central stepped altar: all-wool decorative fixture, no loot or activation logic.
box(8,1,10,12,1,14,'purple')
box(9,2,11,11,2,13,'light_gray')
put(10,3,12,'pink')
for x,z in ((8,10),(12,10),(8,14),(12,14)):
    put(x,1,z,'yellow')
# Two small cloth plinths at the rear; do not obstruct the guard positions.
for x in (5,15):
    box(x,1,17,x+1,2,18,'red')
    box(x,3,17,x+1,3,18,'yellow')

# Small typed NBT encoder; no runtime dependency or downloaded files.
def scalar(tag, value): return (tag, value)
def lst(tag, values): return (9, (tag, list(values)))
def compound(values): return (10, values)
def text(s):
    encoded = s.encode('utf-8')
    return struct.pack('>H',len(encoded)) + encoded

def payload(tag, value):
    formats = {1:'>b',2:'>h',3:'>i',4:'>q',5:'>f',6:'>d'}
    if tag in formats: return struct.pack(formats[tag],value)
    if tag == 8: return text(value)
    if tag == 9:
        subtype, values = value
        return bytes([subtype])+struct.pack('>i',len(values))+b''.join(payload(subtype,v) for v in values)
    if tag == 10:
        return b''.join(bytes([t])+text(name)+payload(t,v) for name,(t,v) in value.items())+b'\0'
    raise ValueError(f'Unsupported NBT tag {tag}')

entities = []
for x,y,z in [(6.5,1.0,10.5),(14.5,1.0,10.5)]:
    tag = {
        'id': scalar(8,'wooltest:test_one'),
        'Pos': lst(6,[x,y,z]), 'Motion': lst(6,[0.0,0.0,0.0]),
        'Rotation': lst(5,[180.0,0.0]), 'Health': scalar(5,20.0),
        'PersistenceRequired': scalar(1,1), 'CanPickUpLoot': scalar(1,0),
        'CustomName': scalar(8,'{"translate":"entity.wooltest.test_one"}'),
        'CustomNameVisible': scalar(1,1),
        'Tags': lst(8,['wooltest_trial_guard']),
        'WoolTestSkillCooldown': scalar(3,40),
    }
    entities.append({'pos':lst(6,[x,y,z]),'blockPos':lst(3,[int(x),int(y),int(z)]),'nbt':compound(tag)})

blocks = []
for y in range(SIZE[1]):
    for z in range(SIZE[2]):
        for x in range(SIZE[0]):
            blocks.append({'pos':lst(3,[x,y,z]),'state':scalar(3,GRID.get((x,y,z),0))})
root = {
    'DataVersion': scalar(3,3465), 'size':lst(3,SIZE),
    'palette':lst(10,[{'Name':scalar(8,name)} for name in PALETTE]),
    'blocks':lst(10,blocks), 'entities':lst(10,entities)
}
raw = b'\x0a\x00\x00'+payload(10,root)
path=RES/f'structures/{ID}.nbt'
path.parent.mkdir(parents=True,exist_ok=True)
path.write_bytes(gzip.compress(raw,compresslevel=9,mtime=0))

# An editable, human-readable manifest supports geometry validation without the game.
source = ROOT/'art_source/structure1'
source.mkdir(parents=True,exist_ok=True)
manifest = {
    'name':'布偶試驗場', 'id':f'wooltest:{ID}', 'size_xyz':list(SIZE),
    'ground_level_delta':1, 'floor_local_y':0, 'standing_local_y':1,
    'expected_natural_floor_y':63, 'expected_natural_max_y':72,
    'palette':PALETTE,
    'solid_blocks':[{'pos':list(p),'state':state} for p,state in sorted(GRID.items())],
    'guards':[{'id':'wooltest:test_one','pos':[x,1.0,10.5]} for x in (6.5,14.5)]
}
(source/'doll_trial_ground_layout.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')

def write_json(relative, obj):
    target=RES/relative; target.parent.mkdir(parents=True,exist_ok=True)
    target.write_text(json.dumps(obj,indent=2)+'\n',encoding='utf-8')

# Native single-piece jigsaw structure. No jigsaw connector blocks are needed.
write_json(f'worldgen/structure/{ID}.json', {
    'type':'minecraft:jigsaw','biomes':'#wooltest:has_structure/doll_trial_ground',
    'step':'surface_structures','spawn_overrides':{},'terrain_adaptation':'none',
    'start_pool':'wooltest:doll_trial_ground/start','size':1,
    'start_height':{'absolute':0},'project_start_to_heightmap':'WORLD_SURFACE_WG',
    'max_distance_from_center':64,'use_expansion_hack':False
})
write_json(f'worldgen/structure_set/{ID}.json', {
    'structures':[{'structure':f'wooltest:{ID}','weight':1}],
    'placement':{'type':'minecraft:random_spread','spacing':24,'separation':12,
                 'salt':718031065,'spread_type':'linear'}
})
write_json(f'worldgen/template_pool/{ID}/start.json', {
    'name':f'wooltest:{ID}/start','fallback':'minecraft:empty',
    'elements':[{'weight':1,'element':{
        'element_type':'minecraft:single_pool_element',
        'location':f'wooltest:{ID}','processors':'minecraft:empty','projection':'rigid'
    }}]
})
write_json(f'tags/worldgen/biome/has_structure/{ID}.json',{
    'replace':False,'values':['wooltest:wool_fields']
})
print(f'Wrote {path.relative_to(ROOT)}: {len(GRID)} wool blocks, {len(blocks)-len(GRID)} air cells, 2 guards; {len(path.read_bytes())} compressed bytes.')
