from pathlib import Path
import csv,json,numpy as np,fitz
P=Path(__file__).resolve().parents[1];O=P.parent/'atlas';Q=P.parent/'qa';Q.mkdir(exist_ok=True)
v=np.load(P/'art_source/city5/city_voxels.npy');docs={};checked=0;pages=0;fail=[]
with (O/'圖頁索引.csv').open(encoding='utf-8-sig') as f:
 rows=list(csv.DictReader(f))
for row in rows:
 if row['分區']=='ALL':continue
 fn=row['檔案'];page=int(row['頁碼'])-1;y=int(row['Y']);xa=int(row['最小X']);xb=int(row['最大X']);za=int(row['最小Z']);zb=int(row['最大Z'])
 if fn not in docs:docs[fn]=fitz.open(O/fn)
 pg=docs[fn][page];arr=v[xa+125:xb+126,za+125:zb+126,y-60].T
 nr,nc=arr.shape;got=np.zeros_like(arr);top=pg.rect.height-61-nr*9.6;left=68
 for x0,y0,x1,y1,t,*_ in pg.get_text('words'):
  if not (t.isdigit() and len(t)==2):continue
  cx=(x0+x1)/2;cy=(y0+y1)/2
  ix=int((cx-left)//9.6);iz=int((cy-top)//9.6)
  if left<=cx<left+nc*9.6 and top<=cy<top+nr*9.6:
   got[iz,ix]=int(t)
 if not np.array_equal(got,arr):fail.append([fn,page+1,int(np.count_nonzero(got!=arr)),int(np.count_nonzero(got)),int(np.count_nonzero(arr))])
 checked+=int(np.count_nonzero(arr));pages+=1
for fn in sorted(O.glob('*.pdf')):
 d=fitz.open(fn);print(fn.name,len(d))
 # Render a cover, legend and occupied slice from each volume for visual review.
 for num in ([0,1,38] if len(d)>38 else [0,6,20]):
  pg=d[num];pix=pg.get_pixmap(matrix=fitz.Matrix(1.3,1.3),alpha=False);pix.save(str(Q/(fn.stem+f'_p{num+1:03d}.png')))
result={'pdf_grid_pages_checked':pages,'non_air_cell_codes_checked':checked,'mismatch_pages':fail,'method':'Extract numeric text positions from completed PDF pages and compare every cell with source voxel array.'}
(P/'validation/city5_pdf_check.json').write_text(json.dumps(result,ensure_ascii=False,indent=2));print(json.dumps(result,ensure_ascii=False,indent=2));assert not fail
