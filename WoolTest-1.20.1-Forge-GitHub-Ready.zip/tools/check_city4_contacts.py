#!/usr/bin/env python3
"""Face-contact topology with 1/16-block masks from the actual custom model boxes.
Not a structural engineering or Minecraft runtime physics simulation.
"""
from pathlib import Path
import numpy as np,json,collections,importlib.util
P=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('geo',P/'tools/render_city4.py');g=importlib.util.module_from_spec(spec);spec.loader.exec_module(g)
v=g.v;pal=g.pal;n=len(pal);F=np.zeros((n,6,16,16),bool)
# Ordering: +X, -X, +Z, -Z, +Y, -Y. Model boxes use x,y,z.
for i,boxes in enumerate(g.models):
 if pal[i].split('[')[0] in ['minecraft:air','minecraft:water']:continue
 for a,b,_ in boxes:
  x1,y1,z1=np.rint(np.array(a)*16).astype(int);x2,y2,z2=np.rint(np.array(b)*16).astype(int)
  if x2==16:F[i,0,y1:y2,z1:z2]=True
  if x1==0:F[i,1,y1:y2,z1:z2]=True
  if z2==16:F[i,2,x1:x2,y1:y2]=True
  if z1==0:F[i,3,x1:x2,y1:y2]=True
  if y2==16:F[i,4,x1:x2,z1:z2]=True
  if y1==0:F[i,5,x1:x2,z1:z2]=True
C=np.zeros((n,6,n),bool)
for i in range(n):
 for d in range(6):C[i,d,:]=np.any(F[i,d][None,:,:]&F[:,d^1,:,:],axis=(1,2))
solid=np.array([s.split('[')[0] not in ['minecraft:air','minecraft:water'] for s in pal])[v]
# Traverse all faces, no diagonal connections or whole-cube approximations.
seen=np.zeros_like(solid);q=collections.deque()
for x in range(251):
 for z in range(251):
  if solid[x,z,0]:seen[x,z,0]=True;q.append((x,z,0))
dirs=[(1,0,0),(-1,0,0),(0,1,0),(0,-1,0),(0,0,1),(0,0,-1)]
while q:
 x,z,y=q.popleft();pi=int(v[x,z,y])
 for d,(dx,dz,dy) in enumerate(dirs):
  xx=x+dx;zz=z+dz;yy=y+dy
  if not(0<=xx<251 and 0<=zz<251 and 0<=yy<68) or seen[xx,zz,yy]:continue
  pj=int(v[xx,zz,yy])
  if C[pi,d,pj]:seen[xx,zz,yy]=True;q.append((xx,zz,yy))
bad=np.argwhere(solid&~seen)
result={'method':'actual model face masks on a 1/16-block lattice, cardinal face contacts only','solid_cells':int(solid.sum()),'foundation_connected_cells':int((seen&solid).sum()),'unconnected_cells':len(bad),'examples':[[int(x-125),int(y+60),int(z-125),pal[int(v[x,z,y])]] for x,z,y in bad[:40]]}
(P/'validation/city4_face_contacts.json').write_text(json.dumps(result,ensure_ascii=False,indent=2));print(json.dumps(result,ensure_ascii=False,indent=2))
raise SystemExit(bool(len(bad)))
