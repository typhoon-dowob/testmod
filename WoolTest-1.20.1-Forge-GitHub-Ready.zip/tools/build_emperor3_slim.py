#!/usr/bin/env python3
"""Rebuild Emperor 3's individually proportioned mesh and remapped existing art.
Only model geometry/UVs/renderer metadata are changed, not entity/gameplay state.
Requires Pillow; base artwork is preserved under art_source/emperor3/baseline.
"""
from pathlib import Path
import copy, json, hashlib
from PIL import Image
P=Path(__file__).resolve().parents[1]
A=P/'art_source/emperor3'; B=A/'baseline'
T=P/'src/main/resources/assets/wooltest/textures/entity'
J=P/'src/main/java/dev/sushi/wooltest/client'
old=json.loads((B/'emperor_model.json').read_text())
nodes=copy.deepcopy(old['nodes']); by={n['name']:n for n in nodes}
oldc={c['name']:c for n in old['nodes'] for c in n['cubes']}

def change(c,origin,size):
 c['source_cube']=c['name']; c['origin']=origin; c['size']=size

def geom(n, rows):
 assert len(n['cubes'])==len(rows),(n['name'],len(n['cubes']),len(rows))
 for c,(origin,size) in zip(n['cubes'],rows): change(c,origin,size)

# The chest, fitted waist, hip and hem have independent widths, not one global scale.
torso=by['torso']
geom(torso,[([-5.5,0,-3.5],[11,10,7]),([-5,-1,-4.5],[10,3,9]),
            ([-5.5,15,-3.5],[11,2,7]),([-2,4,-4.5],[4,6,1]),
            ([-6.5,17,-4],[13,5,8]),([-6.5,25,-5.5],[13,2,1])])
for name,source,origin,size in [
 ('fitted_waist','torso_0',[-4.5,10,-3],[9,7,6]),
 ('lower_robe','torso_4',[-7,22,-4.5],[14,5,9])]:
 c=copy.deepcopy(oldc[source]); c.update(name=name,source_cube=source,origin=origin,size=size);torso['cubes'].append(c)
# Maintain total height: the face is narrower, not flattened vertically.
geom(by['head'],[([-4,-11,-4],[8,11,8]),([-2,-3,-5],[4,5,1]),
                 ([-5,-14,-5],[10,3,10]),([-7,-16,-6],[14,2,12]),
                 ([-1.5,-13,-5.2],[3,3,1])])
# Twelve slender bead strings. Each has five contiguous cubes, avoiding coincident
# faces on the old string/overlaid-bead construction. Six strands per crown edge.
strand_x=[-5.5,-3.3,-1.1,1.1,3.3,5.5]
for n in nodes:
 if n['name'].startswith('bead_'):
  idx=int(n['name'].split('_')[1])//3
  front=n['name'].endswith('_0')
  n['offset']=[strand_x[idx],-14,-5.5 if front else 5.5]
  base=n['cubes'][0]['name']; jewel=n['cubes'][1]['name']; jade=n['cubes'][2]['name']
  n['cubes']=[]
  for y in range(5):
   source=jade if y==2 else jewel if y%2==0 else base
   c=copy.deepcopy(oldc[source]);c.update(name=f'{n["name"]}_segment_{y}',source_cube=source,origin=[-.5,y,-.5],size=[1,1,1]);n['cubes'].append(c)
for side,sign in [('right',-1),('left',1)]:
 n=by[side+'_arm'];n['offset']=[sign*8.5,2,0]
 geom(n,[([-3,-1,-3.5],[6,11,7]),([-3,10,-3.5],[6,3,7]),
         ([-1.5,13,-1.5],[3,4,3]),([-3.5,-3,-3.5],[7,2,7]),
         ([-2.5,-4,-2.5],[5,1,5]),([-2,6,-4.5],[4,4,1]),([-2,11,-4.5],[4,2,1])])
 n=by[side+'_leg'];n['offset']=[sign*3.5,17,0]
 geom(n,[([-2,0,-2],[4,3,4]),([-2,3,-4],[4,4,7])])
geom(by['cape'],[([-6.5,0,3.5],[13,22,2]),([-7.5,1,3.5],[1,20,2]),
                 ([6.5,1,3.5],[1,20,2]),([-6.5,22,3.5],[13,1,2])])
for side,sign in [('left',1),('right',-1)]:
 n=by['pendant_'+side];n['offset']=[sign*5.5,16,-4.6]
 geom(n,[([-.5,0,0],[1,6,2]),([-1.5,5,-.5],[3,3,2]),([-.5,8,0],[1,2,1])])
by['front_skirt']['offset']=[0,17,-5.7]
geom(by['front_skirt'],[([-3,0,0],[6,9,2]),([-4,0,0],[1,9,2]),
                        ([3,0,0],[1,9,2]),([-3,9,0],[6,1,2])])
# Set the crown rails slightly forward/back to avoid coincident textured planes.
geom(by['crown_trim'],[([-6,-15,-6.05],[12,1,1]),([-6,-15,5.05],[12,1,1]),([-6,-14,-5.5],[12,1,11])])
by['beard_tip']['offset']=[0,1,-5.2]
geom(by['beard_tip'],[([-1.5,0,0],[3,3,1]),([-.5,3,0],[1,2,1])])
# Fixed pixel atlas: remap existing face artwork with nearest-neighbour sampling.
x=y=rowh=0
textures={name:Image.open(B/name).convert('RGBA') for name in ['emperor.png','emperor_charge.png']}
out={name:Image.new('RGBA',(512,512)) for name in textures}
for n in nodes:
 for c in n['cubes']:
  w,h,d=c['size'];assert all(isinstance(q,int) and q>0 for q in (w,h,d))
  rw=2*(w+d);rh=h+d
  if x+rw>256:x=0;y+=rowh+1;rowh=0
  u,v=x,y;c['uv']=[u,v]
  c['faces']={'top':[u+d,v,w,d],'bottom':[u+d+w,v,w,d],
              'right':[u,v+d,d,h],'front':[u+d,v+d,w,h],
              'left':[u+d+w,v+d,d,h],'back':[u+2*d+w,v+d,w,h]}
  src=oldc[c['source_cube']]
  for face,(px,py,fw,fh) in c['faces'].items():
   sx,sy,sw,sh=src['faces'][face]
   for name,im in textures.items():
    patch=im.crop((2*sx,2*sy,2*(sx+sw),2*(sy+sh))).resize((2*fw,2*fh),Image.Resampling.NEAREST)
    out[name].paste(patch,(2*px,2*py))
  x+=rw+1;rowh=max(rowh,rh)
assert y+rowh<=256
for name,im in out.items():im.save(T/name)
spec=copy.deepcopy(old)
spec.update(format='WoolTest Emperor 3 exact cuboid geometry - slender court silhouette',nodes=nodes,
    design='Independent chest/waist/hem/sleeve/crown proportions; original height, hand anchor and gameplay collision unchanged.',
    authoring_source='City 5 + Emperor 2; per-face resampling of the existing original artwork, not a global render scale.')
(A/'emperor_model.json').write_text(json.dumps(spec,ensure_ascii=False,indent=2)+'\n')
# Copy animation/hand transforms verbatim. No new engine calls/overrides introduced.
oldcode=(B/'EmperorModel.java.txt').read_text()
start=oldcode.index('        PartDefinition torso =')
end=oldcode.index('        return LayerDefinition.create(')
def f(q):
 s=f'{q:.6f}'.rstrip('0').rstrip('.')
 if '.' not in s:s+=' .0'.replace(' ','')
 return s+'F'
body=''
for n in nodes:
 body+=f'        PartDefinition {n["name"]} = {n["parent"]}.addOrReplaceChild("{n["name"]}", CubeListBuilder.create()\n'
 for c in n['cubes']:
  u,v=c['uv'];nums=', '.join(f(float(q)) for q in c['origin']+c['size'])
  body+=f'                .texOffs({u}, {v}).addBox({nums})\n'
 body+='                , PartPose.offset('+', '.join(f(float(q)) for q in n['offset'])+'));\n'
code=oldcode[:start]+body+oldcode[end:]
code=code.replace('public final class EmperorModel', '/** Emperor 3: individually fitted proportions; fixed 2 x 2 x 3 gameplay bounds are unchanged. */\npublic final class EmperorModel')
(J/'EmperorModel.java').write_text(code)
renderer=(J/'EmperorRenderer.java').read_text().replace(')),0.85F)', ')),0.68F)')
(J/'EmperorRenderer.java').write_text(renderer)
print(f'Emperor 3: {len(nodes)} nodes; {sum(len(n["cubes"]) for n in nodes)} cubes; UV height {y+rowh}/256; height unchanged.')
