#!/usr/bin/env python3
"""Original technical pixel assets: four icons + two UV armor atlases + charge masks.
No vanilla texture copied. Wearing uses the vanilla humanoid armor mesh.
"""
from pathlib import Path
from PIL import Image,ImageDraw,ImageFont
import random,math,json
P=Path(__file__).resolve().parents[1];A=P/'src/main/resources/assets/wooltest';T=A/'textures';O=P/'art_preview';O.mkdir(exist_ok=True)
(T/'models/armor').mkdir(parents=True,exist_ok=True)
INK='#171c26';GOLD='#d8aa4e';BRIGHT='#ffe0a0';RED='#8f2834';JADE='#55b59a';EDGE='#59472f'
# Four distinct inventory silhouettes, hand-authored at 32px and displayed nearest-neighbour.
def icon(name):
 im=Image.new('RGBA',(32,32));d=ImageDraw.Draw(im)
 if name=='imperial_crown':
  d.polygon([(5,11),(8,7),(23,7),(26,11),(24,23),(7,23)],fill=INK,outline=EDGE)
  d.rectangle((3,5,28,9),fill=GOLD);d.rectangle((5,6,26,7),fill=INK)
  d.rectangle((6,19,25,22),fill=GOLD);d.rectangle((13,18,18,23),fill=BRIGHT);d.rectangle((14,19,17,22),fill=JADE)
  for x in [5,9,13,18,22,26]:
   d.line((x,10,x,16),fill=GOLD)
   for y in [10,13,16]:d.rectangle((x,y,x+1,y+1),fill=BRIGHT if y!=13 else JADE)
 elif name=='imperial_robe':
  d.polygon([(9,4),(12,3),(19,3),(22,4),(29,11),(27,22),(22,21),(24,28),(7,28),(9,21),(4,22),(2,11)],fill=INK,outline=EDGE)
  d.polygon([(11,4),(16,10),(20,4),(21,7),(16,13),(10,7)],fill=RED)
  d.line([(11,4),(16,10),(20,4)],fill=GOLD,width=1)
  d.rectangle((8,21,23,23),fill=GOLD);d.rectangle((14,20,17,24),fill=JADE)
  for x in [3,24]:d.rectangle((x,17,x+4,20),fill=GOLD)
  d.line([(17,11),(13,13),(18,15),(13,17),(17,19)],fill=BRIGHT,width=2)
  d.line([(7,26),(23,26)],fill=RED,width=2)
 elif name=='imperial_leggings':
  d.rectangle((6,4,25,9),fill=GOLD);d.rectangle((14,4,17,8),fill=JADE)
  d.polygon([(7,9),(24,9),(24,28),(18,28),(17,17),(14,17),(13,28),(7,28)],fill=INK,outline=EDGE)
  for x in [9,20]:
   d.line((x,10,x,26),fill=GOLD,width=2)
   d.rectangle((x-1,16,x+2,19),fill=RED);d.point((x,17),fill=BRIGHT)
 else:
  for x in [3,18]:
   d.polygon([(x+3,5),(x+10,5),(x+10,23),(x+12,25),(x+12,28),(x,28),(x,24),(x+3,22)],fill=INK,outline=EDGE)
   d.rectangle((x+3,6,x+10,8),fill=GOLD);d.rectangle((x+4,10,x+9,12),fill=RED)
   d.line([(x+7,14),(x+4,17),(x+8,20),(x+4,23)],fill=BRIGHT,width=1)
   d.line((x+1,26,x+11,26),fill=GOLD,width=1)
 im.save(T/f'item/{name}.png');(A/'models/item'/f'{name}.json').write_text(json.dumps({'parent':'minecraft:item/generated','textures':{'layer0':'wooltest:item/'+name}},indent=2))
 return im
icons=[icon(n) for n in ['imperial_crown','imperial_robe','imperial_leggings','imperial_boots']]
# Standard humanoid net, painted at 4x logical resolution: head/body/arms/legs.
S=4
atlas1=Image.new('RGBA',(256,128));atlas2=Image.new('RGBA',(256,128))
net=[('head',0,0,8,8,8),('body',16,16,8,12,4),('arm',40,16,4,12,4),('leg',0,16,4,12,4)]
for layer,atlas in [(1,atlas1),(2,atlas2)]:
 for part,u,v,w,h,d in net:
  faces={'top':(u+d,v,w,d),'bottom':(u+d+w,v,w,d),'right':(u,v+d,d,h),'front':(u+d,v+d,w,h),'left':(u+d+w,v+d,d,h),'back':(u+2*d+w,v+d,w,h)}
  for side,(x,y,fw,fh) in faces.items():
   patch=Image.new('RGBA',(fw*S,fh*S));q=ImageDraw.Draw(patch);W,H=patch.size
   if layer==1 and part=='head':
    if side=='bottom':continue
    if side=='top':
     q.rectangle((0,0,W-1,H-1),fill=INK,outline=GOLD,width=3);q.line((4,H//2,W-5,H//2),fill=RED,width=3)
    else:
     q.rectangle((0,0,W-1,10),fill=INK);q.rectangle((0,8,W-1,11),fill=GOLD)
     if side=='front':
      q.rectangle((W//2-4,7,W//2+4,14),fill=BRIGHT);q.rectangle((W//2-2,8,W//2+2,12),fill=JADE)
     if side in ['right','left','back']:
      for xx in range(4,W-3,8):
       q.line((xx,11,xx,23),fill=GOLD)
       for yy in [14,18,22]:q.rectangle((xx-1,yy,xx+1,yy+1),fill=JADE)
   elif layer==1 and part=='leg':
    # Boots only: transparent upper leg so leggings remain visible.
    if side in ['top','bottom']:
     if side=='bottom':q.rectangle((0,0,W-1,H-1),fill=INK)
    else:
     q.rectangle((0,27,W-1,H-1),fill=INK);q.rectangle((0,27,W-1,30),fill=GOLD)
     q.line((1,H-4,W-2,H-4),fill=GOLD,width=2)
     q.line([(W//2,32),(3,36),(W-4,39),(W//2,43)],fill=BRIGHT,width=2)
   elif layer==2 and part=='head' or layer==2 and part=='arm':continue
   elif layer==2 and part=='body':
    if side in ['top','bottom']:continue
    q.rectangle((0,0,W-1,10),fill=INK);q.rectangle((0,1,W-1,4),fill=GOLD)
    if side=='front':q.rectangle((W//2-3,2,W//2+3,8),fill=JADE)
   else:
    q.rectangle((0,0,W-1,H-1),fill=INK,outline=GOLD,width=1)
    if part=='body':
     q.polygon([(0,0),(W//2,H//3),(W-1,0),(W-1,6),(W//2,H//3+6),(0,6)],fill=RED)
     q.line([(0,1),(W//2,H//3),(W-1,1)],fill=GOLD,width=2)
     q.rectangle((0,H-8,W-1,H-4),fill=GOLD)
     if side in ['front','back']:
      # Original coiling dragon/scroll silhouette with horns and cloud hooks.
      q.line([(W//2+3,16),(W//2-5,20),(W//2+5,25),(W//2-5,29),(W//2+3,34)],fill=BRIGHT,width=3)
      q.line([(W//2+3,16),(W//2+7,13),(W//2+5,11)],fill=GOLD,width=2)
      q.rectangle((W//2-2,H-9,W//2+2,H-3),fill=JADE)
    elif part=='arm':
     for yy in [4,9,13]:q.line((2,yy,W-3,yy),fill=GOLD,width=2)
     q.rectangle((0,H-12,W-1,H-7),fill=RED);q.line((0,H-6,W-1,H-6),fill=GOLD,width=3)
    else:
     q.line((3,2,3,H-4),fill=GOLD,width=2);q.line((W-4,2,W-4,H-4),fill=GOLD,width=2)
     for yy in [12,20,28]:q.line([(3,yy),(W//2,yy+3),(W-4,yy)],fill=RED,width=2)
   atlas.paste(patch,(x*S,y*S))
 atlas.save(T/f'models/armor/imperial_layer_{layer}.png')
# Selective emissive overlay from exactly the same newly exported Emperor UV net.
spec=json.loads((P/'art_source/emperor2/emperor_model.json').read_text());img=Image.open(T/'entity/emperor.png').convert('RGBA');mask=Image.new('RGBA',img.size)
for n in spec['nodes']:
 for c in n['cubes']:
  if c['material'] not in ['jade','seal','beads','gold']:continue
  for x,y,w,h in c['faces'].values():
   patch=img.crop((x*2,y*2,(x+w)*2,(y+h)*2));mask.paste(patch,(x*2,y*2))
mask.save(T/'entity/emperor_charge.png')
# A second independently drawn ground sheet: octagonal boundary, square courtyards,
# interlaced rays, eight small seal knots and a central diamond, not just circles.
N=512;im=Image.new('RGBA',(N,N));d=ImageDraw.Draw(im);C=256
col=(255,192,76,210);pale=(255,234,151,225);red=(243,90,55,190)
def pts(r,n,phase=0):return [(C+math.cos(phase+i*2*math.pi/n)*r,C+math.sin(phase+i*2*math.pi/n)*r) for i in range(n)]
for r in [244,232,194]:
 a=pts(r,8,math.pi/8);d.line(a+[a[0]],fill=col,width=3)
for r,phase in [(170,0),(163,math.pi/4),(94,0),(80,math.pi/4)]:
 a=pts(r,4,phase);d.line(a+[a[0]],fill=pale,width=3)
for i in range(8):
 a=i*math.pi/4;rx=C+math.cos(a)*205;ry=C+math.sin(a)*205
 d.line((C+math.cos(a)*102,C+math.sin(a)*102,C+math.cos(a)*187,C+math.sin(a)*187),fill=red,width=3)
 d.rectangle((rx-10,ry-10,rx+10,ry+10),outline=pale,width=2)
 d.line((rx-6,ry-4,rx+6,ry-4),fill=col,width=2);d.line((rx,ry-8,rx,ry+7),fill=col,width=2)
for i in range(48):
 a=i*2*math.pi/48;d.line((C+math.cos(a)*220,C+math.sin(a)*220,C+math.cos(a)*227,C+math.sin(a)*227),fill=pale,width=2)
# Strong central brush-built seal, all strokes original.
d.rectangle((228,228,284,284),outline=col,width=4)
for y in [240,251,273]:d.line((239,y,273,y),fill=pale,width=4)
d.line((256,240,256,273),fill=pale,width=4);im.save(T/'effect/imperial_ground.png')
# Compact exact-assets contact sheet (not concept art).
B=Image.new('RGB',(1400,830),(236,232,222));d=ImageDraw.Draw(B);font='/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc'
f=ImageFont.truetype(font,26);small=ImageFont.truetype(font,18)
d.text((36,24),'御用裝備｜實際物品貼圖與穿戴材質',font=f,fill=(43,47,51))
d.text((36,63),'四件獨立物品；黑金、赤紅與玉飾。以下是資源檔預覽，非遊戲截圖。',font=small,fill=(83,85,85))
for i,(ico,label) in enumerate(zip(icons,['天子冕','玄龍袍甲','鎮國護腿','踏雲御靴'])):
 x=48+i*335;bg=Image.new('RGBA',(240,240),(39,43,51,255));bg.alpha_composite(ico.resize((240,240),Image.Resampling.NEAREST));B.paste(bg.convert('RGB'),(x,116));d.text((x+50,370),label,font=f,fill=(43,47,51))
for j,(tex,label) in enumerate([(atlas1,'穿戴材質：頭盔／胸甲／靴子'),(atlas2,'穿戴材質：護腿／腰帶')]):
 bg=Image.new('RGBA',(600,300),(56,59,65,255));bg.alpha_composite(tex.resize((600,300),Image.Resampling.NEAREST));B.paste(bg.convert('RGB'),(48+j*690,435));d.text((48+j*690,750),label,font=small,fill=(43,47,51))
B.save(O/'imperial-armor-assets.png')
# Describes all authoring assets; no claim of in-game validation.
(P/'art_source/emperor2/armor_assets.json').write_text(json.dumps({'items':['imperial_crown','imperial_robe','imperial_leggings','imperial_boots'],'item_resolution':[32,32],'armor_resolution':[256,128],'armor_mesh':'Minecraft humanoid armor mesh, independent painted texture atlases','method':'Original coordinate-authored pixel art; no vanilla texture reused','ground_sigil':[512,512]},ensure_ascii=False,indent=2))
print('Armor icons + worn atlases + charge mask + ground sigil written.')
