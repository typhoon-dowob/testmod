#!/usr/bin/env python3
"""Pose sanity preview, transforms copied from EmperorModel.setupAnim (no sword layer).
Uses the exact shipped boxes, texture, hierarchy and charging arm angles.
Not Minecraft rendering and not a collision/animation integration test.
"""
from pathlib import Path
import json, math
import numpy as np
from PIL import Image, ImageDraw, ImageFont, ImageEnhance
P=Path(__file__).resolve().parents[1]
S=json.loads((P/'art_source/emperor3/emperor_model.json').read_text())
T=Image.open(P/'src/main/resources/assets/wooltest/textures/entity/emperor.png').convert('RGBA')
W,H=1100,900

def matrix(offset,rx=0,ry=0,rz=0):
 x,y,z=offset;c,s=math.cos,math.sin
 RX=np.array([[1,0,0],[0,c(rx),-s(rx)],[0,s(rx),c(rx)]])
 RY=np.array([[c(ry),0,s(ry)],[0,1,0],[-s(ry),0,c(ry)]])
 RZ=np.array([[c(rz),-s(rz),0],[s(rz),c(rz),0],[0,0,1]])
 M=np.eye(4);M[:3,:3]=RZ@RY@RX;M[:3,3]=[x,y,z];return M
M={'root':np.eye(4)}
V=np.array([[1,0,0,0],[0,-1,0,24],[0,0,-1,0],[0,0,0,1]])
yaw=math.radians(24);elev=math.radians(12)
cam=np.array([math.sin(yaw)*math.cos(elev),math.sin(elev),math.cos(yaw)*math.cos(elev)])
right=np.array([math.cos(yaw),0,-math.sin(yaw)]);up=np.cross(cam,right)
rgba=np.zeros((H,W,4),dtype=np.uint8);Z=np.full((H,W),-np.inf)
scale=13;cx=550;cy=785;points_all=[]
for n in S['nodes']:
 angles={'right_arm':(-1.15,0,.12),'left_arm':(-.95,0,-.12)}.get(n['name'],(0,0,0))
 M[n['name']]=M[n['parent']]@matrix(n['offset'],*angles);transform=V@M[n['name']]
 for b in n['cubes']:
  x0,y0,z0=b['origin'];x1,y1,z1=np.array(b['origin'])+b['size']
  faces=[('front',[(x0,y0,z0),(x1,y0,z0),(x1,y1,z0),(x0,y1,z0)],(0,0,-1)),
         ('back',[(x1,y0,z1),(x0,y0,z1),(x0,y1,z1),(x1,y1,z1)],(0,0,1)),
         ('right',[(x0,y0,z1),(x0,y0,z0),(x0,y1,z0),(x0,y1,z1)],(-1,0,0)),
         ('left',[(x1,y0,z0),(x1,y0,z1),(x1,y1,z1),(x1,y1,z0)],(1,0,0)),
         ('top',[(x0,y0,z1),(x1,y0,z1),(x1,y0,z0),(x0,y0,z0)],(0,-1,0)),
         ('bottom',[(x0,y1,z0),(x1,y1,z0),(x1,y1,z1),(x0,y1,z1)],(0,1,0))]
  for face,points,normal in faces:
   pp=np.array([(transform@np.array([*p,1]))[:3] for p in points]);points_all.extend(pp.tolist())
   norm=transform[:3,:3]@normal
   if cam@norm<=0:continue
   q=np.array([(cx+p@right*scale,cy-p@up*scale) for p in pp])
   p0=q[0];vx=q[1]-p0;vy=q[3]-p0;A=np.column_stack((vx,vy))
   if abs(np.linalg.det(A))<1e-10:continue
   inv=np.linalg.inv(A)
   bx=max(0,int(q[:,0].min())-1);ex=min(W,int(q[:,0].max())+2)
   by=max(0,int(q[:,1].min())-1);ey=min(H,int(q[:,1].max())+2)
   if bx>=ex or by>=ey:continue
   xx,yy=np.meshgrid(np.arange(bx,ex)+.5,np.arange(by,ey)+.5)
   u,v=np.einsum('ij,jkl->ikl',inv,np.stack((xx-p0[0],yy-p0[1])))
   tx,ty,tw,th=b['faces'][face]
   patch=T.crop((2*tx,2*ty,2*(tx+tw),2*(ty+th)))
   bright=.84+.22*max(0,norm@np.array([-.2,.8,.5]))
   patch=ImageEnhance.Brightness(patch).enhance(bright)
   pix=np.asarray(patch)[np.clip((v*patch.height).astype(int),0,patch.height-1),np.clip((u*patch.width).astype(int),0,patch.width-1)]
   depth=pp[0]@cam+u*((pp[1]-pp[0])@cam)+v*((pp[3]-pp[0])@cam)
   hit=(u>=0)&(u<1)&(v>=0)&(v<1)&(pix[:,:,3]>0)&(depth>Z[by:ey,bx:ex])
   rgba[by:ey,bx:ex][hit]=pix[hit];Z[by:ey,bx:ex][hit]=depth[hit]
out=Image.new('RGBA',(W,H),(235,231,219,255));d=ImageDraw.Draw(out)
d.ellipse((380,758,720,803),fill=(208,201,187))
out=Image.alpha_composite(out,Image.fromarray(rgba));d=ImageDraw.Draw(out)
font='/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf'
d.text((36,24),'EMPEROR 3 / CHARGING POSE CHECK',font=ImageFont.truetype(font,28),fill=(43,48,43))
d.text((36,67),'Actual geometry + arm transforms | Sword/effects omitted | NOT an in-game screenshot',font=ImageFont.truetype(font,18),fill=(87,87,75))
d.text((36,850),'Offline pose inspection only; real held-item rendering and animation still need game testing.',font=ImageFont.truetype(font,17),fill=(87,87,75))
(P/'art_preview').mkdir(exist_ok=True)
out.convert('RGB').save(P/'art_preview/emperor3-charging-pose.png')
pp=np.array(points_all);assert np.isfinite(pp).all()
print('Static charging pose preview generated from shipped mesh and setupAnim angles (not an engine test).')
