#!/usr/bin/env python3
"""Reproducible City 3. Units are world blocks; all geometry originates here.
Separately allocated building parcels, recorded support columns, protected streets.
No external generators or modifications to the combat systems.
"""
from pathlib import Path
import numpy as np, json, gzip, struct, math, hashlib, re, collections
P=Path(__file__).resolve().parents[1]; R=P/'src/main/resources'; A=P/'art_source/city3'; A.mkdir(parents=True,exist_ok=True)
AS=R/'assets/wooltest'; D=R/'data/wooltest'
def js(p,o):
 p.parent.mkdir(parents=True,exist_ok=True); p.write_text(json.dumps(o,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')

def elem(a,b,tex='#all'):
 return {'from':a,'to':b,'faces':{f:{'texture':tex} for f in ['north','south','east','west','up','down']}}
# New variants reuse the original, independently authored material textures. Their
# geometry is new; every visible shaft reaches both block boundaries.
NEW=[
 ('capital_column_shaft','朱漆通長柱身','Vermilion Column Shaft','capital_red_timber','shaft', [([4,0,4],[12,16,12])]),
 ('capital_column_foot','須彌柱礎','Stepped Marble Column Base','capital_marble','foot', [([1,0,1],[15,4,15]),([3,4,3],[13,12,13]),([4,12,4],[12,16,12])]),
 ('capital_hanging_lantern','垂穗宮燈','Hanging Palace Lantern','capital_red_lantern','hanging', [([7,12,7],[9,16,9]),([3,10,3],[13,12,13]),([4,3,4],[12,10,12]),([5,2,5],[11,3,11]),([7,0,7],[9,2,9])]),
 ('capital_stone_lamp','庭院石燈','Courtyard Stone Lamp','capital_gold_lantern','stone_lamp', [([1,0,1],[15,3,15]),([6,3,6],[10,7,10]),([3,7,3],[13,13,13]),([1,13,1],[15,15,15]),([4,15,4],[12,16,12])]),
 ('capital_inlaid_lamp','嵌地琉璃燈','Inlaid Glazed Floor Light','capital_gold_lantern','inlaid', [([0,0,0],[16,16,16])]),
]
for name,zh,en,base,kind,boxes in NEW:
 textures={'all':f'wooltest:block/{base}','stone':'wooltest:block/capital_marble','paving':'wooltest:block/capital_paving','particle':f'wooltest:block/{base}'}
 es=[elem(a,b) for a,b in boxes]
 if kind=='stone_lamp':
  for i in (0,1,3,4): es[i]=elem(*boxes[i],tex='#stone')
 if kind=='inlaid':
  es[0]['faces']={f:{'texture': '#all' if f=='up' else '#paving', 'cullface':f} for f in ['north','south','east','west','up','down']}
 js(AS/'models/block'/f'{name}.json',{'parent':'minecraft:block/block','textures':textures,'elements':es})
 js(AS/'blockstates'/f'{name}.json',{'variants':{'':{'model':f'wooltest:block/{name}'}}})
 js(AS/'models/item'/f'{name}.json',{'parent':f'wooltest:block/{name}'})
 js(D/'loot_tables/blocks'/f'{name}.json',{'type':'minecraft:block','pools':[{'rolls':1,'conditions':[{'condition':'minecraft:survives_explosion'}],'entries':[{'type':'minecraft:item','name':f'wooltest:{name}'}]}]})
for lang,ix in [('zh_tw',1),('en_us',2)]:
 p=AS/'lang'/f'{lang}.json';dic=json.loads(p.read_text())
 for e in NEW:dic['block.wooltest.'+e[0]]=e[ix]
 js(p,dic)
reg=P/'src/main/java/dev/sushi/wooltest/city/CityBlocks.java';s=reg.read_text()
if 'add("capital_column_shaft"' not in s:
 additions=[]
 for n,_,_,_,kind,_ in NEW:
  prop='props("stone").lightLevel(s -> 15).noOcclusion()' if kind in ('stone_lamp','hanging') else 'props("stone").lightLevel(s -> 15)' if kind=='inlaid' else 'props("wood").noOcclusion()' if kind=='shaft' else 'props("stone").noOcclusion()'
  additions.append(f'        add("{n}", () -> new CityDecorBlock("{kind}", {prop}));')
 s=s.replace('    public static void register(IEventBus bus)', '    public static void register(IEventBus bus)')
 s=s.replace('        add("capital_red_column"', '\n'.join(additions)+'\n        add("capital_red_column"')
 reg.write_text(s)
shape=P/'src/main/java/dev/sushi/wooltest/city/CityDecorBlock.java';s=shape.read_text()
if 'case "shaft"' not in s:
 lines=[]
 for _,_,_,_,kind,boxes in NEW:
  expr=','.join('box('+','.join(map(str,a+b))+')' for a,b in boxes)
  lines.append(f'            case "{kind}" -> Shapes.or({expr});' if len(boxes)>1 else f'            case "{kind}" -> {expr};')
 s=s.replace('            case "column"', '\n'.join(lines)+'\n            case "column"');shape.write_text(s)
# Add mining tags without losing previous registrations.
for tag in ['pickaxe','axe']:
 path=R/f'data/minecraft/tags/blocks/mineable/{tag}.json';obj=json.loads(path.read_text())
 for n,*_ in NEW:
  if (n.endswith('shaft'))==(tag=='axe') and 'wooltest:'+n not in obj['values']:obj['values'].append('wooltest:'+n)
 js(path,obj)

N=251; Y0=60; H=68
v=np.zeros((N,N,H),dtype=np.uint16); own=np.zeros_like(v,dtype=np.uint16)
palette=['minecraft:air']; lookup={palette[0]:0}
roles={}; buildings=[]; columns=[]; lamps=[]; stair_records=[]; collision=[]; road=np.zeros((N,N),bool); cur=0

def state(n):return n if ':' in n else 'wooltest:capital_'+n

def code(n):
 n=state(n)
 if n not in lookup:lookup[n]=len(palette);palette.append(n)
 return lookup[n]

def box(x1,x2,y1,y2,z1,z2,n,owner=None, allow=False):
 if x2<x1 or y2<y1 or z2<z1:return
 assert -125<=x1<=x2<=125 and -125<=z1<=z2<=125 and 60<=y1<=y2<=127,(x1,x2,y1,y2,z1,z2,n)
 c=code(n); o=cur if owner is None else owner
 sl=np.s_[x1+125:x2+126,z1+125:z2+126,y1-60:y2-59]
 old=v[sl]; os=own[sl]
 if o and not allow:
  mask=(os!=0)&(os!=o)&(old!=0)
  if np.any(mask):
   q=np.argwhere(mask)[0];raise RuntimeError(f'Unapproved solid collision {roles.get(o)} vs {roles.get(int(os[tuple(q)]))} at {(x1+int(q[0]),y1+int(q[2]),z1+int(q[1]))}')
 v[sl]=c;own[sl]=o if c else 0

def b(x,y,z,n,**kw):box(x,x,y,y,z,z,n,**kw)

def entity_owner(name):
 i=len(roles)+1;roles[i]=name;return i

def reserve(name,cx,cz,w,d,f,h,kind,extra=0,parent=None):
 global cur
 cur=entity_owner(name)
 ex=4 if kind=='palace' else 3
 e=(cx-w//2-ex,cx+w//2+ex,cz-d//2-ex,cz+d//2+max(ex,f-63+2))
 q={'id':cur,'name':name,'cx':cx,'cz':cz,'width':w,'depth':d,'floor':f,'wall_height':h,'type':kind,'envelope':list(e),'parent':parent}
 for other in buildings:
  if parent and parent==other.get('parent'):continue
  a,b1,c,d1=e; aa,bb,cc,dd=other['envelope']
  if max(a,aa)<=min(b1,bb) and max(c,cc)<=min(d1,dd):
   raise RuntimeError(f'Parcel overlap: {name} with {other["name"]}: {e}, {other["envelope"]}')
 buildings.append(q);return q

def perimeter(x1,x2,y1,y2,z1,z2,n):
 box(x1,x2,y1,y2,z1,z1,n);box(x1,x2,y1,y2,z2,z2,n)
 box(x1,x1,y1,y2,z1+1,z2-1,n);box(x2,x2,y1,y2,z1+1,z2-1,n)

def lamp(x,y,z,kind='hanging_lantern'):
 assert v[x+125,z+125,y-60]==0,('lamp occupied',x,y,z,palette[int(v[x+125,z+125,y-60])])
 b(x,y,z,kind);lamps.append([x,y,z,kind,cur])

def column(x,z,f,h):
 b(x,f+1,z,'column_foot');box(x,x,f+2,f+h-1,z,z,'column_shaft');b(x,f+h,z,'bracket')
 columns.append({'x':x,'z':z,'base':f+1,'top':f+h,'owner':cur})

def stair_run(cx,zfront,f,width=5):
 # All risers solidly backfilled; high half faces north, towards the building.
 for r in range(1,f-63+1):
  z=zfront+(f-63)-r+1; yy=63+r
  box(cx-width//2,cx+width//2,64,yy-1,z,z,'carved_marble')
  box(cx-width//2,cx+width//2,yy,yy,z,z,'marble_stairs[facing=north,half=bottom,shape=straight,waterlogged=false]')
  stair_records.append({'x1':cx-width//2,'x2':cx+width//2,'z':z,'y':yy,'face':'north','owner':cur})

def hip_roof(cx,cz,hx,hz,base,tile,ring_only=None):
 maxy=base
 for x in range(cx-hx,cx+hx+1):
  for z in range(cz-hz,cz+hz+1):
   dx=hx-abs(x-cx);dz=hz-abs(z-cz);q=min(dx,dz)
   if ring_only is not None and q>ring_only:continue
   yy=base+q//2;maxy=max(maxy,yy)
   if dx<dz:face='east' if x<cx else 'west'
   else:face='south' if z<cz else 'north'
   # Ridge is full, so finials cannot hover half a block above a slab.
   if q==min(hx,hz) and ring_only is None:n=tile
   elif q%2:n=tile+'_stairs[facing='+face+',half=bottom,shape=straight,waterlogged=false]'
   else:n=tile+'_slab[type=bottom,waterlogged=false]'
   if q>=2:
    box(x,x,base-1,yy-1,z,z,'timber')
   b(x,yy,z,n)
 # Small, solidly backed upturns at all four eave corners.
 for sx in [-1,1]:
  for sz in [-1,1]:
   xx=cx+sx*hx;zz=cz+sz*hz
   b(xx,base,zz,tile);b(xx-sx,base,zz,tile);b(xx,base,zz-sz,tile)
   b(xx,base+1,zz,tile+'_slab[type=bottom,waterlogged=false]')
 # Sculpted cornice: terminal eave blocks connect sideways to the actual shell.
 # Ridge decoration is wholly supported by full tiles, not by an air gap.
 if ring_only is None:
  yy=base+min(hx,hz)//2
  if hx>=hz:
   for x in range(cx-(hx-hz),cx+(hx-hz)+1):b(x,yy+1,cz,'gold_ridge' if tile=='gold_tiles' else tile)
   for x in set((cx-(hx-hz),cx+(hx-hz))): b(x,yy+2,cz,'finial')
  else:
   for z in range(cz-(hz-hx),cz+(hz-hx)+1):b(cx,yy+1,z,'gold_ridge' if tile=='gold_tiles' else tile)
   for z in set((cz-(hz-hx),cz+(hz-hx))):b(cx,yy+2,z,'finial')
  maxy=yy+2
 return maxy

def frame(cx,cz,hx,hz,f,h,open_hall=False,portal=3,through=False):
 # Low plinth, tall windows and upper lintel make facade proportions legible.
 wall='red_wall' if h>=7 else 'white_wall'
 if not open_hall:
  perimeter(cx-hx,cx+hx,f+1,f+h,cz-hz,cz+hz,wall)
  # Repeated bays, interrupted only by actual posts and doors.
  for x in range(cx-hx+2,cx+hx-1):
   if abs(x-cx)>portal//2:
    for z in [cz-hz,cz+hz]:box(x,x,f+2,f+h-1,z,z,'red_lattice' if h>=7 else 'dark_lattice')
  for z in range(cz-hz+2,cz+hz-1):
   for x in [cx-hx,cx+hx]:box(x,x,f+2,f+h-1,z,z,'red_lattice' if h>=7 else 'dark_lattice')
  box(cx-portal//2,cx+portal//2,f+1,f+min(4,h-1),cz+hz,cz+hz,'minecraft:air')
  if through:box(cx-portal//2,cx+portal//2,f+1,f+min(6,h),cz-hz,cz-hz,'minecraft:air')
 # Choose symmetric, off-centre column bays. No column ever occupies the central door.
 xs=sorted(set([-hx,hx]+[p for p in range(-hx+6,hx,6) if p<=-portal//2-2]+[-p for p in range(-hx+6,hx,6) if p<=-portal//2-2]))
 xs=[p for p in xs if -hx<=p<=hx and abs(p)>portal//2]
 zs=sorted(set([-hz,hz]+[p for p in range(-hz+6,hz,6)]))
 if not open_hall:
  for z in [cz-hz,cz+hz]:
   for x in xs:column(cx+x,z,f,h)
  for z in zs[1:-1]:
   for x in [cx-hx,cx+hx]:column(x,cz+z,f,h)
 else:
  for z in [cz-hz,cz+hz]:
   for x in xs:column(cx+x,z,f,h)
 # Cross beams and ceiling join every post and support the roof.
 box(cx-hx,cx+hx,f+h+1,f+h+1,cz-hz,cz+hz,'timber')
 perimeter(cx-hx,cx+hx,f+h+1,f+h+1,cz-hz,cz+hz,'gilded_beam' if h>=7 else 'jade_beam')
 # Soffit edge is held by bracketed eaves, never by detached street columns.
 for x in [cx-hx,cx+hx]:
  for z in [cz-hz,cz+hz]:
   box(x-1,x+1,f+h+1,f+h+1,z-1,z+1,'gilded_beam' if h>=7 else 'jade_beam')
 for x in range(cx-hx+3,cx+hx-2,8):
  for z in [cz-hz+2,cz+hz-2]:lamp(x,f+h,z)


def furniture(cx,cz,hx,hz,f,kind):
 # All furnishings stay out of the central three-block aisle and door landing.
 for x in [cx-hx+2,cx+hx-2]:
  for z in range(cz-hz+2,cz+hz-1,4):
   if kind in ['academy','guild']:
    b(x,f+1,z,'minecraft:bookshelf'); b(x,f+2,z,'minecraft:flower_pot')
   elif kind=='workshop':b(x,f+1,z,'minecraft:crafting_table')
   else:
    b(x,f+1,z,'minecraft:oak_planks');b(x,f+2,z,'minecraft:flower_pot')
 # Central runner is only on a full floor, not a suspended plate.
 for z in range(cz-hz+1,cz+hz):
  for x in range(cx-1,cx+2):b(x,f+1,z,'minecraft:red_carpet')

def building(name,cx,cz,w,d,f=64,h=5,tile='dark_tiles',kind='house',two=False,double=False,portal=3,open_hall=False):
 q=reserve(name,cx,cz,w,d,f,h,kind)
 hx=w//2;hz=d//2
 # Plinths are solid. The palace has three real setbacks, not a flat tall box.
 if kind=='palace':
  box(cx-hx-4,cx+hx+4,64,64,cz-hz-4,cz+hz+4,'carved_marble')
  box(cx-hx-3,cx+hx+3,65,f-1,cz-hz-3,cz+hz+3,'marble')
  box(cx-hx-2,cx+hx+2,f,f,cz-hz-2,cz+hz+2,'carved_marble')
  for xx in [cx-hx-2,cx+hx+2]:box(xx,xx,f+1,f+1,cz-hz-2,cz+hz+2,'marble_rail')
  box(cx-hx-2,cx+hx+2,f+1,f+1,cz-hz-2,cz-hz-2,'marble_rail')
  for xa,xb in [(cx-hx-2,cx-6),(cx+6,cx+hx+2)]:box(xa,xb,f+1,f+1,cz+hz+2,cz+hz+2,'marble_rail')
 else:
  box(cx-hx-2,cx+hx+2,64,f,cz-hz-2,cz+hz+2,'gray_brick')
  box(cx-hx-2,cx+hx+2,f,f,cz-hz-2,cz+hz+2,'floor' if kind!='pavilion' else 'marble')
 stair_run(cx,cz+hz+2,f,9 if kind=='palace' else portal+2)
 frame(cx,cz,hx,hz,f,h,open_hall,portal)
 furniture(cx,cz,hx,hz,f,kind)
 roofbase=f+h+2
 if two:
  upper=f+h+2
  # Upper floor and independent second frame; the two posts align vertically.
  box(cx-hx,cx+hx,upper,upper,cz-hz,cz+hz,'floor')
  frame(cx,cz,hx,hz,upper,5,False,3)
  furniture(cx,cz,hx,hz,upper,kind)
  # A second-floor doorway must open onto a supported balcony, not a drop.
  # Posts start on the existing ground-floor plinth; rail encloses all exposed edges.
  for xx in [cx-hx,cx+hx]:column(xx,cz+hz+2,f,upper-f-1)
  box(cx-hx-2,cx+hx+2,upper,upper,cz+hz+1,cz+hz+2,'floor')
  box(cx-hx-2,cx+hx+2,upper,upper,cz+hz+2,cz+hz+2,'jade_beam')
  box(cx-hx-2,cx+hx+2,upper+1,upper+1,cz+hz+2,cz+hz+2,'marble_rail')
  for xx in [cx-hx-2,cx+hx+2]:box(xx,xx,upper+1,upper+1,cz+hz,cz+hz+2,'marble_rail')
  q['balcony_entry']=[cx,upper+1,cz+hz+1]
  # Seven-step staircase against the rear wall; remove precisely its headroom.
  # It does not cross the door or central circulation aisle.
  sx=cx-hx+2;sz=cz-hz+2;rise=upper-f
  for t in range(rise):
   xx=sx+t;yy=f+1+t
   box(xx,xx,yy,upper+2,sz,sz+1,'minecraft:air')
   box(xx,xx,f+1,yy-1,sz,sz+1,'timber')
   box(xx,xx,yy,yy,sz,sz+1,'marble_stairs[facing=east,half=bottom,shape=straight,waterlogged=false]')
   stair_records.append({'x1':xx,'x2':xx,'z':sz,'y':yy,'face':'east','owner':cur,'upper':True})
  # Exit landing on the upper storey, with clear standing room.
  box(sx+rise,sx+rise+1,upper+1,upper+3,sz,sz+1,'minecraft:air')
  # Move lamps out of the staircase opening, retaining a real ceiling mount.
  for rec in list(lamps):
   lx,ly,lz,lk,lo=rec
   if lo==cur and v[lx+125,lz+125,ly-60]!=code(lk):
    lamps.remove(rec);lamp(lx,ly,cz,lk)
  q['upper_floor']=upper;q['stair_start']=[sx,f+1,sz];q['stair_exit']=[sx+rise,upper+1,sz]
  roofbase=upper+7
 if double:
  # Lower eave skirt and a smaller, supported clerestory, not two colliding roofs.
  hip_roof(cx,cz,hx+3,hz+3,roofbase,tile,ring_only=5)
  uhx=hx-3;uhz=hz-3;uf=roofbase
  box(cx-uhx,cx+uhx,uf,uf,cz-uhz,cz+uhz,'timber')
  perimeter(cx-uhx,cx+uhx,uf+1,uf+4,cz-uhz,cz+uhz,'red_lattice')
  box(cx-uhx,cx+uhx,uf+5,uf+5,cz-uhz,cz+uhz,'gilded_beam')
  q['roof_top']=hip_roof(cx,cz,uhx+3,uhz+3,uf+6,tile)
 else:q['roof_top']=hip_roof(cx,cz,hx+3,hz+3,roofbase,tile)
 q['entry']=[cx,f+1,cz+hz-1]
 return q

# -- Civil engineering, distinct from independent building parcels. --
box(-125,125,60,62,-125,125,'dark_brick',owner=0)
box(-125,125,63,63,-125,125,'grass',owner=0)
# Paved ring, moat and its impermeable bottom/sides.
for x in range(-125,126):
 for z in range(-125,126):
  r=max(abs(x),abs(z))
  if r>=118:
   b(x,63,z,'paving',owner=0)
   if 119<=r<=123:
    box(x,x,61,62,z,z,'minecraft:water',owner=0);b(x,63,z,'minecraft:air',owner=0)
  elif r>=99:b(x,63,z,'paving',owner=0)
# Four 13-wide bridges across the moat. Clearance is not a decorative promise.
for sign in [-1,1]:
 for z in range(118,126):
  for x in range(-6,7):b(x,63,sign*z,'paving',owner=0);b(sign*z,63,x,'paving',owner=0)
 for z in range(118,126):
  for x in [-7,7]:b(x,63,sign*z,'marble',owner=0);b(x,64,sign*z,'marble_rail',owner=0);b(sign*z,63,x,'marble',owner=0);b(sign*z,64,x,'marble_rail',owner=0)
# Mark exact pavement corridors, excluding intentional stair runs.
def street(x1,x2,z1,z2):
 box(x1,x2,63,63,z1,z2,'paving',owner=0);road[x1+125:x2+126,z1+125:z2+126]=True
street(-6,6,-58,125);street(-125,125,-4,4)
for a,b1 in [(-105,-99),(99,105),(-61,-55),(55,61)]:street(a,b1,-28,105)
for za,zb in [(38,44),(68,74),(99,105)]:street(-105,105,za,zb)
street(-105,105,-28,-22)
street(-105,105,-105,-101)
# Palace side access to the north gate; the central hall is not a through-road.
for x in [-77,77]:street(x-1,x+1,-103,-24)
street(-77,77,-103,-101);street(-6,6,-125,-101)
box(-17,17,63,63,-17,17,'marble',owner=0)
# Centre inlay stays flush with the paving.
for x in range(-10,11):
 for z in range(-10,11):
  rr=x*x+z*z
  if 64<=rr<=100:b(x,63,z,'carved_marble',owner=0)
b(0,63,0,'lotus',owner=0)
# Civil canals, under all crossing roads and bridge decks.
for sign in [-1,1]:
 for ax in range(11,15):
  for z in range(10,98):
   x=sign*ax
   if road[x+125,z+125]:continue
   b(x,61,z,'dark_brick',owner=0);b(x,62,z,'minecraft:water',owner=0);b(x,63,z,'minecraft:air',owner=0)
 for ax in [10,15]:
  for z in range(9,99):b(sign*ax,63,z,'carved_marble',owner=0)
# Outer wall compound: gate upper rooms and corner towers intentionally sit on the wall deck.
wallid=entity_owner('城防共同基座');cur=wallid
for x in range(-113,114):
 for z in range(-113,114):
  r=max(abs(x),abs(z))
  if 107<=r<=113:
   for y in range(64,73):b(x,y,z,'gray_brick' if y in [64,70] else 'red_wall' if 65<=y<=69 else 'paving')
   if r in [107,113]:
    b(x,73,z,'carved_marble')
    if (x+z)%3!=0:b(x,74,z,'gray_brick')
# Ground level gate tunnels preserve the marked road width.
for sign in [-1,1]:
 box(-6,6,64,71,sign*110-4,sign*110+4,'minecraft:air',allow=True)
 box(sign*110-4,sign*110+4,64,71,-6,6,'minecraft:air',allow=True)
# Four internal stair passages are carved INTO the seven-wide wall.
# They never consume a public street lane or cross a house parcel.
for sx in [-110,110]:
 for sign in [-1,1]:
  inner=-107 if sx<0 else 107
  # On-grade doorway from the inner ring road into the stair vestibule.
  box(min(inner,sx),max(inner,sx),64,67,min(sign*91,sign*92),max(sign*91,sign*92),'minecraft:air',allow=True)
  for i in range(9):
   zz=sign*(92+i);yy=64+i
   box(sx-1,sx+1,yy,75,zz,zz,'minecraft:air',allow=True)
   box(sx-1,sx+1,yy,yy,zz,zz,'paving_stairs[facing='+('south' if sign>0 else 'north')+',half=bottom,shape=straight,waterlogged=false]')
  # Walk-off landing on top of the wall, at Y=72.
  box(sx-1,sx+1,73,75,sign*101,sign*101,'minecraft:air',allow=True)
# Upper gatehouses and four corner towers. Pillars start on the solid deck y=72.
def wall_hall(name,cx,cz,w,d,portal=5):
 global cur
 cur=wallid
 # Clear only the parapets under this intended superstructure, not another house.
 box(cx-w//2-2,cx+w//2+2,73,75,cz-d//2-2,cz+d//2+2,'minecraft:air',allow=True)
 # Added corbelled floor extends from existing wall; gate columns have solid support.
 box(cx-w//2-1,cx+w//2+1,72,72,cz-d//2-1,cz+d//2+1,'paving')
 frame(cx,cz,w//2,d//2,72,5,False,portal,through=True)
 top=hip_roof(cx,cz,w//2+2,d//2+2,79,'gold_tiles')
 buildings.append({'id':wallid,'name':name,'cx':cx,'cz':cz,'width':w,'depth':d,'floor':72,'wall_height':5,'type':'gate_tower','parent':'fortification','envelope':[cx-w//2-2,cx+w//2+2,cz-d//2-2,cz+d//2+2],'roof_top':top,'entry':[cx,73,cz+d//2-1]})
 # Doorways on west/east walls allow walking from the wall deck through the room.
 for x in [cx-w//2,cx+w//2]:box(x,x,73,76,cz-1,cz+1,'minecraft:air',allow=True)
for sg in [-1,1]:wall_hall(('北' if sg<0 else '南')+'城門樓',0,sg*110,19,7,7)
for sg in [-1,1]:wall_hall(('西' if sg<0 else '東')+'城門樓',sg*110,0,7,19,3)
for x in [-110,110]:
 for z in [-110,110]:wall_hall(('西' if x<0 else '東')+('北' if z<0 else '南')+'角樓',x,z,9,9,3)
# Fill underlying terrace support under corner/gate deck extensions. Open gate
# tunnel remains on the marked route, supported by lintels instead of mid-road posts.
cur=wallid
for q in buildings:
 if q.get('parent')!='fortification':continue
 cx,cz=q['cx'],q['cz'];hx=q['width']//2;hz=q['depth']//2
 for x in [cx-hx,cx+hx]:
  for z in [cz-hz,cz+hz]:
   if road[x+125,z+125]:raise RuntimeError('Gate support on a road')
   box(x,x,64,71,z,z,'gray_brick')

# Palace boundary, distinct from the palace roofs and public streets.
cur=entity_owner('宮苑圍牆')
for x in [-73,73]:box(x,x,64,68,-99,-38,'red_wall');box(x,x,69,69,-99,-38,'dark_tiles_slab[type=bottom,waterlogged=false]')
for z in [-99,-38]:
 box(-73,73,64,68,z,z,'red_wall');box(-73,73,69,69,z,z,'dark_tiles_slab[type=bottom,waterlogged=false]')
# Central palace gate has enough clearance for the full 13-wide main road.
box(-14,14,64,69,-39,-37,'minecraft:air',allow=True)
# Secondary gates lead into the forecourt, not into the side-hall walls.
for x in [-73,73]:box(x,x,64,67,-50,-46,'minecraft:air',allow=True)
# Internal ceremonial paving and entrance apron.
box(-69,69,63,63,-96,-40,'paving',owner=0)
# Main hall: 49x25 body, raised four blocks, seven-bay facade and double eaves.
building('承天正殿',0,-77,49,25,f=67,h=8,tile='gold_tiles',kind='palace',double=True,portal=7)
# West is authoring half. East is an exact block-state reflection, including furniture.
building('西配殿',-52,-77,23,29,f=65,h=6,tile='gold_tiles',kind='academy',portal=3)
# Palace gate is on grade. Through passage has NO centre post and NO furniture.
q=reserve('承天宮門',0,-38,19,9,63,7,'palace_gate');hx=9;hz=4
frame(0,-38,hx,hz,63,7,False,13,through=True)
box(-6,6,64,68,-42,-34,'minecraft:air')
q['roof_top']=hip_roof(0,-38,12,7,72,'gold_tiles');q['entry']=[0,64,-38]
# Gardener's pavilions in independent, clearly spaced garden parcels.
building('西御苑亭',-88,-78,11,11,f=64,h=5,tile='jade_tiles',kind='pavilion',open_hall=True,portal=3)
# Government offices in front of palace, facing central transverse avenue.
building('西內署',-34,-14,23,9,f=64,h=5,tile='dark_tiles',kind='academy')
building('西外署',-77,-14,23,9,f=64,h=5,tile='dark_tiles',kind='academy')
# Lower city: different heights/types, intentionally no overlapping eave envelopes.
building('西市廊',-32,23,23,13,f=64,h=5,tile='dark_tiles',kind='market',open_hall=True)
building('西會館',-80,23,19,13,f=64,h=5,tile='jade_tiles',kind='guild',two=True)
building('西中坊宅院',-32,55,23,9,f=64,h=5,tile='dark_tiles',kind='house')
building('西作坊',-80,55,19,9,f=64,h=5,tile='dark_tiles',kind='workshop')
building('西南坊宅院',-32,86,23,11,f=64,h=5,tile='dark_tiles',kind='house')
building('西茶樓',-80,86,19,11,f=64,h=5,tile='jade_tiles',kind='tea',two=True)
# Door approaches are a protected three-wide circulation lane to the nearest street.
for q in buildings:
 if q['cx']>0 or q['type'] in ['gate_tower','palace_gate','palace','pavilion','academy']:continue
 cx,cz,f=q['cx'],q['cz'],q['floor'];front=cz+q['depth']//2+2+(f-63)
 target=38 if cz==23 else 68 if cz==55 else 99
 if front<target:street(cx-2,cx+2,front+1,target)
# One-step entrance sidewalks for the government offices and side hall.
for cx in [-34,-77]:street(cx-2,cx+2,-5,-4)
street(-54,-50,-57,-50)
street(-70,-49,-50,-46)
street(-90,-86,-69,-59)
# Grounded tree clusters, leaving the roofs and protected approaches untouched.
def tree(x,z,h=5,leaf='peach_leaves'):
 global cur
 cur=entity_owner('庭園樹 '+str((x,z)))
 for xx in range(x-3,x+4):
  for zz in range(z-3,z+4):
   if road[xx+125,zz+125]:raise RuntimeError(('tree over road',x,z))
 box(x,x,64,63+h,z,z,'peach_log')
 for dy,r in [(h-2,2),(h-1,3),(h,3),(h+1,2),(h+2,1)]:
  for xx in range(-r,r+1):
   for zz in range(-r,r+1):
    if xx*xx+zz*zz<=r*r+1 and not(xx==0 and zz==0 and dy<=h):b(x+xx,63+dy,z+zz,leaf)
 b(x,63,z,'minecraft:dirt',owner=0)
for x,z in [(-88,-94),(-94,-64),(-69,8),(-46,8),(-21,8),(-50,86),(-50,23)]:tree(x,z)
# Walled garden ponds have fixed stone rims and impervious bottoms.
cur=entity_owner('西御苑水池')
for x in range(-96,-79):
 for z in range(-55,-41):
  edge=(x in [-96,-80] or z in [-55,-42])
  b(x,61,z,'gray_brick',owner=0);b(x,62,z,'gray_brick' if edge else 'minecraft:water',owner=0);b(x,63,z,'carved_marble' if edge else 'minecraft:air',owner=0)
# Built-in lights: flat street inlays (15) and supported foot/path lamps (15).
cur=entity_owner('公共照明')
for z in range(-28,102,8):
 for x in [-5,5]:b(x,63,z,'inlaid_lamp');lamps.append([x,63,z,'inlaid_lamp',cur])
for z in [0,41,71,102,-25]:
 for x in range(-101,0,8):
  if road[x+125,z+125]:b(x,63,z,'inlaid_lamp');lamps.append([x,63,z,'inlaid_lamp',cur])
for x in [-58,-102]:
 for z in range(-24,103,10):
  b(x,63,z,'inlaid_lamp');lamps.append([x,63,z,'inlaid_lamp',cur])
# Lamp posts sit on sidewalks, never within the protected road rectangle.
for x in [-8]:
 for z in [20,50,82]:
  b(x,64,z,'column_foot');box(x,x,65,66,z,z,'column_shaft');b(x,67,z,'marble');lamp(x,68,z,'stone_lamp')
  columns.append({'x':x,'z':z,'base':64,'top':66,'owner':cur,'lamp_post':True})
# Illumination for palace forecourt, entries and garden walks.
for x,z in [(-18,-50),(-65,-53),(-88,-58),(-24,-30),(-43,-30),(-92,6)]:
 if v[x+125,z+125,4]==0 and v[x+125,z+125,3]!=0:lamp(x,64,z,'stone_lamp')
# Keep the arrival and road centreline free; inlays do not change collision.

# Canonical X reflection, including east/west facing. Center column is left alone.
def mirror(s):
 def exchange(m):return 'facing='+{'east':'west','west':'east'}.get(m.group(1),m.group(1))
 s=re.sub(r'facing=(east|west|north|south)',exchange,s)
 s=s.replace('inner_left','TEMPIL').replace('inner_right','inner_left').replace('TEMPIL','inner_right')
 s=s.replace('outer_left','TEMPOL').replace('outer_right','outer_left').replace('TEMPOL','outer_right')
 return s
for s in list(palette):code(mirror(s))
mirr=np.array([lookup[mirror(s)] for s in palette],dtype=np.uint16)
v[126:]=mirr[v[:125][::-1]];own[126:]=own[:125][::-1];road[126:]=road[:125][::-1]
# Replace metadata east structures with exact reflections of authored west structures.
west=[q for q in buildings if q['cx']<0];center=[q for q in buildings if q['cx']==0];buildings=west+center
for q in west:
 r=json.loads(json.dumps(q));r['name']=r['name'].replace('西','東');r['cx']=-q['cx'];a,b1,c,d1=q['envelope'];r['envelope']=[-b1,-a,c,d1];r['mirrored']=True
 for key in ['entry','stair_start','stair_exit','balcony_entry']:
  if key in r:r[key][0]=-r[key][0]
 buildings.append(r)
columns=[q for q in columns if q['x']<=0]
columns += [dict(q,x=-q['x'],mirrored=True) for q in list(columns) if q['x']<0]
lamps=[q for q in lamps if q[0]<=0]
lamps += [[-q[0],*q[1:]] for q in list(lamps) if q[0]<0]
# Guard that the precisely authored center column itself is mirror invariant.
assert np.array_equal(v,mirr[v[::-1]]),'state reflection mismatch'
# Serialize same runtime format. No duplicate structure placement is introduced.
raw=bytearray(struct.pack('>6i',0x57435431,1,N,Y0,H,len(palette)))
for s in palette:
 t=s.encode('ascii');raw.extend(struct.pack('>H',len(t)));raw.extend(t)
raw.extend(v.astype('>u2').tobytes(order='C'))
source=D/'city/capital_v3.wct.gz';source.parent.mkdir(parents=True,exist_ok=True);source.write_bytes(gzip.compress(bytes(raw),mtime=0))
np.save(A/'city_voxels.npy',v);np.save(A/'ownership.npy',own);np.save(A/'protected_roads.npy',road)
js(A/'palette.json',palette);js(A/'buildings.json',buildings);js(A/'columns.json',columns);js(A/'lights.json',lamps);js(A/'stairs.json',stair_records)
meta=json.loads((P/'art_source/city2/materials.json').read_text());meta['decorations'].extend([[n,zh,en,base,kind] for n,zh,en,base,kind,_ in NEW]);js(A/'materials.json',meta)
manifest={'city_version':3,'bounds':[-125,125,60,127,-125,125],'center':[0,0],'symmetry':'X=0 block column','source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'building_count':len(buildings),'max_occupied_y':int(np.nonzero(v)[2].max()+60),'non_air':int(np.count_nonzero(v)),'states':len(palette),'registered_new_blocks':[q[0] for q in NEW], 'roles':roles}
js(A/'city_manifest.json',manifest)
print(json.dumps(manifest,ensure_ascii=False,indent=2))
