#!/usr/bin/env python3
"""The active appearance is Model 1; run its checks (not the old zombie-UV test)."""
import runpy
from pathlib import Path
runpy.run_path(str(Path(__file__).with_name("check_model1.py")), run_name="__main__")
