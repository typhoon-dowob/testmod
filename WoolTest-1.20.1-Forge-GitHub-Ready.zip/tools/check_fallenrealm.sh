#!/usr/bin/env bash
set -euo pipefail
export LANG=C.UTF-8 LC_ALL=C.UTF-8
cd "$(dirname "$0")/.."
TMP="$(mktemp -d)"; trap 'rm -rf "$TMP"' EXIT
SRC=src/main/java/dev/sushi/wooltest/fallen
javac --release 17 -encoding UTF-8 -d "$TMP" tools/ParseJava.java tools/FallenRulesTest.java "$SRC/FallenRules.java" "$SRC/FallenTerrain.java" "$SRC/FallenLayoutData.java"
java -cp "$TMP" ParseJava src/main/java
java -cp "$TMP" FallenRulesTest src/main/resources/data/wooltest/fallen/landmarks.frp.gz
python tools/check_fallenrealm_resources.py
printf '\nOFFLINE ONLY: not a Forge API compile and not an in-game test.\n'
