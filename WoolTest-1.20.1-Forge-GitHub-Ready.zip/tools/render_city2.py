#!/usr/bin/env python3
"""Offline geometry inspection using actual palette and block models, not an in-game screenshot."""
from pathlib import Path
from PIL import Image,ImageDraw,ImageFont
import numpy as np, json, math, re
ROOT=Path(__file__).resolve().parents[1]; A=ROOT/'art_source/city2'; OUT=ROOT/'art_preview';OUT.mkdir(exist_ok=True)
v=np.load(A/'city_voxels.npy'); palette=json.loads((A/'palette.json').read_text()); meta=json.loads((A/'materials.json').read_text())
colors={a[0]:a[3] for a in meta['base']}
for name,_,_,base,_ in meta['variants']+meta['decorations']:colors[name]=colors[base]
colors['water']=[64,131,150]
# Palette models represented as boxes with exact unit-block geometry.
models=[]; rgb=[]; full=[]
for p in palette:
 name=p.split(':')[1].split('[')[0];rgb.append(colors.get(name,[205,205,205]))
 if name=='air':models.append([]);full.append(False);continue
 boxes=[([0,0,0],[1,1,1])]
 if name.endswith('_slab'):boxes=[([0,0,0],[1,.5,1])]
 if name.endswith('_stairs'):
  facing=re.search(r'facing=(\w+)',p).group(1)
  t={'east':([.5,.5,0],[1,1,1]),'west':([0,.5,0],[.5,1,1]),'north':([0,.5,0],[1,1,.5]),'south':([0,.5,.5],[1,1,1])}[facing]
  boxes=[([0,0,0],[1,.5,1]),t]
 if name in ('capital_red_column','capital_marble_rail','capital_bracket','capital_finial','capital_red_lantern','capital_gold_lantern'):
  model=json.loads((ROOT/'src/main/resources/assets/wooltest/models/block'/f'{name}.json').read_text())
  boxes=[([n/16 for n in e['from']],[n/16 for n in e['to']]) for e in model['elements']]
 models.append(boxes);full.append(boxes==[([0,0,0],[1,1,1])])
full=np.array(full); rgb=np.array(rgb,dtype=float)
# South-east view, towards palace at north (-Z).
right=np.array([.928,0,-.371]);up=np.array([-.224,.798,-.560]);view=np.cross(right,up)
W,H=2000,1550;scale=5.15;origin=np.array([1000.,845.])
def project(points):
 p=np.array(points);return np.stack([p@right,-p@up],axis=1)*scale+origin
faces=[]
coords=np.argwhere(v>0)
for ix,iz,iy in coords:
 pi=int(v[ix,iz,iy]); x=float(ix-125);z=float(iz-125);y=float(iy)
 # Omit fully buried full blocks; see only up/east/south.
 neighbors=[full[int(v[ix+1,iz,iy])] if ix<250 else False,
            full[int(v[ix,iz+1,iy])] if iz<250 else False,
            full[int(v[ix,iz,iy+1])] if iy<67 else False]
 if full[pi] and all(neighbors):continue
 for a,b in models[pi]:
  x1,y1,z1=x+a[0],y+a[1],z+a[2];x2,y2,z2=x+b[0],y+b[1],z+b[2]
  fs=[([(x2,y1,z1),(x2,y1,z2),(x2,y2,z2),(x2,y2,z1)],.71,neighbors[0] and b[0]==1),
      ([(x1,y1,z2),(x2,y1,z2),(x2,y2,z2),(x1,y2,z2)],.86,neighbors[1] and b[2]==1),
      ([(x1,y2,z1),(x2,y2,z1),(x2,y2,z2),(x1,y2,z2)],1.03,neighbors[2] and b[1]==1)]
  for points,shade,hidden in fs:
   if hidden:continue
   pts=np.array(points); depth=float(pts.mean(axis=0)@view)
   noise=(((abs(int(x))*173+int(z)*67+int(y)*23)%11)-5)*.8
   col=tuple(np.clip(rgb[pi]*shade+noise,0,255).astype(np.uint8))
   faces.append((depth,project(pts),col))
faces.sort(key=lambda f:f[0])
im=Image.new('RGB',(W,H),(236,233,222));d=ImageDraw.Draw(im)
# a soft schematic ground shadow (not an illumination simulation)
shadow=project([(-125,-1,-125),(126,-1,-125),(126,-1,126),(-125,-1,126)])+np.array([12,12])
d.polygon([tuple(p) for p in shadow],fill=(203,201,192))
for _,pts,col in faces:d.polygon([tuple(p) for p in pts],fill=col)
font='/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf'
def f(size):return ImageFont.truetype(font,size)
d.text((70,45),'CAPITAL CITY 2 - SYMMETRIC | CHENGTIAN',font=f(42),fill=(39,43,45))
d.text((72,103),'251 x 251 blocks  /  center X=0, Z=0  /  palace at north',font=f(24),fill=(81,85,86))
d.text((72,H-80),'ACTUAL BLUEPRINT GEOMETRY  |  flat-color offline preview, not an in-game screenshot',font=f(22),fill=(81,85,86))
im.save(OUT/'city2-geometry-preview.png')
# Plan from topmost actual block; north is up, not mirrored.
heights=np.max(np.where(v>0,np.arange(v.shape[2])[None,None,:],-1),axis=2)
xx,zz=np.indices(heights.shape);idx=v[xx,zz,heights]
arr=rgb[idx].transpose(1,0,2).astype('uint8')
plan=Image.fromarray(arr).resize((1255,1255),Image.Resampling.NEAREST)
paper=Image.new('RGB',(1455,1465),(236,233,222));paper.paste(plan,(100,130));dr=ImageDraw.Draw(paper)
dr.text((100,35),'CAPITAL CITY 2 - SYMMETRIC | ACTUAL BLOCK PLAN',font=f(36),fill=(39,43,45))
dr.text((100,85),'NORTH (-Z)   |   each block is shown at 5 pixels',font=f(21),fill=(81,85,86))
dr.rectangle((100,130,1354,1384),outline=(40,45,48),width=2)
cx=100+125*5+2;cz=130+125*5+2
dr.ellipse((cx-8,cz-8,cx+8,cz+8),outline=(255,255,255),width=3)
dr.text((cx+14,cz-8),'(0,0)',font=f(20),fill=(255,255,255))
paper.save(OUT/'city2-plan.png')
print('Rendered',len(faces),'faces from actual city data.')
