#!/usr/bin/env python3
"""Reproducible blockout for the Fallen Realm prototype. No downloaded building templates."""
from pathlib import Path
import gzip, struct, json, math, random
import numpy as np
ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'src/main/resources/data/wooltest/fallen';OUT.mkdir(parents=True,exist_ok=True)
palette=['minecraft:air'];lookup={palette[0]:0}
def pid(state):
    if ':' not in state: state='minecraft:'+state
    if state not in lookup:lookup[state]=len(palette);palette.append(state)
    return lookup[state]
class Site:
    def __init__(self,key,cx,cz,w,d,h=80):
        self.key=key;self.cx=cx;self.cz=cz;self.w=w;self.d=d;self.h=h;self.minY=68
        self.a=np.zeros((w,d,h),dtype=np.uint16);self.buildings=[];self.windows=[];self.doors=[]
    def put(self,x,y,z,b):
        xx=x+self.w//2;zz=z+self.d//2;yy=y-self.minY
        if not(0<=xx<self.w and 0<=zz<self.d and 0<=yy<self.h):raise ValueError((self.key,x,y,z))
        self.a[xx,zz,yy]=pid(b)
    def box(self,x0,y0,z0,x1,y1,z1,b):
        for x in range(x0,x1+1):
            for z in range(z0,z1+1):
                for y in range(y0,y1+1):self.put(x,y,z,b)
    def foundation(self):
        self.a[:,:,:4]=pid('stone')
        self.a[:,:,4]=pid('coarse_dirt')
        for x in range(-self.w//2+1,self.w//2+1):
            for z in range(-self.d//2+1,self.d//2+1):
                if abs(x)<=4 or abs(z)<=4:self.put(x,72,z,'stone_bricks')
    def wall(self,x0,z0,x1,z1,y,h=7):
        for x in range(x0,x1+1):
            for z in range(z0,z1+1):
                for yy in range(y,y+h):
                    material='cracked_stone_bricks' if (x*31+z*17+yy)%7<2 else 'stone_bricks'
                    self.put(x,yy,z,material)
                if (x+z)%3!=0:self.put(x,y+h,z,'polished_deepslate')
    def house(self,name,x0,z0,x1,z1,wallh=7,ruined=False,stone=False):
        # Inclusive reserved roof bounds. Doors face south (+Z), windows never touch door frame.
        footprint=(x0-1,z0-1,x1+1,z1+1)
        for b in self.buildings:
            a=b['bounds'];assert footprint[2]<a[0] or footprint[0]>a[2] or footprint[3]<a[1] or footprint[1]>a[3],(name,b['name'])
        self.buildings.append({'name':name,'bounds':footprint,'floor_y':72,'wall_height':wallh})
        self.box(x0,72,z0,x1,72,z1,'stone_bricks')
        mid=(x0+x1)//2
        for x in range(x0,x1+1):
            for z in range(z0,z1+1):
                if x not in (x0,x1) and z not in(z0,z1):continue
                for y in range(73,73+wallh):
                    corner=x in(x0,x1) and z in(z0,z1)
                    mat='polished_blackstone_bricks' if stone else ('dark_oak_log[axis=y]' if corner else 'gray_terracotta')
                    if not corner:
                        if y in(75,76) and ((z in(z0,z1) and abs(x-mid)>=4 and x%4 in(0,1)) or (x in(x0,x1) and (z-z0)%6 in(2,3))):
                            mat='gray_stained_glass';self.windows.append([x,y,z])
                    if not ruined or not (x>x1-3 and z<z0+4 and y>75):self.put(x,y,z,mat)
        for x in range(mid-1,mid+2):
            for y in range(73,77):self.put(x,y,z1,'air');self.doors.append([x,y,z1])
        self.box(mid-2,77,z1,mid+2,77,z1,'polished_blackstone_bricks')
        # Load-bearing horizontal beams beneath the gable and an open interior.
        self.box(x0,73+wallh-1,z0,x1,73+wallh-1,z0,'dark_oak_log[axis=x]')
        self.box(x0,73+wallh-1,z1,x1,73+wallh-1,z1,'dark_oak_log[axis=x]')
        for x in range(x0-1,x1+2):
            rise=min(x-(x0-1),(x1+1)-x)
            yy=73+wallh+rise
            for z in range(z0-1,z1+2):
                # Planned broken corner reaches down to remaining walls, not isolated roof blocks.
                if ruined and x>x1-3 and z<z0+4:continue
                facing='east' if x<mid else 'west'
                mat='deepslate_tile_stairs[facing='+facing+',half=bottom,shape=straight,waterlogged=false]'
                if x==mid:mat='deepslate_tiles'
                self.put(x,yy,z,mat)
                if z in(z0,z1):
                    for fill in range(73+wallh,yy):self.put(x,fill,z,'dark_oak_planks')
        self.put(x0+2,73,z0+2,'crafting_table')
        self.put(x1-2,73,z0+2,'bookshelf')
        self.put(x1-2,74,z0+2,'soul_lantern[hanging=false,waterlogged=false]')
        for x in (x0+1,x1-1):self.put(x,73,z1-1,'cobweb') if ruined else None
    def lamp(self,x,z):
        self.box(x,73,z,x,75,z,'polished_blackstone_bricks')
        self.put(x,76,z,'soul_lantern[hanging=false,waterlogged=false]')
    def border(self):
        a=self.w//2-3;b=self.d//2-3
        self.wall(-a,-b,a,-b,73)
        self.wall(-a,-b,-a,b,73)
        self.wall(a,-b,a,b,73)
        self.wall(-a,b,-5,b,73);self.wall(5,b,a,b,73)
        # Stone arch over a nine-block clear gate; three-block-thick abutments.
        self.box(-7,73,b-1,-5,82,b+1,'polished_blackstone_bricks')
        self.box(5,73,b-1,7,82,b+1,'polished_blackstone_bricks')
        self.box(-7,82,b-1,7,84,b+1,'cracked_stone_bricks')
        for x in(-a,a):
            for z in(-b,b):
                self.box(x-1,73,z-1,x+1,86,z+1,'stone_bricks')
                self.box(x-2,87,z-2,x+2,87,z+2,'polished_deepslate')
    def hall(self):
        # Large open ruin basilica. Root arena is central and free of columns/furniture.
        x0,x1,z0,z1=-24,24,-78,-4
        self.house('斯洛特王座大殿',x0,z0,x1,z1,wallh=17,stone=True)
        # Wider ceremonial entry; no glass within four blocks of it.
        self.box(-4,73,z1,4,81,z1,'air')
        self.box(-5,82,z1,5,83,z1,'polished_deepslate')
        for x in (-18,18):
            for z in (-70,-58,-46,-34,-22):
                self.box(x,73,z,x,88,z,'polished_blackstone_bricks')
                self.box(x-1,89,z-1,x+1,89,z+1,'chiseled_stone_bricks')
        # Raised throne beyond the combat floor; slabs/steps remain outside objective circle.
        self.box(-7,73,-75,7,74,-66,'polished_deepslate')
        for y in range(75,81):self.put(0,y,-73,'gilded_blackstone')
        self.box(-2,75,-73,2,76,-71,'polished_blackstone_bricks')
        for x in(-15,15):
            for z in(-62,-14):self.lamp(x,z)
        # Twin chapel spires, deliberately separate from the nave roof.
        for sx in(-34,34):
            self.box(sx-4,72,-70,sx+4,91,-62,'stone_bricks')
            self.box(sx-2,73,-68,sx+2,89,-64,'air')
            self.box(sx-1,73,-62,sx+1,77,-62,'air')
            for i in range(5):
                self.box(sx-5+i,92+i*2,-71+i,sx+5-i,93+i*2,-61-i,'deepslate_tiles')
            self.box(sx,102,-66,sx,106,-66,'iron_bars')
        # Five permanent visual sockets for objectives (not actual roots).
        for k in range(5):
            ang=2*math.pi*k/5
            x=round(math.sin(ang)*10);z=-29+round(math.cos(ang)*10)
            self.box(x-1,72,z-1,x+1,72,z+1,'chiseled_polished_blackstone')
    def verify(self):
        assert set(map(tuple,self.windows)).isdisjoint(set(map(tuple,self.doors)))
        return {'id':self.key,'center':[self.cx,self.cz],'size':[self.w,self.h,self.d],
                'min_y':self.minY,'buildings':self.buildings,'nonair':int(np.count_nonzero(self.a))}

emp=Site('slot_empire_center',0,0,145,177);emp.foundation();emp.border();emp.hall()
for side in(-1,1):
    for i,z in enumerate((8,43)):
        x0,x1=((-58,-32) if side<0 else(32,58))
        emp.house(('西' if side<0 else'東')+('軍營' if i==0 else'祭院'),x0,z,x1,z+22,7,ruined=(i==0),stone=True)
    for z in(12,35,58,76):emp.lamp(side*8,z)
# Fallen pillars and rubble only in reserved gardens, not the central avenue.
for x,z in[(-20,27),(21,50),(-52,-35),(52,-30)]:
    emp.box(x,73,z,x+4,73,z+1,'mossy_stone_bricks');emp.put(x,74,z,'cracked_stone_bricks')

city=Site('miteye_city',-320,160,95,95,64);city.foundation();city.border()
for side in(-1,1):
    for row,(z0,z1) in enumerate([(-34,-14),(10,30)]):
        x0,x1=((-33,-12) if side<0 else (12,33))
        city.house(('西' if side<0 else'東')+('鐘樓街' if row==0 else'商賈街'),x0,z0,x1,z1,8,ruined=(side<0 and row==0))
for x in(-7,7):
    for z in(-29,0,29):city.lamp(x,z)

v=Site('kers_village',288,224,65,65,48);v.foundation()
for side in(-1,1):
    for row,z0 in enumerate((-25,-5,15)):
        x0,x1=((-26,-10) if side<0 else (10,26))
        v.house(('西' if side<0 else'東')+f'村舍{row+1}',x0,z0,x1,z0+10,5,ruined=(row==2))
v.box(-2,73,-2,2,73,2,'mossy_cobblestone');v.box(-1,73,-1,1,73,1,'water[level=0]')
for x in(-5,5):v.lamp(x,7)
sites=[emp,city,v]
manifest=[s.verify() for s in sites]
# Every objective, boss and spawn point has real support and headroom.
for x,z in[(0,-29)]+[(round(math.sin(2*math.pi*k/5)*10),-29+round(math.cos(2*math.pi*k/5)*10))for k in range(5)]:
    assert emp.a[x+72,z+88,4]!=0
    assert not emp.a[x+72-1:x+72+2,z+88-1:z+88+2,5:9].any(),('arena obstruction',x,z)
buf=bytearray()
def ii(x):buf.extend(struct.pack('>i',x))
def utf(s):
    bs=s.encode();buf.extend(struct.pack('>H',len(bs)));buf.extend(bs)
ii(0x46525031);ii(1);ii(len(palette))
for p in palette:utf(p)
ii(len(sites))
for s in sites:
    utf(s.key)
    for n in(s.cx-s.w//2,s.cz-s.d//2,s.minY,s.w,s.d,s.h):ii(n)
    buf.extend(s.a.astype('>u2').tobytes())
with gzip.GzipFile(filename=str(OUT/'landmarks.frp.gz'),mode='wb',mtime=0) as f:f.write(buf)
(OUT/'landmarks.json').write_text(json.dumps({'palette':palette,'landmarks':manifest},ensure_ascii=False,indent=2))
print(json.dumps(manifest,ensure_ascii=False,indent=2))
