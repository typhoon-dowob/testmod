import dev.sushi.wooltest.logic.TestRules;
import java.util.HashSet;
import java.util.Set;

/** Plain Java smoke tests. Does NOT claim to compile or launch Minecraft/Forge. */
public final class CoreRulesTest {
    private static int assertions;
    private static void check(boolean condition, String message) {
        assertions++;
        if (!condition) throw new AssertionError(message);
    }
    public static void main(String[] args) {
        Set<Integer> all = new HashSet<>();
        for (int x = -64; x < 64; x++) {
            for (int z = -64; z < 64; z++) {
                int c = TestRules.colourIndex(x, 63, z);
                check(c >= 0 && c < 16, "colour out of range");
                check(c == TestRules.colourIndex(x + 32, 63, z + 32), "broken tiling");
                all.add(c);
            }
        }
        check(all.size() == 16, "not all 16 colours generated");
        for (int ox : new int[]{-64, -32, 0, 32}) {
            int[] counts = new int[16];
            for (int x = ox; x < ox + 32; x++) {
                for (int z = ox; z < ox + 32; z++) counts[TestRules.colourIndex(x, 63, z)]++;
            }
            for (int c : counts) check(c == 64, "32x32 tile is not balanced");
        }
        check(!TestRules.isTerrainY(-1), "terrain below zero");
        check(TestRules.isTerrainY(0), "missing bottom wool");
        check(TestRules.isTerrainY(63), "missing surface wool");
        check(!TestRules.isTerrainY(64), "no air above ground");
        check(!TestRules.isTerrainY(128), "terrain above build limit");
        check(TestRules.pillarFits(64, 0, 128), "normal pillar rejected");
        check(TestRules.pillarFits(124, 0, 128), "top valid pillar rejected");
        check(!TestRules.pillarFits(125, 0, 128), "pillar crosses max build height");
        check(!TestRules.pillarFits(0, 0, 128), "pillar has no supporting floor");
        check(!TestRules.pillarFits(Integer.MAX_VALUE, 0, 128), "integer overflow");
        check(TestRules.insidePillarRadius(0.5, 0.5, 5, 0), "five-block boundary rejected");
        check(TestRules.insidePillarRadius(0.5, 0.5, 3, 4), "3-4-5 boundary rejected");
        check(!TestRules.insidePillarRadius(0.5, 0.5, 4, 4), "square instead of circular radius");
        check(!TestRules.insidePillarRadius(0.5, 0.5, 6, 0), "out-of-range pillar accepted");
        int available = 0;
        for (int x = -5; x <= 5; x++) {
            for (int z = -5; z <= 5; z++) {
                if (TestRules.insidePillarRadius(0.5, 0.5, x, z)) available++;
            }
        }
        check(available == 81, "incorrect lattice circle");
        check(TestRules.PILLAR_COUNT == 3 && TestRules.PILLAR_HEIGHT == 4, "wrong pillar shape/count");
        check(TestRules.MAX_HEALTH == 20 && TestRules.MELEE_DAMAGE == 1 && TestRules.PILLAR_DAMAGE == 3,
                "wrong combat base values");
        check(TestRules.PILLAR_LIFETIME_TICKS < TestRules.CAST_COOLDOWN_TICKS,
                "successive casts accumulate pillars by default");
        check(TestRules.HIT_COOLDOWN_TICKS == 20, "wrong shared damage cooldown");
        System.out.println("PASS: " + assertions + " pure-Java rule assertions. No Minecraft runtime tested.");
    }
}
