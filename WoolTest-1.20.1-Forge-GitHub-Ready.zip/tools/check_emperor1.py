from pathlib import Path
from PIL import Image
import numpy as np,json,re,hashlib
P=Path(__file__).resolve().parent.parent
A=P/'art_source/emperor1';J=P/'src/main/java/dev/sushi/wooltest';R=P/'src/main/resources'
spec=json.loads((A/'emperor_model.json').read_text())
tex=Image.open(R/'assets/wooltest/textures/entity/emperor.png').convert('RGBA')
assert tex.size==(512,512)
known={'root':(0,0,0)};used=set();boxes=[];count=0
for node in spec['nodes']:
 assert node['parent'] in known and node['name'] not in known
 known[node['name']]=tuple(a+b for a,b in zip(known[node['parent']],node['offset']))
 for c in node['cubes']:
  count+=1;lo=np.array(known[node['name']])+np.array(c['origin']);hi=lo+np.array(c['size']);boxes.append((lo,hi))
  assert all(v>0 for v in c['size'])
  for face,(x,y,w,h) in c['faces'].items():
   assert 0<=x<x+w<=256 and 0<=y<y+h<=256
   pixels=np.array(tex.crop((x*2,y*2,(x+w)*2,(y+h)*2)))
   assert (pixels[:,:,3]==255).all(),(c['name'],face)
   for yy in range(y,y+h):
    for xx in range(x,x+w):
     assert (xx,yy) not in used,(c['name'],face);used.add((xx,yy))
assert count==37
lo=np.min([b[0] for b in boxes],axis=0);hi=np.max([b[1] for b in boxes],axis=0)
assert lo[0]>=-16 and hi[0]<=16 and lo[2]>=-16 and hi[2]<=16
assert lo[1]==-24 and hi[1]==24
model=(J/'client/EmperorModel.java').read_text()
assert model.count('.addBox(')==37 and 'LayerDefinition.create(mesh, 256, 256)' in model
print('PASS: 22 model nodes, 37 cuboids / 222 UV faces; no UV overlap or transparent mapped surfaces; neutral model fits 2x2x3 box.')
for name,size in [('item/imperial_sword.png',(32,32)),('effect/imperial_circle.png',(512,512)),('effect/imperial_beam.png',(32,32))]:
 im=Image.open(R/'assets/wooltest/textures'/name);assert im.size==size and im.mode=='RGBA';a=np.array(im)[:,:,3];assert a.min()==0 and a.max()>200
print('PASS: Original sword, circle and beam RGBA textures; exact resource dimensions and alpha.')
vox=np.load(P/'art_source/city4/city_voxels.npy');pal=json.loads((P/'art_source/city4/palette.json').read_text())
# Spawn bbox [X-.5?] uses actual X=.5, Z=-80.5, radius=1, feet=68+1/16.
for x in [-1,0,1]:
 for z in [-82,-81,-80]:
  assert pal[int(vox[x+125,z+125,67-60])]=='wooltest:capital_carved_marble'
  s=pal[int(vox[x+125,z+125,68-60])];assert s in ('minecraft:air','minecraft:red_carpet'),(x,z,s)
  for y in [69,70,71]:assert pal[int(vox[x+125,z+125,y-60])]=='minecraft:air'
print('PASS: Actual City 4 palace spawn footprint supported; 2x2x3 bbox clears walls/columns/ceiling and sits at carpet top.')
for p in R.rglob('*.json'):json.loads(p.read_text())
mod=(J/'ModContent.java').read_text();client=(J/'client/ClientEvents.java').read_text();main=(J/'WoolTestMod.java').read_text()
for name in ['emperor','imperial_cast','imperial_sword','emperor_spawn_egg']:assert f'"{name}"' in mod
assert 'EmperorEntity.createAttributes()' in main and 'PalaceEmperorSpawner::onServerTick' in main
assert 'EmperorModel::createBodyLayer' in client and 'ImperialCastRenderer::new' in client
for key in ['imperial_melee','imperial_magic']:assert (R/f'data/wooltest/damage_type/{key}.json').exists()
for p in J.rglob('*.java'):
 if 'client' not in p.parts: assert 'import net.minecraft.client.' not in p.read_text(),p
source=(J/'entity/ImperialCastEntity.java').read_text()
assert source.count('victim.hurt(')==1
assert 'if (!(level() instanceof ServerLevel server) || !isCharging()) return;' in source
assert 'noSave()' in mod and 'palaceBorn' in (J/'entity/EmperorEntity.java').read_text()
print('PASS: Entity/item/effect registrations, damage types, render hookups, language JSON, logical-side separation and one damage call per victim in the release path (static checks).')
print('LIMITATION: This script does not compile against Forge/Minecraft or execute their game engine.')
