#!/usr/bin/env python3
"""Deterministic textured render of the serialized city; not AI concept art and not a game screenshot.
Original custom textures/models are used. Vanilla furnishings have accurate simple
bounding geometry but representative colors, since vanilla assets are not redistributed.
"""
from pathlib import Path
import numpy as np,json,re,sys,collections,math
from PIL import Image,ImageDraw,ImageFont
import vtk
from vtk.util.numpy_support import numpy_to_vtk,numpy_to_vtkIdTypeArray
P=Path(__file__).resolve().parents[1];A=P/'art_source/city5';R=P/'src/main/resources';OUT=P/'art_preview';OUT.mkdir(exist_ok=True)
v=np.load(A/'city_voxels.npy');pal=json.loads((A/'palette.json').read_text());meta=json.loads((A/'materials.json').read_text())
colors={a[0]:a[3] for a in meta['base']}
for a in meta['variants']+meta['decorations']:colors[a[0]]=colors[a[3]]
colors.update(air=[255,255,255],water=[57,139,160],dirt=[117,83,53],oak_planks=[168,131,79],bookshelf=[127,100,65],crafting_table=[154,115,63],red_carpet=[156,34,38],flower_pot=[151,83,58])
# Box representation in normalized block coordinates and face textures.
models=[];full=[];rgb=[]
for s in pal:
 bid=s.split(':')[1].split('[')[0];ns=s.split(':')[0];rgb.append(colors.get(bid,[160,160,160]))
 tex=('wooltest:block/'+bid) if ns=='wooltest' else 'color:'+bid
 boxes=[([0,0,0],[1,1,1],{f:tex for f in ['up','down','north','south','east','west']})]
 if bid=='air':boxes=[]
 elif bid.endswith('_slab'):
  base=bid[:-5];boxes=[([0,0,0],[1,.5,1],{f:'wooltest:block/'+base for f in ['up','down','north','south','east','west']})]
 elif bid.endswith('_stairs'):
  base=bid[:-7];face=re.search(r'facing=(\w+)',s)[1]
  a,b={'east':([.5,.5,0],[1,1,1]),'west':([0,.5,0],[.5,1,1]),'north':([0,.5,0],[1,1,.5]),'south':([0,.5,.5],[1,1,1])}[face]
  t={f:'wooltest:block/'+base for f in ['up','down','north','south','east','west']};boxes=[([0,0,0],[1,.5,1],t),(a,b,t)]
 elif ns=='wooltest':
  m=json.loads((R/f'assets/wooltest/models/block/{bid}.json').read_text())
  if 'elements' in m:
   def ref(t):
    while t.startswith('#'):t=m['textures'][t[1:]]
    return t
   boxes=[(list(np.array(e['from'])/16),list(np.array(e['to'])/16),{f:ref(o['texture']) for f,o in e['faces'].items()}) for e in m['elements']]
 elif bid=='red_carpet':boxes=[([0,0,0],[1,1/16,1],{f:tex for f in ['up','down','north','south','east','west']})]
 elif bid=='flower_pot':
  boxes=[];t={f:tex for f in ['up','down','north','south','east','west']}
  for a,b in [([5,0,5],[11,1,11]),([5,1,5],[6,6,11]),([10,1,5],[11,6,11]),([6,1,5],[10,6,6]),([6,1,10],[10,6,11])]:boxes.append((list(np.array(a)/16),list(np.array(b)/16),t))
 elif bid=='water':boxes=[([0,0,0],[1,.875,1],{f:tex for f in ['up','down','north','south','east','west']})]
 models.append(boxes);full.append(len(boxes)==1 and boxes[0][0]==[0,0,0] and boxes[0][1]==[1,1,1])
full=np.array(full);rgb=np.array(rgb,dtype=np.uint8)
FONT='/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf'
CJK='/usr/share/fonts/truetype/arphic/uming.ttc'

def mesh(bounds=None,ceiling=None,section=None,owner=None):
 vol=v.copy()
 if owner is not None:
  ownership=np.load(A/'ownership.npy');vol[:,:,4:][ownership[:,:,4:]!=owner]=0
 if bounds:
  x1,x2,z1,z2=bounds
  vol[:x1+125]=0;vol[x2+126:]=0;vol[:,:z1+125]=0;vol[:,z2+126:]=0
 if ceiling is not None:vol[:,:,ceiling-60+1:]=0
 if section is not None:
  axis,coord=section
  if axis=='z':vol[:,coord+126:]=0
  if axis=='x':vol[coord+126:]=0
 groups=collections.defaultdict(lambda:[[],[]]);fmask=full[vol]
 visible=(vol!=0)
 # Skip all fully buried cubes before entering the Python loop.
 pad=np.pad(fmask,1);buried=np.ones_like(fmask)
 for dx,dz,dy in [(1,0,0),(-1,0,0),(0,1,0),(0,-1,0),(0,0,1),(0,0,-1)]:buried &=pad[1+dx:252+dx,1+dz:252+dz,1+dy:69+dy]
 visible &= ~(fmask&buried)
 for ix,iz,iy in np.argwhere(visible):
  pi=int(vol[ix,iz,iy]);x=float(ix-125);z=float(iz-125);y=float(iy)
  neighbors={'east':ix<250 and fmask[ix+1,iz,iy],'west':ix>0 and fmask[ix-1,iz,iy], 'south':iz<250 and fmask[ix,iz+1,iy],'north':iz>0 and fmask[ix,iz-1,iy], 'up':iy<67 and fmask[ix,iz,iy+1],'down':iy>0 and fmask[ix,iz,iy-1]}
  for a,b,ts in models[pi]:
   x1,y1,z1=x+a[0],y+a[1],z+a[2];x2,y2,z2=x+b[0],y+b[1],z+b[2]
   faces={
    'east':([(x2,y1,z1),(x2,y2,z1),(x2,y2,z2),(x2,y1,z2)],b[0]==1),
    'west':([(x1,y1,z2),(x1,y2,z2),(x1,y2,z1),(x1,y1,z1)],a[0]==0),
    'south':([(x1,y1,z2),(x2,y1,z2),(x2,y2,z2),(x1,y2,z2)],b[2]==1),
    'north':([(x2,y1,z1),(x1,y1,z1),(x1,y2,z1),(x2,y2,z1)],a[2]==0),
    'up':([(x1,y2,z1),(x1,y2,z2),(x2,y2,z2),(x2,y2,z1)],b[1]==1),
    'down':([(x1,y1,z2),(x1,y1,z1),(x2,y1,z1),(x2,y1,z2)],a[1]==0)}
   for f,(ps,atboundary) in faces.items():
    if f not in ts or (atboundary and neighbors[f]):continue
    tex=ts[f];pts,uv=groups[tex];pts.extend(ps)
    # Minecraft-like tiled UV: one texture unit equals one block, with default face bounds.
    for px,py,pz in ps:
     if f in ['up','down']:uv.append((px-x,pz-z))
     elif f in ['east','west']:uv.append((pz-z,py-y))
     else:uv.append((px-x,py-y))
 return groups

def actors(groups):
 result=[]
 for tex,(pts,uv) in groups.items():
  points=vtk.vtkPoints();points.SetData(numpy_to_vtk(np.asarray(pts,dtype=np.float32),deep=True))
  ar=np.arange(len(pts),dtype=np.int64).reshape(-1,4);ar=np.c_[np.full(len(ar),4,dtype=np.int64),ar].ravel();cells=vtk.vtkCellArray();cells.SetCells(len(pts)//4,numpy_to_vtkIdTypeArray(ar,deep=True))
  poly=vtk.vtkPolyData();poly.SetPoints(points);poly.SetPolys(cells);poly.GetPointData().SetTCoords(numpy_to_vtk(np.asarray(uv,dtype=np.float32),deep=True))
  mapper=vtk.vtkPolyDataMapper();mapper.SetInputData(poly);actor=vtk.vtkActor();actor.SetMapper(mapper)
  prop=actor.GetProperty();prop.SetAmbient(.34);prop.SetDiffuse(.76);prop.SetSpecular(.05);prop.SetSpecularPower(18);prop.BackfaceCullingOn()
  if tex.startswith('color:'):
   name=tex.split(':')[1];col=colors.get(name,[150,150,150]);prop.SetColor(*[c/255 for c in col])
   if name=='water':prop.SetSpecular(.35)
  else:
   ns,path=tex.split(':');file=R/f'assets/{ns}/textures/{path}.png'
   if file.is_file():
    reader=vtk.vtkPNGReader();reader.SetFileName(str(file));reader.Update();t=vtk.vtkTexture();t.SetInputConnection(reader.GetOutputPort());t.InterpolateOff();t.RepeatOn();actor.SetTexture(t)
   else:prop.SetColor(*[c/255 for c in colors.get(tex.split('/')[-1],[150,150,150])])
  result.append(actor)
 return result

def render(name,bounds=None,ceiling=None,section=None,W=2400,H=1700,direction=(1,.85,1.35),title='',subtitle='',small=False,owner=None):
 print('Rendering',name,flush=True)
 groups=mesh(bounds,ceiling,section,owner);ren=vtk.vtkRenderer();ren.SetBackground(.94,.933,.91)
 for a in actors(groups):ren.AddActor(a)
 ren.AutomaticLightCreationOff()
 if bounds:cx=(bounds[0]+bounds[1])/2;cz=(bounds[2]+bounds[3])/2;span=max(bounds[1]-bounds[0]+1,bounds[3]-bounds[2]+1)
 else:cx=cz=0;span=251
 for pos,intens in [((cx-200,400,cz+220),.8),((cx+220,160,cz-120),.35)]:
  light=vtk.vtkLight();light.SetLightTypeToSceneLight();light.SetPosition(*pos);light.SetFocalPoint(cx,10,cz);light.SetIntensity(intens);ren.AddLight(light)
 win=vtk.vtkRenderWindow();win.SetOffScreenRendering(1);win.SetMultiSamples(4);win.SetSize(W,H);win.AddRenderer(ren)
 cam=ren.GetActiveCamera();cy=10 if not bounds else 12
 cam.SetFocalPoint(cx,cy,cz);cam.SetPosition(cx+direction[0]*span*2,cy+direction[1]*span*2,cz+direction[2]*span*2);cam.SetViewUp(0,1,0);cam.ParallelProjectionOn();ren.ResetCamera();
 if bounds:
  sub=v[bounds[0]+125:bounds[1]+126,bounds[2]+125:bounds[3]+126,:];hei=int(np.nonzero(sub)[2].max()+1)
  cam.SetParallelScale(max(span*.55,(hei*.9+span*.4)*.55))
 else:cam.SetParallelScale(span*.58)
 ren.ResetCameraClippingRange()
 win.Render();cap=vtk.vtkWindowToImageFilter();cap.SetInput(win);cap.ReadFrontBufferOff();cap.Update();writer=vtk.vtkPNGWriter();temp=OUT/(name+'-raw.png');writer.SetFileName(str(temp));writer.SetInputConnection(cap.GetOutputPort());writer.Write();win.Finalize()
 im=Image.open(temp).convert('RGB');temp.unlink()
 # Crop unused background without changing a single geometric element.
 arr=np.asarray(im);bg=arr[0,0].astype(int);mask=np.max(np.abs(arr.astype(int)-bg),axis=2)>7
 zz,xx=np.where(mask)
 if len(xx):
  crop=im.crop((max(0,int(xx.min())-25),max(0,int(zz.min())-25),min(W,int(xx.max())+26),min(H,int(zz.max())+26)))
  cw,ch=crop.size;fac=min((W-90)/cw,(H-70)/ch);crop=crop.resize((int(cw*fac),int(ch*fac)),Image.Resampling.LANCZOS)
  im=Image.new('RGB',(W,H),tuple(bg));im.paste(crop,((W-crop.width)//2,(H-crop.height)//2))
 if small:im.save(OUT/(name+'.png'));return
 header=145;footer=65;paper=Image.new('RGB',(W,H+header+footer),(240,238,232));paper.paste(im,(0,header));d=ImageDraw.Draw(paper)
 d.text((64,27),title,font=ImageFont.truetype(CJK,42),fill=(40,46,47));d.text((66,88),subtitle,font=ImageFont.truetype(CJK,24),fill=(78,85,87))
 d.text((64,H+header+18),'由實際藍圖與模型離線繪製；非遊戲截圖。原版家具以代表色顯示，非 Minecraft 光照模擬。',font=ImageFont.truetype(CJK,22),fill=(83,88,87))
 paper.save(OUT/(name+'.png'))

def topplan():
 h=np.max(np.where(v>0,np.arange(68)[None,None,:],-1),axis=2);x,z=np.indices(h.shape);idx=v[x,z,h];im=Image.fromarray(rgb[idx].transpose(1,0,2)).resize((1506,1506),Image.Resampling.NEAREST)
 paper=Image.new('RGB',(1750,1800),(240,238,232));paper.paste(im,(122,170));d=ImageDraw.Draw(paper)
 d.text((122,35),'承天城 City 5｜實際方塊俯視配置',font=ImageFont.truetype(CJK,42),fill=(40,46,47));d.text((122,106),'上北 -Z ／ 右東 +X　　251×251，中心 (0,0)；左右鏡像',font=ImageFont.truetype(CJK,26),fill=(78,85,87))
 d.line((875,170,875,1676),fill=(224,80,68),width=2)
 d.text((122,1720),'地面、地基、屋頂與方塊狀態均來自 capital_v5.wct.gz。',font=ImageFont.truetype(CJK,26),fill=(78,85,87));paper.save(OUT/'city5-plan.png')

if __name__=='__main__':
 palace_id=next(q['id'] for q in json.loads((A/'buildings.json').read_text()) if q['type']=='palace')
 mode=sys.argv[1] if len(sys.argv)>1 else 'all'
 if mode in ['all','overview']:
  topplan();render('city5-overview',title='承天城 City 5｜重簷宮城',subtitle='完整城防／門窗分區／重簷宮殿與御座／32 棟建築／固定原點唯一生成')
  render('city5-palace',(-32,32,-96,-54),W=2400,H=1700,owner=palace_id,direction=(.8,.6,1.6),title='承天正殿｜三重屋面、御座與藻井',subtitle='門窗各自分區、獨立簷廊；地坪 Y=67，屋頂最高 Y=99。')
 if mode in ['all','sections']:
  render('city5-palace-section',(-32,32,-96,-54),section=('z',-77),owner=palace_id,W=2200,H=1500,direction=(.75,.55,1.7),title='正殿剖切｜沿 Z=-77 展開內部',subtitle='僅在預覽切去南半部；模組中的建築並未切除。屋面下有連續承托。')
  render('city5-guild-section',(-95,-65,12,36),section=('z',24),W=2000,H=1500,direction=(.85,.65,1.8),title='兩層會館剖切｜樓梯與上下層淨高',subtitle='一樓地坪 Y=64、二樓 Y=71；樓梯開孔已避開吊燈。')
 if mode in ['all','houses']:
  qs=json.loads((A/'buildings.json').read_text());tiles=[]
  for i,q in enumerate(qs):
   a,b,c,d=q['envelope'];bd=(max(-125,a-1),min(125,b+1),max(-125,c-1),min(125,d+1))
   name=f'city5-building-{i+1:02d}';render(name,bd,W=720,H=520,small=True,direction=(.8,.65,1.4),owner=q['id']);tiles.append((q,OUT/(name+'.png')))
  for j in range(0,len(tiles),6):
   board=Image.new('RGB',(1500,1900),(240,238,232));dd=ImageDraw.Draw(board);dd.text((40,25),f'逐棟比例檢視 {j//6+1} / {(len(tiles)+5)//6}',font=ImageFont.truetype(CJK,36),fill=(40,46,47))
   for k,(q,fp) in enumerate(tiles[j:j+6]):
    xx=20+(k%2)*750;yy=100+(k//2)*590;board.paste(Image.open(fp),(xx,yy));dd.text((xx+25,yy+520),f"{q['name']}  {q['width']}×{q['depth']}  Y={q['floor']}–{q['roof_top']}",font=ImageFont.truetype(CJK,25),fill=(50,55,55))
   board.save(OUT/f'city5-building-review-{j//6+1:02d}.png')
