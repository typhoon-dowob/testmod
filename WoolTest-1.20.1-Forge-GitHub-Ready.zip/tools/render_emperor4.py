#!/usr/bin/env python3
"""Texture/normal-aware triangle rasterizer for the exact WEM4 bytes used in the mod.
No image synthesis. Not a Minecraft screenshot. Held sword/effect entity omitted.
"""
from pathlib import Path
import math,json,gzip,struct
import numpy as np
from PIL import Image,ImageDraw,ImageFont
from numba import njit
P=Path(__file__).resolve().parent.parent
spec=json.loads((P/'art_source/emperor4/emperor_mesh.json').read_text())
raw=gzip.decompress((P/'src/main/resources/assets/wooltest/geometry/emperor4.wem.gz').read_bytes());pos=12
meshes={}
for _ in range(struct.unpack('>i',raw[8:12])[0]):
    size=struct.unpack('>H',raw[pos:pos+2])[0];pos+=2;name=raw[pos:pos+size].decode();pos+=size
    q=struct.unpack('>i',raw[pos:pos+4])[0];pos+=4
    meshes[name]=np.frombuffer(raw[pos:pos+q*128],dtype='>f4').astype(np.float64).reshape(q,4,8);pos+=q*128
assert pos==len(raw)
texture=np.array(Image.open(P/'src/main/resources/assets/wooltest/textures/entity/emperor.png').convert('RGBA'))

def matrix(rot,off):
 x,y,z=rot;cx,sx=math.cos(x),math.sin(x);cy,sy=math.cos(y),math.sin(y);cz,sz=math.cos(z),math.sin(z)
 r=np.array([[cz,-sz,0],[sz,cz,0],[0,0,1]])@np.array([[cy,0,sy],[0,1,0],[-sy,0,cy]])@np.array([[1,0,0],[0,cx,-sx],[0,sx,cx]])
 m=np.eye(4);m[:3,:3]=r;m[:3,3]=off;return m

def scene(charge=False,walk=0,age=0):
 transforms={'root':np.eye(4)};tris=[]
 stride=math.cos(walk*.6662)*.55*(1 if walk else 0)
 for n in spec['nodes']:
  rot=list(n['rotation']);name=n['name']
  if name=='right_arm':rot[0]=-stride*.4-.15
  if name=='left_arm':rot[0]=stride*.4
  if name=='right_leg':rot[0]=stride
  if name=='left_leg':rot[0]=-stride
  if name=='cape':rot[0]=.025+math.sin(age*.07)*.018+(0.045 if walk else 0)
  if name=='front_skirt':rot[0]=-.015+(math.sin(walk*.6662)*.020 if walk else 0)
  if name=='pendant_left':rot[2]=math.sin(age*.08)*.018+stride*.035
  if name=='pendant_right':rot[2]=-math.sin(age*.08)*.018-stride*.035
  if name.startswith('bead_'):
   i=int(name[-1])*2+(1 if 'back' in name else 0);rot[0]=math.sin(age*.08+i*.27)*.022
  if charge and name=='right_arm':rot[0]=-1.15;rot[2]=.12
  if charge and name=='left_arm':rot[0]=-.95;rot[2]=-.12
  transform=transforms[n['parent']]@matrix(rot,n['offset']);transforms[name]=transform
  q=meshes[name].copy();q[:,:,:3]=q[:,:,:3]@transform[:3,:3].T+transform[:3,3]
  q[:,:,3:6]=q[:,:,3:6]@transform[:3,:3].T
  q[:,:,1]=24-q[:,:,1];q[:,:,2]*=-1;q[:,:,4:6]*=-1
  tris.extend(q[:,[0,1,2],:]);tris.extend(q[:,[0,2,3],:])
 return np.array(tris)

@njit(cache=True)
def raster(screen,depth,norm,uv,tex,w,h):
 out=np.zeros((h,w,4),np.uint8);zbuf=np.full((h,w),-1e30)
 light=np.array([-.4,.85,.52]);light/=np.sqrt((light**2).sum())
 for ti in range(len(screen)):
  a,b,c=screen[ti];d=(b[1]-c[1])*(a[0]-c[0])+(c[0]-b[0])*(a[1]-c[1])
  if abs(d)<1e-8:continue
  x0=max(0,int(math.floor(min(a[0],b[0],c[0]))));x1=min(w-1,int(math.ceil(max(a[0],b[0],c[0]))))
  y0=max(0,int(math.floor(min(a[1],b[1],c[1]))));y1=min(h-1,int(math.ceil(max(a[1],b[1],c[1]))))
  for y in range(y0,y1+1):
   for x in range(x0,x1+1):
    aa=((b[1]-c[1])*(x+.5-c[0])+(c[0]-b[0])*(y+.5-c[1]))/d
    bb=((c[1]-a[1])*(x+.5-c[0])+(a[0]-c[0])*(y+.5-c[1]))/d
    cc=1-aa-bb
    if aa<-.00001 or bb<-.00001 or cc<-.00001:continue
    dep=aa*depth[ti,0]+bb*depth[ti,1]+cc*depth[ti,2]
    if dep<=zbuf[y,x]:continue
    u=aa*uv[ti,0,0]+bb*uv[ti,1,0]+cc*uv[ti,2,0]
    v=aa*uv[ti,0,1]+bb*uv[ti,1,1]+cc*uv[ti,2,1]
    tx=max(0,min(tex.shape[1]-1,int(u*tex.shape[1])));ty=max(0,min(tex.shape[0]-1,int(v*tex.shape[0])))
    pix=tex[ty,tx]
    if pix[3]<128:continue
    n=aa*norm[ti,0]+bb*norm[ti,1]+cc*norm[ti,2];nlen=math.sqrt((n*n).sum())
    diffuse=max(0,(n*light).sum()/max(nlen,1e-8));shade=.72+.40*diffuse
    for k in range(3):out[y,x,k]=max(0,min(255,int(pix[k]*shade)))
    out[y,x,3]=255;zbuf[y,x]=dep
 return out

def render(yaw=20,charge=False,walk=0,size=(760,1020),scale=16.5):
 tris=scene(charge,walk,0);e=math.radians(10);a=math.radians(yaw)
 cam=np.array([math.sin(a)*math.cos(e),math.sin(e),math.cos(a)*math.cos(e)])
 right=np.array([math.cos(a),0,-math.sin(a)]);up=np.cross(cam,right)
 p=tris[:,:,:3];d=p@cam;xy=np.stack([p@right,-p@up],axis=-1)*scale+np.array([size[0]/2,size[1]-100])
 out=raster(xy,d,tris[:,:,3:6],tris[:,:,6:8],texture,*size)
 return Image.fromarray(out)

FONT='/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf'
def font(n):return ImageFont.truetype(FONT,n)

def sheet(filename,views,title,subtitle):
 w=1600;h=1080;im=Image.new('RGBA',(w,h),(237,233,222,255));d=ImageDraw.Draw(im)
 d.text((45,27),title,font=font(30),fill='#292d31');d.text((45,72),subtitle,font=font(17),fill='#626464')
 for i,(yaw,charge,walk,label) in enumerate(views):
  ox=20+i*800;d.ellipse((ox+240,900,ox+560,945),fill=(210,204,192,255))
  im.alpha_composite(render(yaw,charge,walk),(ox,0));d=ImageDraw.Draw(im)
  d.text((ox+290,1010),label,font=font(21),fill='#454a4a')
 im.convert('RGB').save(P/'art_preview'/filename)

if __name__=='__main__':
 (P/'art_preview').mkdir(exist_ok=True)
 sheet('emperor4-model-preview.png',[(22,False,0,'FRONT'),(202,False,0,'BACK')],
  'WOOLTEST / EMPEROR 4 - FLOWING ROBES','Actual shipped polygon mesh + texture atlas | Offline render, NOT an in-game screenshot | Held item omitted')
 sheet('emperor4-posing-preview.png',[(24,True,0,'CHARGING'),(-35,False,2.5,'WALK SAMPLE')],
  'EMPEROR 4 / RIG CHECK','Actual rig transforms | Charging and walking samples | Spell effects and held item omitted')
 print('Rendered exact runtime mesh.')
