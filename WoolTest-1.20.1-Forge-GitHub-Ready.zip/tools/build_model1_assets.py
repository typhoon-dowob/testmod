#!/usr/bin/env python3
"""Generate Model 1 geometry and remap the existing Texture 1 artwork.

This script is an art-authoring tool, not a build/runtime dependency.
Python 3 + Pillow are needed only to regenerate the source assets.
"""
from pathlib import Path
from PIL import Image, ImageDraw
import json
import hashlib

ROOT = Path(__file__).resolve().parent.parent
OUT = ROOT / 'art_source/model1'
OUT.mkdir(parents=True, exist_ok=True)
old = Image.open(ROOT/'src/main/resources/assets/wooltest/textures/entity/test_one.png').convert('RGBA')
oldspec = json.loads((ROOT/'art_source/uv_regions.json').read_text())

def tile(name):
    x,y,w,h=oldspec['faces'][name]['uv']
    return old.crop((x*2,y*2,(x+w)*2,(y+h)*2))

nodes=[]
def node(name,parent,offset=(0,0,0)):
    n={'name':name,'parent':parent,'offset':list(offset),'cubes':[]}
    nodes.append(n)
    return n

def cube(n,name,origin,size,material):
    n['cubes'].append({'name':name,'origin':list(origin),'size':list(size),'material':material})

doll=node('doll','root')
torso=node('torso','doll',(0,3,0))
cube(torso,'stuffed_body',(-5,0,-3),(10,11,6),'body')
hips=node('hips','torso',(0,10,0))
cube(hips,'stuffed_hips',(-4,0,-2.5),(8,3,5),'cloth_red')
head=node('head','torso')
cube(head,'stuffed_head',(-5,-10,-4),(10,10,8),'head')
# The eyes are separate cuboids, not painted on the skin.
for name,x in [('right_button',-2.5),('left_button',2.5)]:
    n=node(name,'head',(x,-6,-4.05))
    cube(n,name,(-1.5,-1.5,-0.6),(3,3,1),'button')
# A folded cloth seam sits on the right edge, without changing collision height.
n=node('folded_seam','head',(4.65,-8,0))
cube(n,'folded_seam',(-0.15,-1,-1),(1,2,2),'cloth_gold')
badge=node('badge','torso',(0,3.8,-3.05))
cube(badge,'raised_01_badge',(-3.5,-2,-0.6),(7,5,1),'badge')
patch=node('back_patch','torso',(-0.3,5,2.65))
cube(patch,'raised_back_patch',(-2.5,-1.5,0),(5,4,1),'cloth_gold')
for side,x,mat in [('right',-6.1,'cloth_red'),('left',6.1,'cloth_gold')]:
    arm=node(side+'_arm','torso',(x,2,0))
    cube(arm,side+'_shoulder',(-2,-1,-2.5),(4,4,5),mat)
    cube(arm,side+'_upper_wood',(-1.5,1,-1.5),(3,4,3),'wood')
    elbow=node(side+'_forearm',side+'_arm',(0,5,0))
    cube(elbow,side+'_hinge',(-1.5,-0.8,-1.5),(3,2,3),'joint')
    cube(elbow,side+'_forearm_wood',(-2,1,-2),(4,4,4),'wood')
    cube(elbow,side+'_cuff',(-2.5,4,-2.5),(5,1,5),'cloth_teal')
    cube(elbow,side+'_block_hand',(-2.5,5,-2.5),(5,2,5),'wood')
for side,x,mat in [('right',-2.5,'leg'),('left',2.5,'leg')]:
    leg=node(side+'_leg','doll',(x,15,0))
    cube(leg,side+'_short_leg',(-2,-0.2,-2),(4,6,4),mat)
    cube(leg,side+'_ankle',(-1.5,5,-1.5),(3,2,3),'joint')
    cube(leg,side+'_stuffed_boot',(-2,6,-3.5),(4,3,6),'boot')

# Standard ModelPart/CubeListBuilder box UV layout. All model-space sizes are integral.
def faces_uv(u,v,w,h,d):
    return {'top':[u+d,v,w,d], 'bottom':[u+d+w,v,w,d],
            'right':[u,v+d,d,h], 'front':[u+d,v+d,w,h],
            'left':[u+d+w,v+d,d,h], 'back':[u+2*d+w,v+d,w,h]}

# Shelf packing, with a full logical texel between nets.
ATLAS=128
u=v=row_h=0
for n in nodes:
    for c in n['cubes']:
        w,h,d=c['size'];nw=2*(w+d);nh=h+d
        if u+nw>ATLAS:
            u=0;v+=row_h+1;row_h=0
        assert v+nh<=ATLAS, 'Atlas overflow'
        c['uv']=[u,v]
        c['faces']=faces_uv(u,v,w,h,d)
        u+=nw+1;row_h=max(row_h,nh)

# Reuse the previously accepted artwork; only the UV packing and detail surfaces change.
cloths={
 'cloth_gold':tile('body_top').crop((5,0,15,7)),
 'cloth_red':tile('body_back').crop((1,8,12,22)),
 'cloth_teal':tile('head_back').crop((1,2,12,10)),
}

def material_face(material,face,w,h):
    size=(w*2,h*2)
    if material=='head':
        im=tile('head_'+face)
        if face=='front':
            # Cover the old flat eye paint with neighboring cream cloth; the new eyes
            # are real protruding geometry. Keep the original mouth and patchwork.
            pix=im.load()
            palette=[im.getpixel(p) for p in [(8,6),(7,7),(1,12),(8,8)]]
            for y in range(5,11):
                for x in range(2,14):
                    pix[x,y]=palette[(x+3*y)%len(palette)]
        return im.resize(size,Image.Resampling.NEAREST)
    if material=='body':
        im=tile('body_'+face)
        if face=='front':
            # The number belongs to a separate raised badge now.
            im=tile('body_back').copy()
        return im.resize(size,Image.Resampling.NEAREST)
    if material=='leg':
        return tile('leg_'+face).resize(size,Image.Resampling.NEAREST)
    if material=='boot':
        if face=='bottom': im=tile('leg_bottom')
        else: im=tile('leg_'+face).crop((0,max(0,tile('leg_'+face).height-7),tile('leg_'+face).width,tile('leg_'+face).height))
        return im.resize(size,Image.Resampling.NEAREST)
    if material=='wood':
        im=tile('arm_'+face)
        if face not in ('top','bottom'):
            im=im.crop((0,5,im.width,19))
        return im.resize(size,Image.Resampling.NEAREST)
    if material=='joint':
        im=tile('arm_front').crop((0,8,6,16)).resize(size,Image.Resampling.NEAREST)
        # Subtle darker wood makes the movable joints readable.
        from PIL import ImageEnhance
        return ImageEnhance.Brightness(im).enhance(0.69)
    if material in cloths:
        im=cloths[material].resize(size,Image.Resampling.NEAREST)
        # Stitch marks on edges echo the original sewn-cloth design.
        d=ImageDraw.Draw(im)
        ink=(66,49,35,255)
        for x in range(2,size[0]-1,4):
            d.line((x,0,x,min(1,size[1]-1)),fill=ink)
            d.line((x,max(0,size[1]-2),x,size[1]-1),fill=ink)
        return im
    if material=='button':
        im=Image.new('RGBA',size,(35,31,26,255));d=ImageDraw.Draw(im)
        if face in ('front','back'):
            d.rectangle((0,0,size[0]-1,size[1]-1),outline=(70,62,48,255))
            # Four sewing holes and a diagonal thread on the front face.
            for x,y in [(2,2),(size[0]-3,2),(2,size[1]-3),(size[0]-3,size[1]-3)]:
                d.point((x,y),fill=(184,166,126,255))
        return im
    if material=='badge':
        if face=='front':
            # Preserve the accepted 01 graphic; it is not mirrored.
            return tile('body_front').crop((1,5,15,18)).resize(size,Image.Resampling.NEAREST)
        return Image.new('RGBA',size,(177,153,108,255))
    raise ValueError(material)

atlas=Image.new('RGBA',(ATLAS*2,ATLAS*2),(0,0,0,0))
for n in nodes:
    for c in n['cubes']:
        for face,(x,y,w,h) in c['faces'].items():
            atlas.paste(material_face(c['material'],face,w,h),(x*2,y*2))
atlas.save(ROOT/'src/main/resources/assets/wooltest/textures/entity/test_one_model1.png')
spec={'format':'WoolTest Model 1 authoring data','coordinates':'Minecraft model coordinates: +Y down, front -Z, ground Y=24; 16 units per block',
      'texture_logical_size':[ATLAS,ATLAS],'texture_png_size':[ATLAS*2,ATLAS*2],
      'texture':'wooltest:textures/entity/test_one_model1.png','nodes':nodes,
      'reference_texture_sha256':hashlib.sha256((ROOT/'src/main/resources/assets/wooltest/textures/entity/test_one.png').read_bytes()).hexdigest()}
(OUT/'test_one_model1.json').write_text(json.dumps(spec,ensure_ascii=False,indent=2)+'\n')

# Emit the exact geometry into Java. Runtime does not use Python or this JSON.
def jf(v):
    return f'{float(v):.5f}'.rstrip('0').rstrip('.')+'.0F' if float(v).is_integer() else f'{float(v):.5f}'.rstrip('0')+'F'
lines=[]
for n in nodes:
    builder='CubeListBuilder.create()'
    for c in n['cubes']:
        builder+='\n                .texOffs(%d, %d).addBox(%s)'%(*c['uv'],', '.join(jf(v) for v in c['origin']+c['size']))
    lines.append('        PartDefinition %s = %s.addOrReplaceChild("%s", %s,\n                PartPose.offset(%s));'%(n['name'],n['parent'],n['name'],builder,', '.join(jf(v) for v in n['offset'])))
geometry='\n'.join(lines)
java='''package dev.sushi.wooltest.client;

import dev.sushi.wooltest.WoolTestMod;
import dev.sushi.wooltest.entity.TestOneEntity;
import net.minecraft.client.model.HierarchicalModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;

/** Dedicated patchwork-doll model. No gameplay state is read or changed here.
 * Geometry is generated from art_source/model1/test_one_model1.json.
 * This class is referenced only by the physical-client event subscriber.
 */
public final class TestOneModel extends HierarchicalModel<TestOneEntity> {
    public static final ModelLayerLocation LAYER_LOCATION = new ModelLayerLocation(
            new ResourceLocation(WoolTestMod.MOD_ID, "test_one_model1"), "main");
    private final ModelPart root;
    private final ModelPart torso;
    private final ModelPart head;
    private final ModelPart rightArm;
    private final ModelPart leftArm;
    private final ModelPart rightForearm;
    private final ModelPart leftForearm;
    private final ModelPart rightLeg;
    private final ModelPart leftLeg;

    public TestOneModel(ModelPart root) {
        this.root = root;
        ModelPart doll = root.getChild("doll");
        this.torso = doll.getChild("torso");
        this.head = torso.getChild("head");
        this.rightArm = torso.getChild("right_arm");
        this.leftArm = torso.getChild("left_arm");
        this.rightForearm = rightArm.getChild("right_forearm");
        this.leftForearm = leftArm.getChild("left_forearm");
        this.rightLeg = doll.getChild("right_leg");
        this.leftLeg = doll.getChild("left_leg");
    }

    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();
''' + geometry + '''
        return LayerDefinition.create(mesh, 128, 128);
    }

    @Override
    public ModelPart root() {
        return root;
    }

    @Override
    public void setupAnim(TestOneEntity entity, float limbSwing, float limbSwingAmount,
                          float ageInTicks, float netHeadYaw, float headPitch) {
        // Reset first: multiple entities share the renderer/model instance.
        root.getAllParts().forEach(ModelPart::resetPose);
        float walk = Mth.clamp(limbSwingAmount, 0.0F, 1.0F);
        float phase = limbSwing * 0.6662F;
        float stride = Mth.cos(phase) * 0.82F * walk;
        float idle = Mth.sin(ageInTicks * 0.065F);
        head.yRot = netHeadYaw * (Mth.PI / 180.0F);
        head.xRot = headPitch * (Mth.PI / 180.0F);
        head.zRot = idle * 0.025F * (1.0F - walk);
        torso.zRot = Mth.cos(phase) * 0.035F * walk;
        rightLeg.xRot = stride;
        leftLeg.xRot = -stride;
        rightArm.xRot = -stride * 0.75F;
        leftArm.xRot = stride * 0.75F;
        // The elbows really bend; no zombie arms-out pose is used.
        rightArm.zRot = 0.035F + idle * 0.012F;
        leftArm.zRot = -0.035F - idle * 0.012F;
        rightForearm.xRot = -0.08F - Math.max(0.0F, stride) * 0.24F;
        leftForearm.xRot = -0.08F - Math.max(0.0F, -stride) * 0.24F;
        if (riding) {
            rightLeg.xRot = -1.15F;
            leftLeg.xRot = -1.15F;
            rightLeg.yRot = 0.22F;
            leftLeg.yRot = -0.22F;
        }
        if (attackTime > 0.0F) {
            float swing = Mth.sin(Mth.sqrt(attackTime) * Mth.TWO_PI);
            torso.yRot = swing * 0.12F;
            rightArm.xRot -= Mth.sin(attackTime * Mth.PI) * 1.55F;
            rightForearm.xRot -= Mth.sin(attackTime * Mth.PI) * 0.25F;
        }
    }
}
'''
(ROOT/'src/main/java/dev/sushi/wooltest/client/TestOneModel.java').write_text(java)
print(f'Wrote {len(nodes)} model nodes, {sum(len(n["cubes"]) for n in nodes)} cuboids, 256x256 texture and Java geometry.')
