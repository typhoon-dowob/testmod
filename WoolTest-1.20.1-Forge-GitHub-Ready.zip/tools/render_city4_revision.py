#!/usr/bin/env python3
"""Source-derived geometry previews for the detached-column revision."""
from pathlib import Path
import importlib.util
p=Path(__file__).with_name('render_city4.py')
spec=importlib.util.spec_from_file_location('city4render',p);g=importlib.util.module_from_spec(spec);spec.loader.exec_module(g)
g.render('city4-palace',(-32,32,-96,-54),W=2000,H=1400,direction=(.9,.5,1.6),title='承天城 City 4｜正殿獨立柱廊',subtitle='牆面保持完整；柱列外移兩格，中間留一格淨空。柱腳落在台基、柱頂接梁。')
g.render('city4-columns-cutaway',(-29,29,-93,-59),ceiling=73,W=2000,H=1400,direction=(.8,1.1,1.6),title='正殿柱牆關係｜水平剖切至 Y=73',subtitle='僅預覽隱藏 Y=74 以上；可辨識完整牆線、獨立柱腳與柱牆間隙。')
g.render('city4-guild',(-94,-66,13,34),W=1600,H=1200,direction=(.9,.6,1.6),title='會館｜上下柱列對齊與連續陽臺',subtitle='二樓外廊有樓板、護欄與下層柱列支承；沒有把室內空間縮小來藏柱。')
g.render('city4-corner-tower',(-119,-101,101,119),W=1400,H=1100,direction=(-.8,.65,1.6),title='角樓｜柱身避開牆線及垛口',subtitle='城牆上的柱列站在完整樓板上，周圍保留空隙。')
g.render('city4-overview',W=2000,H=1500,title='承天城 City 4｜獨立柱廊修正版',subtitle='251×251／中心 (0,0)／東西鏡像／30 棟建築／原點唯一城市')
g.topplan()
