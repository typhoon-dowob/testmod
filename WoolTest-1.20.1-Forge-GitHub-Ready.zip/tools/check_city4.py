#!/usr/bin/env python3
"""Independent checks of the serialized runtime blueprint, not of an illustration.
Walking check is a conservative two-block-clearance block-grid model, not Minecraft
physics. Proportions are this project's authored bounds, not architectural standards.
"""
from pathlib import Path
import numpy as np,json,gzip,struct,re,collections,hashlib
from scipy import ndimage
P=Path(__file__).resolve().parents[1];A=P/'art_source/city4';R=P/'src/main/resources';O=P/'validation';O.mkdir(exist_ok=True)
src=R/'data/wooltest/city/capital_v4.wct.gz';raw=gzip.decompress(src.read_bytes());m,ver,n,y0,h,cnt=struct.unpack('>6i',raw[:24]);assert(m,ver,n,y0,h)==(0x57435431,1,251,60,68)
o=24;pal=[]
for _ in range(cnt):l=struct.unpack('>H',raw[o:o+2])[0];o+=2;pal.append(raw[o:o+l].decode());o+=l
v=np.frombuffer(raw[o:],dtype='>u2').reshape(n,n,h);assert np.array_equal(v,np.load(A/'city_voxels.npy'))
buildings=json.loads((A/'buildings.json').read_text());columns=json.loads((A/'columns.json').read_text());lights=json.loads((A/'lights.json').read_text());road=np.load(A/'protected_roads.npy')
errors=[];report={};rows=[]
def at(x,y,z):return int(v[x+125,z+125,y-60]) if -125<=x<=125 and -125<=z<=125 and 60<=y<=127 else 0
names=[s.split('[')[0] for s in pal]
def mirror(s):return re.sub(r'facing=(east|west)',lambda m:'facing='+('west' if m[1]=='east' else 'east'),s)
mi=np.array([pal.index(mirror(s)) for s in pal]);report['mirrored_cell_mismatches']=int(np.count_nonzero(v!=mi[v[::-1]]))
if report['mirrored_cell_mismatches']:errors.append('mirror mismatch')
# Check every independent building parcel INCLUDING roof and entry stair envelopes.
inter=[];mingap=999
for i,q in enumerate(buildings):
 a,b,c,d=q['envelope']
 for r in buildings[i+1:]:
  aa,bb,cc,dd=r['envelope'];ox=max(a,aa)<=min(b,bb);oz=max(c,cc)<=min(d,dd)
  if ox and oz:inter.append([q['name'],r['name']])
  if oz:mingap=min(mingap,max(aa-b-1,a-bb-1))
  if ox:mingap=min(mingap,max(cc-d-1,c-dd-1))
report['building_envelope_intersections']=inter;report['minimum_gap_when_aligned']=mingap
if inter:errors.append('building envelope intersection')
# A real column must be continuous and have a solid foot and a load above the cap.
colbad=[]
for q in columns:
 x,z,yb,yt=q['x'],q['z'],q['base'],q['top']
 states=[names[at(x,yy,z)] for yy in range(yb,yt+1)]
 if not all(s in ['wooltest:capital_column_foot','wooltest:capital_column_shaft','wooltest:capital_bracket'] for s in states):colbad.append([x,yb,z,'column overwritten',states])
 if names[at(x,yb-1,z)] in ['minecraft:air','minecraft:water'] or '_slab' in names[at(x,yb-1,z)]:colbad.append([x,yb,z,'no full-height footing'])
 if names[at(x,yt+1,z)] in ['minecraft:air','minecraft:water']:colbad.append([x,yt,z,'no beam on top'])
 if yb<=66 and road[x+125,z+125]:colbad.append([x,yb,z,'column on protected street'])
report['columns_checked']=len(columns);report['column_errors']=colbad
if colbad:errors.append('column support/road errors')
# The designated public streets have a minimum 3-block unobstructed vertical clearance.
passable=np.array([s in ['minecraft:air','minecraft:red_carpet'] for s in names])
roadbad=np.argwhere(road[:,:,None]&~passable[v[:,:,4:7]])
report['street_obstructions_count']=len(roadbad);report['street_obstruction_examples']=[[int(x-125),int(yy+64),int(z-125),pal[int(v[x,z,yy+4])]] for x,z,yy in roadbad[:25]]
if len(roadbad):errors.append('public street obstruction')
# Verify all emitted light locations physically match their declared luminaire and mount.
reg=(P/'src/main/java/dev/sushi/wooltest/city/CityBlocks.java').read_text();lightbad=[]
for x,y,z,kind,owner in lights:
 s=names[at(x,y,z)];expected='wooltest:capital_'+kind
 if s!=expected:lightbad.append([x,y,z,'overwritten',s]);continue
 if kind=='hanging_lantern':
  above=names[at(x,y+1,z)]
  if above=='minecraft:air' or '_slab' in above:lightbad.append([x,y,z,'no overhead mount'])
 elif kind=='stone_lamp' and names[at(x,y-1,z)] in ['minecraft:air','minecraft:water']:lightbad.append([x,y,z,'no pedestal'])
 if not re.search(r'add\("capital_'+kind+r'"[^\n]*lightLevel\(s -> 15\)',reg):lightbad.append([kind,'no lightLevel(15) registry declaration'])
report['light_positions_checked']=len(lights);report['light_mount_or_registry_errors']=lightbad
if lightbad:errors.append('light errors')
# All solid components must be face-connected to the foundation. This is a block
# topology check; per-column fractional model contact is checked separately.
solid=(v!=0)&np.array([s!='minecraft:water' for s in names])[v]
lab,num=ndimage.label(solid,structure=ndimage.generate_binary_structure(3,1));groundlabels=set(np.unique(lab[:,:,0]))-{0};labels,counts=np.unique(lab,return_counts=True)
floaters=[(int(l),int(c)) for l,c in zip(labels,counts) if l and l not in groundlabels]
report['detached_solid_components']=len(floaters);report['detached_examples']=[]
for l,c in floaters[:10]:
 pts=np.argwhere(lab==l);x,z,y=pts[0];report['detached_examples'].append([c,int(x-125),int(y+60),int(z-125),pal[int(v[x,z,y])]])
if floaters:errors.append('detached geometry')
# Walkable nodes: two passable blocks over a supporting block; cardinal moves
# allow one-block vertical changes for authored stairs. No flight or wall traversal.
free=passable[v];support=solid&~np.array([s=='minecraft:red_carpet' for s in names])[v]
walk=np.zeros_like(free);walk[:,:,1:-1]=free[:,:,1:-1]&free[:,:,2:]&support[:,:,:-2]
seen=np.zeros_like(walk);q=collections.deque([(125,125,4)]);seen[125,125,4]=True
while q:
 x,z,y=q.popleft()
 for dx,dz in [(1,0),(-1,0),(0,1),(0,-1)]:
  xx=x+dx;zz=z+dz
  if not(0<=xx<n and 0<=zz<n):continue
  for dy in [0,1,-1]:
   yy=y+dy
   if not (1<=yy<h-1) or not walk[xx,zz,yy] or seen[xx,zz,yy]:continue
   if dy>0 and not free[x,z,y+2]:continue
   if dy<0 and not free[xx,zz,y+1]:continue
   seen[xx,zz,yy]=True;q.append((xx,zz,yy))
for q in buildings:
 x,y,z=q['entry'];reachable=bool(seen[x+125,z+125,y-60])
 ratio=round((q['roof_top']-q['floor']+1)/max(q['width'],q['depth']),3)
 # Aesthetic guardrails chosen for this design, supplemented by manual image review.
 prop=(max(q['width'],q['depth'])/min(q['width'],q['depth'])<=3 and ratio<=1.6 and q['wall_height']>=5)
 upper=True
 if 'stair_exit' in q:
  xx,yy,zz=q['stair_exit'];upper=bool(seen[xx+125,zz+125,yy-60])
 rows.append({'name':q['name'],'body':f"{q['width']}x{q['depth']}",'floor':q['floor'],'roof_top':q['roof_top'],'height_to_long_span_ratio':ratio,'proportion_bounds_ok':prop,'entry_reachable':reachable,'upper_floor_reachable':upper})
 if not reachable:errors.append('entry unreachable: '+q['name'])
 if not upper:errors.append('upper floor unreachable: '+q['name'])
 if not prop:errors.append('proportion bounds: '+q['name'])
 if 'balcony_entry' in q:
  bx,by,bz=q['balcony_entry'];ok=bool(seen[bx+125,bz+125,by-60])
  rows[-1]['balcony_reachable']=ok
  if not ok:errors.append('balcony unreachable: '+q['name'])
report['buildings']=rows;report['walkable_nodes_reached']=int(seen.sum())
# Water surfaces have a supported bottom and contain no air escape in the same layer.
water=np.array([s=='minecraft:water' for s in names])[v];waterbad=[]
for x,z,y in np.argwhere(water):
 if y==0 or names[int(v[x,z,y-1])]=='minecraft:air':waterbad.append([int(x-125),int(y+60),int(z-125),'bottom'])
 for dx,dz in [(1,0),(-1,0),(0,1),(0,-1)]:
  if 0<=x+dx<n and 0<=z+dz<n and v[x+dx,z+dz,y]==0:waterbad.append([int(x-125),int(y+60),int(z-125),'side'])
report['water_uncontained_edges']=len(waterbad)
if waterbad:errors.append('water escape')
# Source-registry state/resource validation, all custom blocks and state variants exist.
resourcebad=[]
for s in pal:
 nsid=s.split('[')[0];ns,bid=nsid.split(':')
 if ns=='wooltest':
  st=AS=R/'assets/wooltest/blockstates'/f'{bid}.json'
  if not st.is_file():resourcebad.append(s);continue
  bst=json.loads(st.read_text());states={k:val for k,val in re.findall(r'(\w+)=(\w+)',s)}
  matched=[]
  for k,val in bst.get('variants',{}).items():
   cond=dict(t.split('=') for t in k.split(',')) if k else {}
   if all(states.get(a)==b for a,b in cond.items()):matched.append(val)
  if not matched:resourcebad.append(s+' has no model variant')
  for m in matched:
   if isinstance(m,list):m=m[0]
   model=m['model'].split(':')
   if model[0]=='wooltest' and not(R/f'assets/wooltest/models/{model[1]}.json').is_file():resourcebad.append(s+' model missing')
report['resource_errors']=resourcebad
if resourcebad:errors.append('resource references')
report['non_air']=int(np.count_nonzero(v));report['cells_compared']=int(v.size);report['highest_block_y']=int(np.nonzero(v)[2].max()+60);report['sha256']=hashlib.sha256(src.read_bytes()).hexdigest();report['errors']=errors
(O/'city4_checks.json').write_text(json.dumps(report,ensure_ascii=False,indent=2));np.save(A/'reachable_nodes.npy',seen)
print(json.dumps({k:vv for k,vv in report.items() if k!='buildings'},ensure_ascii=False,indent=2))
print('\nBUILDINGS:')
for row in rows:print(row)
raise SystemExit(1 if errors else 0)
