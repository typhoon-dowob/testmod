#!/usr/bin/env python3
"""Same-scale comparison of the old shipped cuboids and new shipped polygon mesh."""
from pathlib import Path
import json,zipfile,sys,io,math
import numpy as np
from PIL import Image,ImageDraw
from render_emperor4 import P,matrix,raster,render,font

def old_scene(oldzip):
 with zipfile.ZipFile(oldzip) as z:
  sp=json.loads(z.read('art_source/emperor3/emperor_model.json'))
  tex=np.array(Image.open(io.BytesIO(z.read('src/main/resources/assets/wooltest/textures/entity/emperor.png'))).convert('RGBA'))
 trans={'root':np.eye(4)};tri=[]
 for n in sp['nodes']:
  rot=[0,0,0]
  if n['name']=='right_arm':rot[0]=-.15
  t=trans[n['parent']]@matrix(rot,n['offset']);trans[n['name']]=t
  for c in n['cubes']:
   x0,y0,z0=c['origin'];dx,dy,dz=c['size'];x1,y1,z1=x0+dx,y0+dy,z0+dz
   for face,pts,nrm in [
    ('front',[(x0,y0,z0),(x1,y0,z0),(x1,y1,z0),(x0,y1,z0)],(0,0,-1)),
    ('back',[(x1,y0,z1),(x0,y0,z1),(x0,y1,z1),(x1,y1,z1)],(0,0,1)),
    ('right',[(x0,y0,z1),(x0,y0,z0),(x0,y1,z0),(x0,y1,z1)],(-1,0,0)),
    ('left',[(x1,y0,z0),(x1,y0,z1),(x1,y1,z1),(x1,y1,z0)],(1,0,0)),
    ('top',[(x0,y0,z1),(x1,y0,z1),(x1,y0,z0),(x0,y0,z0)],(0,-1,0)),
    ('bottom',[(x0,y1,z0),(x1,y1,z0),(x1,y1,z1),(x0,y1,z1)],(0,1,0))]:
    u,v,w,h=c['faces'][face];coords=np.array([[u,v],[u+w,v],[u+w,v+h],[u,v+h]])/256
    points=np.array(pts)@t[:3,:3].T+t[:3,3];norm=np.tile(nrm,(4,1))@t[:3,:3].T
    points[:,1]=24-points[:,1];points[:,2]*=-1;norm[:,1:3]*=-1
    q=np.concatenate([points,norm,coords],axis=1);tri.extend([q[[0,1,2]],q[[0,2,3]]])
 return np.array(tri),tex

def main(oldzip):
 tris,tex=old_scene(oldzip);a=math.radians(22);e=math.radians(10)
 cam=np.array([math.sin(a)*math.cos(e),math.sin(e),math.cos(a)*math.cos(e)])
 right=np.array([math.cos(a),0,-math.sin(a)]);up=np.cross(cam,right)
 p=tris[:,:,:3];d=p@cam;xy=np.stack([p@right,-p@up],axis=-1)*16.5+np.array([380,920])
 old=Image.fromarray(raster(xy,d,tris[:,:,3:6],tris[:,:,6:8],tex,760,1020))
 new=render(22,False)
 out=Image.new('RGBA',(1600,1080),(237,233,222,255));dr=ImageDraw.Draw(out)
 dr.text((45,25),'EMPEROR 3  >  EMPEROR 4',font=font(30),fill='#292d31')
 dr.text((45,72),'Same height and camera scale | Actual shipped meshes + textures | Offline render, NOT an in-game screenshot',font=font(17),fill='#626464')
 for i,img in enumerate((old,new)):
  ox=20+800*i;dr.ellipse((ox+240,900,ox+560,945),fill=(210,204,192,255));out.alpha_composite(img,(ox,0));dr=ImageDraw.Draw(out)
 dr.text((200,1010),'BEFORE / CUBOID MODEL',font=font(21),fill='#454a4a');dr.text((1000,1010),'AFTER / FLOWING MESH',font=font(21),fill='#454a4a')
 out.convert('RGB').save(P/'art_preview/emperor4-before-after.png')
 print('Compared actual meshes at matching camera, animation and scale.')
if __name__=='__main__':main(sys.argv[1])
