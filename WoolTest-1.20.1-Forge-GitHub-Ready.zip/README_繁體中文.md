> **本包為 Model 1 立體造型更新。請先讀 `MODEL1_使用說明.md`；以下原始內容保留為前版參考。**

# 羊毛測試維度 — Wool Test v0.1.0 / Texture 1

本包已整合測試一號專屬材質，包含 hotfix1 木柱修正。更新方法與本次驗證範圍請先讀 `TEXTURE1_使用說明.md`。

**這是 Minecraft Java 版 1.20.1 / Forge 47.4.10 的原始碼專案，不是已編譯 JAR。**

已完成程式撰寫、Java 17 語法解析、資源檔檢查及純 Java 規則測試。
目前交付環境無法連線下載 Forge / Gradle / Minecraft 建置依賴，因此沒有完成 Forge 整體編譯，
也沒有在 Minecraft 客戶端或獨立伺服器中執行。請勿將語法檢查通過理解成「已測試可玩」。

## 1. 本版內容

| 項目 | 程式設定 |
|---|---|
| 遊戲 / 載入器 | Minecraft Java 1.20.1 / Forge 47.4.10；不是 Fabric 或 NeoForge |
| 維度 ID | `wooltest:wool_world` |
| 地形 | 16 色原版羊毛，8×8 格色塊，32×32 區域包含全部 16 色，向四周重複 |
| 地表 / 地下 | Y=0～63 全為羊毛，玩家通常站在 Y=64；無基岩、泥土、石頭、水、礦物、樹木或建築 |
| 建築上界 | Y=128 為不包含的上界；合法方塊層為 Y=0～127 |
| 天候 | 固定白晝，不降雨 |
| 生物 | 新實體 `wooltest:test_one`，繁體中文名稱「測試一號」 |
| 生命 / 近戰 | 最大生命 20 點（10 顆心）；近戰基礎傷害 1 點（半顆心） |
| 技能 | 在生物自身的水平半徑 5 格內，生成 3 根各 4 格高的臨時木柱 |
| 木柱接觸 | 玩家觸碰側面或頂部時，基礎傷害 3 點（1.5 顆心）及擊退 |

「只有羊毛」指自然生成的地形。技能施放時會短暫出現木柱；玩家自行放置的方塊不會被禁止。
Y=128 是方塊建築上界，不是阻止創造模式飛行的隱形天花板。
地底沒有基岩；挖穿 Y=0 可能掉入虛空。

## 2. 未指定細節採用的測試預設

- 生物使用專屬拼布人偶材質，模型與音效仍引用原版殭屍；**有獨立的註冊 ID 與 AI，不是單純改名的原版殭屍**。
  由 `Monster` 衍生，不繼承殭屍的日曬燃燒、增援或裝備生成行為。
- 生物不自然生成，以 `/wooltest spawn` 或生怪蛋控制測試數量。
- 技能冷卻 120 ticks（正常 20 TPS 時 6 秒），木柱維持 80 ticks（4 秒）；首次生成先有 40 ticks 冷卻。
- 玩家必須是生存／冒險、在生物 5 格內且可被它看見。創造及旁觀玩家不被技能鎖定，也不受木柱傷害。
- 3 根柱子必須有 3 個有效位置；空間不足時不生成殘缺的一組，稍後重試。
  一根選靠近目標的位置，另外兩根從其他有效位置隨機選取。
- 木柱只放在有實心地面支撐的空氣中，不覆蓋已有方塊、不生成在玩家／生物身體內。
- 所有木柱對同一玩家共用 20 ticks 接觸傷害間隔，避免 4 節木柱同時造成 4 倍傷害。
- 傷害保留護甲、盾牌、藥水與原版受傷無敵時間等機制；1 點及 3 點是**基礎傷害**。
  本版自訂傷害類型不額外套用簡單／困難難度傷害倍率。
- 木柱是真正有碰撞體的臨時方塊，借用橡木原木外觀；可破壞，但不掉落物品，不可用活塞搬運。
- 木柱的到期時間存入 NBT；生物死亡不會中斷清除，區塊重新載入後過期木柱會清除。
- 本版以測試指令進出，不包含傳送門、合成配方、任務書或自繪模型。

## 3. Windows：產生模組 JAR

需要 64 位元 **JDK 17**，不是只有 Java 執行環境的 JRE。
可使用 Eclipse Temurin 17，官方頁面：https://adoptium.net/temurin/releases/?version=17

1. 把本 ZIP 完整解壓到一般資料夾，例如 `C:\MinecraftDev\WoolTest`。不要直接在 ZIP 裡執行。
2. 安裝 JDK 17；讓 `JAVA_HOME` 指向 JDK 的根目錄，或讓 `java` 與 `javac` 在 PATH 中指向它。
3. 雙擊 `BUILD.bat`。首次建置必須可以連線到 Forge Maven、Gradle、Maven Central 和 Mojang 下載服務。
4. 只有在出現 `BUILD SUCCESSFUL` 並列出成品路徑後，才將下列檔案拿去安裝：

   `build\libs\wooltest-1.20.1-0.1.0.jar`

建置腳本會從 Forge 官方取得指定 47.4.10 MDK，對照官方公開的 SHA-1 校驗值，
只取出原版 Gradle wrapper，再執行正式編譯與 reobfuscation。
腳本不會修改你的 Minecraft 存檔、不會自行安裝載入器，也不會自動接受 Minecraft EULA。
PowerShell 執行政策的 Bypass 僅套用該次子程序，不會更改整台電腦的永久政策。

若失敗，保留專案根目錄中的 `build-log.txt` / `build-error.txt`。
網路錯誤、JDK 設定錯誤與 Java 編譯錯誤是不同問題，這些記錄有助於分辨。

## 4. macOS / Linux：產生 JAR

先安裝 JDK 17，並具備 `curl`、`unzip` 及 `sha1sum` 或 `shasum`：

```bash
export JAVA_HOME=/你的/JDK17/路徑
bash build.sh
```

成品同樣在 `build/libs/wooltest-1.20.1-0.1.0.jar`。

## 5. 安裝進遊戲

在啟動器建立一個 **Minecraft 1.20.1 + Forge 47.4.10** 的獨立測試實例，
把剛才真正編譯出的 JAR 放進該實例的 `mods` 資料夾，再啟動遊戲。
本專案沒有額外的第三方模組依賴，不需要 Fabric API 或 GeckoLib。

Forge 官方下載頁：https://files.minecraftforge.net/net/minecraftforge/forge/index_1.20.1.html

建議只使用新測試存檔，先不要放入重要存檔或大型整合包。
多人測試時，客戶端及伺服器都要安裝相同版本的本模組。

## 6. 最短測試流程

建立新世界，開啟作弊，先用創造模式，難度設為普通。依序輸入：

```mcfunction
/difficulty normal
/wooltest enter
/wooltest spawn
/gamemode survival
```

靠近測試一號，保持在 5 格內，觀察木柱出現；刻意碰觸木柱側面測試傷害及擊退。
不要穿護甲，也不要帶有抗性等效果，較容易觀察 1 點與 3 點基礎傷害。

返回原來維度與位置：

```mcfunction
/wooltest leave
```

若原位置已被阻擋，程式會搜尋附近安全落腳處；找不到時取消傳送，不會清除玩家建築。
首次使用 `enter` 才會記錄返回點；重複在羊毛維度內執行不會覆蓋它。

其他測試指令：

```mcfunction
/give @s wooltest:test_one_spawn_egg
/summon wooltest:test_one ~ ~ ~3
/data get entity @e[type=wooltest:test_one,sort=nearest,limit=1] Health
/attribute @e[type=wooltest:test_one,sort=nearest,limit=1] minecraft:generic.attack_damage get
```

自訂指令需要作弊權限／伺服器 OP 等級 2。和平難度不適合此敵對生物測試。
測試結束可回創造模式，避免繼續受傷：`/gamemode creative`。

## 7. 開發模式與 CI

`RUN-DEV-CLIENT.bat` 可在依賴下載與編譯成功後啟動開發用 Minecraft 客戶端。
它不是一般遊戲啟動器的安裝程式，也沒有在本次交付環境實際跑過。

取得 wrapper 後，開發者可執行：

```bash
./gradlew runClient
./gradlew runServer
./gradlew clean build
```

獨立伺服器的 EULA 必須由使用者自行閱讀與接受。
`.github/workflows/build.yml` 提供可選的 GitHub Actions 建置流程；本次沒有在任何帳號或儲存庫執行它。

## 8. 調整數值與主要程式

基本數值集中於 `src/main/java/dev/sushi/wooltest/logic/TestRules.java`。
修改維度高度時，**也必須**同步修改 `data/wooltest/dimension_type/wool_type.json`，並使用新測試存檔。

- `world/WoolChunkGenerator.java`：只生成各色羊毛及空氣。
- `world/DimensionTravel.java`：進出維度、安全位置與返回點儲存。
- `entity/TestOneEntity.java`：生命、近戰、追蹤目標與技能冷卻。
- `entity/PillarAbility.java`：半徑判定、選位、一次三柱與建立失敗時回復。
- `block/TemporaryPillarBlockEntity.java`：接觸傷害、共用傷害間隔及到期清除。
- `client/`：外觀註冊；與伺服器端程式分離。

詳見 `TEST_PLAN_繁體中文.md` 與 `VALIDATION_繁體中文.md`。本 ZIP 不含 Minecraft 遊戲本體或原版材質 PNG；包含本次自訂材質與美術原稿。
