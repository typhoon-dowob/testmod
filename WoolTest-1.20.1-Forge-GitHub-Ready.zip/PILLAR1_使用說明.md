# WoolTest：木柱材質更新 Pillar 1

適用：Minecraft Java 1.20.1、Forge、已安裝且可啟動的 WoolTest 模組。
原始碼基礎：上一版 Model 1 專屬立體布偶模型，包含先前的木柱 mapColor 修正。

## 最快測試：使用獨立資源包，不用重新編譯

1. 保留目前可以啟動的 WoolTest JAR。
2. 將 `WoolTest-Pillar1-ResourcePack.zip` 放入目前遊戲實例的 `resourcepacks` 資料夾，不必解壓，**不要放進 `mods`**。
3. 在遊戲內進入「選項 → 資源包 → 開啟資源包資料夾」也能找到正確資料夾。
4. 回到資源包畫面，將 `WoolTest | Pillar 1` 移到「已選取」一側，放在其他可能修改 WoolTest 的資源包上方，按「完成」。
5. 回到測試存檔，讓測試一號重新施放技能，檢查木柱外觀。

這份 ZIP 只有木柱的模型資源與材質，不會新增生物、不會替你安裝模組，也不會把舊的生物外形升級成 Model 1。它只是覆蓋已存在的 `wooltest:temporary_pillar` 外觀。沒有安裝 WoolTest 時，不會出現木柱。

不需要安裝 OptiFine、其他動畫模組或光影。
使用資源包的路線不會更改 Mods 清單內的模組名稱。
取消啟用資源包，便會回到你目前 JAR 內建的木柱外觀。

## 整合進 JAR：沿用既有 GitHub Actions

1. 用這次提供的 `WoolTest-1.20.1-Forge-GitHub-Ready.zip` 替換儲存庫根目錄的同名 ZIP。不要把下載時多出的 `(1)` 留在檔名裡。
2. 提交變更，使用你先前已成功的 ZIP 建置 workflow。不要只重跑更新前的舊提交。
3. 建置成功後，從本次 Actions 的產物下載 `wooltest-1.20.1-0.1.0.jar`。
4. 關閉遊戲，用新 JAR 替換目前實例中的舊 JAR，勿同時保留兩份 WoolTest。
5. 新版 Mods 名稱為 `Wool Test Dimension (Model 1 + Pillar 1)`。

整合版已內建相同的木柱資源，不需要再啟用獨立資源包。兩條安裝路線選一條即可。
如果已經啟用獨立資源包，換用整合版之後可以將資源包停用；它的優先權可能遮住將來 JAR 內的材質更新。

## 實際實裝範圍

這版加入五張 **32×32、完全不透明的 PNG**：正面、背面、左右側與上下端面。每個立方體方塊都使用相同的一組六面引用。

- `temporary_pillar_front.png`
- `temporary_pillar_back.png`
- `temporary_pillar_right.png`
- `temporary_pillar_left.png`
- `temporary_pillar_end.png`

四格高的木柱仍由四個完整方塊堆疊，所以圖案會每格重複。這次沒有新增連接材質或四段狀態，也沒有將圖案拉成整根只出現一次。
所有新資源位於 `assets/wooltest/`，不覆蓋原版橡木、其他木頭或普通殭屍。

### 圖片的區別

`art_source/pillar1/generated_design.png` 是生成的原始設計稿，包含概念示意，**不是遊戲截圖，也不是直接放入遊戲的貼圖**。

`art_preview/pillar1-preview.png` 是以實際的五張 PNG 和四個完整方塊離線繪製的預覽，較準確反映本版的每格重複方式，但仍不是遊戲截圖。光照與畫面效果應以遊戲為準。

PNG 經裁切、重排、縮放及有限色盤處理。可用 `tools/build_pillar1_assets.py` 重建；工具需要 Pillow，正常 GitHub 編譯不需要執行它，也不需要安裝 Python。

## 沒有改動的內容

所有 Java 原始碼均與 Model 1 逐位元組一致，包括生物模型、動畫、生命值、近戰、技能生成、傷害、擊退、壽命、冷卻、碰撞、維度與傳送。生物材質及所有伺服器資料、建置參數也保持不變。

沒有新增發光材質、光源、粒子或音效。這次只是視覺資源更新，不能用來修正舊版 Java 程式崩潰。
多人遊戲中，獨立資源包是每位玩家端的外觀設定；這份交付沒有新增伺服器自動推送資源包功能。

## 驗證狀態

已執行：PNG 可讀性、尺寸與透明度、JSON/TOML 解析、模型資源引用、原版資源不覆蓋、基礎檔案 SHA-256 比對、原有離線模型檢查、Java 17 語法解析，以及與 Minecraft 無關的核心規則測試。

**尚未執行：新版 Forge 完整編譯、遊戲啟動、資源包載入與實際遊戲畫面測試。**
單純字節相同及離線檢查，不等於新增的材質已通過遊戲實測。交付的是來源專案及獨立資源包，不是已編譯 JAR。

## 驗收

先在測試存檔操作：

```mcfunction
/difficulty normal
/wooltest enter
/wooltest spawn
/gamemode survival
```

靠近生物，確認每次出現三根四格高木柱，木柱有新材質而非紫黑缺圖；側面、端面、堆疊接縫顯示正常；接觸傷害、擊退與自動消失仍如舊版。
資源包不會改變創造模式免受傷的原行為。

## 技術參照

Forge 1.20.1 官方文件：

- Resources：資源包可覆蓋模組資源，命名空間和優先順序。https://docs.minecraftforge.net/en/1.20.1/concepts/resources/
- Models：模型引用材質、UV 與正方形二次冪貼圖。https://docs.minecraftforge.net/en/1.20.1/resources/client/models/

本包 `pack_format: 15` 與原始 1.20.1 專案的 `pack.mcmeta` 一致。
