City 3 已整合。
以同名 WoolTest-1.20.1-Forge-GitHub-Ready.zip 替換儲存庫根目錄的舊 ZIP，沿用 ZIP 外已成功的 GitHub Actions。
不要把外層 ZIP 改名；ZIP 中含 build.gradle、src、tools 及 .github。
若將專案解壓上傳，所有內容直接放儲存庫根目錄。
詳細更新與備份警告請讀 CITY3_使用說明.md。
