羊毛維度專案：直接上傳用目錄版

這次只整理檔案位置，沒有修改模組玩法或 Java 原始碼。
本包移除原本 ZIP 中額外的 WoolTest-1.20.1-Forge/ 外層目錄，
並把先前提供的 workflow 修正版放在 .github/workflows/build.yml。
必要的 src/、tools/、.github/ 及其他子目錄仍完整保留。

使用方式：
1. 將本 ZIP 全部解壓縮到一個空資料夾。
2. 打開該資料夾，確認這一層直接包含 build.gradle、settings.gradle、
   gradle.properties、src/、tools/、.github/ 等項目。
3. 上傳到 GitHub 時，上傳這一層內的全部內容，保留子目錄結構。
   不要只上傳 ZIP，也不要把整個外層資料夾多包一層。
4. 請特別確認 .github/workflows/build.yml 有一併上傳。
   若檔案選擇器隱藏 .github，請啟用顯示隱藏項目或單獨補上此檔案。

重要區別：
這仍是原始碼，不是已編譯的 .jar；這次沒有執行 Forge 編譯或遊戲測試。
原本 VALIDATION_繁體中文.md 與 validation/ 內容是原版本留下的檢查紀錄，
並不代表本次已完成編譯。

這次已檢查：
- 所有原始碼、資源與建置腳本均保留，位元組內容與原 ZIP 相同。
- workflow 位於此專案最外層的 .github/workflows/build.yml。
- workflow YAML 可解析，內嵌 Bash 指令通過 bash -n 語法檢查。
- 重新產生 SHA256SUMS.txt；此包不含預編譯的模組 JAR。
