# 皇帝版編譯修正 1（Emperor 1 Fix 1）

## 這次修正
本專案使用 Minecraft 1.20.1、Forge 47.4.10，以及 official mappings。
上一版 EmperorEntity.java 第 160 行使用了不適用於本專案映射的三參數方法名稱：

    dropEquipment(DamageSource source, int lootingLevel, boolean recentlyHit)

已改成：

    dropCustomDeathLoot(DamageSource source, int lootingLevel, boolean recentlyHit)

保留 @Override，讓真正的 Forge 編譯器繼續檢查繼承關係。
方法內容維持不呼叫父類裝備掉落流程，延續「尚未指定皇帝掉落，因此不額外掉天子劍」的規則。
未移除皇帝、法陣或武器功能，未變更城市藍圖。

## 操作：只替換模組 ZIP
1. 保留儲存庫 ZIP 外面目前可進入 Java 編譯的 .github/workflows/build.yml；本次不需要再修改它。
2. 在 GitHub 儲存庫最外層，將 WoolTest-1.20.1-Forge-GitHub-Ready.zip 替換成此次修正版，提交變更。
3. 檔名不要多出 (1) 或 (2)。不需要解壓縮。
4. 開啟該次新提交的 Actions 執行；不要重跑舊提交的失敗紀錄。
5. 只有建置成功後，才下載 wooltest-minecraft-1.20.1-forge 成品。
6. 關閉遊戲後替換舊 JAR，不要同時留下兩份 WoolTest。

產出的 JAR 檔名不變：wooltest-1.20.1-0.1.0.jar。
Mods 名稱：Wool Test Dimension (City 4 + Emperor 1 Fix 1)。
既有城市不需重建，不要為此修正執行 city build confirm。
ZIP 內的備用 workflow 也已同步為上一輪修正 runner.temp 後的版本；ZIP 外的 workflow 不會被 ZIP 自動替換。

## 警告與錯誤的區別
method does not override or implement a method from a supertype 是會阻擋編譯的錯誤。
Process completed with exit code 1 是該步驟失敗的結果，不是另一個可直接定位的程式錯誤。
ResourceLocation 與 FMLJavaModLoadingContext.get() 的 deprecated/marked for removal 訊息是警告。
這次保留這些警告，沒有以 SuppressWarnings、移除 @Override 或隱藏錯誤來假裝修復。

## 驗證範圍與限制
已執行語法解析、皇帝蓄力規則測試、模型／貼圖／生成空間檢查，以及來源檔比對。
使用 JDK 21 的 --release 17 進行離線 Java 語法／純 Java 規則檢查；GitHub 建置仍指定 JDK 17。
未完成完整 Forge 編譯與遊戲實測；此環境無法解析 maven.minecraftforge.net。
本次只能直接讀到使用者貼上的 annotations，以及先前交付的原始碼；未取得完整 GitHub 日誌。
修正的是原始碼中可確定存在的錯誤，是否尚有其他錯誤需由新一次真實建置確認。
若仍失敗，請傳新一次的 wooltest-build-log 下載包或 build-log.txt，不要只貼 exit code 1。

## API 核對來源
- Java 17 Override: https://docs.oracle.com/en/java/javase/17/docs/api/java.base/java/lang/Override.html
- Forge 1.20.1 generated Mob API reference: https://lexxie.dev/forge/1.20.1/net/minecraft/world/entity/Mob.html#dropCustomDeathLoot(net.minecraft.world.damagesource.DamageSource,int,boolean)
- Java 17 Deprecated: https://docs.oracle.com/en/java/javase/17/docs/api/java.base/java/lang/Deprecated.html
