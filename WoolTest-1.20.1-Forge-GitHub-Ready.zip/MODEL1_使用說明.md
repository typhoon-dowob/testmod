# 測試一號：Model 1 立體造型更新

本包接續 `Texture 1`，保留 hotfix1 木柱地圖顏色修正。這次不是只換 PNG：新增獨立模型、模型層註冊、分節木臂動畫，以及配合新模型重新配置的材質。

**本包是原始碼，不是已編譯的 JAR。這次尚未通過完整 Forge 編譯或遊戲實測。**

## 外觀

延續原本「拼布羊毛人偶」的構思與色系：青藍、芥黃、磚紅、米白和紫色；保留黑色鈕扣眼、縫線嘴、胸前 `01` 布牌及木製手臂。

本版模型包含 15 個節點、26 個立方體：

- 頭部加大，軀幹變厚，腿部縮短，腳掌有獨立立體形狀。
- 兩顆黑色鈕扣眼、胸前布牌和背部補丁均為突出於表面的立體部件。
- 木製手臂分為上臂、肘部、前臂和手掌；肩膀與手腕保留彩色布料。
- 加入待機輕晃、轉頭、走路擺臂與肘部彎曲、近戰揮臂動作。

動作是模型端的視覺計算，不增加新的技能，也沒有改變攻擊判定。這次沒有新增與木柱施放同步的施法動畫。

本版材質是將上一版已接受的拼布圖像重新配置到新模型，不是另一個完全不同的設計。舊 PNG 留作重製來源；渲染器實際讀取 `test_one_model1.png`。

## 維持不變

Minecraft 1.20.1 / Forge 專案目標 47.4.10；模組 ID 仍為 `wooltest`。

維度地形、高度、進出指令、實體註冊、生物 20 點生命、1 點近戰基礎傷害、半徑 5 格內 3 根 4 格高木柱、木柱 3 點基礎傷害與擊退、技能冷卻、存檔格式及碰撞箱，均沿用上一版程式。沒有新增第三方前置模組。

伺服器端碰撞箱仍是 0.6 × 1.95 格，沒有做逐部位命中判定。新的肩膀、手臂、眼睛和布牌是模型部件，不是額外碰撞箱。造型靜止時從腳底到頭頂約 1.9375 格，腳底保持在原本地面位置。

`validation/model1-unchanged-files.json` 記錄 29 個未變動檔案的 SHA-256，包括所有非客戶端 Java、原有遊戲資源、主要建置設定及舊材質。

## 沿用你的 GitHub ZIP 建置流程

1. 上傳這份 `WoolTest-1.20.1-Forge-GitHub-Ready.zip`，替換儲存庫最外層的同名舊 ZIP。下載時若多了 `(1)`，請先還原原檔名。
2. 提交變更後，查看針對「新提交」執行的 Actions；沿用目前已成功的外層 workflow，不需要更改工作流程內容。
3. 建置成功後，在該次執行的 Artifacts 下載 `wooltest-minecraft-1.20.1-forge`，解壓取得 `wooltest-1.20.1-0.1.0.jar`。
4. 關閉遊戲，以新 JAR 替換同一測試實例的舊 JAR。不要同時保留兩個 WoolTest 模組。
5. Mods 清單名稱應顯示 **Wool Test Dimension (Model 1)**，可用來區別舊版。JAR 檔名刻意維持不變，以相容既有 workflow 的產物路徑。

不必另外安裝材質包或動畫模組。伺服器測試時，客戶端與伺服器建議使用相同一版 JAR。

## 遊戲內檢查

建議先在測試存檔中確認，不直接使用重要存檔。

```mcfunction
/difficulty normal
/wooltest enter
/wooltest spawn
```

先用創造模式從正面、背面和側面確認眼睛、布牌、木製關節和腳掌；再改生存模式觀察走路、追擊與木柱技能。

```mcfunction
/gamemode survival
```

檢查重點：新模型是否載入、是否有紫黑缺圖、`01` 是否正常、走路時腳掌是否明顯離地、肘關節是否錯位、近戰與木柱是否維持原有效果。已存在的同 ID 生物在客戶端重啟後也應使用新渲染器，但仍需遊戲實測確認。

若崩潰，請保留新一次 `latest.log` 或 crash report；若只是貼圖／動作有問題，請提供正面和側面截圖。

## 原始檔

- `src/main/java/dev/sushi/wooltest/client/TestOneModel.java`：新模型、骨架與動作。
- `src/main/java/dev/sushi/wooltest/client/TestOneRenderer.java`：接上模型與新 PNG。
- `src/main/java/dev/sushi/wooltest/client/ClientEvents.java`：客戶端模型層註冊。
- `src/main/resources/assets/wooltest/textures/entity/test_one_model1.png`：256 × 256 RGBA 材質，對應 128 × 128 邏輯 UV。
- `art_source/model1/test_one_model1.json`：模型幾何與逐面貼圖座標的參考資料。
- `tools/build_model1_assets.py`：由上一版 PNG 重製材質及 Java 幾何；不在遊戲或 Gradle 建置時執行。
- `art_preview/model1-preview.png`：依實際幾何與 PNG 產生的離線預覽；不是遊戲截圖，不能視為遊戲渲染測試。

重製素材工具需要 Python、Pillow；預覽另需 NumPy。一般使用 GitHub 編譯模組時不需要這些 Python 套件。

## 驗證狀態

已完成：Java 17 語法解析、原有核心規則測試、JSON/TOML 格式、模型父子階層、UV 越界／重疊／透明面檢查、客戶端模型層引用檢查，以及 29 個基準檔案逐位元組比對。

未完成：完整 Forge 編譯、遊戲啟動、遊戲內貼圖／動作，以及多人模式。此環境下載 Forge MDK 時仍出現 `Could not resolve host: maven.minecraftforge.net`，因此不將離線檢查當成編譯成功。

詳見 `validation/model1-offline-check.txt` 與 `validation/model1-build-attempt.txt`。其他 Texture 1／hotfix1 說明與檢查檔保留作為歷史紀錄，不代表本版已完成遊戲測試。
