#!/usr/bin/env python3
"""Offline asset checks; does not launch Minecraft or test Forge API linkage."""
from pathlib import Path
import json, hashlib
from PIL import Image

root = Path(__file__).resolve().parent.parent
path = root / 'src/main/resources/assets/wooltest/textures/entity/test_one.png'
with Image.open(path) as probe:
    probe.verify()
with Image.open(path) as image:
    assert image.size == (128, 128), image.size
    assert image.mode == 'RGBA', image.mode
    spec = json.loads((root / 'art_source/uv_regions.json').read_text())
    used = set()
    for name, face in spec['faces'].items():
        x, y, w, h = face['uv']
        for py in range(y * 2, (y + h) * 2):
            for px in range(x * 2, (x + w) * 2):
                assert 0 <= px < 128 and 0 <= py < 128, name
                assert (px, py) not in used, ('UV overlap', name, px, py)
                assert image.getpixel((px, py))[3] == 255, ('transparent base', name)
                used.add((px, py))
    for py in range(128):
        for px in range(128):
            if (px, py) not in used:
                assert image.getpixel((px, py))[3] == 0, ('unused UV not clear', px, py)
print('PASS: 128x128 RGBA PNG; 24 mapped faces are opaque, non-overlapping and in bounds.')
print('PASS: All unused and head-overlay UVs remain transparent.')
renderer = (root / 'src/main/java/dev/sushi/wooltest/client/TestOneRenderer.java').read_text()
assert 'new ResourceLocation("wooltest", "textures/entity/test_one.png")' in renderer
assert 'ModelLayers.ZOMBIE' in renderer
assert '"minecraft", "textures/entity/zombie/zombie.png"' not in renderer
assert not (root / 'src/main/resources/assets/minecraft').exists()
print('PASS: Custom texture reference resolves; vanilla resources are not overridden.')
for entry in json.loads((root / 'validation/texture1-unchanged-files.json').read_text()):
    data = (root / entry['path']).read_bytes()
    assert hashlib.sha256(data).hexdigest() == entry['sha256'], entry['path']
print('PASS: 22 gameplay/world/model files match the working hotfix1 baseline byte-for-byte.')
print('NOTE: No Forge compilation, in-game rendering, animation or multiplayer test is implied.')
