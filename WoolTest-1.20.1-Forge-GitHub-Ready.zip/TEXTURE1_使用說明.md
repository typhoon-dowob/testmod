# 測試一號外觀更新 — Texture 1

此包以你已回報測試通過的 hotfix1 為基礎。已將專屬材質接到模組原始碼；**此包不是 JAR，這次的外觀更新尚未經過 Forge 完整編譯或遊戲內實測**。

## 如何更新

1. 將本包 `WoolTest-1.20.1-Forge-GitHub-Ready.zip` 原檔上傳到原本的 GitHub 儲存庫最外層，取代同名 ZIP。不要改名，也不用解壓；若瀏覽器自動加上 `(1)`，先恢復原檔名。
2. 沿用你已成功的 ZIP 建置 workflow；提交新 ZIP 後，查看新的 Actions 執行紀錄。必要時使用 Run workflow 對最新分支啟動。不要只重跑更新前的舊提交。
3. 建置成功後，從該次執行的 Artifacts 取得 `wooltest-minecraft-1.20.1-forge`，解壓其中的 `wooltest-1.20.1-0.1.0.jar`。
4. 關閉遊戲，移除或替換實例 `mods` 內的舊 WoolTest JAR，只保留一份，再開啟原本的 Minecraft 1.20.1 Forge 實例。不必另裝材質包或其他模組。
5. Mods 清單中的顯示名稱應為 **Wool Test Dimension (Texture 1)**。名稱沒變就先確認是否用了舊建置產物或放錯實例。
6. 在測試世界輸入 `/wooltest spawn` 或使用原本的生怪蛋。這次沒有改生物 ID 或資料格式，仍為 `wooltest:test_one`；建議先備份測試存檔。

保留 `mod_version=0.1.0` 和原 JAR 檔名，是為了相容你現有 workflow 的固定產物路徑。請靠 Mods 顯示名稱與 JAR 內的 `wooltest-build-info.txt` 確認更新，而不是只看檔名。

## 本次交付

- `src/main/resources/assets/wooltest/textures/entity/test_one.png`：實際載入的 128×128 RGBA 材質，依既有模型的 64×64 邏輯 UV 配置整理。
- `src/main/java/dev/sushi/wooltest/client/TestOneRenderer.java`：改用 `wooltest:textures/entity/test_one.png`，不覆蓋一般殭屍的資源。
- `art_source/`：生成的視覺設計原稿、各面的取樣區域與 UV 對照。
- `art_preview/`：將實際貼圖映射到人形方塊尺寸後的離線預覽。**這不是 Minecraft 截圖，不代表遊戲已驗證。**
- `tools/remap_test_one_texture.py`：精確 UV 重排與像素標籤整理工具；成品 PNG 已放好，正常編譯不需執行它，也不需安裝 Python 或 Pillow。
- `validation/texture1.patch`、`texture1-unchanged-files.json`、`texture1-offline-check.txt`：程式修改和檢查記錄。

## 本次不變更的內容

生命 20、近戰傷害 1、三根四格高木柱、半徑五格、木柱傷害與擊退、冷卻／清除時間、維度、碰撞箱與生物 AI 均保持原程式。木柱的原木材質與生物音效也保持原樣。只改「測試一號」的貼圖引用與模組顯示標記。

模型仍使用原版人形模型，兩隻手臂與兩隻腿各共用鏡像 UV。胸前 `01` 是表面像素標籤；縫線與鈕扣是材質圖案，沒有增加凸出的幾何模型。

## 檢查狀態與驗收

已檢查 PNG 格式、24 個基礎面的座標與透明度、材質引用、資源格式、Java 17 語法及純 Java 核心規則；另確認 22 個遊戲邏輯／維度／原方塊模型檔與 hotfix1 完全一致。

**未完成：此更新的 Forge 全量編譯、遊戲啟動、動態渲染、光影／其他材質包相容性與多人測試。**本環境對 Forge Maven 的 DNS 解析仍失敗；離線檢查不能替代這些測試。

遊戲內請確認：正面／背面沒有紫黑缺圖或空洞；胸前標籤正向顯示；走路與攻擊時貼圖正常；普通殭屍外觀不變；原有木柱技能仍可使用。

## 資源路徑依據

Forge 1.20.1 官方 Resources 說明：
https://docs.minecraftforge.net/en/1.20.1/concepts/resources/

本次美術由本對話生成的設計圖重新對齊 UV、離散像素化並整理標籤而成，沒有複製原版殭屍的 PNG。原稿在 `art_source/test_one_generated.png`，與遊戲實際載入的貼圖不同；不要直接用原稿取代實裝 PNG。
