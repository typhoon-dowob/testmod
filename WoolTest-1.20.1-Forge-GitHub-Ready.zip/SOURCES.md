# Development references

The following references were consulted for version-specific APIs and project setup.
They are not evidence that this project has been built or tested in Minecraft.

- Forge 1.20.1 setup and Java 17 requirements:
  https://docs.minecraftforge.net/en/1.20.1/gettingstarted/
- Official Forge 1.20.1 release files (target: 47.4.10):
  https://files.minecraftforge.net/net/minecraftforge/forge/index_1.20.1.html
- Official 1.20.1 MDK Gradle template:
  https://raw.githubusercontent.com/MinecraftForge/MinecraftForge/1.20.1/mdk/build.gradle
- Official 1.20.1 MDK settings template:
  https://raw.githubusercontent.com/MinecraftForge/MinecraftForge/1.20.1/mdk/settings.gradle
- Forge registries:
  https://docs.minecraftforge.net/en/1.20.1/concepts/registries/
- Forge entity networking:
  https://docs.minecraftforge.net/en/1.20.1/networking/entities/
- Generated API signatures from the 1.20.1 code:
  https://lexxie.dev/forge/1.20.1/net/minecraft/world/level/chunk/ChunkGenerator.html
  https://lexxie.dev/forge/1.20.1/net/minecraft/world/level/block/state/BlockBehaviour.Properties.html
  https://lexxie.dev/forge/1.20.1/net/minecraft/world/damagesource/DamageSource.html
  https://lexxie.dev/forge/1.20.1/net/minecraft/client/renderer/entity/MobRenderer.html

Official MDK bootstrap artifact:
https://maven.minecraftforge.net/net/minecraftforge/forge/1.20.1-47.4.10/forge-1.20.1-47.4.10-mdk.zip

SHA-1 published on the official Forge release page:
31133abd261aa4d23672d1820db06ccec80326ad

The original Gradle wrapper is downloaded at build time; it is not imitated by a generated JAR.
No Minecraft game code or textures are redistributed in this project.
