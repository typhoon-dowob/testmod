# Development references

The following references were consulted for version-specific APIs and project setup.
They are not evidence that this project has been built or tested in Minecraft.

- Forge 1.20.1 setup and Java 17 requirements:
  https://docs.minecraftforge.net/en/1.20.1/gettingstarted/
- Official Forge 1.20.1 release files (target: 47.4.10):
  https://files.minecraftforge.net/net/minecraftforge/forge/index_1.20.1.html
- Official 1.20.1 MDK Gradle template:
  https://raw.githubusercontent.com/MinecraftForge/MinecraftForge/1.20.1/mdk/build.gradle
- Official 1.20.1 MDK settings template:
  https://raw.githubusercontent.com/MinecraftForge/MinecraftForge/1.20.1/mdk/settings.gradle
- Forge registries:
  https://docs.minecraftforge.net/en/1.20.1/concepts/registries/
- Forge entity networking:
  https://docs.minecraftforge.net/en/1.20.1/networking/entities/
- Generated API signatures from the 1.20.1 code:
  https://lexxie.dev/forge/1.20.1/net/minecraft/world/level/chunk/ChunkGenerator.html
  https://lexxie.dev/forge/1.20.1/net/minecraft/world/level/block/state/BlockBehaviour.Properties.html
  https://lexxie.dev/forge/1.20.1/net/minecraft/world/damagesource/DamageSource.html
  https://lexxie.dev/forge/1.20.1/net/minecraft/client/renderer/entity/MobRenderer.html

Official MDK bootstrap artifact:
https://maven.minecraftforge.net/net/minecraftforge/forge/1.20.1-47.4.10/forge-1.20.1-47.4.10-mdk.zip

SHA-1 published on the official Forge release page:
31133abd261aa4d23672d1820db06ccec80326ad

The original Gradle wrapper is downloaded at build time; it is not imitated by a generated JAR.
No Minecraft game code or textures are redistributed in this project.


## Model 1 API reference

The custom client model layer is registered through the Forge 1.20.1
EntityRenderersEvent.RegisterLayerDefinitions API. Primary source:
https://github.com/MinecraftForge/MinecraftForge/blob/1.20.1/src/main/java/net/minecraftforge/client/event/EntityRenderersEvent.java

The art reuses/remaps the project's previously generated Texture 1 image,
with separate cuboid geometry for the buttons, badge and limbs.
No third-party geometry, texture, animation library or code dependency was added.
The preview is an offline diagnostic of the shipped geometry, not a game screenshot.


## Pillar 1 resource update
Generated original artwork: art_source/pillar1/generated_design.png.
Five square textures are cropped/rearranged from that artwork using tools/build_pillar1_assets.py.
No downloaded Minecraft textures are bundled in this update.
Implementation references, checked during this update:
- https://docs.minecraftforge.net/en/1.20.1/concepts/resources/
- https://docs.minecraftforge.net/en/1.20.1/resources/client/models/

## Sword 1 implementation references

The Minecraft/Forge target is 1.20.1, not the moving 1.20.x branch.
- Forge item registration and item properties: https://docs.minecraftforge.net/en/1.20.1/items/
- Official Forge 1.20.1 IForgeItem source (stack-aware getAttributeModifiers, getShareTag, onEntityItemUpdate): https://raw.githubusercontent.com/MinecraftForge/MinecraftForge/1.20.1/src/main/java/net/minecraftforge/common/extensions/IForgeItem.java
- Official Forge 1.20.1 ItemStack patch (stack-aware attributes and NBT propagation): https://raw.githubusercontent.com/MinecraftForge/MinecraftForge/1.20.1/patches/minecraft/net/minecraft/world/item/ItemStack.java.patch

Sword sprite: recovered exactly from the prior original 32x32 pixel artwork's 512x512 preview. Only its two checkerboard background colours were converted to transparency. Not the promotional collage and not a vanilla sword texture. See art_source/sword1/texture_provenance.json.


## Structure 1 implementation references

- Forge 1.20.1 server data: https://docs.minecraftforge.net/en/1.20.1/resources/server/
- Native 1.20.1 structure JSON extracted from the game (read-only reference, not copied artwork): https://github.com/misode/mcmeta/blob/1.20.1-data/data/minecraft/worldgen/structure/village_plains.json
- Author's example of native jigsaw templates with embedded persistent entities; 1.19.3+ branch: https://github.com/TelepathicGrunt/StructureTutorialMod/tree/1.19.3-Forge-Jigsaw
- Building geometry, gate glyphs, NBT generation, layout checks and configuration in this release are newly authored for this project.
- No third-party template artwork or downloaded structures were packaged.
- Native engine placement has NOT been executed in this environment. The template/entity and clipping checks are offline checks only.


## Capital City 1 implementation references
- Forge 1.20.1 SavedData (persistent migration progress): https://docs.minecraftforge.net/en/1.20.1/datastorage/saveddata/
- Forge 1.20.1 block / BlockItem registration and properties: https://docs.minecraftforge.net/en/1.20.1/blocks/
- Forge 1.20.1 model/texture resources: https://docs.minecraftforge.net/en/1.20.1/resources/client/models/
- Forge 1.20.1 ServerTickEvent source: https://raw.githubusercontent.com/MinecraftForge/MinecraftForge/1.20.1/src/main/java/net/minecraftforge/event/TickEvent.java
The prior generated concept illustration is a design reference, not a Minecraft screenshot or a building template.
All city pixel textures, JSON models, blueprint and geometry previews were authored by the included tools/build_city1.py and tools/render_city1.py scripts.
