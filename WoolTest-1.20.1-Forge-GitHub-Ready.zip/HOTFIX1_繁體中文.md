# hotfix1：修正臨時木柱初始化時缺少 axis 的錯誤

## 依據
使用者上傳的崩潰紀錄指出，在 TemporaryPillarBlock.java:20 建立方塊時，
原版 Blocks.lambda$log$51 讀取不存在的 axis 屬性；隨後因木柱註冊失敗，
出現 Registry Object not present: wooltest:temporary_pillar。

## 本次修改
TemporaryPillarBlock 原本複製 Blocks.OAK_LOG 的屬性，其中地圖顏色函式依賴 axis。
此技能方塊沒有 axis 狀態。現在於 copy 後、super 建立狀態前呼叫
mapColor(MapColor.WOOD)，將該函式替換成固定值。
木柱的材質、生命週期、碰撞與傷害邏輯未修改，其他 Java 原始碼未修改。

## 如何辨識修正版
為相容上一則提供的 workflow 固定產物路徑，維持 mod_version=0.1.0：
wooltest-1.20.1-0.1.0.jar。
因此檔名相同不代表內容相同。請使用新提交所產生的 Actions artifact，替換舊 JAR。
此版 JAR 應包含 wooltest-build-info.txt，其中標記 hotfix1-pillar-mapcolor。

## GitHub ZIP 建置方式
1. 將本修正版 ZIP 以 WoolTest-1.20.1-Forge-GitHub-Ready.zip 的檔名上傳至儲存庫根目錄，替換原同名 ZIP。
2. 檔名不要帶下載器附加的 (1)、(2)。不需要解壓；保留儲存庫外層的 .github/workflows/build.yml。
3. 使用先前提供的 ZIP 解壓 workflow，對新提交執行建置。不要只重跑舊提交的紀錄。
4. 成功後下載該次 wooltest-minecraft-1.20.1-forge artifact，取出新 JAR。
5. 關閉遊戲，在啟動器選定的 1.20.1 Forge 實例中，以新 JAR 替換舊模組。避免同時保留兩份 wooltest。

若你原先使用的是 v0.1.0-source.zip，新上傳的 GitHub-Ready.zip 會由上一則 ZIP workflow 優先選取。
這個包內的 workflow 是供解壓專案使用；直接上傳 ZIP 時，仍由儲存庫 ZIP 外面的 workflow 啟動建置。

## 驗證狀態
已重跑 JSON、TOML、引用、核心規則與 Java 17 語法解析檢查，原始輸出見
validation/hotfix1-offline-check.txt。使用本機 JDK 21 以 --release 17 檢查語法；這不是 Forge 型別檢查。
另已檢查兩個 shell 腳本語法，以及 ZIP 結構能被前述 workflow 辨識。
本環境仍無法解析 maven.minecraftforge.net，未完成此修正版的 Forge 編譯或遊戲啟動測試。
不能把此修正視為其餘所有模組功能已驗證通過。
舊版 VALIDATION_繁體中文.md 與 validation/offline-check.txt 為先前交付紀錄。
