# WoolTest Structure 1：布偶試驗場

本版以「桃木劍介紹精簡版」為基礎，整合布偶試驗場的結構模板與自然生成設定。
包含 Model 1 生物造型、Pillar 1 木柱材質、FX 1 生成／消失特效、Sword 1 桃木劍與精簡介紹。
這是原始碼專案，不是可直接放入 mods 的 JAR；必須先編譯。

## 1. 更新方式

把 GitHub 儲存庫最外層的舊 `WoolTest-1.20.1-Forge-GitHub-Ready.zip` 替換成這次的同名檔案，提交變更，再使用之前成功的外層 ZIP 建置 workflow。
不必修改 workflow、不必另外安裝資料包或資源包，也沒有新增模組依賴。

建置成功後，下載該次新提交的 Actions 成品。關閉遊戲，以新 JAR 替換舊 JAR；多人伺服器與玩家端都應更新，mods 內不要同時保留兩份 WoolTest。

- Minecraft Java：1.20.1。
- 目標 Forge：47.4.10；依賴範圍保留 `[47.4.10,48)`。
- 建置 Java：17；既有編譯設定未更動。
- JAR 檔名仍為 `wooltest-1.20.1-0.1.0.jar`，相容原有 workflow。
- Mods 清單辨識名稱：`Wool Test Dimension (Structure 1)`。
- `wooltest` 模組 ID、維度 ID、既有生物／物品 ID 均未更動。

請先備份存檔，最好以新測試世界驗收。這版尚未完成 Forge 編譯及遊戲實測。

## 2. 建築設定

| 項目 | 實作設定 |
| --- | --- |
| 結構名稱 | 布偶試驗場 |
| 結構 ID | `wooltest:doll_trial_ground` |
| 模板 ID | `wooltest:doll_trial_ground` |
| 尺寸 | X=21、Z=21、Y=10，含地板 |
| 方塊 | 813 個羊毛方塊，其餘為空氣；無箱子、刷怪籠、木樑或石磚 |
| 外觀 | 拼布地板、斷續矮牆、四角立柱、入口大型「01」、階梯式中央祭壇 |
| 中央祭壇 | 此版為裝飾，尚無互動、獻祭或領獎功能 |
| 守衛 | 模板內含兩隻 `wooltest:test_one`，設定保留及正常 AI；不是無限刷怪點 |
| 自然生成高度 | 地板預期 Y=63，站立層 Y=64，最高方塊 Y=72；不改維度 0～127 的方塊範圍 |
| 自然生成朝向 | 由原生 jigsaw 放置決定四種水平朝向 |
| 頻率 | `random_spread`：spacing=24 個區塊、separation=12 個區塊、salt=718031065 |

每個 24×24 區塊區域（384×384 格）有一個候選起點，位置由世界種子決定；這不是「沿直線每 384 格一定出現一座」，也不是兩棟建築固定距離。
自然生成僅配對 `wooltest:wool_fields`；本專案只有羊毛維度使用這個群系。不更動主世界、地獄或終界的群系標籤。
若外部資料包額外把此群系用在其他維度，或改寫本模組的結構／群系標籤，生成範圍也可能隨之改變。

## 3. 測試自然生成（建議先測這個）

建立開啟作弊的新測試世界，保留「生成結構」設定，依序輸入：

```mcfunction
/gamemode creative
/difficulty normal
/wooltest enter
/locate structure wooltest:doll_trial_ground
```

前往定位結果的 X、Z。測試時可以把定位結果的 X、Z 代入 `/tp @s X 80 Z`；X、Z 必須改成實際數字，不是照抄字母。
在創造模式從高處觀察建築，再靠近入口，檢查「01」、中央祭壇以及兩隻守衛。

需測試戰鬥時，準備好裝備再切換：

```mcfunction
/gamemode survival
```

守衛使用原本的 20 點生命、1 點近戰基礎傷害與木柱技能。正常死亡後仍走原有桃木劍 90% 獨立掉落判定。
本次沒有修改掉落、抽值、攻速或介紹文字。

### 舊存檔

這版沒有登入補建、區塊載入補建或守衛重生迴圈。已經完整生成過的區域不會被主動補上建築，需探索尚未生成的區域。
新舊區域邊界上的結構可能因舊區塊不重新生成而出現不完整情況，驗收最好離開舊探索範圍或使用新世界。
不需要、也不建議為此直接刪除維度資料夾，那會刪掉已有地形與建築。

## 4. 立即放一座來檢查外觀與守衛

在羊毛維度內找一片空地，確定已設為非和平難度。**下列指令會改動目標區域的方塊，不能用在基地旁。**

```mcfunction
/place template wooltest:doll_trial_ground ~8 63 ~8
```

這會以玩家當前位置 X+8、Z+8 作為未旋轉模板的西北角，放置 21×21 格、Y=63～72 的模板，包含空氣清除範圍和兩隻守衛。
它使用固定 Y=63，專門對應這版羊毛平地；不要拿它在其他高度的建築內測試。
重複執行會重複放置並新增兩隻生物，並非只更新原有建築。

這個指令測試的是模板放置，不會建立自然生成用的結構起點紀錄。手動放置的建築不應拿來判斷 `/locate structure` 是否能找到自然生成結構，也不等於自然生成已通過測試。

返回主世界：

```mcfunction
/wooltest leave
```

## 5. 守衛與難度

兩隻守衛隨模板初次放置產生，不靠一般刷怪群系清單生成。擊殺後不會由這座建築反覆補生。
它們沿用原本 AI，能走動與追逐，不保證一直站在初始位置。
請先切到簡單／普通／困難，再放置或探索建築。和平難度可能移除敵對生物；再切回普通難度也不會替已生成的建築補回守衛。
`PersistenceRequired` 用於避免一般距離造成的自然消失，不是免除和平難度移除、死亡或管理員指令。
兩隻守衛共用原本的桃木劍掉落邏輯，不是兩隻必掉兩把。

## 6. 技術內容與檢查界線

此版只修改一個既有 Java 原始碼檔：`WoolChunkGenerator.java`。
把原本空的 `createStructures` 及 `applyBiomeDecoration` 接回父類別，使用原生結構起點、參照與分區塊放置。
其餘新增內容為 NBT 模板、結構 JSON、結構集合、模板池與群系標籤。沒有新增 ChunkEvent.Load 回填邏輯。

新增資源路徑：

```text
src/main/resources/data/wooltest/
├── structures/doll_trial_ground.nbt
├── worldgen/structure/doll_trial_ground.json
├── worldgen/structure_set/doll_trial_ground.json
├── worldgen/template_pool/doll_trial_ground/start.json
└── tags/worldgen/biome/has_structure/doll_trial_ground.json
```

`tools/build_structure1.py` 可重建本次原創結構與設定，不依賴第三方 Python 套件。
`tools/check_structure1.py` 會獨立解碼 NBT，檢查方塊、守衛落點、資源引用，並執行既有規則測試與 Java 17 語法解析。
`tools/render_structure1_plan.py` 需 Pillow，只產生從真實模板推導的方塊配置示意，不是遊戲截圖。

已完成：NBT/GZIP 解碼、完整體積與高度、全羊毛檢查、守衛落點／頭部空間、四朝向的區塊歸屬算術、資源引用、既有檔案雜湊比對、Java 語法與規則測試。
未完成：Forge 編譯、資料包在遊戲內載入、真實自然生成、`/locate`、模板生物放置、存檔重載及多人實測。
離線測試與測試替身不能取代這些驗證；目前沒有在此產出可玩的 JAR。

本次記錄：`validation/structure1-offline-check.txt`。
過往 validation 檔與版本說明保留作歷史記錄，不應解讀為本版已完成的遊戲測試。
