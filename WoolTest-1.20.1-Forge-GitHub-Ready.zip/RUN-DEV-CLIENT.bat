@echo off
setlocal
cd /d "%~dp0"
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0tools\build.ps1" -Task client
set "RESULT=%ERRORLEVEL%"
pause
exit /b %RESULT%
