# City 5 + Emperor 5：短臉、稜面修正版

## 已整合的外觀修改
本版以 Emperor 4 完整原始碼 ZIP 為基礎，只調整皇帝客戶端外觀與版本識別。
主體使用較大的平面與小倒角，不再把衣袍、袖子和冠帽做成圓筒，也不是退回單純堆大方盒。
臉部高度由 10.7 個模型像素改成 7.8，約縮短 27.1%；最大臉寬為 6.8，臉部長寬比約 1.15。
鼻樑由原來 2.25 改成 1.6；鬍鬚高度由 6.45 改成 3.6 個模型像素。
頭部與冕冠下移 2.2 個模型像素，避免縮短下巴後反而出現很長的脖子；紅領重新接合。
幾何主表面使用獨立的平面法線，不跨倒角平均成光滑曲面。
黑金紅配色、冕冠垂珠、玉佩、龍紋與披風保留。

## 尺寸與不變的內容
中立幾何高度約 2.86 格（不含骨架擺動）；原設定的 2×2×3 碰撞箱完全不變。
視覺頭部變短不代表碰撞箱一起縮小。
皇帝的 AI、50 點生命、10 點近戰傷害、頭目血條、五秒技能和中斷光束沒有改動。
四件裝備各 90% 掉落、隨機盔甲值與韌性、天子劍、桃木劍、測試一號和木柱技能沒有改動。
City 5 城市藍圖與唯一原點生成規則沒有改動。

## 安裝更新
1. 將 GitHub 儲存庫最外層的舊 ZIP 替換成這份同名檔案：
   `WoolTest-1.20.1-Forge-GitHub-Ready.zip`。
2. 沿用目前能執行的外部 `.github/workflows/build.yml`，本次不用修改 workflow。
3. 從這次新提交建置成功後的產物取得 `wooltest-1.20.1-0.1.0.jar`。
4. 關閉遊戲，備份存檔，以新 JAR 替換舊模組，勿同時保留兩份 WoolTest。
5. Mods 名稱應顯示 `Wool Test Dimension (City 5 + Emperor 5 - Faceted)`。
已存在的皇帝會使用新版外觀；不需要重新生成或重設自然皇帝紀錄。
不要為本次外觀更新執行 `/wooltest city build confirm`，城市沒有修改。
本包是原始碼 ZIP，不是可直接放進 mods 的 JAR；不用額外資源包或模型模組。

## 預覽
- `art_preview/emperor5-before-after.png`：與 Emperor 4 同鏡頭、同物理尺度對照。
- `art_preview/emperor5-face-detail.png`：同尺度臉部近看。
- `art_preview/emperor5-model-preview.png`：新版正面與背面。
- `art_preview/emperor5-posing-preview.png`：蓄力與行走姿勢樣本。
預覽解碼的是隨模組打包的實際 WEM4 格式幾何，並使用同一套貼圖；不是概念圖或遊戲截圖。
預覽沒有渲染另行掛接的天子劍、獨立技能實體或真正 Minecraft 光照。

## 可重現的來源
- `tools/build_emperor5.py` 產生模型、像素貼圖與相同 WEM4 格式的二進位資料。
- `art_source/emperor5/emperor_mesh.json` 保存頂點、UV、骨架和各部件尺寸。
- `src/main/resources/assets/wooltest/geometry/emperor5.wem.gz` 是遊戲實際載入的模型。
- `tools/render_emperor5.py` 從執行資料製作預覽。
- `tools/compare_emperor5.py <上一版原始碼ZIP>` 製作原始模型對照。
- `tools/check_current.sh` 是本版離線檢查入口。
WEM4 是沿用的檔案格式，不是把模型還留在 Emperor 4；載入路徑已改為 emperor5.wem.gz。
舊版說明、作者檔與預覽保留供歷史對照；本版以本文件和 Emperor 5 資源為準。

## 驗證及限制
已執行 41 份 Java 原始碼語法解析、正式模型解碼器測試、全部頂點與 UV/法線檢查、
骨架一致性檢查、120 個姿勢的繪製測試替身檢查、模型與貼圖可重現檢查，
並重跑既有技能、裝備、城市離線檢查。
334 個既有執行檔案與上一版逐位元組一致；只更新 5 個既有檔案，
將舊網格換成新網格，沒有修改非客戶端玩法 Java 程式。
完整 Forge 編譯、實際 GPU 繪製、持劍對位、動畫、發光層與多人顯示尚未驗證。
測試替身編譯不等於通過 Forge 編譯；語法檢查不等於遊戲可執行。
