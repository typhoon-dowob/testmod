> **本包為 Model 1 立體造型更新。請先讀 `MODEL1_使用說明.md`；以下原始內容保留為前版參考。**

# Texture 1 本次狀態

請以 `TEXTURE1_使用說明.md` 與 `validation/texture1-offline-check.txt` 為本次檢查依據。以下保留原版歷史紀錄，並非新增的遊戲實測。

# 交付前檢查記錄

## 已執行

1. 解析全部 13 個 JSON / pack.mcmeta 資源檔，確認格式可讀。
2. 解析 mods.toml，檢查模組 ID、維度 ID、生成器 ID、生態域參照與高度設定。
3. 比對繁體中文與英文翻譯鍵，以及程式中的訊息鍵。
4. 檢查非 client 來源檔沒有直接 import `net.minecraft.client`。
5. 使用 JDK 的 Java 編譯器 API，以 `--release 17` 解析 13 個來源檔的語法。
6. 將純 Java `TestRules` 與測試程式實際編譯並執行；32,852 個斷言通過。
   斷言包括 16 色涵蓋／負座標與週期、合法地形層、半徑圓形邊界、柱高及指定生命傷害常數。
7. 以 `bash -n` 檢查兩個 shell 建置腳本的語法。
8. 實際嘗試下載官方 Forge MDK，下載因無法解析 `maven.minecraftforge.net` 而失敗，exit code 6。

執行原始輸出附於 `validation/offline-check.txt` 與 `validation/build-attempt.txt`。
離線檢查可在有 Python 3.11+ 與 JDK 的電腦重跑：

```bash
python tools/check_offline.py
```

## 尚未完成，不能視為通過

- 以真實 Forge / Minecraft 依賴進行完整 Java 型別檢查、編譯與 reobfuscation。
- 產生可安裝的正式模組 JAR。
- 客戶端啟動、資源載入、維度建立、實際地形與渲染測試。
- 生物 AI、碰撞傷害、實際擊退方向／幅度與技能時間的遊戲內測試。
- 多人同步、獨立伺服器、區塊卸載重載及保存重啟測試。
- Windows PowerShell 腳本的實際執行。
- 與任何其他模組的相容性。

**Java 語法測試不等於 Forge 編譯；純數值斷言不等於遊戲內整合測試。**
交付物是附建置流程的完整測試版原始碼，不是已實機驗收的產品。
