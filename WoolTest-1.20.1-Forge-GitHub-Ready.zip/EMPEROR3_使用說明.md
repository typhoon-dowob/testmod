# WoolTest：City 5 + Emperor 3（文雅修長型）

## 本次交付
已將皇帝的瘦身模型、重新配置的貼圖與蓄力發光遮罩直接接入完整模組原始碼。
這是 Minecraft Java 1.20.1／Forge 專案，不是已編譯 JAR。沿用原本的 GitHub Actions 即可；不需要修改外層 build.yml。

## 外觀改動
不是把整隻模型等比例壓扁。胸部、腰、裙擺、手臂、肩飾、頭、冠板、珠串與披風分別調整。
中立姿勢（不含手持物）最寬從 32 模型單位縮為 24，即 2 格縮為 1.5 格，減少 25%；總高維持 48 單位，即 3 格。
上身寬 11、收腰 9、裙擺分成 13 與 14 單位；原裙擺寬 20。保留黑金長袍、紅領、玉佩、前擺、冕冠及十二串垂珠。
肩部與手臂樞紐往內移，手掌的上下位置和原本持物變換保持一致。沒有新增或改寫動畫方法。
冕冠裝飾條、垂珠及玉佩調整，避免部分重疊共面的表面；遊戲渲染效果仍需實測。
現有原創臉部／袍服材質按各面重排 UV，不使用原版殭屍材質。蓄力發光遮罩同步重排。
24 個節點、110 個長方體、660 個材質面。使用原 512×512 PNG 與 256×256 邏輯 UV 尺度。

## 明確不改的內容
碰撞箱仍為 2×2×3，沒有因外觀變窄而偷偷改變碰撞、索敵或戰鬥規則。
生命 50、近戰基礎攻擊 10、頭目血條、固定五秒蓄力、打斷光束、地面法陣與天子劍都保留。
四件裝備各自 90% 掉落，盔甲 1.00～3.00／韌性 1.00～2.00 的獨立隨機值與保存邏輯不變。
City 5 城市、宮殿、生成紀錄、測試一號、木柱與桃木劍均未改動。
玩家穿戴的御用裝備貼圖和網格也沒有改動；本次瘦身只針對皇帝生物。

## 更新方法
1. 將本 ZIP 保持檔名 WoolTest-1.20.1-Forge-GitHub-Ready.zip，上傳取代 GitHub 儲存庫根目錄舊 ZIP。
2. 沿用目前能進入編譯的 workflow，查看新提交的 Actions。不要重跑舊提交。
3. 建置成功後取得 wooltest-1.20.1-0.1.0.jar；關閉遊戲，再替換舊 JAR，勿同時留下兩份。
4. Mods 顯示名稱應為 Wool Test Dimension (City 5 + Emperor 3 - Slim)。

不需要另裝材質包。這次沒有改城市，**不要為了瘦身執行 /wooltest city build confirm**，不需要覆寫存檔或重建宮殿。
既有皇帝使用相同實體 ID 和新的顯示模型；本次不會自動復活已死亡的宮殿皇帝。
多人遊玩時，建議伺服器與玩家端使用同一版 JAR。

## 測試
先備份存檔，進遊戲檢查正面、側面、背面、轉頭、走路、揮劍與完整／打斷施法。
/wooltest emperor 可查看宮殿皇帝的紀錄。
/wooltest emperor test 會額外生成測試皇帝，並非只檢查現有的一隻；請在空地使用。
保持原有非和平難度以查看敵對行為。實際持劍位置、動畫穿模、光照與多人顯示仍待遊戲確認。

## 預覽與驗證界限
art_preview/emperor3-model-preview.png 使用實際模型及貼圖渲染中立姿勢，不含獨立持物層，不是遊戲截圖。
art_preview/emperor3-charging-pose.png 使用實際幾何與 setupAnim 的蓄力旋轉角度，未渲染劍、粒子與法陣。
離線資料與 Java 模型逐格匹配，UV 無越界或重疊；語法、純 Java 規則、裝備測試替身、原城市離線檢查均通過。
40 份 Java 檔的語法解析不等於 Forge API 編譯；裝備測試替身不等於實際遊戲存讀檔。
本環境無法解析 maven.minecraftforge.net，沒有完成本版 Forge 建置；未提供編譯 JAR，也未進 Minecraft 實測。
完整記錄：validation/emperor3-current-checks.log 及 validation/emperor3-checks.json。

## 重現
安裝本地開發用 Python Pillow／NumPy／SciPy 與 JDK17+ 後：
python tools/build_emperor3_slim.py
python tools/render_emperor3_preview.py
python tools/preview_emperor3_pose.py
bash tools/check_current.sh

art_source/emperor3/emperor_model.json 是本版模型資料，baseline 保存上一版幾何及素材供重現貼圖重排。
tools/build_emperor2_assets.py、tools/check_emperor2.py 與 CITY5_EMPEROR2_使用說明.md 為上一版資料／工具，不要用舊建圖工具覆寫新版模型。
